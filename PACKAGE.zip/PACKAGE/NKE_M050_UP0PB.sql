CREATE OR REPLACE PACKAGE BODY          NKE_M050_UP0P
IS
--------------------------------------------------------------------------------
-- System   : Factory-ONE �d�]�H��
-- Title    : �l��Ͻ���ް� �X�V�pPackage
-- Version  : R 3.0.10
--------------------------------------------------------------------------------
-- �V�K     : @@009001  ENG KAWAKAMI SHIORI
-- �ύX     : @@005144  EX HAMASHIMA TAKASHI ү���޺��ނ̈����ɶ�ϋ�؂��ǉ��B
-- �ύX     : @@005040  FJN DANH-HH �������F�@�\�ǉ�
-- �ύX     : @@005273  JCS TUAN E00018�����Ұ��w����폜�B
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
-- �V�K     : @15/07/23 IVS LE MINH �J�X�^�}�C�Y
--------------------------------------------------------------------------------
--=================================================
-- PUBLIC PROCEDURES or FUNCTIONS
--=================================================
--**********************************************************
-- PRIVATE
-- �ǉ������O����
--**********************************************************
PROCEDURE CHECK_INS(
	 P_EMP_CD    IN  DFW_M050M.EMP_CD%TYPE
	,P_MSGCD    OUT  VARCHAR2
	,P_ERRCD    OUT  NUMBER
	,P_ERRTX    OUT  VARCHAR2
)
IS
	W_ROWCOUNT NUMBER;
BEGIN
-------------------------------------------
	P_MSGCD	:= ' ';
	P_ERRCD	:= 0;
	P_ERRTX	:= ' ';
	W_ROWCOUNT := 0;
-------------------------------------------
--�����ް�������
	SELECT COUNT(*)
	INTO W_ROWCOUNT
	FROM DFW_M050M
	WHERE EMP_CD   =   P_EMP_CD
	;
	IF W_ROWCOUNT > 0 THEN
<<ERROR_010>>
		P_MSGCD := 'E00013';
		RAISE ERROR_OCCURRED;
	END IF;
--(���̑��������͂�����)
----
-------------------------------------------
EXCEPTION
	WHEN    ERROR_OCCURRED  THEN
		NULL;
	WHEN	OTHERS	THEN
		P_ERRCD	:= SQLCODE;
		P_ERRTX := SQLERRM || '(' || G_PACKAGEID || '.CHECK_INS)';
END;
--==============================================================================
--**********************************************************
-- PRIVATE
-- �ύX�����O����
--**********************************************************
PROCEDURE CHECK_UPD(
	 P_EMP_CD    IN  DFW_M050M.EMP_CD%TYPE
	,P_MSGCD    OUT  VARCHAR2
	,P_ERRCD    OUT  NUMBER
	,P_ERRTX    OUT  VARCHAR2
)
IS
	W_ROWCOUNT NUMBER;
BEGIN
-------------------------------------------
	P_MSGCD := ' ';
	P_ERRCD := 0;
	P_ERRTX := ' ';
	W_ROWCOUNT := 0;
-------------------------------------------
--�����ް�������
	SELECT COUNT(*)
	INTO W_ROWCOUNT
	FROM DFW_M050M
	WHERE EMP_CD   =   P_EMP_CD
	;
	IF W_ROWCOUNT = 0 THEN
<<ERROR_010>>
		--P_MSGCD :=  'E00018' || ',' ||                        --@@005273 JCS TUAN DEL
		--      '(' || G_PACKAGEID || '.CHECK_UPD:ERROR_010)';  --@@005273 JCS TUAN DEL
		P_MSGCD :=  'E00018';                                   --@@005273 JCS TUAN ADD
		RAISE ERROR_OCCURRED;
	END IF;
--(���̑��������͂�����)
----
-------------------------------------------
EXCEPTION
	WHEN    ERROR_OCCURRED  THEN
		NULL;
	WHEN	OTHERS	THEN
		P_ERRCD	:= SQLCODE;
		P_ERRTX	:= SQLERRM || '(' ||  G_PACKAGEID || '.CHECK_UPD)';
END;
--==============================================================================
--**********************************************************
-- PRIVATE
-- �폜�����O����		
--**********************************************************
PROCEDURE CHECK_DEL(
	 P_EMP_CD	IN	DFW_M050M.EMP_CD%TYPE
	,P_MSGCD	OUT	VARCHAR2
	,P_ERRCD	OUT	NUMBER
	,P_ERRTX	OUT	VARCHAR2
)
IS
	W_ROWCOUNT NUMBER;
BEGIN
-------------------------------------------
	P_MSGCD	:= ' ';
	P_ERRCD	:= 0;
	P_ERRTX	:= ' ';
	W_ROWCOUNT := 0;
-------------------------------------------
--�����ް�������
	SELECT COUNT(*)
	INTO W_ROWCOUNT
	FROM DFW_M050M
	WHERE EMP_CD    =   P_EMP_CD
	;
	IF W_ROWCOUNT = 0 THEN
<<ERROR_010>>
		--P_MSGCD :=  'E00018' || ',' ||                        --@@005273 JCS TUAN DEL
		--      '(' || G_PACKAGEID || '.CHECK_DEL:ERROR_010)';  --@@005273 JCS TUAN DEL
		P_MSGCD :=  'E00018';                                   --@@005273 JCS TUAN ADD
		RAISE ERROR_OCCURRED;
	END IF;
--(���̑��������͂�����)
-------------------------------------------
--۸޲ݒ�������
	SELECT	COUNT(*)
	INTO W_ROWCOUNT
	FROM DFW_SYS.DFW_C010C
	WHERE EMP_CD    	=   P_EMP_CD
	 AND  SCHEMA_NAME	=	USER
	;
	IF W_ROWCOUNT <> 0 THEN
<<ERROR_020>>
		P_MSGCD :=  'DFW_M050_000E_0002E' || ',' ||
					'(' || G_PACKAGEID || '.CHECK_DEL:ERROR_020)';
		RAISE ERROR_OCCURRED;
	END IF;
-------------------------------------------
EXCEPTION
	WHEN    ERROR_OCCURRED  THEN
		NULL;
	WHEN	OTHERS	THEN
		P_ERRCD	:= SQLCODE;
		P_ERRTX	:= SQLERRM || '(' || G_PACKAGEID || '.CHECK_DEL)';
END;
--==============================================================================
--**********************************************************
-- PRIVATE
-- �ύX����ǋL����		
--**********************************************************
PROCEDURE WRITE_HISTORY(
	 P_OLD_NEW     IN  DFW_M050M_J.OLD_NEW%TYPE
	,P_EMP_CD      IN  DFW_M050M_J.EMP_CD%TYPE
	,P_OPERATOR_CD IN  DFW_M050M_J.OPERATOR_CD%TYPE
	,P_MSGCD       OUT VARCHAR2
	,P_ERRCD       OUT NUMBER
	,P_ERRTX       OUT VARCHAR2
)
IS
	W_SEQ		DFW_M050M_J.SEQ%TYPE;
BEGIN
-------------------------------------------
	P_MSGCD	:= ' ';
	P_ERRCD	:= 0;
	P_ERRTX	:= ' ';
-------------------------------------------
-- �l��Ͻ��̧�ٗ���SEQ�̍̔�
	C000_C090C.GET_M050_HISTORY_SEQ(
		 W_SEQ
		,P_MSGCD
		,P_ERRCD
		,P_ERRTX
		);
	IF P_MSGCD <> ' ' OR P_ERRCD <> 0 THEN
		RAISE ERROR_OCCURRED;
	END IF;
-------------------------------------------
INSERT INTO	DFW_M050M_J(
	 SEQ
	,OPERATION_DIV
	,OLD_NEW
	,OPERATION_DATE
	,OPERATOR_CD
	,EMP_CD
	,DEPT_CD
	,EMP_DIV
	,POSITION_DIV
	,DUTY_DIV
	,SHORT_NAME_KANA
	,EMP_SHORT_NAME
	,EMP_NAME
	,KANA
	,PASSWORD
	,TEL_NO
	,EXTENSION_NO
	,SERVICE_DIV
	,CELL_CD
	,MAN_HOUR_UNIT_DIV
	,OPERATOR_DIV
	,LANGUAGE_KEY
	,EMAIL_ADDRESS --@@005040 FJN DANH-HH ADD
	,REGIST_DATE
	,UPDATE_DATE
	,UPDATE_EMP_CD
  	-- ��ADD IVS LE MINH @15/07/23
  	,ELECT_EQUIP_DIV
  	-- ��ADD IVS LE MINH @15/07/23
)
SELECT
	 W_SEQ
	,C000_UTILITY.GET_OPERATION_DIV
	,P_OLD_NEW
	,C000_UTILITY.GET_EXECUTE_DATE
	,P_OPERATOR_CD
	,EMP_CD
	,DEPT_CD
	,EMP_DIV
	,POSITION_DIV
	,DUTY_DIV
	,SHORT_NAME_KANA
	,EMP_SHORT_NAME
	,EMP_NAME
	,KANA
	,PASSWORD
	,TEL_NO
	,EXTENSION_NO
	,SERVICE_DIV
	,CELL_CD
	,MAN_HOUR_UNIT_DIV
	,OPERATOR_DIV
	,LANGUAGE_KEY
	,EMAIL_ADDRESS --@@005040 FJN DANH-HH ADD
	,REGIST_DATE
	,UPDATE_DATE
	,UPDATE_EMP_CD
  	-- ��ADD IVS LE MINH @15/07/23
  	,ELECT_EQUIP_DIV
  	-- ��ADD IVS LE MINH @15/07/23
FROM DFW_M050M
WHERE EMP_CD	=	P_EMP_CD
;
	IF SQL%ROWCOUNT = 0 THEN
<<ERROR_010>>
		P_MSGCD := 'F90003' || ',' ||
		           '(' || G_PACKAGEID || '.WRITE_HISTORY.ERROR_010)';
		RAISE ERROR_OCCURRED;
	END IF;
-------------------------------------------
EXCEPTION
	WHEN    ERROR_OCCURRED  THEN
		NULL;
	WHEN	OTHERS	THEN
		P_ERRCD	:= SQLCODE;
		P_ERRTX	:= SQLERRM || '(' ||  G_PACKAGEID || '.WRITE_HISTORY)';
END;
--==============================================================================
--**********************************************************
-- PUBLIC
-- �ǉ�����		
--**********************************************************
PROCEDURE   INS	(
	 P_OPERATOR          IN DFW_M050M.EMP_CD%TYPE
	,P_EMP_CD            IN  DFW_M050M.EMP_CD%TYPE
	,P_DEPT_CD           IN  DFW_M050M.DEPT_CD%TYPE
	,P_EMP_DIV           IN  DFW_M050M.EMP_DIV%TYPE
	,P_POSITION_DIV      IN  DFW_M050M.POSITION_DIV%TYPE
	,P_DUTY_DIV          IN  DFW_M050M.DUTY_DIV%TYPE
	,P_SHORT_NAME_KANA   IN  DFW_M050M.SHORT_NAME_KANA%TYPE
	,P_EMP_SHORT_NAME    IN  DFW_M050M.EMP_SHORT_NAME%TYPE
	,P_EMP_NAME          IN  DFW_M050M.EMP_NAME%TYPE
	,P_KANA              IN  DFW_M050M.KANA%TYPE
	,P_PASSWORD          IN  DFW_M050M.PASSWORD%TYPE
	,P_EXTENSION_NO      IN  DFW_M050M.EXTENSION_NO%TYPE
	,P_SERVICE_DIV       IN  DFW_M050M.SERVICE_DIV%TYPE
	,P_CELL_CD           IN  DFW_M050M.CELL_CD%TYPE
	,P_MAN_HOUR_UNIT_DIV IN  DFW_M050M.MAN_HOUR_UNIT_DIV%TYPE
	,P_OPERATOR_DIV      IN  DFW_M050M.OPERATOR_DIV%TYPE
	,P_LANGUAGE_KEY      IN  DFW_M050M.LANGUAGE_KEY%TYPE
	,P_EMAIL_ADDRESS     IN  DFW_M050M.EMAIL_ADDRESS%TYPE--@@005040 FJN DANH-HH ADD
	,P_MSGCD             OUT VARCHAR2
	,P_ERRCD             OUT NUMBER
	,P_ERRTX             OUT VARCHAR2
  	-- ��ADD IVS LE MINH @15/07/23
  	,P_ELECT_EQUIP_DIV     IN  DFW_M050M.ELECT_EQUIP_DIV%TYPE
  	-- ��ADD IVS LE MINH @15/07/23
)
IS
BEGIN
	P_MSGCD	:= ' ';
	P_ERRCD	:= 0;
	P_ERRTX	:= ' ';
-------------------------------------------
--�ް�������
-------------------------------------------
	CHECK_INS(
		 P_EMP_CD
		,P_MSGCD
		,P_ERRCD
		,P_ERRTX
		);
	IF P_MSGCD <> ' ' OR P_ERRCD <> 0 THEN
		RAISE ERROR_OCCURRED;
	END IF;
-------------------------------------------
INSERT INTO	DFW_M050M(
	 EMP_CD
	,DEPT_CD
	,EMP_DIV
	,POSITION_DIV
	,DUTY_DIV
	,SHORT_NAME_KANA
	,EMP_SHORT_NAME
	,EMP_NAME
	,KANA
	,PASSWORD
	,EXTENSION_NO
	,SERVICE_DIV
	,CELL_CD
	,MAN_HOUR_UNIT_DIV
	,OPERATOR_DIV
	,LANGUAGE_KEY
	,EMAIL_ADDRESS --@@005040 FJN DANH-HH ADD
	,REGIST_DATE
	,UPDATE_DATE
	,UPDATE_EMP_CD
  	-- ��ADD IVS LE MINH @15/07/23
  	,ELECT_EQUIP_DIV
  	-- ��ADD IVS LE MINH @15/07/23
) VALUES (
	 P_EMP_CD
	,P_DEPT_CD
	,P_EMP_DIV
	,P_POSITION_DIV
	,P_DUTY_DIV
	,P_SHORT_NAME_KANA
	,P_EMP_SHORT_NAME
	,P_EMP_NAME
	,P_KANA
	,P_PASSWORD
	,P_EXTENSION_NO
	,P_SERVICE_DIV
	,P_CELL_CD
	,P_MAN_HOUR_UNIT_DIV
	,P_OPERATOR_DIV
	,P_LANGUAGE_KEY
	,P_EMAIL_ADDRESS --@@005040 FJN DANH-HH ADD
	,C000_UTILITY.GET_EXECUTE_DATE
	,C000_UTILITY.GET_EXECUTE_DATE
	,P_OPERATOR
  	-- ��ADD IVS LE MINH @15/07/23
  	,P_ELECT_EQUIP_DIV
  	-- ��ADD IVS LE MINH @15/07/23
);
<<ERROR_010>>
	IF SQL%ROWCOUNT = 0 THEN
--		P_MSGCD := 'F90004' || '(' || G_PACKAGEID || '.INS.ERROR_010)';--@@005144  EX HAMASHIMA TAKASHI DEL
        P_MSGCD := 'F90004' || ',' || '(' || G_PACKAGEID || '.INS.ERROR_010)';--@@005144  EX HAMASHIMA TAKASHI ADD
		RAISE ERROR_OCCURRED;
	END IF;
-------------------------------------------
--�ǉ��ް��𗚗��ɒǋL
-------------------------------------------
	WRITE_HISTORY(
		 '1'
		,P_EMP_CD
		,P_OPERATOR
		,P_MSGCD
		,P_ERRCD
		,P_ERRTX
	 );
	IF (P_MSGCD <> ' ') OR (P_ERRCD <> 0) THEN
		RAISE ERROR_OCCURRED;
	END IF;
-------------------------------------------
EXCEPTION
	WHEN    ERROR_OCCURRED  THEN
		NULL;
	WHEN	OTHERS	THEN
		P_ERRCD	:= SQLCODE;
		P_ERRTX	:= SQLERRM || '(' ||  G_PACKAGEID || '.INS)';
END;
--==============================================================================
--**********************************************************
-- PUBLIC
-- �ύX����		
--**********************************************************
PROCEDURE   UPD	(
	 P_OPERATOR             IN DFW_M050M.EMP_CD%TYPE
	,P_EMP_CD               IN  DFW_M050M.EMP_CD%TYPE
	,P_DEPT_CD              IN  DFW_M050M.DEPT_CD%TYPE
	,P_EMP_DIV              IN  DFW_M050M.EMP_DIV%TYPE
	,P_POSITION_DIV         IN  DFW_M050M.POSITION_DIV%TYPE
	,P_DUTY_DIV             IN  DFW_M050M.DUTY_DIV%TYPE
	,P_SHORT_NAME_KANA      IN  DFW_M050M.SHORT_NAME_KANA%TYPE
	,P_EMP_SHORT_NAME       IN  DFW_M050M.EMP_SHORT_NAME%TYPE
	,P_EMP_NAME             IN  DFW_M050M.EMP_NAME%TYPE
	,P_KANA                 IN  DFW_M050M.KANA%TYPE
	,P_PASSWORD             IN  DFW_M050M.PASSWORD%TYPE
	,P_EXTENSION_NO         IN  DFW_M050M.EXTENSION_NO%TYPE
	,P_SERVICE_DIV          IN  DFW_M050M.SERVICE_DIV%TYPE
	,P_CELL_CD              IN  DFW_M050M.CELL_CD%TYPE
	,P_MAN_HOUR_UNIT_DIV    IN  DFW_M050M.MAN_HOUR_UNIT_DIV%TYPE
	,P_OPERATOR_DIV         IN  DFW_M050M.OPERATOR_DIV%TYPE
	,P_LANGUAGE_KEY         IN  DFW_M050M.LANGUAGE_KEY%TYPE
	,P_EMAIL_ADDRESS        IN  DFW_M050M.EMAIL_ADDRESS%TYPE --@@005040 FJN DANH-HH ADD
	,P_MSGCD                OUT VARCHAR2
	,P_ERRCD                OUT NUMBER
	,P_ERRTX                OUT VARCHAR2
  	-- ��ADD IVS LE MINH @15/07/23
  	,P_ELECT_EQUIP_DIV        IN  DFW_M050M.ELECT_EQUIP_DIV%TYPE
  	-- ��ADD IVS LE MINH @15/07/23
)
IS
	DFW_M050M_REC DFW_M050M%ROWTYPE;
BEGIN
	P_MSGCD	:= ' ';
	P_ERRCD	:= 0;
	P_ERRTX	:= ' ';
-------------------------------------------
--�ް�������
-------------------------------------------
	CHECK_UPD(
	 	 P_EMP_CD
		,P_MSGCD
		,P_ERRCD
		,P_ERRTX
		);
	IF P_MSGCD <> ' ' OR P_ERRCD <> 0 THEN
		RAISE ERROR_OCCURRED;
	END IF;
-------------------------------------------
--�Ώ��ް���ۯ�
-------------------------------------------
	SELECT * 
	INTO DFW_M050M_REC 
	FROM DFW_M050M
	WHERE EMP_CD	=	P_EMP_CD
	FOR UPDATE;
-------------------------------------------
--�X�V�O�ް��𗚗��ɒǋL
-------------------------------------------
	WRITE_HISTORY(
		 '0'
		,P_EMP_CD
		,P_OPERATOR
		,P_MSGCD
		,P_ERRCD
		,P_ERRTX
	 );
	IF P_MSGCD <> ' ' OR P_ERRCD <> 0 THEN
		RAISE ERROR_OCCURRED;
	END IF;
-------------------------------------------
UPDATE	DFW_M050M
SET
	 EMP_CD =   P_EMP_CD
	,DEPT_CD    =   P_DEPT_CD
	,EMP_DIV    =   P_EMP_DIV
	,POSITION_DIV   =   P_POSITION_DIV
	,DUTY_DIV   =   P_DUTY_DIV
	,SHORT_NAME_KANA    =   P_SHORT_NAME_KANA
	,EMP_SHORT_NAME =   P_EMP_SHORT_NAME
	,EMP_NAME   =   P_EMP_NAME
	,KANA   =   P_KANA
	,PASSWORD   =   P_PASSWORD
	,EXTENSION_NO   =   P_EXTENSION_NO
	,SERVICE_DIV    =   P_SERVICE_DIV
	,CELL_CD    =   P_CELL_CD
	,MAN_HOUR_UNIT_DIV  =   P_MAN_HOUR_UNIT_DIV
	,OPERATOR_DIV   =   P_OPERATOR_DIV
	,LANGUAGE_KEY   =   P_LANGUAGE_KEY
	,EMAIL_ADDRESS  =   P_EMAIL_ADDRESS --@@005040 FJN DANH-HH ADD
	,UPDATE_DATE    =   SYSDATE
	,UPDATE_EMP_CD  =   P_OPERATOR
  	-- ��ADD IVS LE MINH @15/07/23
  	,ELECT_EQUIP_DIV = P_ELECT_EQUIP_DIV
  	-- ��ADD IVS LE MINH @15/07/23
WHERE EMP_CD	=	P_EMP_CD
;
	IF SQL%ROWCOUNT = 0 THEN
<<ERROR_010>>
		--@@005144 EX HAMASHIMA TAKASHI DEL ��
--		P_MSGCD :=  'F90003' || ',' ||
--					'(' || G_PACKAGEID || '.WRITE_HISTORY.ERROR_010)';
		--@@005144 EX HAMASHIMA TAKASHI DEL ��
		P_MSGCD := 'F90004' || ',' || '(' || G_PACKAGEID || '.UPD.ERROR_010)';--@@005144  EX HAMASHIMA TAKASHI ADD
		RAISE ERROR_OCCURRED;
	END IF;
-------------------------------------------
--�X�V���ް��𗚗��ɒǋL
-------------------------------------------
	WRITE_HISTORY(
		 '1'
		,P_EMP_CD
		,P_OPERATOR
		,P_MSGCD
		,P_ERRCD
		,P_ERRTX
	 );
	IF P_MSGCD <> ' ' OR P_ERRCD <> 0 THEN
		RAISE ERROR_OCCURRED;
	END IF;
-------------------------------------------
EXCEPTION
	WHEN    ERROR_OCCURRED  THEN
		NULL;
	WHEN	OTHERS	THEN
		P_ERRCD	:= SQLCODE;
		P_ERRTX	:= SQLERRM || '(' ||  G_PACKAGEID || '.UPD)';
END;
--==============================================================================
--**********************************************************
-- PUBLIC
-- �폜����		
--**********************************************************
PROCEDURE   DEL	(
	 P_OPERATOR                 IN DFW_M050M.EMP_CD%TYPE
	,P_EMP_CD   IN  DFW_M050M.EMP_CD%TYPE
	,P_MSGCD    OUT VARCHAR2
	,P_ERRCD    OUT NUMBER
	,P_ERRTX    OUT VARCHAR2
)
IS
	DFW_M050M_REC DFW_M050M%ROWTYPE;
BEGIN
	P_MSGCD	:= ' ';
	P_ERRCD	:= 0;
	P_ERRTX	:= ' ';
-------------------------------------------
--�ް�������
-------------------------------------------
	CHECK_DEL(
	 	 P_EMP_CD
		,P_MSGCD
		,P_ERRCD
		,P_ERRTX
	);
	IF P_MSGCD <> ' ' OR P_ERRCD <> 0 THEN
		RAISE ERROR_OCCURRED;
	END IF;
-------------------------------------------
--�Ώ��ް���ۯ�
-------------------------------------------
	SELECT * 
	INTO DFW_M050M_REC 
	FROM DFW_M050M
	WHERE EMP_CD	=	P_EMP_CD
	FOR UPDATE;
-------------------------------------------
--�폜�O�ް��𗚗��ɒǋL
-------------------------------------------
	WRITE_HISTORY(
		 '0'
		,P_EMP_CD
		,P_OPERATOR
		,P_MSGCD
		,P_ERRCD
		,P_ERRTX
		 );
	IF P_MSGCD <> ' ' OR P_ERRCD <> 0 THEN
		RAISE ERROR_OCCURRED;
	END IF;
-------------------------------------------
DELETE
FROM DFW_M050M
WHERE EMP_CD	=	P_EMP_CD
;
-------------------------------------------
EXCEPTION
	WHEN    ERROR_OCCURRED  THEN
		NULL;
	WHEN	OTHERS	THEN
		P_ERRCD	:= SQLCODE;
		P_ERRTX	:= SQLERRM || '(' ||  G_PACKAGEID || '.DEL)';
END;
--==============================================================================
END;
/
