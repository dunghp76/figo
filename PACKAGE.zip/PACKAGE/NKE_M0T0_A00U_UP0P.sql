create or replace 
PACKAGE          NKE_M0T0_A00U_UP0P
IS
--------------------------------------------------------------------------------
-- System   : Factory-ONE �d�]�H��
-- Title    : ���ʒP��Ͻ���ꊇ�捞���� �X�V�pPackage
-- Version  : R 3.0.0
--------------------------------------------------------------------------------
-- �V�K     : @@009001 EX VIET-LH     20130701
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
-- �V�K     : @15/07/21 IVS NGUYEN PHU QUOC �J�X�^�}�C�Y
--------------------------------------------------------------------------------
--=================================================
-- PUBLIC PROCEDURES or FUNCTIONS
--=================================================
--------------------------------------------------------------------------------
--  EXCEPTION
--------------------------------------------------------------------------------
	ERROR_OCCURRED EXCEPTION;
--------------------------------------------------------------------------------
-- PACKAGE ID
--------------------------------------------------------------------------------
	G_PACKAGEID      VARCHAR2(30) := 'DFW_M0T0_A00U_UP0P';
--------------------------------------------------------------------------------
--  ERROR HANDLING
--------------------------------------------------------------------------------
	G_MSGCD        VARCHAR2(3000) := ' ';
	G_ERRCD        NUMBER(6)      := 0;
	G_ERRTX        VARCHAR2(3000) := ' ';
--------------------------------------------------------------------------------
--  GLOBAL VARIANT
--------------------------------------------------------------------------------
	G_OPERATION_DIV DFW_M0T0M_J.OPERATION_DIV%TYPE;
--=================================================
-- PROCEDURES or FUNCTIONS
--=================================================
--*********************************************************
-- �^����ð���
--*********************************************************
	TYPE CHAR_ARRAY IS TABLE OF VARCHAR2(2000)	INDEX BY BINARY_INTEGER;
	TYPE NUM_ARRAY  IS TABLE OF NUMBER			INDEX BY BINARY_INTEGER;
	CT_MAXCOL NUMBER := 88; -- ��
	G_EMP_CD          DFW_M050M.UPDATE_EMP_CD%TYPE := ' ';
	G_LANGUAGE_KEY    DFW_M050M.LANGUAGE_KEY%TYPE := ' ';
	------------------------------------
	CT_VAL    CHAR_ARRAY;   -- �l
	CT_NAME   CHAR_ARRAY;   -- ��(�װ�o�͗p)
	CT_TYPE   CHAR_ARRAY;   -- "N":���l�^,"C":���p����,"M":�S�p����,"D":���t�^,"F":Flg
	CT_LEN    NUM_ARRAY;    -- ����				(���p����,�S�p�����͐ݒ�v)
	CT_MAX    NUM_ARRAY;    -- �ő�l			(���l�^�͐ݒ�v)
	CT_HISU   NUM_ARRAY;    -- 1:�K�{
	CT_MINS   NUM_ARRAY;    -- 1:ϲŽ��err		(���l�^�͐ݒ�v)
	CT_DCML   NUM_ARRAY;    -- ��������			(���l�^�͐ݒ�v)
--*********************************************************
-- CURSOR
--*********************************************************
	CURSOR G_M0T0_TEMP_CUR IS
		SELECT	*
		FROM	V_DFW_M0T0_A00U_0
		WHERE	ERROR_DIV <> 'Z'		-- �i�ڏd���װ������
		 AND	TARGET_F  = '1'
		;
	-------------------------------------------------------
	CURSOR M010M_1_CUR IS
			SELECT M010M.*
			FROM   DFW_M010M M010M
			WHERE  KEY = '1900';
	CURSOR M010M_2_CUR IS
			SELECT M010M.*
			FROM   DFW_M010M M010M
			WHERE  M010M.KEY = '2930';
	CURSOR M010M_3_CUR IS
			SELECT M010M.*
			FROM   DFW_M010M M010M
			WHERE  M010M.KEY = '2960';
	M010M_1_REC M010M_1_CUR%ROWTYPE;
	M010M_2_REC M010M_2_CUR%ROWTYPE;
	M010M_3_REC M010M_3_CUR%ROWTYPE;
--*********************************************************
-- �捞�m�F�����i�����������j
--*********************************************************
PROCEDURE DOWN_RTN( 
	 P_PROGRAM  IN  VARCHAR2
	,P_LANGUAGE	IN  VARCHAR2
	,P_MSGCD    OUT VARCHAR2
	,P_ERRCD    OUT NUMBER
	,P_ERRTX    OUT VARCHAR2
);
--*********************************************************
--	�X�V����
--*********************************************************
PROCEDURE LOOP_EXECUTE(
	 P_OPERATOR       	IN  DFW_M050M.EMP_CD%TYPE
	,P_OPERATION_DIV	IN  VARCHAR2
	,P_COMPUTER			IN  VARCHAR2
	,P_PROGRAM			IN  VARCHAR2
	,P_BACKUP_DATA		IN  VARCHAR2      -- "1":�O��捞�ް�������
	,P_MSGCD			OUT VARCHAR2
	,P_ERRCD			OUT NUMBER
	,P_ERRTX			OUT VARCHAR2
);
--*********************************************************
--	���ʒP��ܰ�ð���(�捞E)�X�V����
--*********************************************************
PROCEDURE INS_M0T0M_EW(
	 P_COMPUTER			IN  VARCHAR2
	,P_PROGRAM			IN  VARCHAR2
	,P_BACKUP_DATA		IN  VARCHAR2  -- "1":�O��捞�ް�������
	,P_MSGCD            OUT VARCHAR2
	,P_ERRCD            OUT NUMBER
	,P_ERRTX            OUT VARCHAR2
);
END;
