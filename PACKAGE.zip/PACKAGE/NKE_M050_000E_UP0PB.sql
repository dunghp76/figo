CREATE OR REPLACE PACKAGE BODY          NKE_M050_000E_UP0P
IS
--------------------------------------------------------------------------------
-- System   : Factory-ONE �d�]�H��
-- Title    : �l��Ͻ������ݽ �X�V�pPackage Body
-- Version  : R 3.0.7
--------------------------------------------------------------------------------
-- �V�K     : @@009001  ENG KAWAKAMI SHIORI
-- �ύX     : @@005040  FJN DANH-HH �������F�@�\�ǉ�
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
-- �V�K     : @15/07/23 IVS LE MINH �J�X�^�}�C�Y
--------------------------------------------------------------------------------
--=================================================
-- PROCEDURES or FUNCTIONS
--=================================================
--**********************************************************
-- PRIVATE
-- �X�V�O�ް�����
-- (�ײ��Ă�CheckBodyRefer()���s��Ȃ���������)
--**********************************************************
PROCEDURE CHECK_DATA(
	/*�K�v��Param�͂����ɒǉ����ĉ������B*/
	 P_MSGCD	OUT	VARCHAR2
	,P_ERRCD	OUT	NUMBER
	,P_ERRTX	OUT	VARCHAR2
)
IS
	W_ROWCOUNT NUMBER;
BEGIN
-------------------------------------------
	P_MSGCD	:= ' ';
	P_ERRCD	:= 0;
	P_ERRTX	:= ' ';

	W_ROWCOUNT := 0;
-------------------------------------------
--(���̑��������͂�����)
----
-----------------------------------------------
EXCEPTION
	WHEN    ERROR_OCCURRED  THEN
		NULL;
	WHEN	OTHERS	THEN
		P_ERRCD	:= SQLCODE;
		P_ERRTX	:= SQLERRM || '(' || G_PACKAGEID || '.CHECK_DATA)';
END;
--==============================================================================
--**********************************************************
-- PUBLIC
-- �A�����s����
--**********************************************************
PROCEDURE LOOP_EXECUTE(
	 P_OPERATOR         IN  DFW_M050M.EMP_CD%TYPE
	,P_OPERATION_DIV    IN  VARCHAR2
	,P_MSGCD    OUT  VARCHAR2
	,P_ERRCD    OUT  NUMBER
	,P_ERRTX    OUT  VARCHAR2
)
IS
-------------------------------------------
CURSOR  M050_000E_UP0P_1_CUR IS
	SELECT *	
  	-- ��DEL IVS LE MINH @15/07/23 
  	-- FROM W_DFW_M050_000E_UP0P_1
  	-- ��DEL IVS LE MINH @15/07/23
  	-- ��ADD IVS LE MINH @15/07/23
  	FROM W_NKE_M050_000E_UP0P_1
  	-- ��ADD IVS LE MINH @15/07/23
	ORDER BY DATA_NO;
-------------------------------------------
BEGIN
	P_MSGCD	:= ' ';
	P_ERRCD	:= 0;
	P_ERRTX	:= ' ';
-----------------------------------
C000_UTILITY.SET_OPERATION_DIV(P_OPERATION_DIV);
-----------------------------------
	FOR M050_000E_UP0P_1_REC IN M050_000E_UP0P_1_CUR   LOOP
	-----------------------------------
	-- �X�V�����O�Ɉꎞð����ް��̴װ����
		CHECK_DATA(
			 P_MSGCD
			,P_ERRCD
			,P_ERRTX
		);
		IF (P_MSGCD <> ' ') OR (P_ERRCD <> 0) THEN
			RAISE ERROR_OCCURRED;
		END IF;
	-----------------------------------
		CASE    P_OPERATION_DIV
			WHEN '1' THEN
			-- �V�K�̏ꍇ
				NKE_M050_UP0P.INS(
					 P_OPERATOR
					,M050_000E_UP0P_1_REC.EMP_CD
					,M050_000E_UP0P_1_REC.DEPT_CD
					,M050_000E_UP0P_1_REC.EMP_DIV
					,M050_000E_UP0P_1_REC.POSITION_DIV
					,M050_000E_UP0P_1_REC.DUTY_DIV
					,M050_000E_UP0P_1_REC.SHORT_NAME_KANA
					,M050_000E_UP0P_1_REC.EMP_SHORT_NAME
					,M050_000E_UP0P_1_REC.EMP_NAME
					,M050_000E_UP0P_1_REC.KANA
					,M050_000E_UP0P_1_REC.PASSWORD
					,M050_000E_UP0P_1_REC.EXTENSION_NO
					,M050_000E_UP0P_1_REC.SERVICE_DIV
					,M050_000E_UP0P_1_REC.CELL_CD
					,M050_000E_UP0P_1_REC.MAN_HOUR_UNIT_DIV
					,M050_000E_UP0P_1_REC.OPERATOR_DIV
					,M050_000E_UP0P_1_REC.LANGUAGE_KEY
					,M050_000E_UP0P_1_REC.EMAIL_ADDRESS --@@005040 FJN DANH-HH ADD
					,P_MSGCD
					,P_ERRCD
					,P_ERRTX
          			-- ��ADD IVS LE MINH @15/07/23
          			,M050_000E_UP0P_1_REC.ELECT_EQUIP_DIV
          			-- ��ADD IVS LE MINH @15/07/23
				);
			WHEN '2' THEN
			-- �ύX�̏ꍇ
				NKE_M050_UP0P.UPD(
					 P_OPERATOR
					,M050_000E_UP0P_1_REC.EMP_CD
					,M050_000E_UP0P_1_REC.DEPT_CD
					,M050_000E_UP0P_1_REC.EMP_DIV
					,M050_000E_UP0P_1_REC.POSITION_DIV
					,M050_000E_UP0P_1_REC.DUTY_DIV
					,M050_000E_UP0P_1_REC.SHORT_NAME_KANA
					,M050_000E_UP0P_1_REC.EMP_SHORT_NAME
					,M050_000E_UP0P_1_REC.EMP_NAME
					,M050_000E_UP0P_1_REC.KANA
					,M050_000E_UP0P_1_REC.PASSWORD
					,M050_000E_UP0P_1_REC.EXTENSION_NO
					,M050_000E_UP0P_1_REC.SERVICE_DIV
					,M050_000E_UP0P_1_REC.CELL_CD
					,M050_000E_UP0P_1_REC.MAN_HOUR_UNIT_DIV
					,M050_000E_UP0P_1_REC.OPERATOR_DIV
					,M050_000E_UP0P_1_REC.LANGUAGE_KEY
					,M050_000E_UP0P_1_REC.EMAIL_ADDRESS --@@005040 FJN DANH-HH ADD
					,P_MSGCD
					,P_ERRCD
					,P_ERRTX
          			-- ��ADD IVS LE MINH @15/07/23
          			,M050_000E_UP0P_1_REC.ELECT_EQUIP_DIV
          			-- ��ADD IVS LE MINH @15/07/23
				);
			WHEN '3' THEN
			-- �폜�̏ꍇ
				NKE_M050_UP0P.DEL(
					 P_OPERATOR
					,M050_000E_UP0P_1_REC.EMP_CD
					,P_MSGCD
					,P_ERRCD
					,P_ERRTX
				);
		END CASE;
		-------------------------------
		IF	(P_MSGCD <> ' ') OR (P_ERRCD <> 0) THEN
			RAISE	ERROR_OCCURRED;
		END IF;
END LOOP;
-----------------------------------
EXCEPTION
	WHEN    ERROR_OCCURRED  THEN
		IF	M050_000E_UP0P_1_CUR%ISOPEN	THEN	CLOSE	M050_000E_UP0P_1_CUR;	END	IF;
	WHEN    OTHERS          THEN
		IF	M050_000E_UP0P_1_CUR%ISOPEN	THEN	CLOSE	M050_000E_UP0P_1_CUR;	END	IF;
		P_ERRCD     :=  SQLCODE;
		P_ERRTX     :=  SQLERRM || '(' || G_PACKAGEID || '.LOOP_EXECUTE)';
END;
--==============================================================================
END;
/
