CREATE OR REPLACE PACKAGE         NKE_M050_UP0P
IS
--------------------------------------------------------------------------------
-- System   : Factory-ONE �d�]�H��
-- Title    : �l��Ͻ���ް� �X�V�pPackage
-- Version  : R 3.0.7
--------------------------------------------------------------------------------
-- �V�K     : @@009001  ENG KAWAKAMI SHIORI
-- �ύX     : @@005040  FJN DANH-HH �������F�@�\�ǉ�
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
-- �V�K     : @15/07/23 IVS LE MINH �J�X�^�}�C�Y
--------------------------------------------------------------------------------
-- ��DEL IVS LE MINH @15/07/23
--G_PACKAGEID VARCHAR2(30) := 'DFW_M050_UP0P';
-- ��DEL IVS LE MINH @15/07/23
-- ��ADD IVS LE MINH @15/07/23
G_PACKAGEID VARCHAR2(30) := 'NKE_M050_UP0P';
-- ��ADD IVS LE MINH @15/07/23
ERROR_OCCURRED	EXCEPTION;
--==========================================================
--PUBLIC PROCEDURES or FUNCTIONS
--==========================================================
--**********************************************************
-- �ǉ�����		
--**********************************************************
PROCEDURE   INS	(
	 P_OPERATOR             IN  DFW_M050M.EMP_CD%TYPE
	,P_EMP_CD               IN  DFW_M050M.EMP_CD%TYPE
	,P_DEPT_CD              IN  DFW_M050M.DEPT_CD%TYPE
	,P_EMP_DIV              IN  DFW_M050M.EMP_DIV%TYPE
	,P_POSITION_DIV         IN  DFW_M050M.POSITION_DIV%TYPE
	,P_DUTY_DIV             IN  DFW_M050M.DUTY_DIV%TYPE
	,P_SHORT_NAME_KANA      IN  DFW_M050M.SHORT_NAME_KANA%TYPE
	,P_EMP_SHORT_NAME       IN  DFW_M050M.EMP_SHORT_NAME%TYPE
	,P_EMP_NAME             IN  DFW_M050M.EMP_NAME%TYPE
	,P_KANA                 IN  DFW_M050M.KANA%TYPE
	,P_PASSWORD             IN  DFW_M050M.PASSWORD%TYPE
	,P_EXTENSION_NO         IN  DFW_M050M.EXTENSION_NO%TYPE
	,P_SERVICE_DIV          IN  DFW_M050M.SERVICE_DIV%TYPE
	,P_CELL_CD              IN  DFW_M050M.CELL_CD%TYPE
	,P_MAN_HOUR_UNIT_DIV    IN  DFW_M050M.MAN_HOUR_UNIT_DIV%TYPE
	,P_OPERATOR_DIV         IN  DFW_M050M.OPERATOR_DIV%TYPE
	,P_LANGUAGE_KEY         IN  DFW_M050M.LANGUAGE_KEY%TYPE
	,P_EMAIL_ADDRESS        IN  DFW_M050M.EMAIL_ADDRESS%TYPE --@@005040 FJN DANH-HH ADD
	,P_MSGCD                OUT     VARCHAR2
	,P_ERRCD                OUT     NUMBER
	,P_ERRTX                OUT     VARCHAR2
  	-- ��ADD IVS LE MINH @15/07/23
  	,P_ELECT_EQUIP_DIV        IN  DFW_M050M.ELECT_EQUIP_DIV%TYPE
  	-- ��ADD IVS LE MINH @15/07/23
);

--**********************************************************
-- �ύX����		
--**********************************************************
PROCEDURE   UPD	(
	 P_OPERATOR               IN DFW_M050M.EMP_CD%TYPE
	,P_EMP_CD                 IN  DFW_M050M.EMP_CD%TYPE
	,P_DEPT_CD                IN  DFW_M050M.DEPT_CD%TYPE
	,P_EMP_DIV                IN  DFW_M050M.EMP_DIV%TYPE
	,P_POSITION_DIV           IN  DFW_M050M.POSITION_DIV%TYPE
	,P_DUTY_DIV               IN  DFW_M050M.DUTY_DIV%TYPE
	,P_SHORT_NAME_KANA        IN  DFW_M050M.SHORT_NAME_KANA%TYPE
	,P_EMP_SHORT_NAME         IN  DFW_M050M.EMP_SHORT_NAME%TYPE
	,P_EMP_NAME               IN  DFW_M050M.EMP_NAME%TYPE
	,P_KANA                   IN  DFW_M050M.KANA%TYPE
	,P_PASSWORD               IN  DFW_M050M.PASSWORD%TYPE
	,P_EXTENSION_NO           IN  DFW_M050M.EXTENSION_NO%TYPE
	,P_SERVICE_DIV            IN  DFW_M050M.SERVICE_DIV%TYPE
	,P_CELL_CD                IN  DFW_M050M.CELL_CD%TYPE
	,P_MAN_HOUR_UNIT_DIV      IN  DFW_M050M.MAN_HOUR_UNIT_DIV%TYPE
	,P_OPERATOR_DIV           IN  DFW_M050M.OPERATOR_DIV%TYPE
	,P_LANGUAGE_KEY           IN  DFW_M050M.LANGUAGE_KEY%TYPE
	,P_EMAIL_ADDRESS          IN  DFW_M050M.EMAIL_ADDRESS%TYPE --@@005040 FJN DANH-HH ADD
	,P_MSGCD                  OUT     VARCHAR2
	,P_ERRCD                  OUT     NUMBER
	,P_ERRTX                  OUT     VARCHAR2
  	-- ��ADD IVS LE MINH @15/07/23
  	,P_ELECT_EQUIP_DIV        IN  DFW_M050M.ELECT_EQUIP_DIV%TYPE
  	-- ��ADD IVS LE MINH @15/07/23
);

--**********************************************************
-- �폜����		
--**********************************************************
PROCEDURE   DEL	(
	 P_OPERATOR     IN  DFW_M050M.EMP_CD%TYPE
	,P_EMP_CD       IN  DFW_M050M.EMP_CD%TYPE
	,P_MSGCD        OUT     VARCHAR2
	,P_ERRCD        OUT     NUMBER
	,P_ERRTX        OUT     VARCHAR2
);
------------------------------------------------------------
END;
/
