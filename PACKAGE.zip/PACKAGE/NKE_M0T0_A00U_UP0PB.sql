create or replace 
PACKAGE BODY          NKE_M0T0_A00U_UP0P
IS
--------------------------------------------------------------------------------
-- System   : Factory-ONE �d�]�H��
-- Title    : ���ʒP��Ͻ���ꊇ�捞���� �X�V�pPackage Body
-- Version  : R 3.0.0
--------------------------------------------------------------------------------
-- �V�K     : @@009001 EX VIET-LH     20130701
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
-- �V�K     : @15/07/21 IVS NGUYEN PHU QUOC �J�X�^�}�C�Y
--------------------------------------------------------------------------------
--=================================================
-- PUBLIC PROCEDURES or FUNCTIONS
--=================================================
--*********************************************************
-- ���l�^����
--*********************************************************
FUNCTION CHECK_NUMBER(P_VAL IN VARCHAR2)
RETURN BOOLEAN
IS
	W_NUM NUMBER := 0;
BEGIN
	W_NUM := TO_NUMBER(P_VAL);
	RETURN TRUE;
EXCEPTION
	WHEN OTHERS THEN
		RETURN FALSE;
END;
--*********************************************************
-- ���t�^����
--*********************************************************
FUNCTION CHECK_DATE(P_VAL IN VARCHAR2)
RETURN BOOLEAN
IS
	W_DATE DATE;
BEGIN
	W_DATE := TO_DATE(P_VAL, 'YYYY/MM/DD');
	RETURN TRUE;
EXCEPTION
	WHEN OTHERS THEN
		RETURN FALSE;
END;
--*********************************************************
-- ����ð��� �쐬
--*********************************************************
PROCEDURE CRT_CHKTB(
	 P_PROGRAM	IN	VARCHAR2
	,P_MSGCD 	OUT VARCHAR2
	,P_ERRCD 	OUT NUMBER
	,P_ERRTX 	OUT VARCHAR2
	)
IS
	I NUMBER := 0;
BEGIN
	P_MSGCD     :=  ' ';
	P_ERRCD     :=  0;
	P_ERRTX     :=  ' ';
	----------------------------------------------------------------------------
	-- ���޺���
	----------------------------------------------------------------------------
	FOR I IN 1..CT_MAXCOL  LOOP
		CT_VAL(I)  := ' ';
		CT_NAME(I) := ' ';
		CT_TYPE(I) := ' ';
		CT_LEN(I)  := 0;
		CT_MAX(I)  := 0;
		CT_HISU(I) := 0;
		CT_MINS(I) := 0;
		CT_DCML(I) := 0;
	END LOOP; 
	I := 0;
	------------------------------------------------------------------------------------------------------------------------------------------
	I := I + 1;CT_NAME(I) := P_PROGRAM || ':ITEM_DIV';                 	CT_TYPE(I) := 'C';	CT_LEN(I) := 8;                             CT_HISU(I) := 1;
	I := I + 1;CT_NAME(I) := P_PROGRAM || ':ITEM_CD';                  	CT_TYPE(I) := 'C';	CT_LEN(I) := 40;                            CT_HISU(I) := 1;
	I := I + 1;CT_NAME(I) := P_PROGRAM || ':UNIT';                     	CT_TYPE(I) := 'M';	CT_LEN(I) := 4;                             CT_HISU(I) := 1;
	I := I + 1;CT_NAME(I) := P_PROGRAM || ':PROC_CD';                  	CT_TYPE(I) := 'C';	CT_LEN(I) := 15;
	I := I + 1;CT_NAME(I) := P_PROGRAM || ':DATA_DIV';       			CT_TYPE(I) := 'C';	CT_LEN(I) := 1;
	I := I + 1;CT_NAME(I) := P_PROGRAM || ':RANK';                     	CT_TYPE(I) := 'N';  CT_MAX(I) := 99999;        CT_DCML(I) := 0;CT_MINS(I) := 1;
	I := I + 1;CT_NAME(I) := P_PROGRAM || ':INVALID_F';                	CT_TYPE(I) := 'F';
	I := I + 1;CT_NAME(I) := P_PROGRAM || ':UNITPRICE_EFFECTIVE_DATE'; 	CT_TYPE(I) := 'D';                                            	CT_HISU(I) := 1;
	I := I + 1;CT_NAME(I) := P_PROGRAM || ':COMPANY_CD';               	CT_TYPE(I) := 'C';	CT_LEN(I) := 15;
	I := I + 1;CT_NAME(I) := P_PROGRAM || ':BASIS_QTY';                	CT_TYPE(I) := 'N';  CT_MAX(I) := 999999999.99; CT_DCML(I) := 2;CT_MINS(I) := 1;
	I := I + 1;CT_NAME(I) := P_PROGRAM || ':UNITPRICE';                	CT_TYPE(I) := 'N';  CT_MAX(I) := 999999999.99; CT_DCML(I) := 2;CT_MINS(I) := 1;
	I := I + 1;CT_NAME(I) := P_PROGRAM || ':LOT_QTY';                  	CT_TYPE(I) := 'N';  CT_MAX(I) := 999999999.99; CT_DCML(I) := 2;CT_MINS(I) := 1;
	I := I + 1;CT_NAME(I) := P_PROGRAM || ':MIN_QTY';                  	CT_TYPE(I) := 'N';  CT_MAX(I) := 999999999.99; CT_DCML(I) := 2;CT_MINS(I) := 1;
	I := I + 1;CT_NAME(I) := P_PROGRAM || ':LT';                		CT_TYPE(I) := 'N';  CT_MAX(I) := 999.9;        CT_DCML(I) := 1;CT_MINS(I) := 1;
	I := I + 1;CT_NAME(I) := P_PROGRAM || ':REFER_UNITPRICE';          	CT_TYPE(I) := 'N';  CT_MAX(I) := 999999999.99; CT_DCML(I) := 2;CT_MINS(I) := 1;
	I := I + 1;CT_NAME(I) := P_PROGRAM || ':REMARKS';                  	CT_TYPE(I) := 'M';	CT_LEN(I) := 60;
	I := I + 1;CT_NAME(I) := P_PROGRAM || ':UNITPRICE_UPDATE_DATE';    	CT_TYPE(I) := ' ';
	I := I + 1;CT_NAME(I) := P_PROGRAM || ':NEWEST_UNITPRICE';         	CT_TYPE(I) := ' ';
	------------------------------------------------------------------------------------------------------------------------------------------
EXCEPTION
	----------------------------------------------------------------------------
	-- ��O����
	----------------------------------------------------------------------------
	WHEN OTHERS THEN
		P_ERRCD := SQLCODE;
		P_ERRTX := SQLERRM || G_PACKAGEID || '.CRT_CHKTB ';
END;
--*********************************************************
-- ����ð��ق֗�̓��e��]��
--*********************************************************
PROCEDURE SEF_CHKTB(
	 P_REC		IN	G_M0T0_TEMP_CUR%ROWTYPE
	,P_MSGCD	OUT VARCHAR2
	,P_ERRCD	OUT NUMBER
	,P_ERRTX	OUT VARCHAR2
	)
IS
	I NUMBER := 0;
BEGIN
	P_MSGCD     :=  ' ';
	P_ERRCD     :=  0;
	P_ERRTX     :=  ' ';
	----------------------------------------------------------------------------
	I := 0;
	-------------------------------------------------------
	I := I + 1;CT_VAL(I) := P_REC.ITEM_DIV;
	I := I + 1;CT_VAL(I) := P_REC.ITEM_CD;
	I := I + 1;CT_VAL(I) := P_REC.UNIT;
	I := I + 1;CT_VAL(I) := P_REC.PROC_CD;
	I := I + 1;CT_VAL(I) := P_REC.DATA_DIV;
	I := I + 1;CT_VAL(I) := P_REC.PRIORITY_RANK;
	I := I + 1;CT_VAL(I) := P_REC.INVALID_F;
	I := I + 1;CT_VAL(I) := P_REC.UNITPRICE_EFFECTIVE_DATE;
	I := I + 1;CT_VAL(I) := P_REC.COMPANY_CD;
	I := I + 1;CT_VAL(I) := P_REC.BASIS_QTY;
	I := I + 1;CT_VAL(I) := P_REC.UNITPRICE;
	I := I + 1;CT_VAL(I) := P_REC.PO_LOT_QTY;
	I := I + 1;CT_VAL(I) := P_REC.MIN_QTY;
	I := I + 1;CT_VAL(I) := P_REC.PO_LT;
	I := I + 1;CT_VAL(I) := P_REC.REFER_UNITPRICE;
	I := I + 1;CT_VAL(I) := P_REC.REMARKS;
EXCEPTION
	----------------------------------------------------------------------------
	-- ��O����
	----------------------------------------------------------------------------
	WHEN OTHERS THEN
		P_ERRCD := SQLCODE;
		P_ERRTX := SQLERRM || G_PACKAGEID || '.SEF_CHKTB ';
END;
--*********************************************************
-- �װ�����i��{�j
--*********************************************************
PROCEDURE CHK_BASIC(
	 P_VAL       IN     VARCHAR2
	,P_NAME      IN     VARCHAR2
	,P_TYPE      IN     VARCHAR2
	,P_LEN       IN     NUMBER
	,P_MAX       IN     NUMBER
	,P_HISU      IN     NUMBER
	,P_MINS      IN     NUMBER
	,P_DCML      IN     NUMBER
	,P_INP_ERRKB IN OUT DFW_M040M_EW.ERROR_DIV%TYPE
	,P_INP_ERRMS IN OUT DFW_M040M_EW.ERROR_CONTENTS%TYPE
	,P_LANGUAGE	 IN		VARCHAR2
	,P_MSGCD     OUT    VARCHAR2
	,P_ERRCD     OUT    NUMBER
	,P_ERRTX     OUT    VARCHAR2
	)
IS
BEGIN
	P_MSGCD     :=  ' ';
	P_ERRCD     :=  0;
	P_ERRTX     :=  ' ';
	-------------------------------------------------------
	OPEN  M010M_1_CUR;
	FETCH M010M_1_CUR INTO M010M_1_REC;
	CLOSE M010M_1_CUR;
	----------------------------------------------------------------------------
	-- �֑���������
	----------------------------------------------------------------------------
	IF RTRIM(P_VAL) IS NOT NULL THEN
		IF P_TYPE IN ('C','D') THEN
			IF LENGTH(RTRIM(P_VAL)) <> LENGTHB(RTRIM(P_VAL)) THEN
				P_INP_ERRKB := '1';
				P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0046M,'||P_NAME);
				GOTO CHK_RTN_END;
			END IF;
		END IF;
	END IF;
	----------------------------------------------------------------------------
	-- �����A����
	----------------------------------------------------------------------------
	IF P_TYPE = 'F' THEN
		--------------------------------	�׸�
		IF (P_VAL <> '0') AND (P_VAL <> '1') THEN
			P_INP_ERRKB := '1';
			P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0054M,'||P_NAME);
			GOTO CHK_RTN_END;
		END IF;
	END IF;
	IF RTRIM(P_VAL) IS NOT NULL THEN
		IF P_TYPE = 'C' THEN
			----------------------------	���p
			IF LENGTH(RTRIM(P_VAL)) > P_LEN Then
				P_INP_ERRKB := '1';
				P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0047M,'||P_NAME||','||P_LEN||','||LENGTH(RTRIM(P_VAL)));
				GOTO CHK_RTN_END;
			END IF;
		END IF;
		IF P_TYPE = 'M' THEN
			----------------------------	�S�p
			IF LENGTH(RTRIM(P_VAL)) > P_LEN Then
				P_INP_ERRKB := '1';
				P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0047M,'||P_NAME||','||P_LEN||','||LENGTH(RTRIM(P_VAL)));
				GOTO CHK_RTN_END;
			END IF;
		END IF;
		IF P_TYPE = 'N' THEN
			----------------------------	���l
			IF CHECK_NUMBER(P_VAL) = FALSE THEN
				P_INP_ERRKB := '1';
				P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0048M,'||P_NAME);
				GOTO CHK_RTN_END;
			END IF;
			------------------
			IF ABS(TO_NUMBER(P_VAL)) > P_MAX THEN
				P_INP_ERRKB := '1';
				P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0049M,'||P_NAME||','||P_MAX||','||LENGTHB(RTRIM(P_VAL)));
				GOTO CHK_RTN_END;
			END IF;
			------------------
			IF INSTR(P_VAL, '.') <> 0 Then
				IF LENGTH(RTRIM(SUBSTR(P_VAL, INSTR(P_VAL, '.') + 1))) > P_DCML Then
					P_INP_ERRKB := '1';
					P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0058M,'||P_NAME||','||P_DCML||','
									||LENGTH(RTRIM(SUBSTR(P_VAL, INSTR(P_VAL, '.') + 1))));
					GOTO CHK_RTN_END;
				END IF;
			END IF;
		END IF;
		IF P_TYPE = 'D' THEN
			----------------------------	���t
			IF CHECK_DATE(P_VAL) = FALSE THEN
				P_INP_ERRKB := '1';
				P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0050M,'||P_NAME);
				GOTO CHK_RTN_END;
			END IF;
			------------------
			IF LENGTH(RTRIM(P_VAL)) <> 10 Then
				P_INP_ERRKB := '1';
				P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0051M,'||P_NAME);
				GOTO CHK_RTN_END;
			END IF;
			------------------
			IF (SUBSTR(P_VAL,5,1) <> '/') OR (SUBSTR(P_VAL,8,1) <> '/')	Then
				P_INP_ERRKB := '1';
				P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0054M,'||P_NAME);
				GOTO CHK_RTN_END;
			END IF;
			------------------
			IF (SUBSTR(P_VAL,1,4) < '1900') OR (SUBSTR(P_VAL,1,4) > '2100')	Then
				P_INP_ERRKB := '1';
				P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0051M,'||P_NAME);
				GOTO CHK_RTN_END;
			END IF;
		END IF;
	END IF;
	----------------------------------------------------------------------------
	-- �K�{����
	----------------------------------------------------------------------------
	IF P_HISU = 1 THEN
		IF P_VAL = ' ' THEN
			P_INP_ERRKB := '1';
			P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0055M,'||P_NAME);
			GOTO CHK_RTN_END;
		END IF;
		IF P_TYPE = 'N' THEN
			IF P_VAL =  0 THEN
				P_INP_ERRKB := '1';
				P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0055M,'||P_NAME);
				GOTO CHK_RTN_END;
			END IF;
		END IF;
	END IF;
	----------------------------------------------------------------------------
	-- ϲŽ����
	----------------------------------------------------------------------------
	IF P_MINS = 1 THEN
		IF (P_TYPE = 'N') AND (P_VAL <> ' ') THEN
			IF P_VAL < 0 THEN
				P_INP_ERRKB := '1';
				P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0057M,'||P_NAME);
				GOTO CHK_RTN_END;
			END IF;
		END IF;
	END IF;
<<CHK_RTN_END>>
	NULL;
EXCEPTION
	----------------------------------------------------------------------------
	-- ��O����
	----------------------------------------------------------------------------
	WHEN OTHERS THEN
		P_ERRCD := SQLCODE;
		P_ERRTX := SQLERRM || G_PACKAGEID || '.CHK_BASIC('|| P_NAME ||')';
END;
--*********************************************************
-- �װ����(�ڍ�)
--*********************************************************
PROCEDURE CHK_DETL(
	 P_REC		 IN		G_M0T0_TEMP_CUR%ROWTYPE
	,P_INP_ERRKB IN OUT DFW_M0T0M_EW.ERROR_DIV%TYPE
	,P_INP_ERRMS IN OUT DFW_M0T0M_EW.ERROR_CONTENTS%TYPE
	,P_LANGUAGE	 IN		VARCHAR2
	,P_MSGCD     OUT    VARCHAR2
	,P_ERRCD     OUT    NUMBER
	,P_ERRTX     OUT    VARCHAR2
) IS
	W_ITEM_DIV                 DFW_M0T0M.ITEM_DIV%TYPE := P_REC.ITEM_DIV;
	W_ITEM_CD                  DFW_M0T0M.ITEM_CD%TYPE := P_REC.ITEM_CD;
	W_DATA_DIV                 DFW_M0T0M.DATA_DIV%TYPE := P_REC.DATA_DIV;
	W_UNIT                     DFW_M0T0M.UNIT%TYPE := P_REC.UNIT;
	W_PROC_CD                  DFW_M0T0M.PROC_CD%TYPE := P_REC.PROC_CD;
	W_UNITPRICE_EFFECTIVE_DATE DFW_M0T0M.UNITPRICE_EFFECTIVE_DATE%TYPE := P_REC.UNITPRICE_EFFECTIVE_DATE;
	W_COMPANY_CD               DFW_M0T0M.COMPANY_CD%TYPE := P_REC.COMPANY_CD;
	W_BASIS_QTY                DFW_M0T0M.BASIS_QTY%TYPE := P_REC.BASIS_QTY;
	-------------------------------------------------------
	CURSOR MT0M_DUP_CUR IS
			SELECT COUNT(*) COUNT_NUMBER
			FROM   DFW_M0T0M MT0M
			WHERE (MT0M.ITEM_DIV   = W_ITEM_DIV)
				AND (MT0M.ITEM_CD  = W_ITEM_CD)
				AND (MT0M.DATA_DIV = W_DATA_DIV)
				AND (MT0M.UNIT     = W_UNIT)
				AND (MT0M.PROC_CD  = W_PROC_CD)
				AND (MT0M.UNITPRICE_EFFECTIVE_DATE = W_UNITPRICE_EFFECTIVE_DATE)
				AND (MT0M.COMPANY_CD  = W_COMPANY_CD)
				AND (MT0M.BASIS_QTY  = W_BASIS_QTY);
	MT0M_DUP_REC MT0M_DUP_CUR%ROWTYPE;
	-------------------------------------------------------
	CURSOR M0P0M_LAST_PROC_CUR IS
			SELECT LOWER_ITEM_CD PROC_CD
			FROM   DFW_M0P0M M0P0M
			WHERE (M0P0M.UPPER_ITEM_DIV = W_ITEM_DIV)
				AND (M0P0M.UPPER_ITEM_CD = W_ITEM_CD)
				AND (M0P0M.UNFOLDING_NO  = 1);
	M0P0M_LAST_PROC_REC M0P0M_LAST_PROC_CUR%ROWTYPE;
	-------------------------------------------------------
	CURSOR M0P0M_BUY_CUR IS
			SELECT COUNT(*) COUNT_NUMBER
			FROM   DFW_M0P0M M0P0M
			WHERE (M0P0M.UPPER_ITEM_DIV  = W_ITEM_DIV)
				AND (M0P0M.UPPER_ITEM_CD  = W_ITEM_CD)
				AND (M0P0M.LOWER_ITEM_DIV = 'K')
				AND (M0P0M.LOWER_ITEM_CD <> M010M_2_REC.DATA_VALUE);
	M0P0M_BUY_REC M0P0M_BUY_CUR %ROWTYPE;
	-------------------------------------------------------
	CURSOR M0P0M_PROC_CUR IS
			SELECT COUNT(*) COUNT_NUMBER
			FROM   DFW_M0P0M M0P0M
			WHERE (M0P0M.UPPER_ITEM_DIV = W_ITEM_DIV)
				AND (M0P0M.UPPER_ITEM_CD  = W_ITEM_CD)
				AND (M0P0M.LOWER_ITEM_DIV = 'K')
				AND (M0P0M.LOWER_ITEM_CD  = W_PROC_CD);
	M0P0M_PROC_REC M0P0M_PROC_CUR%ROWTYPE;
	-------------------------------------------------------
	CURSOR M20M_CUR IS
		SELECT  M20M_1.NAME1 ITEM_DIV
				,M20M_2.NAME1 ITEM_CD
				,M20M_3.NAME1 UNIT
				,M20M_4.NAME1 PROC_CD
				,M20M_5.NAME1 UNITPRICE_CATEGORY
				,M20M_6.NAME1 RANK
				,M20M_7.NAME1 INVALID_F
				,M20M_8.NAME1 UNITPRICE_EFFECTIVE_DATE
				,M20M_9.NAME1 COMPANY_CD
				,M20M_10.NAME1 BASIS_QTY
				,M20M_11.NAME1 UNITPRICE
				,M20M_12.NAME1 LOT_QTY
				,M20M_13.NAME1 MIN_QTY
				,M20M_14.NAME1 LEAD_TIME
				,M20M_15.NAME1 REFER_UNITPRICE
				,M20M_16.NAME1 REMARKS
				,M20M_17.NAME1 UNITPRICE_UPDATE_DATE
				,M20M_18.NAME1 NEWEST_UNITPRICE
		FROM DFW_M020M M20M_1
				,DFW_M020M M20M_2
				,DFW_M020M M20M_3
				,DFW_M020M M20M_4
				,DFW_M020M M20M_5
				,DFW_M020M M20M_6
				,DFW_M020M M20M_7
				,DFW_M020M M20M_8
				,DFW_M020M M20M_9
				,DFW_M020M M20M_10
				,DFW_M020M M20M_11
				,DFW_M020M M20M_12
				,DFW_M020M M20M_13
				,DFW_M020M M20M_14
				,DFW_M020M M20M_15
				,DFW_M020M M20M_16
				,DFW_M020M M20M_17
				,DFW_M020M M20M_18
		WHERE (M20M_1.NAME_DIV1 = 'A0101' AND M20M_1.NAME_DIV2 = '0')
			AND (M20M_2.NAME_DIV1 = 'A0101' AND M20M_2.NAME_DIV2 = '1')
			AND (M20M_3.NAME_DIV1 = 'A0101' AND M20M_3.NAME_DIV2 = '2')
			AND (M20M_4.NAME_DIV1 = 'A0101' AND M20M_4.NAME_DIV2 = '3')
			AND (M20M_5.NAME_DIV1 = 'A0101' AND M20M_5.NAME_DIV2 = '4')
			AND (M20M_6.NAME_DIV1 = 'A0101' AND M20M_6.NAME_DIV2 = '5')
			AND (M20M_7.NAME_DIV1 = 'A0101' AND M20M_7.NAME_DIV2 = '6')
			AND (M20M_8.NAME_DIV1 = 'A0101' AND M20M_8.NAME_DIV2 = '7')
			AND (M20M_9.NAME_DIV1 = 'A0101' AND M20M_9.NAME_DIV2 = '8')
			AND (M20M_10.NAME_DIV1 = 'A0101' AND M20M_10.NAME_DIV2 = '9')
			AND (M20M_11.NAME_DIV1 = 'A0101' AND M20M_11.NAME_DIV2 = '10')
			AND (M20M_12.NAME_DIV1 = 'A0101' AND M20M_12.NAME_DIV2 = '11')
			AND (M20M_13.NAME_DIV1 = 'A0101' AND M20M_13.NAME_DIV2 = '12')
			AND (M20M_14.NAME_DIV1 = 'A0101' AND M20M_14.NAME_DIV2 = '13')
			AND (M20M_15.NAME_DIV1 = 'A0101' AND M20M_15.NAME_DIV2 = '14')
			AND (M20M_16.NAME_DIV1 = 'A0101' AND M20M_16.NAME_DIV2 = '15')
			AND (M20M_17.NAME_DIV1 = 'A0101' AND M20M_17.NAME_DIV2 = '16')
			AND (M20M_18.NAME_DIV1 = 'A0101' AND M20M_18.NAME_DIV2 = '17');
	M20M_REC M20M_CUR%ROWTYPE;
BEGIN
	P_MSGCD     :=  ' ';
	P_ERRCD     :=  0;
	P_ERRTX     :=  ' ';
	-------------------------------------------------------
	OPEN  M010M_1_CUR;
	FETCH M010M_1_CUR INTO M010M_1_REC;
	CLOSE M010M_1_CUR;
	-------------------------------------------------------
	OPEN  M010M_2_CUR;
	FETCH M010M_2_CUR INTO M010M_2_REC;
	CLOSE M010M_2_CUR;
	-------------------------------------------------------
	OPEN  M010M_3_CUR;
	FETCH M010M_3_CUR INTO M010M_3_REC;
	CLOSE M010M_3_CUR;
	-------------------------------------------------------
	OPEN  M20M_CUR;
	FETCH M20M_CUR INTO M20M_REC;
	CLOSE M20M_CUR;
	-------------------------------------------------------
	--���ٓǂݍ��ݗpܰ��֓]��
	-------------------------------------------------------
	IF RTRIM(P_REC.OPERATION_DIV) <> 'D' THEN
		-------------------------------------------------------
		--�i�ڂj
		-------------------------------------------------------
		IF RTRIM(P_REC.ITEM_DIV_NAME) IS NULL THEN
			P_INP_ERRKB := '1';
			P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0018M');
			GOTO CHK_DETL_END;
		END IF;
		-------------------------------------------------------
		IF RTRIM(P_REC.ITEM_DIV) = 'K' THEN
			P_INP_ERRKB := '1';
			P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0019M');
			GOTO CHK_DETL_END;
		END IF;
		-------------------------------------------------------
		--�i�ڂb
		-------------------------------------------------------
		IF RTRIM(P_REC.ITEM_NAME1) IS NULL THEN
			P_INP_ERRKB := '1';
			P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0020M');
			GOTO CHK_DETL_END;
		END IF;
		-------------------------------------------------------
		OPEN M0P0M_LAST_PROC_CUR;
		FETCH M0P0M_LAST_PROC_CUR INTO M0P0M_LAST_PROC_REC;
		IF M0P0M_LAST_PROC_CUR%FOUND  THEN
			IF RTRIM(M0P0M_LAST_PROC_REC.PROC_CD) = RTRIM(M010M_3_REC.DATA_VALUE) THEN
				P_INP_ERRKB := '1';
				P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0021M');
				GOTO CHK_DETL_END;
			END IF;
		END IF;
		CLOSE M0P0M_LAST_PROC_CUR;
		-------------------------------------------------------
		--�H���b
		-------------------------------------------------------
		IF RTRIM(P_REC.DATA_DIV) IS NULL THEN
			IF RTRIM(P_REC.PROC_CD) IS  NULL THEN
				---------------------------------------------------
				OPEN M0P0M_BUY_CUR;
				FETCH M0P0M_BUY_CUR INTO M0P0M_BUY_REC;
				IF M0P0M_BUY_REC.COUNT_NUMBER > 0 THEN
					P_INP_ERRKB := '2';
					IF RTRIM(P_INP_ERRMS) IS NULL THEN
						P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0022M');
					ELSE
						P_INP_ERRMS := SUBSTRB(C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0023M,'||P_INP_ERRMS),1,200);
					END IF;
				END IF;
				CLOSE M0P0M_BUY_CUR;
			ELSE
				---------------------------------------------------
				IF RTRIM(P_REC.PROC_NAME) IS NULL THEN
					P_INP_ERRKB := '1';
					P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0024M');
					GOTO CHK_DETL_END;
				END IF;
				---------------------------------------------------
				IF RTRIM(P_REC.PROC_CD) = RTRIM(M010M_2_REC.DATA_VALUE) THEN
					P_INP_ERRKB := '1';
					P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0025M');
					GOTO CHK_DETL_END;
				END IF;
				---------------------------------------------------
				IF RTRIM(P_REC.PROC_CD) = RTRIM(M010M_3_REC.DATA_VALUE) THEN
					P_INP_ERRKB := '1';
					P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0026M');
					GOTO CHK_DETL_END;
				END IF;
				---------------------------------------------------
				IF RTRIM(P_REC.STOCK_ADMIN_DIV) < '8' THEN
					OPEN M0P0M_PROC_CUR;
					FETCH M0P0M_PROC_CUR INTO M0P0M_PROC_REC;
					IF M0P0M_PROC_REC.COUNT_NUMBER = 0 THEN
						P_INP_ERRKB := '2';
						IF RTRIM(P_INP_ERRMS) IS NULL THEN
							P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0027M');
						ELSE
							P_INP_ERRMS := SUBSTRB(C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0028M,'||P_INP_ERRMS),1,200);
						END IF;
					END IF;
					CLOSE M0P0M_PROC_CUR;
				END IF;
			END IF;
		ELSIF RTRIM(P_REC.DATA_DIV) = '1' THEN
			IF RTRIM(P_REC.PROC_CD) IS NOT NULL THEN
				P_INP_ERRKB := '1';
				P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0029M');
				GOTO CHK_DETL_END;
			END IF;
		END IF;
		-------------------------------------------------------
		--�P��
		-------------------------------------------------------
		IF RTRIM(P_REC.DATA_DIV) IS NULL THEN
			OPEN M0P0M_BUY_CUR;
			FETCH M0P0M_BUY_CUR INTO M0P0M_BUY_REC;
			--------------------------------------------------- �����P��(����UNIT�L�̍w���i)
			IF (RTRIM(P_REC.UNIT2) IS NOT NULL) And (M0P0M_BUY_REC.COUNT_NUMBER = 0) Then
				IF RTRIM(P_REC.UNIT) <> RTRIM(P_REC.UNIT2) THEN
					P_INP_ERRKB := '2';
					IF RTRIM(P_INP_ERRMS) IS NULL THEN
						P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0030M');
					ELSE
						P_INP_ERRMS := SUBSTRB(C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0031M,'||P_INP_ERRMS),1,200);
					END IF;
				END IF;
			--------------------------------------------------- �����P��(�����P�ʖ����w���i�ȊO)
			ELSE
				IF RTRIM(P_REC.UNIT) <> RTRIM(P_REC.STD_UNIT) THEN
					P_INP_ERRKB := '2';
					IF RTRIM(P_INP_ERRMS) IS NULL THEN
						P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0032M');
					ELSE
						P_INP_ERRMS := SUBSTRB(C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0033M,'||P_INP_ERRMS),1,200);
					END IF;
				END IF;
			END IF;
			CLOSE M0P0M_BUY_CUR;
		ELSE
			--------------------------------------------------- �󒍒P��
			IF RTRIM(P_REC.UNIT) <> RTRIM(P_REC.STD_UNIT) THEN
				P_INP_ERRKB := '2';
				IF RTRIM(P_INP_ERRMS) IS NULL THEN
					P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0032M');
				ELSE
					P_INP_ERRMS := SUBSTRB(C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0033M,'||P_INP_ERRMS),1,200);
				END IF;
			END IF;
		END IF;
		-------------------------------------------------------
		--�����b
		-------------------------------------------------------
		IF RTRIM(P_REC.DATA_DIV) IS NULL THEN
			IF RTRIM(P_REC.COMPANY_CD) IS  NULL THEN
				P_INP_ERRKB := '1';
				P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0034M');
				GOTO CHK_DETL_END;
			END IF;
		END IF;
		IF RTRIM(P_REC.COMPANY_CD) IS  NOT NULL THEN
			IF RTRIM(P_REC.SHORT_NAME_KANJI) IS NULL THEN
				P_INP_ERRKB := '1';
				P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0035M');
				GOTO CHK_DETL_END;
			END IF;
		END IF;
		IF RTRIM(P_REC.DATA_DIV) IS NULL THEN
			--------------------------------------------------- �����P��
			IF RTRIM(P_REC.PROC_CD) IS NULL THEN
				IF RTRIM(P_REC.SUPPLIER_F) = '0' THEN
					P_INP_ERRKB := '1';
					P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0036M');
					GOTO CHK_DETL_END;
				END IF;
			ELSE
				IF RTRIM(P_REC.OUTSOURCER_F) = '0' AND
					RTRIM(P_REC.DEPT_F) = '0' THEN
					P_INP_ERRKB := '1';
					P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0037M');
					GOTO CHK_DETL_END;
				END IF;
			END IF;
    -- ��DEL IVS NGUYEN PHU QUOC @15/07/21 
    /*ELSIF RTRIM(P_REC.DATA_DIV) = '1' THEN
			--------------------------------------------------- �󒍒P��
			IF RTRIM(P_REC.COMPANY_CD) IS  NOT NULL THEN
				IF RTRIM(P_REC.CUSTOMER_F) = '0' THEN
					P_INP_ERRKB := '1';
					P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0038M');
					GOTO CHK_DETL_END;
				END IF;
			END IF;*/
    -- ��DEL IVS NGUYEN PHU QUOC @15/07/21
    -- ��ADD IVS NGUYEN PHU QUOC @15/07/21
    ELSIF (RTRIM(P_REC.DATA_DIV) = '1') OR (RTRIM(P_REC.DATA_DIV) = '2')  THEN
			--------------------------------------------------- �󒍒P��
			IF RTRIM(P_REC.COMPANY_CD) IS  NOT NULL THEN
				IF RTRIM(P_REC.CUSTOMER_F) = '0' THEN
					P_INP_ERRKB := '1';
					P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0038M');
					GOTO CHK_DETL_END;
				END IF;
			END IF;
    -- ��ADD IVS  NGUYEN PHU QUOC @15/07/21 
		
		ELSE
			P_INP_ERRKB := '1';
				P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'NKE_M0T0_A00U_0001M');
			GOTO CHK_DETL_END;
		END IF;
		-------------------------------------------------------
		--�P��
		-------------------------------------------------------
		IF RTRIM(P_REC.UNITPRICE) IS NULL THEN
			P_INP_ERRKB := '2';
			IF RTRIM(P_INP_ERRMS) IS NULL THEN
				P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0039M');
			ELSE
				P_INP_ERRMS := SUBSTRB(C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0040M,'||P_INP_ERRMS),1,200);
			END IF;
		END IF;
		--------------------------------------------------------
		IF P_REC.UNITPRICE = 0 THEN
			P_INP_ERRKB := '2';
			IF RTRIM(P_INP_ERRMS) IS NULL THEN
				P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0039M');
			ELSE
				P_INP_ERRMS := SUBSTRB(C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0040M,'||P_INP_ERRMS),1,200);
			END IF;
		END IF;
		--------------------------------------------------------
		--�D�揇��
		--------------------------------------------------------
		IF RTRIM(P_REC.PRIORITY_RANK) IS NULL THEN
			P_INP_ERRKB := '1';
			P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0064M');
		END IF;
		--------------------------------------------------------
		IF P_REC.PRIORITY_RANK	=	0 THEN
			P_INP_ERRKB := '1';
			P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0064M');
		END IF;
	END IF ;
	-------------------------------------------------------
	--�d������
	-------------------------------------------------------
    OPEN MT0M_DUP_CUR;
	FETCH MT0M_DUP_CUR INTO MT0M_DUP_REC;
	IF RTRIM(MT0M_DUP_REC.COUNT_NUMBER) > 0 THEN
		IF RTRIM(P_REC.OPERATION_DIV) = 'A' THEN
			P_INP_ERRKB := '1';
			P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0041M');
			GOTO CHK_DETL_END;
		END IF;
	ELSE
		IF RTRIM(P_REC.OPERATION_DIV) <> 'A' THEN
			P_INP_ERRKB := '1';
			P_INP_ERRMS := C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0042M');
		END IF;
	END IF;
	CLOSE MT0M_DUP_CUR;
	-------------------------------------------------------
<<CHK_DETL_END>>
	NULL;
EXCEPTION
	-------------------------------------------------------
	--��O����
	-------------------------------------------------------
	WHEN OTHERS THEN
		IF MT0M_DUP_CUR%ISOPEN  		THEN CLOSE MT0M_DUP_CUR; END IF;
		IF M0P0M_LAST_PROC_CUR%ISOPEN  	THEN CLOSE M0P0M_LAST_PROC_CUR; END IF;
		IF M0P0M_BUY_CUR%ISOPEN 		THEN CLOSE M0P0M_BUY_CUR; END IF;
		IF M0P0M_PROC_CUR%ISOPEN 		THEN CLOSE M0P0M_PROC_CUR; END IF;
		IF M20M_CUR%ISOPEN   			THEN CLOSE M20M_CUR; END IF;
		G_ERRCD         := SQLCODE;
		G_ERRTX         := SQLERRM || G_PACKAGEID || '.CHK_DETL ';
END;
--*********************************************************
-- �捞�m�F�����i�����������j
--*********************************************************
PROCEDURE DOWN_RTN( 
	 P_PROGRAM  IN  VARCHAR2
	,P_LANGUAGE	IN  VARCHAR2
	,P_MSGCD    OUT VARCHAR2
	,P_ERRCD    OUT NUMBER
	,P_ERRTX    OUT VARCHAR2
	)
IS
	W_ERROR_DIV			DFW_M040M_EW.ERROR_DIV%TYPE := ' ';
	W_ERROR_CONTENTS	DFW_M040M_EW.ERROR_CONTENTS%TYPE := ' ';
	----------------------------------------------
	CURSOR CHK_SAME_ITEM_CUR IS
		SELECT
			 ITEM_DIV
			,ITEM_CD
			,DATA_DIV
			,UNIT
			,COMPANY_CD
			,BASIS_QTY
			,PROC_CD
			,UNITPRICE_EFFECTIVE_DATE
		FROM
			W_DFW_M0T0_A00U_UP0P_1
		GROUP BY ITEM_DIV ,ITEM_CD,DATA_DIV,UNIT,COMPANY_CD,BASIS_QTY,PROC_CD,UNITPRICE_EFFECTIVE_DATE
		HAVING	COUNT(*) > 1
	;
	----------------------------------------------
	W_CURRENCY_CD				VARCHAR2(3);
	W_AMT_RD_DIV				VARCHAR2(8);
	W_UNITPRICE_CONV_RD_DIV		VARCHAR2(8);
	W_AMT_CONV_RD_DIV			VARCHAR2(8);
	W_UNITPRICE_DECIMAL_DIGIT	NUMBER;
	W_AMT_DECIMAL_DIGIT			NUMBER;
BEGIN 
	----------------------------------------------------------------------------
	-- ��������
	----------------------------------------------------------------------------
	P_MSGCD := ' ';
	P_ERRCD := 0;
	P_ERRTX := ' ';
	----------------------------------------------------------------------------
	-- ����ð��� �쐬
	----------------------------------------------------------------------------
	CRT_CHKTB(
		 P_PROGRAM
		,P_MSGCD
		,P_ERRCD
		,P_ERRTX
	);
	IF P_ERRCD <> 0  THEN
		RAISE ERROR_OCCURRED;
	END IF;
	----------------------------------------------------------------------------
	--	���ꐔ�ʒP������
	----------------------------------------------------------------------------
	FOR	ITEM_REC	IN	CHK_SAME_ITEM_CUR	LOOP
		UPDATE  W_DFW_M0T0_A00U_UP0P_1	SET
			 ERROR_DIV		= 'Z'
			,ERROR_CONTENTS = C000_UTILITY.GET_MESSAGE(P_LANGUAGE,'DFW_M0T0_A00U_0017M')
		WHERE	ITEM_DIV				=	ITEM_REC.ITEM_DIV
		 AND	ITEM_CD					=	ITEM_REC.ITEM_CD
		 AND	DATA_DIV				=	ITEM_REC.DATA_DIV
		 AND	UNIT					=	ITEM_REC.UNIT
		 AND	COMPANY_CD				=	ITEM_REC.COMPANY_CD
		 AND	BASIS_QTY				=	ITEM_REC.BASIS_QTY
		 AND	PROC_CD					=	ITEM_REC.PROC_CD
		 AND	UNITPRICE_EFFECTIVE_DATE	=	ITEM_REC.UNITPRICE_EFFECTIVE_DATE
		 AND	TARGET_F	=	'1'
		;
	END LOOP;
	----------------------------------------------------------------------------
	-- �װ����
	----------------------------------------------------------------------------
	FOR	M0T0_TEMP_REC	IN	G_M0T0_TEMP_CUR	LOOP
		W_ERROR_DIV      := ' ';
		W_ERROR_CONTENTS := ' ';
		------------------------------------------
		SEF_CHKTB(
			 M0T0_TEMP_REC
			,P_MSGCD
			,P_ERRCD
			,P_ERRTX
		);
		IF (P_ERRCD <> 0) OR (P_MSGCD <> ' ') THEN
			RAISE ERROR_OCCURRED;
		END IF;
		------------------------------------------
		-- ��{����
		------------------------------------------
		FOR I IN 1..CT_MAXCOL  LOOP
			IF	RTRIM(CT_NAME(I))	=	 P_PROGRAM || ':UNITPRICE'
				AND	RTRIM(M010M_1_REC.DATA_VALUE)	=	'1'
				AND	RTRIM(M0T0_TEMP_REC.COMPANY_CD) IS NOT NULL	THEN
				IF	RTRIM(M0T0_TEMP_REC.DATA_DIV) 	IS NULL	THEN	--����
					C000_UTILITY.GET_PU_EXCHANGE_CONDITION(
						RTRIM(M0T0_TEMP_REC.COMPANY_CD)
						,W_CURRENCY_CD
						,W_AMT_RD_DIV
						,W_UNITPRICE_CONV_RD_DIV
						,W_AMT_CONV_RD_DIV
						,W_UNITPRICE_DECIMAL_DIGIT
						,W_AMT_DECIMAL_DIGIT
						,P_MSGCD
						,P_ERRCD
						,P_ERRTX
					);
				ELSE												--��
					C000_UTILITY.GET_SA_EXCHANGE_CONDITION(
						RTRIM(M0T0_TEMP_REC.COMPANY_CD)
						,W_CURRENCY_CD
						,W_AMT_RD_DIV
						,W_UNITPRICE_CONV_RD_DIV
						,W_AMT_CONV_RD_DIV
						,W_UNITPRICE_DECIMAL_DIGIT
						,W_AMT_DECIMAL_DIGIT
						,P_MSGCD
						,P_ERRCD
						,P_ERRTX
					);
				END IF;
				IF (P_ERRCD <> 0) OR (P_MSGCD <> ' ') THEN
					RAISE ERROR_OCCURRED;
				END IF;
				-- ������̍ő�l�Ə���������؂�ւ�
				IF	RTRIM(W_CURRENCY_CD)	IS	NULL	THEN
					-- �~��
					CT_MAX(I) := 999999999.99;
					CT_DCML(I) := 2;
				ELSE
					-- �O��
					CT_MAX(I) := TRUNC(999999999.999999999 ,W_UNITPRICE_DECIMAL_DIGIT);
					CT_DCML(I) := W_UNITPRICE_DECIMAL_DIGIT;
				END IF;
			END IF;
			CHK_BASIC(
				 CT_VAL(I)
				,CT_NAME(I)
				,CT_TYPE(I)
				,CT_LEN(I)
				,CT_MAX(I)
				,CT_HISU(I)
				,CT_MINS(I)
				,CT_DCML(I)
				,W_ERROR_DIV
				,W_ERROR_CONTENTS
				,P_LANGUAGE
				,P_MSGCD
				,P_ERRCD
				,P_ERRTX
			);
			IF (P_ERRCD <> 0) OR (P_MSGCD <> ' ') THEN
				RAISE ERROR_OCCURRED;
			END IF;
			IF W_ERROR_DIV = '1' THEN
				GOTO	NEXT_DATA;
			END IF;
		END LOOP;
		------------------------------------------
		-- �ڍ�����
		------------------------------------------
		CHK_DETL(
			 M0T0_TEMP_REC
			,W_ERROR_DIV
			,W_ERROR_CONTENTS
			,P_LANGUAGE
			,P_MSGCD
			,P_ERRCD
			,P_ERRTX
		);
		IF (P_ERRCD <> 0) OR (P_MSGCD <> ' ') THEN
			RAISE ERROR_OCCURRED;
		END IF;
		IF W_ERROR_DIV IN ('1','2') THEN
			GOTO	NEXT_DATA;
		ELSE
			W_ERROR_DIV := '0';
		END IF;
<<NEXT_DATA>>
		------------------------------------------
		-- �װ�敪�A���e���X�V
		------------------------------------------
		IF	W_ERROR_DIV = '1'	THEN
			UPDATE W_DFW_M0T0_A00U_UP0P_1 SET
				 ERROR_DIV		= W_ERROR_DIV
				,ERROR_CONTENTS	= W_ERROR_CONTENTS
			WHERE	SEQ	= M0T0_TEMP_REC.SEQ
				;
		ELSE
			UPDATE W_DFW_M0T0_A00U_UP0P_1 SET
				 ERROR_DIV				= W_ERROR_DIV
				,ERROR_CONTENTS			= W_ERROR_CONTENTS
				,BASIS_QTY				= NVL(RTRIM(BASIS_QTY),0)
                ,UNITPRICE				= NVL(RTRIM(UNITPRICE),0)
                ,PO_LOT_QTY				= NVL(RTRIM(PO_LOT_QTY),0)
                ,MIN_QTY				= NVL(RTRIM(MIN_QTY),0)
                ,REFER_UNITPRICE		= NVL(RTRIM(REFER_UNITPRICE),0)
			WHERE	SEQ	= M0T0_TEMP_REC.SEQ
				;
		END IF;
		------------------------------------------
	END LOOP;
	--------------------------------------------------------
	-- ���ʒP���d���װ(�װ�敪='Z')��'1'�ɍX�V�������Ă��܂��B
	UPDATE W_DFW_M0T0_A00U_UP0P_1 SET
		ERROR_DIV= '1'
	WHERE ERROR_DIV = 'Z'
	;
	--------------------------------------------------------
EXCEPTION
	----------------------------------------------------------------------------
	-- ��O����
	----------------------------------------------------------------------------
	WHEN ERROR_OCCURRED THEN
		IF G_M0T0_TEMP_CUR%ISOPEN THEN CLOSE G_M0T0_TEMP_CUR;     END IF;
	----------------------------------------------------------------------------
	WHEN OTHERS THEN
		IF G_M0T0_TEMP_CUR%ISOPEN THEN CLOSE G_M0T0_TEMP_CUR;     END IF;
		P_ERRCD := SQLCODE;
		P_ERRTX := SQLERRM || G_PACKAGEID || '.DOWN_RTN '; 
END;
--*********************************************************
--	�X�V����
--*********************************************************
PROCEDURE LOOP_EXECUTE(
	 P_OPERATOR       	IN  DFW_M050M.EMP_CD%TYPE
	,P_OPERATION_DIV	IN  VARCHAR2
	,P_COMPUTER			IN  VARCHAR2
	,P_PROGRAM			IN  VARCHAR2
	,P_BACKUP_DATA		IN  VARCHAR2      -- "1":�O��捞�ް�������
	,P_MSGCD			OUT VARCHAR2
	,P_ERRCD			OUT NUMBER
	,P_ERRTX			OUT VARCHAR2
)
IS
	----------------------------------------------
	W_MAXSEQ		NUMBER	:=	0;
	----------------------------------------------
BEGIN
	----------------------------------------------
	-- ��������
	----------------------------------------------
	P_MSGCD := ' ';
	P_ERRCD := 0;
	P_ERRTX := ' ';
	----------------------------------------------
	-- ���ʒP��Ͻ���X�V�p�ꎞ�\�֓]��
	----------------------------------------------
	INSERT	INTO	W_DFW_M0T0_G00E_UP0P_1	(
			OPERATION_DIV
			,ROW_NO
			,ITEM_DIV
			,ITEM_CD
			,DATA_DIV
			,UNIT
			,COMPANY_CD
			,BASIS_QTY
			,UNITPRICE
			,INVALID_F
			,REMARKS
			,PROC_CD
			,PO_LOT_QTY
			,PO_LT
			,MIN_QTY
			,REFER_UNITPRICE
			,PRIORITY_RANK
			,UNITPRICE_EFFECTIVE_DATE
			,CURRENCY_CD
			,UNITPRICE_EFFECTIVE_DATE_OLD
			,COMPANY_CD_OLD
			,BASIS_QTY_OLD
			,REGIST_DATE
	)	(
		SELECT
			P_OPERATION_DIV
			,W_M0T0.SEQ
			 ,W_M0T0.ITEM_DIV
             ,W_M0T0.ITEM_CD
             ,W_M0T0.DATA_DIV
             ,W_M0T0.UNIT
             ,W_M0T0.COMPANY_CD
             ,W_M0T0.BASIS_QTY
             ,W_M0T0.UNITPRICE
             ,W_M0T0.INVALID_F
             ,W_M0T0.REMARKS
             ,W_M0T0.PROC_CD
             ,W_M0T0.PO_LOT_QTY
             ,W_M0T0.PO_LT
             ,W_M0T0.MIN_QTY
             ,W_M0T0.REFER_UNITPRICE
             ,W_M0T0.PRIORITY_RANK
             ,W_M0T0.UNITPRICE_EFFECTIVE_DATE
             ,W_M0T0.CURRENCY_CD
			,W_M0T0.UNITPRICE_EFFECTIVE_DATE
			,W_M0T0.COMPANY_CD
			,W_M0T0.BASIS_QTY
			,CASE
				WHEN	M0T0M.REGIST_DATE	IS  NULL	THEN
					C000_UTILITY.GET_EXECUTE_DATE
				ELSE
					M0T0M.REGIST_DATE
				END	AS	REGIST_DATE
		FROM	W_DFW_M0T0_A00U_UP0P_1 W_M0T0
				LEFT OUTER JOIN DFW_M0T0M M0T0M
		ON  W_M0T0.ITEM_DIV  = M0T0M.ITEM_DIV
		AND W_M0T0.ITEM_CD  = M0T0M.ITEM_CD
		AND W_M0T0.DATA_DIV  = M0T0M.DATA_DIV
		AND W_M0T0.UNIT  = M0T0M.UNIT
		AND W_M0T0.COMPANY_CD  = M0T0M.COMPANY_CD
		AND W_M0T0.BASIS_QTY  = M0T0M.BASIS_QTY
		AND W_M0T0.PROC_CD  = M0T0M.PROC_CD
		AND W_M0T0.UNITPRICE_EFFECTIVE_DATE  = M0T0M.UNITPRICE_EFFECTIVE_DATE
		WHERE	W_M0T0.TARGET_F	= '1'
	);
	----------------------------------------------
	-- ���ʒP��Ͻ���X�V����
	----------------------------------------------
	DFW_M0T0_G00E_UP0P.LOOP_EXECUTE(
		 P_OPERATOR
		,P_OPERATION_DIV
		,P_MSGCD
		,P_ERRCD
		,P_ERRTX
	);
	IF	(P_MSGCD <> ' ') OR (P_ERRCD <> 0) THEN
		RAISE	ERROR_OCCURRED;
	END IF;
	----------------------------------------------
	-- TEMPTABLE�폜
	DELETE	W_DFW_M0T0_A00U_UP0P_1;
EXCEPTION
	--------------------------------------------------------
	-- ��O����
	--------------------------------------------------------
	WHEN ERROR_OCCURRED THEN
		NULL;
		------------------------------------------
	WHEN OTHERS THEN
		P_ERRCD := SQLCODE;
		P_ERRTX := SQLERRM || G_PACKAGEID || '.LOOP_EXECUTE';
END;
--*********************************************************
--	���ʒP��ܰ�ð���(�捞E)�X�V����
--*********************************************************
PROCEDURE INS_M0T0M_EW(
	 P_COMPUTER			IN  VARCHAR2
	,P_PROGRAM			IN  VARCHAR2
	,P_BACKUP_DATA		IN  VARCHAR2  -- "1":�O��捞�ް�������
	,P_MSGCD            OUT VARCHAR2
	,P_ERRCD            OUT NUMBER
	,P_ERRTX            OUT VARCHAR2
)
IS
	----------------------------------------------
	W_MAXSEQ		NUMBER	:=	0;
	----------------------------------------------
BEGIN
	----------------------------------------------
	-- ��������
	----------------------------------------------
	P_MSGCD := ' ';
	P_ERRCD := 0;
	P_ERRTX := ' ';
	----------------------------------------------
	-- �O��捞�ް��폜
	----------------------------------------------
	IF P_BACKUP_DATA = '1' THEN
		DELETE DFW_M0T0M_EW
		WHERE	COMPUTER	= P_COMPUTER
		 AND 	PROGRAM		= P_PROGRAM
		;
	ELSE
		SELECT NVL(MAX(SEQ),0)
			INTO	W_MAXSEQ
		FROM	DFW_M0T0M_EW
		WHERE	COMPUTER	= P_COMPUTER
		 AND 	PROGRAM		= P_PROGRAM
		;
	END IF;
	----------------------------------------------
	INSERT	INTO	DFW_M0T0M_EW	(
			COMPUTER
			,PROGRAM
			,ITEM_DIV
			,ITEM_CD
			,DATA_DIV
			,UNIT
			,COMPANY_CD
			,BASIS_QTY
			,UNITPRICE
			,INVALID_F
			,REMARKS
			,PROC_CD
			,PO_LOT_QTY
			,PO_LT
			,MIN_QTY
			,REFER_UNITPRICE
			,PRIORITY_RANK
			,UNITPRICE_EFFECTIVE_DATE
			,OPERATION_DIV
			,SEQ
			,ERROR_DIV
			,ERROR_CONTENTS
			,TARGET_F
	)	(
		SELECT
		     P_COMPUTER
		    ,P_PROGRAM
			 ,ITEM_DIV
             ,ITEM_CD
             ,DATA_DIV
             ,UNIT
             ,COMPANY_CD
             ,BASIS_QTY
             ,UNITPRICE
             ,INVALID_F
             ,REMARKS
             ,PROC_CD
             ,PO_LOT_QTY
             ,PO_LT
             ,MIN_QTY
             ,REFER_UNITPRICE
             ,PRIORITY_RANK
             ,UNITPRICE_EFFECTIVE_DATE
             ,OPERATION_DIV
             ,SEQ
             ,ERROR_DIV
             ,ERROR_CONTENTS
             ,TARGET_F
		FROM	W_DFW_M0T0_A00U_UP0P_1
	);
	----------------------------------------------
EXCEPTION
	--------------------------------------------------------
	-- ��O����
	--------------------------------------------------------
	WHEN ERROR_OCCURRED THEN
		NULL;
		------------------------------------------
	WHEN OTHERS THEN
		P_ERRCD := SQLCODE;
		P_ERRTX := SQLERRM || G_PACKAGEID || '.LOOP_EXECUTE';
END;
END;