--------------------------------------------------------
--  File created - Friday-May-13-2016
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Package CSG02_0205_PKG
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE PACKAGE "CSNAVI"."CSG02_0205_PKG"
AS
/*******************************************************************************
* �ݒu�@��ꊇ�ύX�̈ڍs                                                       *
*------------------------------------------------------------------------------*
* <�X�V����>                                                                   *
* <Version>   <���t>      <�X�V�T�v>                             <�X�V��>      *
*   1.0     2016/04/01      �V�K                                FOCUS_LTBINH   *
*   1.01    2016/05/20      �C��                                FOCUS_AOKI     *
********************************************************************************/
  /******************************************************************************
  * �ݒu�@��ꊇ�ύX�iPL/SQL�j                                                  *
  * CSG02-0205 (MAIN)                                                           *
  *******************************************************************************/
  PROCEDURE MAIN_CSG02_0205(
      INPUT_USER_ID    IN VARCHAR2,                   --���[�UID
      INPUT_PATH_FILE  IN VARCHAR2,                   --CSV�t�@�C���p�X
      OUT_PROCESS_ID OUT VARCHAR2,                    --����ID
      OUT_STATUS OUT VARCHAR2,                        --�X�e�[�^�X
      OUT_ERR_CONTENT OUT NVARCHAR2,                  --�G���[���e
      OUT_ERR_DETAIL OUT NVARCHAR2,                   --�G���[�ڍ�
      OUT_RESULT_CD OUT VARCHAR2                      --�I���R�[�h
    );
  /******************************************************************************
  * �ݒu�@��ꊇ�ύX�iPL/SQL�j                                                     *
  * CSG02-0205                                                                  *
  *******************************************************************************/
  PROCEDURE CSG02_PROC_CHANGE_INS_EQUI_COL(
      INPUT_USER_ID    IN VARCHAR2,                   --���[�UID
      INPUT_PROCESS_ID IN VARCHAR2 DEFAULT NULL,      --�v���Z�XID
      INPUT_PATH_FILE  IN VARCHAR2,                   --CSV�t�@�C���p�X
      OUT_STATUS OUT VARCHAR2,                        --�X�e�[�^�X
      OUT_ERR_CONTENT OUT NVARCHAR2,                  --�G���[���e
      OUT_ERR_DETAIL OUT NVARCHAR2,                   --�G���[�ڍ�
      OUT_RESULT_CD OUT VARCHAR2                      --�I���R�[�h
    );
END CSG02_0205_PKG;

/
