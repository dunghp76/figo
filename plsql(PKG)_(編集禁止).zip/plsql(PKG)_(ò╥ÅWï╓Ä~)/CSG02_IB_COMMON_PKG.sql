CREATE OR REPLACE EDITIONABLE PACKAGE "CSG02_IB_COMMON_PKG" 
AS
/*******************************************************************************
* 設置機器・共通テーブル追加更新API（PL/SQL）移行                                *
*-------------------------------------------------------------------------------*
* <更新履歴>                                                                     *
* <Version>   <日付>      <更新概要>                             <更新者>         *
*   1.0     2016/04/01      新規                                FOCUS_LTBINH    *
********************************************************************************/
  /*******************************************************************************
  * 設置機器・共通テーブル追加更新API（PL/SQL）                                       *
  * CSG02_PROC_IB_TABLE_UPDATE                                                   *
  ********************************************************************************/
  PROCEDURE CSG02_PROC_IB_TABLE_UPDATE(
      PROC_TYPE             IN NUMBER DEFAULT 0,     -- 追加・更新区分
      INPUT_INSTANCE_ID     IN VARCHAR2,             -- インスタンス番号
      INPUT_TOP_INSTANCE_ID IN VARCHAR2,             -- 最上位インスタンス番号
      tIB_BASE              IN ARRAY_IB_BASE,        -- 設置機器情報
      tIB_COMMON            IN ARRAY_IB_COMMON,      -- 設置機器共通情報
      PROGRAM_ID            IN VARCHAR2,             -- 更新プログラムID
      PROCESS_ID            IN VARCHAR2,             -- 処理ID
      USER_ID               IN VARCHAR2,             -- ユーザID
      LOCK_FLG              IN VARCHAR2 DEFAULT 'N', -- 楽観ロック比較有無フラグ
      LOCK_DATE             IN DATE,                 -- 比較日時
      END_CODE              OUT VARCHAR2,            -- 終了コード      
      ERROR_MESSAGE         OUT VARCHAR2,            -- エラーメッセージ
      OUT_INSTANCE_ID       OUT VARCHAR2,            -- インスタンス番号
      UPDATE_DATE           OUT DATE                 -- 更新日時
      );
  /*******************************************************************************
  * 設置機器ソフトウェア追加更新API（PL/SQL）                                    *
  * CSG02_PROC_IB_SI_UPDATE                                                      *
  ********************************************************************************/
  PROCEDURE CSG02_PROC_IB_SI_UPDATE(
      PROC_TYPE         IN NUMBER DEFAULT 0,     -- 追加・更新区分
      INPUT_INSTANCE_ID IN VARCHAR2,             -- インスタンス番号
      INPUT_SOFTWARE_ID IN VARCHAR2,             -- ソフトウェアID
      tSOFTWARE_INFO    IN ARRAY_IB_SOFTWARE,    -- ソフトウェア情報
      PROGRAM_ID        IN VARCHAR2,             -- 更新プログラムID
      PROCESS_ID        IN VARCHAR2,             -- 処理ID
      USER_ID           IN VARCHAR2,             -- ユーザID
      LOCK_FLG          IN VARCHAR2 DEFAULT 'N', -- 楽観ロック比較有無フラグ
      LOCK_DATE         IN DATE,                 -- 比較日時
      END_CODE          OUT VARCHAR2,            -- 終了コード
      ERROR_MESSAGE     OUT VARCHAR2,            -- エラーメッセージ
      OUT_INSTANCE_ID   OUT VARCHAR2,            -- インスタンス番号
      OUT_SOFTWARE_ID   OUT VARCHAR2,            -- ソフトウェアID
      UPDATE_DATE       OUT VARCHAR2             -- 更新日時
      ) ;
  /*******************************************************************************
  * 設置機器パーツ情報追加更新API（PL/SQL）                                      *
  * CSG02_PR0C_IB_PI_UPDATE                                                      *
  ********************************************************************************/
  PROCEDURE CSG02_PR0C_IB_PI_UPDATE(
      PROC_TYPE         IN NUMBER DEFAULT 0,     -- 追加・更新区分
      INPUT_INSTANCE_ID IN VARCHAR2,             -- インスタンス番号
      INPUT_PARTS_ID    IN VARCHAR2,             -- パーツID
      tPARTS_INFO       IN ARRAY_IB_PARTS,       -- パーツ情報
      PROGRAM_ID        IN VARCHAR2,             -- 更新プログラムID
      PROCESS_ID        IN VARCHAR2,             -- 処理ID
      USER_ID           IN VARCHAR2,             -- ユーザID
      LOCK_FLG          IN VARCHAR2 DEFAULT 'N', -- 楽観ロック比較有無フラグ
      LOCK_DATE         IN DATE,                 -- 比較日時
      END_CODE          OUT VARCHAR2,            -- 終了コード
      ERROR_MESSAGE     OUT VARCHAR2,            -- エラーメッセージ
      OUT_INSTANCE_ID   OUT VARCHAR2,            -- インスタンス番号
      OUT_PARTS_ID      OUT VARCHAR2,            -- パーツID
      UPDATE_DATE       OUT DATE                 -- 更新日時
      );
  /*******************************************************************************
  * 設置機器メモ情報追加更新API（PL/SQL）                                        *
  * CSG02_PROC_IB_MEMO_INFO_UPDATE                                               *
  ********************************************************************************/
  PROCEDURE CSG02_PROC_IB_MEMO_INFO_UPDATE(
      PROC_TYPE         IN NUMBER DEFAULT 0,     -- 追加・更新区分
      INPUT_INSTANCE_ID IN VARCHAR2,             -- インスタンス番号
      MEMO_ID           IN VARCHAR2,             -- メモID
      tMEMO_INFO        IN ARRAY_IB_MEMO,        -- メモ情報
      PROGRAM_ID        IN VARCHAR2,             -- 更新プログラムID
      PROCESS_ID        IN VARCHAR2,             -- 処理ID
      USER_ID           IN VARCHAR2,             -- ユーザID
      LOCK_FLG          IN VARCHAR2 DEFAULT 'N', -- 楽観ロック比較有無フラグ
      LOCK_DATE         IN DATE,                 -- 比較日時
      END_CODE          OUT VARCHAR2,            -- 終了コード
      ERROR_MESSAGE     OUT VARCHAR2,            -- エラーメッセージ
      OUT_INSTANCE_ID   OUT VARCHAR2,            -- インスタンス番号
      OUT_MEMO_ID       OUT VARCHAR2,            -- メモID
      UPDATE_DATE       OUT DATE                 -- 更新日時
      );
END CSG02_IB_COMMON_PKG;
