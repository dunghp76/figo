--------------------------------------------------------
--  ファイルを作成しました - 火曜日-6月-14-2016   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Package CSG05_0101_PKG
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE PACKAGE "CSNAVI"."CSG05_0101_PKG" 
AS 
   PROCEDURE "CSG05_PROC_BG_PROCESS_START" (
    --プログラムID
    INPUT_PROGRAM_ID IN VARCHAR2 ,
    --処理パラメータ
    INPUT_PROCESS_PARAM IN CLOB ,
    --処理開始日時
    INPUT_PROCESS_START_DATE IN VARCHAR2 ,
    --ユーザID
    INPUT_USER_ID IN VARCHAR2 ,
    --プロセスID
    PROCESS_ID OUT VARCHAR2 ,
    --終了コード
    RESULT_CD OUT VARCHAR2 );
    
    PROCEDURE "CSG05_PROC_BG_PROCESS_UPD" (
    --処理ID
    INPUT_PROCESS_ID IN VARCHAR2 ,
    --ステータス
    INPUT_STATUS IN VARCHAR2 ,
    --処理終了日時
    INPUT_PROCESS_END_DATE IN VARCHAR2 ,
    --エラー内容
    INPUT_ERR_CONTENT IN VARCHAR2 ,
    --エラー詳細
    INPUT_ERR_DETAIL IN CLOB ,
    --ダウンロードファイル
    INPUT_DL_FILE IN VARCHAR2 ,
    --終了コード
    RESULT_CD OUT VARCHAR2 );
  END CSG05_0101_PKG;

/
