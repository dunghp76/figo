--------------------------------------------------------
--  DDL for Package CSG04_0601_PKG
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE PACKAGE "CSG04_0601_PKG" AS

   PROCEDURE "CSG04_PROC_ZIP_REGISTRATION" (
    --ユーザID
    INPUT_USERID         IN VARCHAR2 ,
    --プロセスID
    INPUT_PROCESS_ID     IN VARCHAR2 ,
    --終了コード
    RESULT_CD           OUT VARCHAR2 );
  /* TODO enter package declarations (types, exceptions, methods etc) here */

END CSG04_0601_PKG;