--------------------------------------------------------
--  ファイルを作成しました - 火曜日-6月-14-2016   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Package CSG05_0201_PKG
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE PACKAGE "CSNAVI"."CSG05_0201_PKG" 
AS 
   PROCEDURE CSG05_PROC_AUTO_NUMBERING (
    INPUT_MANAGEMENT_CODE  IN VARCHAR2 ,
    INPUT_USERID           IN VARCHAR2 ,
    INPUT_PROCESS_ID       IN VARCHAR2 ,
    INPUT_UPDATE_DATE      IN VARCHAR2 ,
    OUTPUT_MANAGEMENT_CODE OUT VARCHAR2 ,
    RESULT_CODE OUT VARCHAR2 );
END CSG05_0201_PKG;

/
