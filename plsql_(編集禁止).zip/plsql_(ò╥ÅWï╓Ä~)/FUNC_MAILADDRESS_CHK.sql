--------------------------------------------------------
--  DDL for Function FUNC_MAILADDRESS_CHK
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "CSNAVI"."FUNC_MAILADDRESS_CHK" (PARAM1 IN VARCHAR2)
RETURN STRING
  IS LANGUAGE java
  NAME 'MailAddressChk.mailadrchk(java.lang.String) return String';
