--------------------------------------------------------
--  ファイルを作成しました - 水曜日-6月-01-2016   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Package Body CSG02_IB_COMMON_PKG
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE PACKAGE BODY "CSNAVI"."CSG02_IB_COMMON_PKG" AS
/*******************************************************************************
* 設置機器・共通テーブル追加更新API（PL/SQL）移行                                    *
*-------------------------------------------------------------------------------*
* <更新履歴>                                                                     *
* <Version>   <日付>      <更新概要>                             <更新者>         *
*   1.0     2016/04/01      新規                                FOCUS_LTBINH    *
********************************************************************************/
  PROCEDURE CSG02_PROC_IB_TABLE_UPDATE(
      PROC_TYPE             IN NUMBER DEFAULT 0,     -- 追加・更新区分
      INPUT_INSTANCE_ID     IN VARCHAR2,             -- インスタンス番号
      INPUT_TOP_INSTANCE_ID IN VARCHAR2,             -- 最上位インスタンス番号
      tIB_BASE              IN ARRAY_IB_BASE,        -- 設置機器情報
      tIB_COMMON            IN ARRAY_IB_COMMON,      -- 設置機器共通情報
      PROGRAM_ID            IN VARCHAR2,             -- 更新プログラムID
      PROCESS_ID            IN VARCHAR2,             -- 処理ID
      USER_ID               IN VARCHAR2,             -- ユーザID
      LOCK_FLG              IN VARCHAR2 DEFAULT 'N', -- 楽観ロック比較有無フラグ
      LOCK_DATE             IN DATE,                 -- 比較日時
      END_CODE              OUT VARCHAR2,            -- 終了コード
      ERROR_MESSAGE         OUT VARCHAR2,            -- エラーメッセージ
      OUT_INSTANCE_ID       OUT VARCHAR2,            -- インスタンス番号
      UPDATE_DATE           OUT DATE                 -- 更新日時
  ) AS
-- *****************************************************************************
-- 処理パラメータ
-- *****************************************************************************
  PRAM_PLACE_HOLDER    VARCHAR2(32670); -- プレースホルダパラメータ
  NO_SEARCH_PROGRAM_ID EXCEPTION;
  PRAM_EXCEPTION       EXCEPTION;
  MASTER_EXCEPTION     EXCEPTION;
  LOCK_FLG_EXCEPTION   EXCEPTION;
  table_name           VARCHAR2(100);
  stmt_str             VARCHAR2(32670);
  set_column_name      VARCHAR2(20000);
  set_value_column     VARCHAR2(20000);
  set_sysdate          DATE;
  ib_base_obj          CONTACT_IB_BASE_OBJ;
  ib_common_obj        CONTACT_IB_COMMON_OBJ;
  cur_hdl              NUMBER;
  rows_processed       NUMBER;
  get_count            NUMBER;
  v_END_CODE           VARCHAR2(10);
  p_BUNDLE_ITEM_CODE_NULL_FLAG VARCHAR2(1) := 'N';
--******************************************************************************
-- 設置機器情報のパラメータ
--******************************************************************************
  p_INSTANCE_ID_IBI CSG_M_IB_INFO.INSTANCE_ID%type ;                 -- インスタンス番号
  p_PARENT_INSTANCE_ID_IBI CSG_M_IB_INFO.PARENT_INSTANCE_ID%type ;   -- 親インスタンス番号
  p_TOP_INSTANCE_ID_IBI CSG_M_IB_INFO.TOP_INSTANCE_ID%type ;         -- 最上位インスタンス番号
  p_INVENTORY_ITEM_CODE_IBI CSG_M_IB_INFO.INVENTORY_ITEM_CODE%type ; -- 品目コード
  p_ORG_ID_IBI CSG_M_IB_INFO.ORG_ID%type ;                           -- プラント
  p_BUNDLE_ITEM_CODE CSG_M_IB_INFO.BUNDLE_ITEM_CODE%type ;           -- バンドル品目コード
  p_INVENTORY_ITEM_NAME_IBI CSG_M_IB_INFO.INVENTORY_ITEM_NAME%type ; -- 品目名
  p_CREATION_USER_ID_IBI CSG_M_IB_INFO.CREATION_USER_ID%type ;       -- 作成者
  p_CREATION_DATE_IBI CSG_M_IB_INFO.CREATION_DATE%type ;             -- 作成日時
  p_UPDATE_USER_ID_IBI CSG_M_IB_INFO.UPDATE_USER_ID%type ;           -- 更新者
  p_UPDATE_DATE_IBI CSG_M_IB_INFO.UPDATE_DATE%type ;                 -- 更新日時
  v_INSTANCE_ID_IBI CSG_M_IB_INFO.INSTANCE_ID%type ;                 -- インスタンス番号
--******************************************************************************
-- 設置機器共通情報のパラメータ
--******************************************************************************
  p_TOP_INSTANCE_ID CSG_M_IB_COMMON_INFO.TOP_INSTANCE_ID%type ;                                       -- 最上位インスタンス番号
  p_CS_IN_CHARGE_CODE CSG_M_IB_COMMON_INFO.CS_IN_CHARGE_CODE%type ;                                   -- 担当CSコード
  p_CE_CODE CSG_M_IB_COMMON_INFO.CE_CODE%type DEFAULT NULL;                                           -- 担当CEコード
  p_INSTALL_CUSTOMER_CODE CSG_M_IB_COMMON_INFO.INSTALL_CUSTOMER_CODE%type ;                           -- 設置先顧客コード
  p_INSTALL_LOCATION_CODE CSG_M_IB_COMMON_INFO.INSTALL_LOCATION_CODE%type ;                           -- 設置先顧客住所コード
  p_INSTALL_LOCATION_DEPT_NAME CSG_M_IB_COMMON_INFO.INSTALL_LOCATION_DEPT_NAME%type DEFAULT NULL;     -- 設置先顧客部署名
  p_INSTALL_LOCATION_PERSON_NAME CSG_M_IB_COMMON_INFO.INSTALL_LOCATION_PERSON_NAME%type DEFAULT NULL; -- 設置先顧客担当者名
  p_INSTALL_LOCATION_TEL CSG_M_IB_COMMON_INFO.INSTALL_LOCATION_TEL%type DEFAULT NULL;                 -- 設置先TEL
  p_INSTALL_LOCATION_FAX CSG_M_IB_COMMON_INFO.INSTALL_LOCATION_FAX%type DEFAULT NULL;                 -- 設置先FAX
  p_INCIDENT_SERVIRITY_NAME CSG_M_IB_COMMON_INFO.INCIDENT_SERVIRITY_NAME%type ;                       -- 重要度
  p_USE_CONDITION CSG_M_IB_COMMON_INFO.USE_CONDITION%type DEFAULT NULL;                               -- 利用形態
  p_USE_PERPOSE CSG_M_IB_COMMON_INFO.USE_PERPOSE%type DEFAULT NULL;                                   -- 利用目的
  p_ENDUSER_PARTY_CODE CSG_M_IB_COMMON_INFO.ENDUSER_PARTY_CODE%type DEFAULT NULL;                     -- エンドユーザ会社コード
  p_ENDUSER_PARTY_NAME CSG_M_IB_COMMON_INFO.ENDUSER_PARTY_NAME%type DEFAULT NULL;                     -- エンドユーザ会社名
  p_ENDUSER_LOCATION CSG_M_IB_COMMON_INFO.ENDUSER_LOCATION%type DEFAULT NULL;                         -- エンドユーザ住所
  p_ENDUSER_CHRG_DEPT_NAME CSG_M_IB_COMMON_INFO.ENDUSER_CHRG_DEPT_NAME%type DEFAULT NULL;             -- エンドユーザ部署名
  p_ENDUSER_CHRG_PERSON_NAME CSG_M_IB_COMMON_INFO.ENDUSER_CHRG_PERSON_NAME%type DEFAULT NULL;         -- エンドユーザ担当者名
  p_ENDUSER_TEL CSG_M_IB_COMMON_INFO.ENDUSER_TEL%type DEFAULT NULL;                                   -- エンドユーザTEL
  p_ENDUSER_FAX CSG_M_IB_COMMON_INFO.ENDUSER_FAX%type DEFAULT NULL;                                   -- エンドユーザFAX
  p_ENDUSER_MAIL_ADDRESS CSG_M_IB_COMMON_INFO.ENDUSER_MAIL_ADDRESS%type DEFAULT NULL;                 -- エンドユーザメールアドレス
  p_PROGRAM_ID CSG_M_IB_COMMON_INFO.PROGRAM_ID%type DEFAULT NULL;                                     -- 更新プログラムID
  p_PROCESS_ID CSG_M_IB_COMMON_INFO.PROCESS_ID%type DEFAULT NULL;                                     -- 処理ID
  p_CREATION_USER_ID CSG_M_IB_COMMON_INFO.CREATION_USER_ID%type ;                                     -- 作成者
  p_CREATION_DATE CSG_M_IB_COMMON_INFO.CREATION_DATE%type ;                                           -- 作成日時
  p_UPDATE_USER_ID CSG_M_IB_COMMON_INFO.UPDATE_USER_ID%type ;                                         -- 更新者
  p_UPDATE_DATE CSG_M_IB_COMMON_INFO.UPDATE_DATE%type ;                                               -- 更新日時
--******************************************************************************
-- 設置機器情報テーブルのレコードロック管理
--******************************************************************************
CURSOR c_CSG_M_IB_INFO
IS
  SELECT INSTANCE_ID,             -- インスタンス番号
    PARENT_INSTANCE_ID,           -- 親インスタンス番号
    TOP_INSTANCE_ID,              -- 最上位インスタンス番号
    INVENTORY_ITEM_CODE,          -- 品目コード
    ORG_ID,                       -- プラント
    INVENTORY_ITEM_NAME,          -- 品目名
    SERIAL_NO,                    -- シリアル番号
    MAIN_OPTION_TYPE,             -- 本体オプション区分
    IB_SYNC_STATUS,               -- IBステータス
    QUANTITY,                     -- 数量
    INSTALL_DATE,                 -- 納入日
    SALES_DATE,                   -- 売上日
    CUSTOMER_ORDER_NO,            -- 客先注文番号
    MAKER_ORDER_NO,               -- メーカー発注番号
    ORDER_NO,                     -- 受注番号
    TRANSFER_FLAG,                -- 移管品フラグ
    TRANSFER_MAINTENANCE_FROM,    -- 保守移管元
    TRANSFER_MAINTENANCE_TO,      -- 保守移管先
    TRANSFER_MAINTENANCE_DATE,    -- 保守移管日
    TRANSFER_MAINTNANCE_REASON,   -- 保守移管理由
    SALES_OWNER_CODE,             -- 販売元
    MAINTENANCE_TYPE,             -- 保守種別
    IMPORTANT_ITEM_FLAG,          -- 重要案件
    SERVICE_CONDITION,            -- サービス形態
    OUT_SOURCING_FLAG,            -- 外注フラグ
    SHIPPING_INSPECTION_FLAG,     -- 出荷検査実施フラグ
    HOST_NAME,                    -- ホスト名
    SYSTEM_NAME,                  -- システム名
    SUPPORT_START_DATE,           -- 要サポート開始日
    SUPPORT_END_DATE,             -- 要サポート終了日
    SUPPORT_INSTRUCT_CODE,        -- 要サポートフラグ
    FIRST_SALE_PARTY_CODE,        -- 初期販売会社コード
    FIRST_SALE_PARTY_LOCATION,    -- 初期販売会社住所
    FIRST_SALE_DEPT_NAME,         -- 初期販売部署名
    FIRST_SALE_TEL,               -- 初期販売会社TEL
    FIRST_SALE_FAX,               -- 初期販売会社FAX
    FIRST_SALE_PERSON_NAME,       -- 初期販売担当者名
    FIRST_SALE_MAIL_ADDRESS,      -- 初期販売メールアドレス
    FIRST_COVERAGE,               -- 初回ワランティ条件
    FIRST_MONTHS,                 -- 初回ワランティ月数
    FIRST_START_DATE,             -- 初回期間(自)
    FIRST_END_DATE,               -- 初回期間(至)
    NEXT_COVERAGE,                -- 次回ワランティ条件
    NEXT_MONTHS,                  -- 次回ワランティ月数
    NEXT_START_DATE,              -- 次回期間(自)
    NEXT_END_DATE,                -- 次回期間(至)
    AGENT_FLAG,                   -- 販社フラグ
    SECONDARY_INVENTORY_CODE,     -- 委託先コード
    BUNDLE_ITEM_CODE,             -- バンドル品目コード
    BUNDLE_ITEM_NAME,             -- バンドル品目名
    BUNDLE_SERIAL_NO,             -- バンドルシリアル
    HOST_ID,                      -- ホストID
    KEEP_WATCH_SYSTEM_ID,         -- 監視システムID
    HP_CONFIG_CODE,               -- HPコンフィグコード
    OS_TYPE,                      -- OS種別
    OS_VERSION,                   -- OSバージョン
    FIRMWARE_VERSION,             -- Firmware Version
    REVISION,                     -- リビジョン
    CPU_ROM_REVISION,             -- CPU　ROMリビジョン
    DISK_CAPACITY,                -- ディスク容量
    POWER_SUPPLY_TYPE,            -- 電源設備種類
    POWER_SUPPLY_CAPACITY,        -- 電源容量
    USE_POWER_FREQUENCY,          -- 使用電源周波数
    USE_POWER_VOLTAGE,            -- 使用電源電圧
    HAVING_EARTH_FLAG,            -- アース有無フラグ
    MAC_ADDRESS,                  -- MACアドレス
    IP_ADDRESS,                   -- IPアドレス
    LICENSE_MANAGEMENT_NO,        -- ライセンス管理番号
    SUPERINTENDE_MANAGE_NO,       -- 主管部管理番号
    LISENCE_START_DATE,           -- ライセンス開始日
    LISENCE_END_DATE,             -- ライセンス終了日
    REMOVE_ORDER_NO,              -- 移設受注番号
    REMOVE_PO_NO,                 -- 移設先発注番号
    REMOVE_DATE,                  -- 移設日
    REMOVE_REASON,                -- 移設理由
    SALES_DEPT_ORG_ID,            -- F営業販売部署コード
    SALES_DEPT_PERSON_ID,         -- F営業販売担当者コード
    PRESENT_DEPT_ORG_ID,          -- F営業現在担当部署コード
    CTC_SALESREP_PERSON_ID,       -- F営業現在担当者コード
    MAINTE_BUS_DEPT_ORG_ID,       -- 保守営業担当部署コード
    MAINTE_BUS_PERSON_ID,         -- 保守営業担当者コード
    PP_CONT_AK_NO,                -- PP契約AK番号
    PP_CONT_START_DATE,           -- 契約期間(自)
    PP_CONT_END_DATE,             -- 契約期間(至)
    SN_CHANGE_REASON,             -- シリアル番号変更理由
    X_DEPLOY_FLAG,                -- X配備対象フラグ
    ACCEPTANCE_DATE,              -- 受入日
    OUT_WARRANTY_REGISTERED_FLAG, -- 外注契約ワランティ登録済フラグ
    PROGRAM_ID,                   -- 更新プログラムID
    PROCESS_ID,                   -- 処理ID
    CREATION_USER_ID,             -- 作成者
    CREATION_DATE,                -- 作成日時
    UPDATE_USER_ID,               -- 更新者
    UPDATE_DATE                   -- 更新日時
  FROM CSG_M_IB_INFO
  WHERE INSTANCE_ID   = INPUT_INSTANCE_ID FOR UPDATE OF INSTANCE_ID,
    TOP_INSTANCE_ID nowait;
--******************************************************************************
-- 設置機器共通情報テーブルのレコードロック管理
--******************************************************************************
CURSOR c_CSG_M_IB_COMMON_INFO
IS
  SELECT TOP_INSTANCE_ID,         -- 最上位インスタンス番号
    CS_IN_CHARGE_CODE,            -- 担当CSコード
    CE_CODE,                      -- 担当CEコード
    INSTALL_CUSTOMER_CODE,        -- 設置先顧客コード
    INSTALL_LOCATION_CODE,        -- 設置先顧客住所コード
    INSTALL_LOCATION_DEPT_NAME,   -- 設置先顧客部署名
    INSTALL_LOCATION_PERSON_NAME, -- 設置先顧客担当者名
    INSTALL_LOCATION_TEL,         -- 設置先TEL
    INSTALL_LOCATION_FAX,         -- 設置先FAX
    INCIDENT_SERVIRITY_NAME,      -- 重要度
    USE_CONDITION,                -- 利用形態
    USE_PERPOSE,                  -- 利用目的
    ENDUSER_PARTY_CODE,           -- エンドユーザ会社コード
    ENDUSER_PARTY_NAME,           -- エンドユーザ会社名
    ENDUSER_LOCATION,             -- エンドユーザ住所
    ENDUSER_CHRG_DEPT_NAME,       -- エンドユーザ部署名
    ENDUSER_CHRG_PERSON_NAME,     -- エンドユーザ担当者名
    ENDUSER_TEL,                  -- エンドユーザTEL
    ENDUSER_FAX,                  -- エンドユーザFAX
    ENDUSER_MAIL_ADDRESS,         -- エンドユーザメールアドレス
    PROGRAM_ID,                   -- 更新プログラムID
    PROCESS_ID,                   -- 処理ID
    CREATION_USER_ID,             -- 作成者
    CREATION_DATE,                -- 作成日時
    UPDATE_USER_ID,               -- 更新者
    UPDATE_DATE                   -- 更新日時
  FROM CSG_M_IB_COMMON_INFO
  WHERE TOP_INSTANCE_ID = INPUT_TOP_INSTANCE_ID FOR UPDATE OF TOP_INSTANCE_ID nowait;
  BEGIN
  set_column_name              := '';
  set_value_column             := '';
  stmt_str                     := '';
  v_END_CODE                   := '0';
  p_INVENTORY_ITEM_CODE_IBI    := '';
  p_ORG_ID_IBI                 := '';
  p_BUNDLE_ITEM_CODE           := '';
  set_sysdate                  := SYSDATE;
  -- ***************************************************************************
  -- 2. 設置機器情報テーブルの追加
  -- （判定１）追加処理でパラメータの「設置機器情報」の項目が設定されている場合
  -- 【設置機器情報テーブル追加処理】
  -- ・「【マスタチェック】設置機器情報」を実施する。（エラーとなった場合は返却値として、21：異常コード(マスタ存在チェックエラー)を返却）
  -- ***************************************************************************
  IF tIB_BASE IS NOT NULL OR tIB_BASE IS NOT EMPTY THEN
    FOR i IN 1..tIB_BASE.COUNT
    LOOP
      ib_base_obj     := tIB_BASE(i);
      -- *********************************************************************
      -- マスタ存在チェック
      -- 設置機器情報の以下の項目が存在する値か否かをチェックする。
      -- ※件数が0件の場合は、マスタに存在しない値として、エラーとする。
      -- *********************************************************************
      set_column_name      := ib_base_obj.COLUM_NAME;
      set_value_column     := ib_base_obj.SET_VALUE;
      
       -- ?品目コードの存在チェック（品目マスタ）
       IF 'INVENTORY_ITEM_CODE' = set_column_name THEN
         p_INVENTORY_ITEM_CODE_IBI := set_value_column;
         IF p_ORG_ID_IBI IS NOT NULL THEN
            IF FUNC_SNV_M_ITEM_CHK(P_INVENTORY_ITEM_CODE_IBI, p_ORG_ID_IBI) = 1 THEN
              PRAM_PLACE_HOLDER := 'マスタに存在しない品目コードが設定されています。';
              RAISE MASTER_EXCEPTION;
            END IF;
         END IF;
       ELSIF 'ORG_ID' = set_column_name THEN
         p_ORG_ID_IBI := set_value_column;
         IF p_INVENTORY_ITEM_CODE_IBI IS NOT NULL THEN
            IF FUNC_SNV_M_ITEM_CHK(P_INVENTORY_ITEM_CODE_IBI, p_ORG_ID_IBI) = 1 THEN
              PRAM_PLACE_HOLDER := 'マスタに存在しない品目コードが設定されています。';
              RAISE MASTER_EXCEPTION;
            END IF;
         END IF;
       END IF;
       
       IF set_value_column IS NOT NULL THEN
         -- ?本体オプション区分（汎用マスタ（オプション区分））
         IF 'MAIN_OPTION_TYPE' = set_column_name THEN
          IF FUNC_SNV_M_GNRC_SNV_CHK('CSG_CONFIG_TYPE',set_value_column) = 1 THEN
             PRAM_PLACE_HOLDER := 'マスタに存在しない本体オプション区分が設定されています。';
             RAISE MASTER_EXCEPTION;
          END IF;
         END IF;
         
         -- ?IBステータス（汎用マスタ（設置機器ステータス））
         IF 'IB_SYNC_STATUS' = set_column_name THEN
          IF FUNC_SNV_M_GNRC_SNV_CHK('CSG_INSTANCE_STATUSES',set_value_column) = 1 THEN
             PRAM_PLACE_HOLDER := 'マスタに存在しないIBステータスが設定されています。';
             RAISE MASTER_EXCEPTION;
          END IF;
         END IF;
         
         -- ?販売元（汎用マスタ（設置機器使用会社））
         IF 'SALES_OWNER_CODE' = set_column_name THEN
          IF FUNC_SNV_M_GNRC_SNV_CHK('CSG_INSTANCE_USE_COMPANY',set_value_column, 2) = 1 THEN
             PRAM_PLACE_HOLDER := 'マスタに存在しない販売元が設定されています。';
             RAISE MASTER_EXCEPTION;
          END IF;
         END IF;
         
         -- ?保守種別（汎用マスタ（設置機器使用会社））
         IF 'MAINTENANCE_TYPE' = set_column_name THEN
          IF FUNC_SNV_M_GNRC_SNV_CHK('CSG_INSTANCE_USE_COMPANY',set_value_column, 1) = 1 THEN
             PRAM_PLACE_HOLDER := 'マスタに存在しない保守種別が設定されています。';
             RAISE MASTER_EXCEPTION;
          END IF;
         END IF;
         
         -- ?サービス形態（汎用マスタ-ERP（サービス形態））
         IF 'SERVICE_CONDITION' = set_column_name THEN
          IF FUNC_SNV_M_GNRC_SNV_CHK('ZMMDESERVICE',set_value_column) = 1 THEN
             PRAM_PLACE_HOLDER := 'マスタに存在しないサービス形態が設定されています。';
             RAISE MASTER_EXCEPTION;
          END IF;
         END IF;
         
         -- ?外注フラグ（汎用マスタ（外注フラグ））
         IF 'OUT_SOURCING_FLAG' = set_column_name THEN
          IF FUNC_SNV_M_GNRC_SNV_CHK('SBCN_FLAG',set_value_column) = 1 THEN
             PRAM_PLACE_HOLDER := 'マスタに存在しない外注フラグが設定されています。';
             RAISE MASTER_EXCEPTION;
          END IF;
         END IF;
         
         -- ?要サポートフラグ（汎用マスタ（要サポートフラグ））
         IF 'SUPPORT_INSTRUCT_CODE' = set_column_name THEN
          IF FUNC_SNV_M_GNRC_SNV_CHK('CSG_SUPPORT_INSTRUCT_CODE',set_value_column) = 1 THEN
             PRAM_PLACE_HOLDER := 'マスタに存在しない要サポートフラグが設定されています。';
             RAISE MASTER_EXCEPTION;
          END IF;
         END IF;
         
         -- ?初期販売会社コード
         IF 'FIRST_SALE_PARTY_CODE' = set_column_name THEN
          IF FUNC_SNV_M_CUST_CHK(set_value_column) = 1 THEN
             PRAM_PLACE_HOLDER := 'マスタに存在しない初期販売会社コードが設定されています。';
             RAISE MASTER_EXCEPTION;
          END IF;
         END IF;
         
         -- ?初回ワランティ条件
         IF 'FIRST_COVERAGE' = set_column_name THEN
          IF FUNC_SNV_M_GNRC_SNV_CHK('ZMMDEFIRST_WT_COND',set_value_column) = 1 THEN
             PRAM_PLACE_HOLDER := 'マスタに存在しない初回ワランティ条件が設定されています。';
             RAISE MASTER_EXCEPTION;
          END IF;
         END IF;
         
         -- ?次回ワランティ条件
         IF 'NEXT_COVERAGE' = set_column_name THEN
          IF FUNC_SNV_M_GNRC_SNV_CHK('ZMMDENEXT_WT_COND',set_value_column) = 1 THEN
             PRAM_PLACE_HOLDER := 'マスタに存在しない次回ワランティ条件が設定されています。';
             RAISE MASTER_EXCEPTION;
          END IF;
         END IF;
         
         -- ?委託先コード
         IF 'SECONDARY_INVENTORY_CODE' = set_column_name THEN
          IF FUNC_CSL_M_DEPO_CHK(set_value_column) = 1 THEN
             PRAM_PLACE_HOLDER := 'マスタに存在しない委託先コードが設定されています。';
             RAISE MASTER_EXCEPTION;
          END IF;
         END IF;
         
         -- ?販社フラグ（汎用マスタ（設置機器使用会社））
         IF 'AGENT_FLAG' = set_column_name THEN
          IF FUNC_SNV_M_GNRC_SNV_CHK('CSG_INSTANCE_USE_COMPANY',set_value_column, 3) = 1 THEN
             PRAM_PLACE_HOLDER := 'マスタに存在しない販社フラグが設定されています。';
             RAISE MASTER_EXCEPTION;
          END IF;
         END IF;
         
         -- ?OS種別
         IF 'OS_TYPE' = set_column_name THEN
          IF FUNC_SNV_M_GNRC_SNV_CHK('CSG_OS_TYPE',set_value_column) = 1 THEN
             PRAM_PLACE_HOLDER := 'マスタに存在しないOS種別が設定されています。';
             RAISE MASTER_EXCEPTION;
          END IF;
         END IF;
         
         -- ?電源設備種類
         IF 'POWER_SUPPLY_TYPE' = set_column_name THEN
          IF FUNC_SNV_M_GNRC_SNV_CHK('CSG_POWER_SUPPLY_TYPE',set_value_column) = 1 THEN
             PRAM_PLACE_HOLDER := 'マスタに存在しない電源設置種類が設定されています。';
             RAISE MASTER_EXCEPTION;
          END IF;
         END IF;

         -- ?使用電源周波数
         IF 'USE_POWER_FREQUENCY' = set_column_name THEN
          IF FUNC_SNV_M_GNRC_SNV_CHK('CSG_USE_POWER_FREQUENCY',set_value_column) = 1 THEN
             PRAM_PLACE_HOLDER := 'マスタに存在しない使用電源周波数が設定されています。';
             RAISE MASTER_EXCEPTION;
          END IF;
         END IF;
         
         -- ?F営業販売部署コード
         IF 'SALES_DEPT_ORG_ID' = set_column_name THEN
          IF FUNC_SNV_M_DPT_CHK(set_value_column, 1) = 1 THEN
             PRAM_PLACE_HOLDER := 'マスタに存在しないF営業販売部署コードが設定されています。';
             RAISE MASTER_EXCEPTION;
          END IF;
         END IF;
         
         -- ?F営業現在部署コード
         IF 'PRESENT_DEPT_ORG_ID' = set_column_name THEN
          IF FUNC_SNV_M_DPT_CHK(set_value_column, 2) = 1 THEN
             PRAM_PLACE_HOLDER := 'マスタに存在しないF営業現在担当部署コードが設定されています。';
             RAISE MASTER_EXCEPTION;
          END IF;
         END IF;

         -- 21.保守営業担当部署
         IF 'MAINTE_BUS_DEPT_ORG_ID' = set_column_name THEN
          IF FUNC_SNV_M_DPT_CHK(set_value_column, 1) = 1 THEN
             PRAM_PLACE_HOLDER := 'マスタに存在しない保守営業担当部署コードが設定されています。';
             RAISE MASTER_EXCEPTION;
          END IF;
         END IF;

         -- 22.F営業販売担当者コード
         IF 'SALES_DEPT_PERSON_ID' = set_column_name THEN
          IF FUNC_SNV_M_EMP_CHK(set_value_column, 1) = 1 THEN
             PRAM_PLACE_HOLDER := 'マスタに存在しないF営業販売担当者コードが設定されています。';
             RAISE MASTER_EXCEPTION;
          END IF;
         END IF;

         -- 23.F営業現在担当者コード
         IF 'CTC_SALESREP_PERSON_ID' = set_column_name THEN
          IF FUNC_SNV_M_EMP_CHK(set_value_column, 2) = 1 THEN
             PRAM_PLACE_HOLDER := 'マスタに存在しないF営業現在担当者コードが設定されています。';
             RAISE MASTER_EXCEPTION;
          END IF;
         END IF;

         -- 24.保守営業担当者コード
         IF 'MAINTE_BUS_PERSON_ID' = set_column_name THEN
          IF FUNC_SNV_M_EMP_CHK(set_value_column, 2) = 1 THEN
             PRAM_PLACE_HOLDER := 'マスタに存在しない保守営業担当者コードが設定されています。';
             RAISE MASTER_EXCEPTION;
          END IF;
         END IF;
       END IF;

       -- ?バンドル品目コード
       IF 'BUNDLE_ITEM_CODE' = set_column_name THEN
         p_BUNDLE_ITEM_CODE := set_value_column;
         IF p_ORG_ID_IBI IS NOT NULL AND p_BUNDLE_ITEM_CODE IS NOT NULL THEN
           IF FUNC_SNV_M_ITEM_CHK(p_BUNDLE_ITEM_CODE, p_ORG_ID_IBI) = 1 THEN
             PRAM_PLACE_HOLDER := 'マスタに存在しないバンドル品目コードが設定されています。';
             RAISE MASTER_EXCEPTION;
           END IF;
         ELSIF p_ORG_ID_IBI IS NOT NULL AND p_BUNDLE_ITEM_CODE IS NULL THEN
           --NULLへ更新する場合に、後続処理で存在チェックを行わないよう設定を行う
           p_BUNDLE_ITEM_CODE_NULL_FLAG := 'Y';
         END IF;
       END IF;
    END LOOP;
  END IF;
  -- ***************************************************************************
  -- 4. 設置機器共通情報テーブルの追加
  -- （判定１）追加処理でパラメータの「設置機器共通情報」の項目が設定されている場合
  -- 【設置機器共通情報テーブル追加処理】
  -- ・「【マスタチェック】設置機器共通情報」を実施する。（エラーとなった場合は返却値として、21：異常コード(マスタ存在チェックエラー)を返却）
  -- ***************************************************************************
  IF tIB_COMMON IS NOT NULL OR tIB_COMMON IS NOT EMPTY THEN
    FOR i IN 1..tIB_COMMON.COUNT
    LOOP
      ib_common_obj   := tIB_COMMON(i);
      -- *********************************************************************
      -- マスタ存在チェック
      -- 設置機器共通情報の以下の項目が存在する値か否かをチェックする。
      -- ※件数が0件の場合は、マスタに存在しない値として、エラーとする。（パラメータのエラーメッセージに下記内容を設定して、終了コードを21で返却する。）
      -- *********************************************************************
      set_column_name     := ib_common_obj.COLUM_NAME;
      set_value_column    := ib_common_obj.SET_VALUE;
      
      IF set_value_column IS NOT NULL THEN
        -- ?担当CSコードの存在チェック（グループマスタ）
        IF 'CS_IN_CHARGE_CODE' = set_column_name THEN
         IF FUNC_CSG_M_GROUP_MANA_CHK(set_value_column) = 1 THEN
            PRAM_PLACE_HOLDER := 'マスタに存在しない担当CSコードが設定されています。';
            RAISE MASTER_EXCEPTION;
         END IF;
        END IF;
  
        -- ?担当CEコード
        IF 'CE_CODE' = set_column_name THEN
         IF FUNC_SNV_M_EMP_CHK(set_value_column, 3) = 1 THEN
            PRAM_PLACE_HOLDER := 'マスタに存在しない担当CEコードが設定されています。';
            RAISE MASTER_EXCEPTION;
         END IF;
        END IF;
  
        -- ?設置先顧客コード
        IF 'INSTALL_CUSTOMER_CODE' = set_column_name THEN
         IF FUNC_SNV_M_CUST_CHK(set_value_column) = 1 THEN
            PRAM_PLACE_HOLDER := 'マスタに存在しない設置先顧客コードが設定されています。';
            RAISE MASTER_EXCEPTION;
         END IF;
        END IF;
  
        -- ?設置先顧客住所コード
        IF 'INSTALL_LOCATION_CODE' = set_column_name THEN
         IF FUNC_CSG_M_IB_ADDRESS_CHK(set_value_column) = 1 THEN
            PRAM_PLACE_HOLDER := 'マスタに存在しない設置先住所コードが設定されています。';
            RAISE MASTER_EXCEPTION;
         END IF;
        END IF;
  
        -- ?重要度（汎用マスタ（重要度））
        IF 'INCIDENT_SERVIRITY_NAME' = set_column_name THEN
         IF FUNC_SNV_M_GNRC_SNV_CHK('CSG_IMPORTANCE_LEVEL', set_value_column) = 1 THEN
            PRAM_PLACE_HOLDER := 'マスタに存在しない重要度が設定されています。';
            RAISE MASTER_EXCEPTION;
         END IF;
        END IF;
  
        -- ?エンドユーザ会社コード
        IF 'ENDUSER_PARTY_CODE' = set_column_name THEN
         IF FUNC_SNV_M_CUST_CHK(set_value_column) = 1 THEN
            PRAM_PLACE_HOLDER := 'マスタに存在しないエンドユーザ会社コードが設定されています。';
            RAISE MASTER_EXCEPTION;
         END IF;
        END IF;
      END IF;
    END LOOP;
  END IF;
  -- ***************************************************************************
  set_column_name     := '';
  set_value_column    := '';
  -- ***************************************************************************
  -- 設置機器情報・設置機器共通情報の追加・更新における以下の内容を設定する。
  -- 0 ：追加
  -- ***************************************************************************
  IF PROC_TYPE = 0 THEN
    -- *************************************************************************
    -- 品目コードの追加チェック
    -- 追加処理の場合
    -- ①品目コードが設定されていてプラントが設定されていない場合にエラー
    -- ②プラントが設定されていて品目コードが設定されていない場合にエラー
    -- ③バンドル品目コードが設定されていて、プラントが設定されていない場合にエラー
    -- ※品目コードがNULLかつプラントがNULLの場合はインサート時にNOTNULL制約でエラーとなる
    -- *************************************************************************
    IF p_INVENTORY_ITEM_CODE_IBI IS NOT NULL AND p_ORG_ID_IBI IS NULL THEN
      PRAM_PLACE_HOLDER := 'マスタに存在しない品目コードが設定されています。';
      RAISE MASTER_EXCEPTION;
    END IF;
    
    IF p_ORG_ID_IBI IS NOT NULL AND p_INVENTORY_ITEM_CODE_IBI IS NULL THEN
      PRAM_PLACE_HOLDER := 'マスタに存在しない品目コードが設定されています。';
      RAISE MASTER_EXCEPTION;
    END IF;
    
    IF p_BUNDLE_ITEM_CODE IS NOT NULL AND p_ORG_ID_IBI IS NULL THEN
      PRAM_PLACE_HOLDER := 'マスタに存在しないバンドル品目コードが設定されています。';
      RAISE MASTER_EXCEPTION;
    END IF;
    -- *************************************************************************
    -- 追加処理の場合、インスタンス番号はNULLとなります。
    -- Oracleシーケンスから新規に払い出す。
    -- *************************************************************************
    SELECT CSG_M_INSTANCE_ID_SEQ.NEXTVAL
    INTO v_INSTANCE_ID_IBI
    FROM DUAL;
    --**************************************************************************
    -- インスタンス番号、親インスタンス番号、最上位インスタンス番号にOracleシーケンス番号を設定（同値）
    -- (親インスタンス番号、最上位インスタンスが設置機器情報に設定されている場合は、後処理で上書き)
    --**************************************************************************
    p_INSTANCE_ID_IBI        := v_INSTANCE_ID_IBI;
    p_PARENT_INSTANCE_ID_IBI := v_INSTANCE_ID_IBI;
    p_TOP_INSTANCE_ID_IBI    := v_INSTANCE_ID_IBI;
    
    -- *************************************************************************
    -- 1. 階層判断
    -- 1.インスタンス階層チェックを行う。
    -- パラメータ.最上位インスタンス番号＝パラメータ.インスタンス番号　の場合
    -- ⇒最上位インスタンス（単独インスタンス）とする。
    -- *************************************************************************
    -- *************************************************************************
    -- 2. 設置機器情報テーブルの追加
    -- （判定１）追加処理でパラメータの「設置機器情報」の項目が設定されている場合
    -- 【設置機器情報テーブル追加処理】
    -- ・設置機器情報テーブルの追加
    -- *************************************************************************
      BEGIN
        PRAM_PLACE_HOLDER := '設置機器情報の挿入';
        table_name        := 'CSG_M_IB_INFO';

        IF (tIB_BASE IS NOT NULL OR tIB_BASE IS NOT EMPTY) THEN
          FOR i IN 1..tIB_BASE.COUNT
          LOOP
            ib_base_obj    := tIB_BASE(i);
            -- カラム名が「親インスタンス番号」の場合
            IF ib_base_obj.COLUM_NAME = 'PARENT_INSTANCE_ID' THEN
               IF (LENGTH(ib_base_obj.SET_VALUE) != 0 ) THEN
                   -- 親インスタンス番号の上書き
                   p_PARENT_INSTANCE_ID_IBI :=  ib_base_obj.SET_VALUE;
               END IF;
            -- カラム名が「最上位インスタンス番号」の場合
            ELSIF ib_base_obj.COLUM_NAME = 'TOP_INSTANCE_ID' THEN
               IF (LENGTH(ib_base_obj.SET_VALUE) != 0 ) THEN
                   -- 最上位インスタンス番号の上書き
                   p_TOP_INSTANCE_ID_IBI :=  ib_base_obj.SET_VALUE;
               END IF;
            ELSE
               set_column_name     := set_column_name || ib_base_obj.COLUM_NAME;
               set_value_column    := set_value_column || ':' || ib_base_obj.COLUM_NAME;
               IF i < tIB_BASE.COUNT THEN 
                  set_column_name  := set_column_name || ', ';
                  set_value_column := set_value_column || ', ';
               END IF;
            END IF;
          END LOOP;
          -- 更新プログラムID || 処理ID || 作成者 || 作成日時 || 更新者 || 更新日時のカラム名
          set_column_name     := 'INSTANCE_ID, PARENT_INSTANCE_ID, TOP_INSTANCE_ID,' || set_column_name || ', ' || 'PROGRAM_ID, PROCESS_ID, CREATION_USER_ID, CREATION_DATE, UPDATE_USER_ID, UPDATE_DATE';
          -- 更新プログラムID || 処理ID || 作成者 || 作成日時 || 更新者 || 更新日時の更新データ
          set_value_column    := ':INPUT_INSTANCE_ID, :PARENT_INSTANCE_ID, :TOP_INSTANCE_ID,' || set_value_column || ', :PROGRAM_ID, :PROCESS_ID, :CREATION_USER_ID, :CREATION_DATE, :UPDATE_USER_ID, :UPDATE_DATE';
          -- 設置機器情報テーブルの追加
          stmt_str := 'INSERT INTO ' || table_name || '(' || set_column_name || ') VALUES ('|| set_value_column ||')';
          cur_hdl  := DBMS_SQL.OPEN_CURSOR;
          DBMS_SQL.PARSE(cur_hdl, stmt_str, DBMS_SQL.NATIVE);
          -- supply binds
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':INPUT_INSTANCE_ID', p_INSTANCE_ID_IBI);
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':PARENT_INSTANCE_ID', p_PARENT_INSTANCE_ID_IBI);
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':TOP_INSTANCE_ID', p_TOP_INSTANCE_ID_IBI);
          FOR i IN 1..tIB_BASE.COUNT
          LOOP
            ib_base_obj := tIB_BASE(I);
            IF ib_base_obj.COLUM_NAME NOT IN ('INSTANCE_ID','PARENT_INSTANCE_ID','TOP_INSTANCE_ID') THEN
              DBMS_SQL.BIND_VARIABLE(CUR_HDL, ':' || ib_base_obj.COLUM_NAME, ib_base_obj.SET_VALUE);
            END IF;
          END LOOP;
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':PROGRAM_ID', PROGRAM_ID);
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':PROCESS_ID', PROCESS_ID);
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':CREATION_USER_ID', USER_ID);
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':CREATION_DATE', set_sysdate);
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':UPDATE_USER_ID', USER_ID);
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':UPDATE_DATE', set_sysdate);
          rows_processed := dbms_sql.execute(cur_hdl);
          -- execute
          DBMS_SQL.CLOSE_CURSOR(cur_hdl);
        END IF;
        -- *********************************************************************
        -- 4. 設置機器共通情報テーブルの追加
        -- （判定１）追加処理でパラメータの「設置機器共通情報」の項目が設定されている場合
        -- 【設置機器共通情報テーブル追加処理】
        -- ・設置機器共通情報テーブルの追加
        -- *********************************************************************
        set_column_name       := '';
        set_value_column      := '';
        stmt_str              := '';
        PRAM_PLACE_HOLDER     := '設置機器共通情報の挿入';
        table_name            := 'CSG_M_IB_COMMON_INFO';
        IF tIB_COMMON IS NOT NULL OR tIB_COMMON IS NOT EMPTY THEN
          FOR i IN 1..tIB_COMMON.COUNT
          LOOP
            ib_common_obj  := tIB_COMMON(i);
            -- カラム名が「最上位インスタンス番号」の場合
            IF ib_common_obj.COLUM_NAME = 'TOP_INSTANCE_ID' THEN
               -- 最上位インスタンス番号の上書き
               p_TOP_INSTANCE_ID_IBI :=  ib_base_obj.SET_VALUE;
            ELSE
               set_column_name     := set_column_name || ib_common_obj.COLUM_NAME;
               set_value_column    := set_value_column || ':' || ib_common_obj.COLUM_NAME;
               IF i < tIB_COMMON.COUNT THEN 
                 set_column_name   := set_column_name || ', ';
                 set_value_column  := set_value_column || ', ';
               END IF;
            END IF;
          END LOOP;
          -- 更新プログラムID || 処理ID || 作成者 || 作成日時 || 更新者 || 更新日時のカラム名
          set_column_name     := 'TOP_INSTANCE_ID, ' || set_column_name || ', ' || 'PROGRAM_ID, PROCESS_ID, CREATION_USER_ID, CREATION_DATE, UPDATE_USER_ID, UPDATE_DATE';
          -- 更新プログラムID || 処理ID || 作成者 || 作成日時 || 更新者 || 更新日時の更新データ
          set_value_column    := ':TOP_INSTANCE_ID,' || set_value_column || ', :PROGRAM_ID, :PROCESS_ID, :CREATION_USER_ID, :CREATION_DATE, :UPDATE_USER_ID, :UPDATE_DATE';
          -- 設置機器共通情報テーブルの追加
          stmt_str := 'INSERT INTO ' || table_name || '(' || set_column_name || ') VALUES ('|| set_value_column ||')';
          cur_hdl  := DBMS_SQL.OPEN_CURSOR;
          DBMS_SQL.PARSE(cur_hdl, stmt_str, DBMS_SQL.NATIVE);
          -- supply binds
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':TOP_INSTANCE_ID', p_TOP_INSTANCE_ID_IBI);
          FOR i IN 1..tIB_COMMON.COUNT
          LOOP
            IB_COMMON_OBJ := TIB_COMMON(I);
            IF ib_common_obj.COLUM_NAME NOT IN ('TOP_INSTANCE_ID') THEN
              DBMS_SQL.BIND_VARIABLE(cur_hdl, ':' || ib_common_obj.COLUM_NAME, ib_common_obj.SET_VALUE);
            END IF;
          END LOOP;
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':PROGRAM_ID', PROGRAM_ID);
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':PROCESS_ID', PROCESS_ID);
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':CREATION_USER_ID', USER_ID);
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':CREATION_DATE', set_sysdate);
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':UPDATE_USER_ID', USER_ID);
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':UPDATE_DATE', set_sysdate);
          rows_processed := dbms_sql.execute(cur_hdl);
          -- execute
          DBMS_SQL.CLOSE_CURSOR(cur_hdl);
        END IF;
      END;
--    END IF;
    --**************************************************************************
    -- 追加・・・払い出したインスタンス番号
    -- 更新・・・更新したインスタンス番号
    --**************************************************************************
    OUT_INSTANCE_ID := p_INSTANCE_ID_IBI;
    -- *************************************************************************
    -- 設置機器情報・設置機器共通情報の追加・更新における以下の内容を設定する。
    -- 10：更新
    -- *************************************************************************
  ELSIF PROC_TYPE = 10 THEN
    -- *************************************************************************
    -- 1. 階層判断
    -- 1.インスタンス階層チェックを行う。
    -- パラメータ.最上位インスタンス番号＝パラメータ.インスタンス番号　の場合
    -- ⇒最上位インスタンス（単独インスタンス）とする。
    -- *************************************************************************
    IF INPUT_INSTANCE_ID = INPUT_TOP_INSTANCE_ID THEN
      -- *************************************************************************
      -- 3. 設置機器情報テーブルの更新
      -- （判定１）更新処理でパラメータの「設置機器情報」の項目が設定されている場合
      -- （判定２）更新処理かつ最上位インスタンス（単独インスタンス）で「設置機器情報」の項目が設定されていないが「設置機器共通情報」の項目が設定されている場合
      -- 【設置機器情報テーブル更新処理】
      -- ・設置機器情報テーブルの排他取得
      -- ・設置機器情報テーブルの更新　　　　　※（判定2）の場合は更新プログラムID、処理ID、更新日時、更新者のみ更新。
      -- ・設置機器情報履歴テーブルの追加
      -- *************************************************************************
      BEGIN
        IF (tIB_BASE IS NULL OR tIB_BASE IS EMPTY) AND 
           (tIB_COMMON IS NULL OR tIB_COMMON IS EMPTY) THEN
           PRAM_PLACE_HOLDER := '設置機器情報・設置機器共通情報の追加・更新に失敗しました。設置機器情報もしくは設置機器共通情報の変更項目が設定されていません。';
          RAISE PRAM_EXCEPTION;
        END IF;
        
        IF (tIB_BASE IS NOT NULL OR tIB_BASE IS NOT EMPTY) OR
           ((tIB_BASE IS NULL OR tIB_BASE IS EMPTY) AND (tIB_COMMON IS NOT NULL OR tIB_COMMON IS NOT EMPTY)) THEN
          -- *******************************************************************
          -- ・設置機器情報履歴テーブルの追加
          -- *******************************************************************
          FOR row_CSG_M_IB_INFO IN c_CSG_M_IB_INFO
            LOOP
            -- *************************************************************************
            -- 品目コードの追加チェック
            -- 更新処理の場合
            -- ①品目コードが設定されていてプラントが設定されていない場合に、引数の品目コードとDBのプラントで存在チェックを行う
            -- ②プラントが設定されていて品目コードが設定されていない場合に、引数のプラントとDBの品目コードで存在チェックを行う
            -- ③バンドル品目コードにNULL以外が設定されているか、設定されていない場合で、プラントが設定されていない場合に、
            -- 　引数のバンドル品目コードとDBのプラントで存在チェックを行う
            -- ※品目コードがNULLかつプラントがNULLの場合はインサート時にNOTNULL制約でエラーとなる
            -- *************************************************************************
            IF p_INVENTORY_ITEM_CODE_IBI IS NOT NULL AND p_ORG_ID_IBI IS NULL THEN
              IF FUNC_SNV_M_ITEM_CHK(P_INVENTORY_ITEM_CODE_IBI, row_CSG_M_IB_INFO.ORG_ID) = 1 THEN
                PRAM_PLACE_HOLDER := 'マスタに存在しない品目コードが設定されています。';
                RAISE MASTER_EXCEPTION;
              END IF;
            END IF;
    
            IF p_ORG_ID_IBI IS NOT NULL AND p_INVENTORY_ITEM_CODE_IBI IS NULL THEN
              IF FUNC_SNV_M_ITEM_CHK(row_CSG_M_IB_INFO.INVENTORY_ITEM_CODE, p_ORG_ID_IBI) = 1 THEN
                PRAM_PLACE_HOLDER := 'マスタに存在しない品目コードが設定されています。';
                RAISE MASTER_EXCEPTION;
              END IF;
              IF row_CSG_M_IB_INFO.BUNDLE_ITEM_CODE IS NOT NULL THEN
                IF FUNC_SNV_M_ITEM_CHK(row_CSG_M_IB_INFO.BUNDLE_ITEM_CODE, p_ORG_ID_IBI) = 1 THEN
                  PRAM_PLACE_HOLDER := 'マスタに存在しないバンドル品目コードが設定されています。';
                  RAISE MASTER_EXCEPTION;
                END IF;
              END IF;
            END IF;
    
            IF p_BUNDLE_ITEM_CODE IS NOT NULL AND p_ORG_ID_IBI IS NULL AND p_BUNDLE_ITEM_CODE_NULL_FLAG = 'N' THEN
              IF FUNC_SNV_M_ITEM_CHK(p_BUNDLE_ITEM_CODE, row_CSG_M_IB_INFO.ORG_ID) = 1 THEN
                PRAM_PLACE_HOLDER := 'マスタに存在しないバンドル品目コードが設定されています。';
                RAISE MASTER_EXCEPTION;
              END IF;
            END IF;
            -- *************************************************************************
            PRAM_PLACE_HOLDER     := '設置機器情報履歴の挿入';
            table_name            := 'CSG_M_IB_INFO_HIS';
            INSERT
            INTO CSG_M_IB_INFO_HIS
              (
                INSTANCE_HIS_ID,              --インスタンス履歴ID
                INSTANCE_ID,                  --インスタンス番号
                PARENT_INSTANCE_ID,           --親インスタンス番号
                TOP_INSTANCE_ID,              --最上位インスタンス番号
                INVENTORY_ITEM_CODE,          --品目コード
                INVENTORY_ITEM,               --品目
                ORG_ID,                       --プラント
                INVENTORY_ITEM_NAME,          --品目名
                SERIAL_NO,                    --シリアル番号
                MAIN_OPTION_TYPE,             --本体オプション区分
                MAIN_OPTION_TYPE_NAME,        --本体オプション区分名
                IB_SYNC_STATUS,               --IBステータス
                IB_SYNC_STATUS_NAME,          --IBステータス名
                QUANTITY,                     --数量
                INSTALL_DATE,                 --納入日
                SALES_DATE,                   --売上日
                CUSTOMER_ORDER_NO,            --客先注文番号
                MAKER_ORDER_NO,               --メーカー発注番号
                ORDER_NO,                     --受注番号
                TRANSFER_FLAG,                --移管品フラグ
                TRANSFER_MAINTENANCE_FROM,    --保守移管元
                TRANSFER_MAINTENANCE_TO,      --保守移管先
                TRANSFER_MAINTENANCE_DATE,    --保守移管日
                TRANSFER_MAINTNANCE_REASON,   --保守移管理由
                SALES_OWNER_CODE,             --販売元
                SALES_OWNER_CODE_NAME,        --販売元名
                MAINTENANCE_TYPE,             --保守種別
                MAINTENANCE_TYPE_NAME,        --保守種別名
                IMPORTANT_ITEM_FLAG,          --重要案件
                SERVICE_CONDITION,            --サービス形態
                SERVICE_CONDITION_NAME,       --サービス形態名
                OUT_SOURCING_FLAG,            --外注フラグ
                OUT_SOURCING_FLAG_NAME,       --外注フラグ名
                SHIPPING_INSPECTION_FLAG,     --出荷検査実施フラグ
                HOST_NAME,                    --ホスト名
                SYSTEM_NAME,                  --システム名
                SUPPORT_START_DATE,           --要サポート開始日
                SUPPORT_END_DATE,             --要サポート終了日
                SUPPORT_INSTRUCT_CODE,        --要サポートフラグ
                SUPPORT_INSTRUCT_NAME,        --要サポートフラグ名
                FIRST_SALE_PARTY_CODE,        --初期販売会社コード
                FIRST_SALE_PARTY_NAME,        --初期販売会社名
                FIRST_SALE_PARTY_LOCATION,    --初期販売会社住所
                FIRST_SALE_DEPT_NAME,         --初期販売部署名
                FIRST_SALE_TEL,               --初期販売会社TEL
                FIRST_SALE_FAX,               --初期販売会社FAX
                FIRST_SALE_PERSON_NAME,       --初期販売担当者名
                FIRST_SALE_MAIL_ADDRESS,      --初期販売メールアドレス
                FIRST_COVERAGE,               --初回ワランティ条件
                FIRST_COVERAGE_COMMENT,       --初回ワランティ条件(摘要)
                FIRST_MONTHS,                 --初回ワランティ月数
                FIRST_START_DATE,             --初回期間(自)
                FIRST_END_DATE,               --初回期間(至)
                NEXT_COVERAGE,                --次回ワランティ条件
                NEXT_COVERAGE_COMMENT,        --次回ワランティ条件(摘要)
                NEXT_MONTHS,                  --次回ワランティ月数
                NEXT_START_DATE,              --次回期間(自)
                NEXT_END_DATE,                --次回期間(至)
--                COVERAGE_START_BASE,          --ワランティ開始日基準
--                COVERAGE_START_BASE_COMMENT,  --ワランティ開始日基準(摘要)
                AGENT_FLAG,                   --販社フラグ
                AGENT_FLAG_NAME,              --販社名
                SECONDARY_INVENTORY_CODE,     --委託先コード
                SECONDARY_INVENTORY_NAME,     --委託先名
                BUNDLE_ITEM_CODE,             --バンドル品目コード
                BUNDLE_ITEM,                  --バンドル品目
                BUNDLE_ITEM_NAME,             --バンドル品目名
                BUNDLE_SERIAL_NO,             --バンドルシリアル
                HOST_ID,                      --ホストID
                KEEP_WATCH_SYSTEM_ID,         --監視システムID
                HP_CONFIG_CODE,               --HPコンフィグコード
                OS_TYPE,                      --OS種別
                OS_TYPE_NAME,                 --OS種別名
                OS_VERSION,                   --OSバージョン
                FIRMWARE_VERSION,             --Firmware Version
                REVISION,                     --リビジョン
                CPU_ROM_REVISION,             --CPU　ROMリビジョン
                DISK_CAPACITY,                --ディスク容量
                POWER_SUPPLY_TYPE,            --電源設備種類
                POWER_SUPPLY_TYPE_NAME,       --電源設備種類名
                POWER_SUPPLY_CAPACITY,        --電源容量
                USE_POWER_FREQUENCY,          --使用電源周波数
                USE_POWER_FREQUENCY_NAME,     --使用電源周波数名
--                USE_POWER_VOLTAGE,             --使用電源電圧
                HAVING_EARTH_FLAG,            --アース有無フラグ
                MAC_ADDRESS,                  --MACアドレス
                IP_ADDRESS,                   --IPアドレス
                LICENSE_MANAGEMENT_NO,        --ライセンス管理番号
                SUPERINTENDE_MANAGE_NO,       --主管部管理番号
                LISENCE_START_DATE,           --ライセンス開始日
                LISENCE_END_DATE,             --ライセンス終了日
                REMOVE_ORDER_NO,              --移設受注番号
                REMOVE_PO_NO,                 --移設先発注番号
                REMOVE_DATE,                  --移設日
                REMOVE_REASON,                --移設理由
                SALES_DEPT_ORG_ID,            --F営業販売部署コード
                SALES_DEPT_ORG_NAME,          --F営業販売部署名
                SALES_DEPT_PERSON_ID,         --F営業販売担当者コード
                SALES_DEPT_PERSON_NAME,       --F営業販売担当者名
                PRESENT_DEPT_ORG_ID,          --F営業現在担当部署コード
                PRESENT_DEPT_ORG_NAME,        --F営業現在担当部署名
                CTC_SALESREP_PERSON_ID,       --F営業現在担当者コード
                CTC_SALESREP_PERSON_NAME,     --F営業現在担当者名
                MAINTE_BUS_DEPT_ORG_ID,       --保守営業担当部署コード
                MAINTE_BUS_DEPT_ORG_NAME,     --保守営業担当部署名
                MAINTE_BUS_PERSON_ID,         --保守営業担当者コード
                MAINTE_BUS_PERSON_NAME,       --保守営業担当者名
                PP_CONT_AK_NO,                --PP契約AK番号
                PP_CONT_START_DATE,           --契約期間(自)
                PP_CONT_END_DATE,             --契約期間(至)
                SN_CHANGE_REASON,             --シリアル番号変更理由
                X_DEPLOY_FLAG,                --X配備対象フラグ
                ACCEPTANCE_DATE,              --受入日
                OUT_WARRANTY_REGISTERED_FLAG, --外注契約ワランティ登録済フラグ
                PROGRAM_ID,                   --更新プログラムID
                PROCESS_ID,                   --処理ID
                CREATION_USER_ID,             --作成者
                CREATION_DATE,                --作成日時
                UPDATE_USER_ID,               --更新者
                UPDATE_DATE                   --更新日時
              )
              VALUES
              (
                CSG_M_IB_HIS_ID_SEQ.NEXTVAL,                    --インスタンス履歴ID
                row_CSG_M_IB_INFO.INSTANCE_ID,                  --インスタンス番号
                row_CSG_M_IB_INFO.PARENT_INSTANCE_ID,           --親インスタンス番号
                row_CSG_M_IB_INFO.TOP_INSTANCE_ID,              --最上位インスタンス番号
                row_CSG_M_IB_INFO.INVENTORY_ITEM_CODE,          --品目コード
                (
                SELECT
                  PROD_CD || '.' || MAKR_MDL_NO || '.' || BR_NO || '..'  --品目
                FROM
                  SNV_M_ITEM
                WHERE
                  ITEM_CD=row_CSG_M_IB_INFO.INVENTORY_ITEM_CODE AND
                  PLT=row_CSG_M_IB_INFO.ORG_ID AND
                  NVL(DEL_FLG,'N') <>'X'
                ),
                row_CSG_M_IB_INFO.ORG_ID,                       --プラント
                row_CSG_M_IB_INFO.INVENTORY_ITEM_NAME,          --品目名
                row_CSG_M_IB_INFO.SERIAL_NO,                    --シリアル番号
                row_CSG_M_IB_INFO.MAIN_OPTION_TYPE,             --本体オプション区分
                (
                SELECT
                  DTL_TXT_SHRT_NM
                FROM
                  SNV_M_GNRC_SNV
                WHERE
                  CLSFCTN='M' AND
                  KEY_ITEM='CSG_CONFIG_TYPE' AND                  --本体オプション区分名
                  CD_VAL=row_CSG_M_IB_INFO.MAIN_OPTION_TYPE AND
                  VALD_STRT_DT <= set_sysdate AND
                  NVL(VALD_END_DT,SYSDATE) >= set_sysdate AND
                  NVL(DEL_FLG,'N') <>'X'
                ),
                row_CSG_M_IB_INFO.IB_SYNC_STATUS,               --IBステータス
                (
                SELECT
                  DTL_TXT_SHRT_NM
                FROM
                  SNV_M_GNRC_SNV
                WHERE
                  CLSFCTN='M' AND
                  KEY_ITEM='CSG_INSTANCE_STATUSES' AND            --IBステータス名
                  CD_VAL=row_CSG_M_IB_INFO.IB_SYNC_STATUS AND
                  VALD_STRT_DT <= set_sysdate AND
                  NVL(VALD_END_DT,SYSDATE) >= set_sysdate AND
                  NVL(DEL_FLG,'N') <>'X'
                ),
                row_CSG_M_IB_INFO.QUANTITY,                     --数量
                row_CSG_M_IB_INFO.INSTALL_DATE,                 --納入日
                row_CSG_M_IB_INFO.SALES_DATE,                   --売上日
                row_CSG_M_IB_INFO.CUSTOMER_ORDER_NO,            --客先注文番号
                row_CSG_M_IB_INFO.MAKER_ORDER_NO,               --メーカー発注番号
                row_CSG_M_IB_INFO.ORDER_NO,                     --受注番号
                row_CSG_M_IB_INFO.TRANSFER_FLAG,                --移管品フラグ
                row_CSG_M_IB_INFO.TRANSFER_MAINTENANCE_FROM,    --保守移管元
                row_CSG_M_IB_INFO.TRANSFER_MAINTENANCE_TO,      --保守移管先
                row_CSG_M_IB_INFO.TRANSFER_MAINTENANCE_DATE,    --保守移管日
                row_CSG_M_IB_INFO.TRANSFER_MAINTNANCE_REASON,   --保守移管理由
                row_CSG_M_IB_INFO.SALES_OWNER_CODE,             --販売元
                (
                SELECT
                  DTL_TXT_SHRT_NM
                FROM
                  SNV_M_GNRC_SNV
                WHERE
                  CLSFCTN='M' AND
                  KEY_ITEM='CSG_INSTANCE_USE_COMPANY' AND         --販売元名
                  CD_VAL=row_CSG_M_IB_INFO.SALES_OWNER_CODE AND
                  VALD_STRT_DT <= set_sysdate AND
                  NVL(VALD_END_DT,SYSDATE) >= set_sysdate AND
                  PARM2='Y' AND
                  NVL(DEL_FLG,'N') <>'X'
                ),
                row_CSG_M_IB_INFO.MAINTENANCE_TYPE,             --保守種別
                (
                SELECT
                  DTL_TXT_SHRT_NM
                FROM
                  SNV_M_GNRC_SNV
                WHERE
                  CLSFCTN='M' AND
                  KEY_ITEM='CSG_INSTANCE_USE_COMPANY' AND         --保守種別名
                  CD_VAL=row_CSG_M_IB_INFO.MAINTENANCE_TYPE AND
                  VALD_STRT_DT <= set_sysdate AND
                  NVL(VALD_END_DT,SYSDATE) >= set_sysdate AND
                  PARM1='Y' AND
                  NVL(DEL_FLG,'N') <>'X'
                ),
                row_CSG_M_IB_INFO.IMPORTANT_ITEM_FLAG,          --重要案件
                row_CSG_M_IB_INFO.SERVICE_CONDITION,            --サービス形態
                (
                SELECT
                  DTL_TXT_SHRT_NM
                FROM
                  SNV_M_GNRC_SNV
                WHERE
                  CLSFCTN='V' AND
                  GRP_KEY='IBDATA' AND
                  KEY_ITEM='ZMMDESERVICE' AND                     --サービス形態名
                  CD_VAL=row_CSG_M_IB_INFO.SERVICE_CONDITION AND
                  VALD_STRT_DT <= set_sysdate AND
                  NVL(VALD_END_DT,SYSDATE) >= set_sysdate AND
                  NVL(DEL_FLG,'N') <>'X'
                ),
                row_CSG_M_IB_INFO.OUT_SOURCING_FLAG,            --外注フラグ
                (
                SELECT
                  DTL_TXT_SHRT_NM
                FROM
                  SNV_M_GNRC_SNV
                WHERE
                  CLSFCTN='M' AND
                  GRP_KEY='SNV' AND
                  KEY_ITEM='SBCN_FLAG' AND                        --外注フラグ名
                  CD_VAL=row_CSG_M_IB_INFO.OUT_SOURCING_FLAG AND
                  VALD_STRT_DT <= set_sysdate AND
                  NVL(VALD_END_DT,SYSDATE) >= set_sysdate AND
                  NVL(DEL_FLG,'N') <>'X'
                ),
                row_CSG_M_IB_INFO.SHIPPING_INSPECTION_FLAG,     --出荷検査実施フラグ
                row_CSG_M_IB_INFO.HOST_NAME,                    --ホスト名
                row_CSG_M_IB_INFO.SYSTEM_NAME,                  --システム名
                row_CSG_M_IB_INFO.SUPPORT_START_DATE,           --要サポート開始日
                row_CSG_M_IB_INFO.SUPPORT_END_DATE,             --要サポート終了日
                row_CSG_M_IB_INFO.SUPPORT_INSTRUCT_CODE,        --要サポートフラグ
                (
                SELECT
                  DTL_TXT_SHRT_NM
                FROM
                  SNV_M_GNRC_SNV
                WHERE
                  CLSFCTN='M' AND
                  KEY_ITEM='CSG_SUPPORT_INSTRUCT_CODE' AND        --要サポートフラグ名
                  CD_VAL=row_CSG_M_IB_INFO.SUPPORT_INSTRUCT_CODE AND
                  VALD_STRT_DT <= set_sysdate AND
                  NVL(VALD_END_DT,SYSDATE) >= set_sysdate AND
                  NVL(DEL_FLG,'N') <>'X'
                ),
                row_CSG_M_IB_INFO.FIRST_SALE_PARTY_CODE,        --初期販売会社コード
                (
                SELECT
                  CUST_FRML_NM                                    --初期販売会社名
                FROM
                  SNV_M_CUST
                WHERE
                  CUST_CD=row_CSG_M_IB_INFO.FIRST_SALE_PARTY_CODE AND
                  CUST_ACCT_GRP='Z001' AND
                  NVL(DEL_FLG,'N') <>'X'
                ),
                row_CSG_M_IB_INFO.FIRST_SALE_PARTY_LOCATION,    --初期販売会社住所
                row_CSG_M_IB_INFO.FIRST_SALE_DEPT_NAME,         --初期販売部署名
                row_CSG_M_IB_INFO.FIRST_SALE_TEL,               --初期販売会社TEL
                row_CSG_M_IB_INFO.FIRST_SALE_FAX,               --初期販売会社FAX
                row_CSG_M_IB_INFO.FIRST_SALE_PERSON_NAME,       --初期販売担当者名
                row_CSG_M_IB_INFO.FIRST_SALE_MAIL_ADDRESS,      --初期販売メールアドレス
                row_CSG_M_IB_INFO.FIRST_COVERAGE,               --初回ワランティ条件
                (
                SELECT
                  DTL_TXT_SHRT_NM
                FROM
                  SNV_M_GNRC_ERP
                WHERE
                  CLSFCTN='V' AND
                  GRP_KEY='MATERIAL' AND
                  KEY_ITEM='ZMMDEFIRST_WT_COND' AND               --初回ワランティ条件(摘要)
                  CD_VAL=row_CSG_M_IB_INFO.FIRST_COVERAGE AND
                  VALD_STRT_DT <= set_sysdate AND
                  NVL(VALD_END_DT,SYSDATE) >= set_sysdate AND
                  NVL(DEL_FLG,'N') <>'X'
                ),
                row_CSG_M_IB_INFO.FIRST_MONTHS,                 --初回ワランティ月数
                row_CSG_M_IB_INFO.FIRST_START_DATE,             --初回期間(自)
                row_CSG_M_IB_INFO.FIRST_END_DATE,               --初回期間(至)
                row_CSG_M_IB_INFO.NEXT_COVERAGE,                --次回ワランティ条件
                (
                SELECT
                  DTL_TXT_SHRT_NM
                FROM
                  SNV_M_GNRC_ERP
                WHERE
                  CLSFCTN='V' AND
                  GRP_KEY='MATERIAL' AND
                  KEY_ITEM='ZMMDENEXT_WT_COND' AND                --次回ワランティ条件(摘要)
                  CD_VAL=row_CSG_M_IB_INFO.NEXT_COVERAGE AND
                  VALD_STRT_DT <= set_sysdate AND
                  NVL(VALD_END_DT,SYSDATE) >= set_sysdate AND
                  NVL(DEL_FLG,'N') <>'X'
                ),
                row_CSG_M_IB_INFO.NEXT_MONTHS,                  --次回ワランティ月数
                row_CSG_M_IB_INFO.NEXT_START_DATE,              --次回期間(自)
                row_CSG_M_IB_INFO.NEXT_END_DATE,                --次回期間(至)
--                row_CSG_M_IB_INFO.COVERAGE_START_BASE,          --ワランティ開始日基準
--                row_CSG_M_IB_INFO.COVERAGE_START_BASE_COMMENT,  --ワランティ開始日基準(摘要)
                row_CSG_M_IB_INFO.AGENT_FLAG,                   --販社フラグ
                (
                SELECT
                  DTL_TXT_SHRT_NM
                FROM
                  SNV_M_GNRC_SNV
                WHERE
                  CLSFCTN='M' AND
                  KEY_ITEM='CSG_INSTANCE_USE_COMPANY' AND         --販社名
                  CD_VAL=row_CSG_M_IB_INFO.AGENT_FLAG AND
                  VALD_STRT_DT <= set_sysdate AND
                  NVL(VALD_END_DT,SYSDATE) >= set_sysdate AND
                  PARM3='Y' AND
                  NVL(DEL_FLG,'N') <>'X'
                ),
                row_CSG_M_IB_INFO.SECONDARY_INVENTORY_CODE,     --委託先コード
                (
                SELECT
                  DEPO_NAME                                       --委託先名
                FROM
                  CSL_M_DEPO
                WHERE
                  DEPO_SUM_TYPE='30' AND
                  INVALID_FLAG ='0' AND
                  DEPO_CD=row_CSG_M_IB_INFO.SECONDARY_INVENTORY_CODE
                ),
                row_CSG_M_IB_INFO.BUNDLE_ITEM_CODE,             --バンドル品目コード
                (
                SELECT
                  PROD_CD || '.' || MAKR_MDL_NO || '.' || BR_NO || '..'  --バンドル品目
                FROM
                  SNV_M_ITEM
                WHERE
                  ITEM_CD=row_CSG_M_IB_INFO.BUNDLE_ITEM_CODE AND
                  PLT=row_CSG_M_IB_INFO.ORG_ID AND
                  NVL(DEL_FLG,'N') <>'X'
                ),
                row_CSG_M_IB_INFO.BUNDLE_ITEM_NAME,             --バンドル品目名
                row_CSG_M_IB_INFO.BUNDLE_SERIAL_NO,             --バンドルシリアル
                row_CSG_M_IB_INFO.HOST_ID,                      --ホストID
                row_CSG_M_IB_INFO.KEEP_WATCH_SYSTEM_ID,         --監視システムID
                row_CSG_M_IB_INFO.HP_CONFIG_CODE,               --HPコンフィグコード
                row_CSG_M_IB_INFO.OS_TYPE,                      --OS種別
                (
                SELECT
                  DTL_TXT_SHRT_NM
                FROM
                  SNV_M_GNRC_SNV
                WHERE
                  CLSFCTN='M' AND
                  KEY_ITEM='CSG_OS_TYPE' AND                      --OS種別名
                  CD_VAL=row_CSG_M_IB_INFO.OS_TYPE AND
                  VALD_STRT_DT <= set_sysdate AND
                  NVL(VALD_END_DT,SYSDATE) >= set_sysdate AND
                  NVL(DEL_FLG,'N') <>'X'
                ),
                row_CSG_M_IB_INFO.OS_VERSION,                   --OSバージョン
                row_CSG_M_IB_INFO.FIRMWARE_VERSION,             --Firmware Version
                row_CSG_M_IB_INFO.REVISION,                     --リビジョン
                row_CSG_M_IB_INFO.CPU_ROM_REVISION,             --CPU　ROMリビジョン
                row_CSG_M_IB_INFO.DISK_CAPACITY,                --ディスク容量
                row_CSG_M_IB_INFO.POWER_SUPPLY_TYPE,            --電源設備種類
                (
                SELECT
                  DTL_TXT_SHRT_NM
                FROM
                  SNV_M_GNRC_SNV
                WHERE
                  CLSFCTN='M' AND
                  KEY_ITEM='CSG_POWER_SUPPLY_TYPE' AND            --電源設備種類名
                  CD_VAL=row_CSG_M_IB_INFO.POWER_SUPPLY_TYPE AND
                  VALD_STRT_DT <= set_sysdate AND
                  NVL(VALD_END_DT,SYSDATE) >= set_sysdate AND
                  NVL(DEL_FLG,'N') <>'X'
                ),
                row_CSG_M_IB_INFO.POWER_SUPPLY_CAPACITY,        --電源容量
                row_CSG_M_IB_INFO.USE_POWER_FREQUENCY,          --使用電源周波数
                (
                SELECT
                  DTL_TXT_SHRT_NM
                FROM
                  SNV_M_GNRC_SNV
                WHERE
                CLSFCTN='M' AND
                KEY_ITEM='CSG_USE_POWER_FREQUENCY' AND          --使用電源周波数名
                CD_VAL=row_CSG_M_IB_INFO.USE_POWER_FREQUENCY AND
                VALD_STRT_DT <= set_sysdate AND
                NVL(VALD_END_DT,SYSDATE) >= set_sysdate AND
                NVL(DEL_FLG,'N') <>'X'
                ),
--                row_CSG_M_IB_INFO.USE_POWER_VOLTAGE,            --使用電源電圧
                row_CSG_M_IB_INFO.HAVING_EARTH_FLAG,            --アース有無フラグ
                row_CSG_M_IB_INFO.MAC_ADDRESS,                  --MACアドレス
                row_CSG_M_IB_INFO.IP_ADDRESS,                   --IPアドレス
                row_CSG_M_IB_INFO.LICENSE_MANAGEMENT_NO,        --ライセンス管理番号
                row_CSG_M_IB_INFO.SUPERINTENDE_MANAGE_NO,       --主管部管理番号
                row_CSG_M_IB_INFO.LISENCE_START_DATE,           --ライセンス開始日
                row_CSG_M_IB_INFO.LISENCE_END_DATE,             --ライセンス終了日
                row_CSG_M_IB_INFO.REMOVE_ORDER_NO,              --移設受注番号
                row_CSG_M_IB_INFO.REMOVE_PO_NO,                 --移設先発注番号
                row_CSG_M_IB_INFO.REMOVE_DATE,                  --移設日
                row_CSG_M_IB_INFO.REMOVE_REASON,                --移設理由
                row_CSG_M_IB_INFO.SALES_DEPT_ORG_ID,            --F営業販売部署コード
                (
                SELECT
                  DPT_NM                                          ----F営業販売部署名
                FROM
                  SNV_M_DPT
                WHERE
                  EXP_DPT_CD=row_CSG_M_IB_INFO.SALES_DEPT_ORG_ID
                ),
                row_CSG_M_IB_INFO.SALES_DEPT_PERSON_ID,         --F営業販売担当者コード
                (
                SELECT
                  FULL_NM                                          --F営業販売担当者名
                FROM
                  SNV_M_EMP
                WHERE
                  EMP_CD=row_CSG_M_IB_INFO.SALES_DEPT_PERSON_ID
                ),
                row_CSG_M_IB_INFO.PRESENT_DEPT_ORG_ID,          --F営業現在担当部署コード
                (
                SELECT
                  DPT_NM                                          --F営業現在担当部署名
                FROM
                  SNV_M_DPT
                WHERE
                  EXP_DPT_CD=row_CSG_M_IB_INFO.PRESENT_DEPT_ORG_ID AND
                  VALD_STRT_DT <= set_sysdate AND
                  NVL(VALD_END_DT,SYSDATE) >= set_sysdate AND
                  NVL(DEL_FLG,'N') <>'X'
                ),
                row_CSG_M_IB_INFO.CTC_SALESREP_PERSON_ID,       --F営業現在担当者コード
                (
                SELECT
                  FULL_NM                                         --F営業現在担当者名
                FROM
                  SNV_M_EMP
                WHERE
                  EMP_CD=row_CSG_M_IB_INFO.CTC_SALESREP_PERSON_ID AND 
                  VALD_STRT_DT <= set_sysdate AND
                  NVL(VALD_END_DT,SYSDATE) >= set_sysdate
                ),
                row_CSG_M_IB_INFO.MAINTE_BUS_DEPT_ORG_ID,       --保守営業担当部署コード
                (
                SELECT
                  DPT_NM                                          --保守営業担当部署名
                FROM
                  SNV_M_DPT
                WHERE
                  EXP_DPT_CD=row_CSG_M_IB_INFO.MAINTE_BUS_DEPT_ORG_ID
                ),
                row_CSG_M_IB_INFO.MAINTE_BUS_PERSON_ID,         --保守営業担当者コード
                (
                SELECT
                  FULL_NM                                         --保守営業担当者名
                FROM
                  SNV_M_EMP
                WHERE
                  EMP_CD=row_CSG_M_IB_INFO.MAINTE_BUS_PERSON_ID AND 
                  VALD_STRT_DT <= set_sysdate AND
                  NVL(VALD_END_DT,SYSDATE) >= set_sysdate
                ),
                row_CSG_M_IB_INFO.PP_CONT_AK_NO,                --PP契約AK番号
                row_CSG_M_IB_INFO.PP_CONT_START_DATE,           --契約期間(自)
                row_CSG_M_IB_INFO.PP_CONT_END_DATE,             --契約期間(至)
                row_CSG_M_IB_INFO.SN_CHANGE_REASON,             --シリアル番号変更理由
                row_CSG_M_IB_INFO.X_DEPLOY_FLAG,                --X配備対象フラグ
                row_CSG_M_IB_INFO.ACCEPTANCE_DATE,              --受入日
                row_CSG_M_IB_INFO.OUT_WARRANTY_REGISTERED_FLAG, --外注契約ワランティ登録済フラグ
                row_CSG_M_IB_INFO.PROGRAM_ID,                   --更新プログラムID
                row_CSG_M_IB_INFO.PROCESS_ID,                   --処理ID
                row_CSG_M_IB_INFO.CREATION_USER_ID,             --作成者
                row_CSG_M_IB_INFO.CREATION_DATE,                --作成日時
                row_CSG_M_IB_INFO.UPDATE_USER_ID,               --更新者
                row_CSG_M_IB_INFO.UPDATE_DATE                   --更新日時
              );
              -- ***************************************************************
              -- N ：楽観ロック比較なし
              -- Y ：楽観ロック比較あり
              -- ※「楽観ロック比較」とは、テーブルの更新タイムスタンプとの比較の事であり、行ロックは両値とも行う。
              -- ※追加の場合は「N」
              -- ***************************************************************
              PRAM_PLACE_HOLDER := '設置機器情報の更新';
              table_name        := 'CSG_M_IB_INFO';
              IF LOCK_FLG = 'Y' THEN
                IF LOCK_DATE <> row_CSG_M_IB_INFO.UPDATE_DATE THEN
                  v_END_CODE := '22';
                  RAISE LOCK_FLG_EXCEPTION;
                END IF;
              END IF;
              --（判定１）更新処理でパラメータの「設置機器情報」の項目が設定されている場合
              --         パラメータの「インスタンス番号」の対象行に対し、設置機器情報テーブルの更新を行う。
              IF tIB_BASE IS NOT NULL OR tIB_BASE IS NOT EMPTY THEN
                FOR i IN 1..tIB_BASE.COUNT
                LOOP
                  ib_base_obj       := tIB_BASE(i);
                  set_column_name   := set_column_name || ib_base_obj.COLUM_NAME || '=' || ':' || ib_base_obj.COLUM_NAME;
                  IF i < tIB_BASE.COUNT THEN
                    set_column_name := set_column_name || ', ';
                  END IF;
                END LOOP;
                
                -- 更新プログラムID || 処理ID || 更新者 || 更新日時のカラム名と更新データ
                IF NVL(LENGTH(set_column_name),0) = 0 THEN
                     set_column_name := 'PROGRAM_ID = :PROGRAM_ID, PROCESS_ID = :PROCESS_ID, UPDATE_USER_ID = :UPDATE_USER_ID, UPDATE_DATE = :UPDATE_DATE';
                ELSE 
                     set_column_name := set_column_name || ', ' || 'PROGRAM_ID = :PROGRAM_ID, PROCESS_ID = :PROCESS_ID, UPDATE_USER_ID = :UPDATE_USER_ID, UPDATE_DATE = :UPDATE_DATE';
                END IF;
                
                -- 設置機器情報テーブルの更新
                stmt_str := 'UPDATE ' || table_name || ' SET ' || set_column_name || '                                       
                             WHERE INSTANCE_ID        = :INSTANCE_ID                                       
                               AND TOP_INSTANCE_ID    = :TOP_INSTANCE_ID';
                cur_hdl  := DBMS_SQL.OPEN_CURSOR;
                DBMS_SQL.PARSE(cur_hdl, stmt_str, DBMS_SQL.NATIVE);
                -- supply binds
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':INSTANCE_ID', INPUT_INSTANCE_ID);
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':TOP_INSTANCE_ID', INPUT_TOP_INSTANCE_ID);
                FOR i IN 1..tIB_BASE.COUNT
                LOOP
                  ib_base_obj := tIB_BASE(i);
                  DBMS_SQL.BIND_VARIABLE(cur_hdl, ':' || ib_base_obj.COLUM_NAME, ib_base_obj.SET_VALUE);
                END LOOP;
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':PROGRAM_ID', PROGRAM_ID);
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':PROCESS_ID', PROCESS_ID);
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':UPDATE_USER_ID', USER_ID);
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':UPDATE_DATE', set_sysdate);
                rows_processed := dbms_sql.execute(cur_hdl);
                -- execute
                DBMS_SQL.CLOSE_CURSOR(cur_hdl);
              -- （判定２）更新処理かつ最上位インスタンス（単独インスタンス）で「設置機器情報」の項目が設定されていないが「設置機器共通情報」の項目が設定されている場合
              --          パラメータの「インスタンス番号」の対象行に対し、設置機器情報テーブルの更新を行う。
              --          ※（判定2）の場合は更新プログラムID、処理ID、更新日時、更新者のみ更新。
              ELSIF (tIB_BASE IS NULL OR tIB_BASE IS EMPTY) AND (tIB_COMMON IS NOT NULL OR tIB_COMMON IS NOT EMPTY) THEN
                -- 更新プログラムID || 処理ID || 更新者 || 更新日時のカラム名と更新データ
                set_column_name := 'PROGRAM_ID = :PROGRAM_ID, PROCESS_ID = :PROCESS_ID, UPDATE_USER_ID = :UPDATE_USER_ID, UPDATE_DATE = :UPDATE_DATE';
                -- 設置機器情報テーブルの更新
                stmt_str := 'UPDATE ' || table_name || ' SET ' || set_column_name || '                                     
                             WHERE INSTANCE_ID        = ' || row_CSG_M_IB_INFO.INSTANCE_ID || '                                     
                               AND PARENT_INSTANCE_ID = ' || row_CSG_M_IB_INFO.PARENT_INSTANCE_ID || '                                     
                               AND TOP_INSTANCE_ID    = ' || row_CSG_M_IB_INFO.TOP_INSTANCE_ID;
                cur_hdl  := DBMS_SQL.OPEN_CURSOR;
                DBMS_SQL.PARSE(cur_hdl, stmt_str, DBMS_SQL.NATIVE);
                -- supply binds
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':PROGRAM_ID', PROGRAM_ID);
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':PROCESS_ID', PROCESS_ID);
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':UPDATE_USER_ID', USER_ID);
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':UPDATE_DATE', LOCK_DATE);
                rows_processed := dbms_sql.execute(cur_hdl);
                -- execute
                DBMS_SQL.CLOSE_CURSOR(cur_hdl);
              END IF;
            END LOOP;
        END IF;
        -- ***********************************************************************
        -- 5. 設置機器共通情報テーブルの更新
        -- （判定１）更新処理でパラメータの「設置機器共通情報」の項目が設定されている場合
        -- （判定２）更新処理かつ最上位インスタンス（単独インスタンス）で「設置機器共通情報」の項目が設定されていないが「設置機器情
        -- 【設置機器共通情報テーブル更新処理】
        -- ・設置機器共通情報テーブルの排他取得
        -- ・設置機器共通情報テーブルの更新　　　　　※（判定2）の場合は更新プログラムID、処理ID、更新日時、更新者のみ更新。
        -- ・設置機器共通情報履歴テーブルの追加
        -- ***********************************************************************
        set_column_name       := '';
        set_value_column      := '';
        stmt_str              := '';
        IF (tIB_COMMON IS NOT NULL OR tIB_COMMON IS NOT EMPTY) OR
           (tIB_COMMON IS NULL OR tIB_COMMON IS EMPTY) AND (tIB_BASE IS NOT NULL OR tIB_BASE IS NOT EMPTY) THEN
          -- *******************************************************************
          -- ・設置機器共通情報履歴テーブルの追加
          -- *******************************************************************
          FOR row_CSG_M_IB_COMMON_INFO IN c_CSG_M_IB_COMMON_INFO
            LOOP
            PRAM_PLACE_HOLDER := '設置機器共通情報履歴の挿入';
            table_name        := 'CSG_M_IB_COMMON_INFO_HIS';
            INSERT
            INTO CSG_M_IB_COMMON_INFO_HIS
              (
                INSTANCE_HIS_ID,              -- 履歴ID
                TOP_INSTANCE_ID,              -- 最上位インスタンス番号
                CS_IN_CHARGE_CODE,            -- 担当CSコード
                CS_IN_CHARGE_NAME,            -- 担当CS名
                CE_CODE,                      -- 担当CEコード
                CE_NAME,                      -- 担当CE名
                INSTALL_CUSTOMER_CODE,        -- 設置先顧客コード
                INSTALL_CUSTOMER_NAME,        -- 設置先顧客名
--                INSTALL_CUSTOMER_AR_NAME,     -- 顧客略称
                INSTALL_LOCATION_CODE,        -- 設置先顧客住所コード
                INSTALL_LOCATION,             -- 設置先顧客住所
                INSTALL_LOCATION_DEPT_NAME,   -- 設置先顧客部署名
                INSTALL_LOCATION_PERSON_NAME, -- 設置先顧客担当者名
                INSTALL_LOCATION_TEL,         -- 設置先TEL
                INSTALL_LOCATION_FAX,         -- 設置先FAX
                INCIDENT_SERVIRITY_NAME,      -- 重要度
                USE_CONDITION,                -- 利用形態
                USE_PERPOSE,                  -- 利用目的
                ENDUSER_PARTY_ID,             -- エンドユーザ会社コード
                ENDUSER_PARTY_NAME,           -- エンドユーザ会社名
                ENDUSER_LOCATION,             -- エンドユーザ住所
                ENDUSER_CHRG_DEPT_NAME,       -- エンドユーザ部署名
                ENDUSER_CHRG_PERSON_NAME,     -- エンドユーザ担当者名
                ENDUSER_TEL,                  -- エンドユーザTEL
                ENDUSER_FAX,                  -- エンドユーザFAX
                ENDUSER_MAIL_ADDRESS,         -- エンドユーザメールアドレス
                PROGRAM_ID,                   -- 更新プログラムID
                PROCESS_ID,                   -- 処理ID
                CREATION_USER_ID,             -- 作成者
                CREATION_DATE,                -- 作成日時
                UPDATE_USER_ID,               -- 更新者
                UPDATE_DATE                   -- 更新日時
              )
              VALUES
              (
                CSG_M_IB_COMMON_HIS_ID_SEQ.NEXTVAL,                    -- 履歴ID
                row_CSG_M_IB_COMMON_INFO.TOP_INSTANCE_ID,              -- 最上位インスタンス番号
                row_CSG_M_IB_COMMON_INFO.CS_IN_CHARGE_CODE,            -- 担当CSコード
                (
                SELECT
                  GROUP_NAME --担当CS名
                FROM
                  CSG_M_GROUP_MANAGEMENT
                WHERE
                  GROUP_ID=row_CSG_M_IB_COMMON_INFO.CS_IN_CHARGE_CODE AND
                  START_DATE <= row_CSG_M_IB_COMMON_INFO.UPDATE_DATE AND
                  NVL(END_DATE,SYSDATE) >= row_CSG_M_IB_COMMON_INFO.UPDATE_DATE
                ),
                row_CSG_M_IB_COMMON_INFO.CE_CODE,                      -- 担当CEコード
                (
                SELECT
                  FULL_NM -- 担当CE名
                FROM
                  SNV_M_EMP
                WHERE
                  EMP_CD=row_CSG_M_IB_COMMON_INFO.CE_CODE AND
                  VALD_STRT_DT <= row_CSG_M_IB_COMMON_INFO.UPDATE_DATE AND
                  NVL(VALD_END_DT,SYSDATE) >= row_CSG_M_IB_COMMON_INFO.UPDATE_DATE
                ),
                row_CSG_M_IB_COMMON_INFO.INSTALL_CUSTOMER_CODE,        -- 設置先顧客コード
                (
                SELECT
                  CUST_FRML_NM -- 設置先顧客名
                FROM
                  SNV_M_CUST
                WHERE
                  CUST_CD=row_CSG_M_IB_COMMON_INFO.INSTALL_CUSTOMER_CODE AND
                  CUST_ACCT_GRP='Z001'
                ),
--                row_CSG_M_IB_COMMON_INFO.INSTALL_CUSTOMER_AR_NAME,     -- 顧客略称
                row_CSG_M_IB_COMMON_INFO.INSTALL_LOCATION_CODE,        -- 設置先顧客住所コード
                (
                SELECT
                  INSTALL_LOCATION -- 設置先顧客住所
                FROM
                  CSG_M_IB_ADDRESS
                WHERE
                  INSTALL_LOCATION_CODE=row_CSG_M_IB_COMMON_INFO.INSTALL_LOCATION_CODE
                ),
                row_CSG_M_IB_COMMON_INFO.INSTALL_LOCATION_DEPT_NAME,   -- 設置先顧客部署名
                row_CSG_M_IB_COMMON_INFO.INSTALL_LOCATION_PERSON_NAME, -- 設置先顧客担当者名
                row_CSG_M_IB_COMMON_INFO.INSTALL_LOCATION_TEL,         -- 設置先TEL
                row_CSG_M_IB_COMMON_INFO.INSTALL_LOCATION_FAX,         -- 設置先FAX
                row_CSG_M_IB_COMMON_INFO.INCIDENT_SERVIRITY_NAME,      -- 重要度
                row_CSG_M_IB_COMMON_INFO.USE_CONDITION,                -- 利用形態
                row_CSG_M_IB_COMMON_INFO.USE_PERPOSE,                  -- 利用目的
                row_CSG_M_IB_COMMON_INFO.ENDUSER_PARTY_CODE,           -- エンドユーザ会社コード
                (
                SELECT
                  CUST_FRML_NM -- エンドユーザ会社名
                FROM
                  SNV_M_CUST
                WHERE
                  CUST_CD=row_CSG_M_IB_COMMON_INFO.ENDUSER_PARTY_CODE AND
                  CUST_ACCT_GRP='Z001'
                ),
                row_CSG_M_IB_COMMON_INFO.ENDUSER_LOCATION,             -- エンドユーザ住所
                row_CSG_M_IB_COMMON_INFO.ENDUSER_CHRG_DEPT_NAME,       -- エンドユーザ部署名
                row_CSG_M_IB_COMMON_INFO.ENDUSER_CHRG_PERSON_NAME,     -- エンドユーザ担当者名
                row_CSG_M_IB_COMMON_INFO.ENDUSER_TEL,                  -- エンドユーザTEL
                row_CSG_M_IB_COMMON_INFO.ENDUSER_FAX,                  -- エンドユーザFAX
                row_CSG_M_IB_COMMON_INFO.ENDUSER_MAIL_ADDRESS,         -- エンドユーザメールアドレス
                row_CSG_M_IB_COMMON_INFO.PROGRAM_ID,                   -- 更新プログラムID
                row_CSG_M_IB_COMMON_INFO.PROCESS_ID,                   -- 処理ID
                row_CSG_M_IB_COMMON_INFO.CREATION_USER_ID,             -- 作成者
                row_CSG_M_IB_COMMON_INFO.CREATION_DATE,                -- 作成日時
                row_CSG_M_IB_COMMON_INFO.UPDATE_USER_ID,               -- 更新者
                row_CSG_M_IB_COMMON_INFO.UPDATE_DATE                   -- 更新日時
              );
              -- ***************************************************************
              -- N ：楽観ロック比較なし
              -- Y ：楽観ロック比較あり
              -- ※「楽観ロック比較」とは、テーブルの更新タイムスタンプとの比較の事であり、行ロックは両値とも行う。
              -- ※追加の場合は「N」
              -- ***************************************************************
              PRAM_PLACE_HOLDER := '設置機器共通情報の更新';
              table_name        := 'CSG_M_IB_COMMON_INFO';
              
              IF LOCK_FLG = 'Y' THEN
                IF LOCK_DATE <> row_CSG_M_IB_COMMON_INFO.UPDATE_DATE THEN
                  v_END_CODE := '22';
                  RAISE LOCK_FLG_EXCEPTION;
                END IF;
              END IF;
              -- （判定１）更新処理でパラメータの「設置機器共通情報」の項目が設定されている場合
              --          パラメータの「インスタンス番号」の対象行に対し、設置機器共通情報テーブルの更新を行う。　　　　
              IF tIB_COMMON IS NOT NULL OR tIB_COMMON IS NOT EMPTY THEN
                FOR i IN 1..tIB_COMMON.COUNT
                LOOP
                  ib_common_obj := tIB_COMMON(i);
                  set_column_name   := set_column_name || ib_common_obj.COLUM_NAME || '=' || ':' || ib_common_obj.COLUM_NAME;
                  IF i           < tIB_COMMON.COUNT THEN
                    set_column_name := set_column_name || ', ';
                  END IF;
                END LOOP;
                
                -- 更新プログラムID || 処理ID || 更新者 || 更新日時のカラム名と更新データ
                IF NVL(LENGTH(set_column_name),0) = 0 THEN
                     set_column_name := 'PROGRAM_ID = :PROGRAM_ID, PROCESS_ID = :PROCESS_ID, UPDATE_USER_ID = :UPDATE_USER_ID, UPDATE_DATE = :UPDATE_DATE';
                ELSE 
                     set_column_name := set_column_name || ', ' || 'PROGRAM_ID = :PROGRAM_ID, PROCESS_ID = :PROCESS_ID, UPDATE_USER_ID = :UPDATE_USER_ID, UPDATE_DATE = :UPDATE_DATE';
                END IF;
                
                -- 設置機器共通情報テーブルの更新
                stmt_str := 'UPDATE ' || table_name || ' SET ' || set_column_name || '                                         
                             WHERE TOP_INSTANCE_ID = :TOP_INSTANCE_ID';
                cur_hdl  := DBMS_SQL.OPEN_CURSOR;
                DBMS_SQL.PARSE(cur_hdl, stmt_str, DBMS_SQL.NATIVE);
                -- supply binds
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':TOP_INSTANCE_ID', INPUT_TOP_INSTANCE_ID);
                FOR i IN 1..tIB_COMMON.COUNT
                LOOP
                  ib_common_obj := tIB_COMMON(i);
                  DBMS_SQL.BIND_VARIABLE(cur_hdl, ':' || ib_common_obj.COLUM_NAME, ib_common_obj.SET_VALUE);
                END LOOP;
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':PROGRAM_ID', PROGRAM_ID);
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':PROCESS_ID', PROCESS_ID);
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':UPDATE_USER_ID', USER_ID);
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':UPDATE_DATE', set_sysdate);
                rows_processed := dbms_sql.execute(cur_hdl);
                -- execute
                DBMS_SQL.CLOSE_CURSOR(cur_hdl);
                -- （判定２）更新処理かつ最上位インスタンス（単独インスタンス）で「設置機器共通情報」の項目が設定されていないが「設置機器情報」の項目が設定されている場合
                --          パラメータの「インスタンス番号」の対象行に対し、設置機器情報テーブルの更新を行う。
                --          ※（判定2）の場合は更新プログラムID、処理ID、更新日時、更新者のみ更新。
              ELSIF (tIB_COMMON IS NULL OR tIB_COMMON IS EMPTY) AND (tIB_BASE IS NOT NULL OR tIB_BASE IS NOT EMPTY) THEN
                -- 更新プログラムID || 処理ID || 更新者 || 更新日時のカラム名と更新データ
                set_column_name := 'PROGRAM_ID = :PROGRAM_ID, PROCESS_ID = :PROCESS_ID, UPDATE_USER_ID = :UPDATE_USER_ID, UPDATE_DATE = :UPDATE_DATE';
                -- 設置機器共通情報テーブルの更新
                stmt_str := 'UPDATE ' || table_name || ' SET ' || set_column_name || '                                       
                             WHERE TOP_INSTANCE_ID = ' || row_CSG_M_IB_COMMON_INFO.TOP_INSTANCE_ID;
                cur_hdl  := DBMS_SQL.OPEN_CURSOR;
                DBMS_SQL.PARSE(cur_hdl, stmt_str, DBMS_SQL.NATIVE);
                -- supply binds
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':PROGRAM_ID', PROGRAM_ID);
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':PROCESS_ID', PROCESS_ID);
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':UPDATE_USER_ID', USER_ID);
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':UPDATE_DATE', LOCK_DATE);
                rows_processed := dbms_sql.execute(cur_hdl);
                -- execute
                DBMS_SQL.CLOSE_CURSOR(cur_hdl);
              END IF;
            END LOOP;
        END IF;
      END;
      -- *************************************************************************
      -- 1. 階層判断
      -- 1.インスタンス階層チェックを行う。
      -- パラメータ.最上位インスタンス<>パラメータ.インスタンス　の場合
      -- ⇒子インスタンスとする。
      -- *************************************************************************
    ELSIF INPUT_INSTANCE_ID <> INPUT_TOP_INSTANCE_ID THEN
      -- ***********************************************************************
      -- 3. 設置機器情報テーブルの更新
      -- （判定１）更新処理でパラメータの「設置機器情報」の項目が設定されている場合
      -- （判定２）更新処理かつ最上位インスタンス（単独インスタンス）で「設置機器情報」の項目が設定されていないが「設置機器共通情
      -- 【設置機器情報テーブル更新処理】
      -- ・設置機器情報テーブルの排他取得
      -- ・設置機器情報テーブルの更新　　　　　※（判定2）の場合は更新プログラムID、処理ID、更新日時、更新者のみ更新。
      -- ・設置機器情報履歴テーブルの追加
      -- ***********************************************************************
      BEGIN
        IF (tIB_BASE IS NULL OR tIB_BASE IS EMPTY) AND 
           (tIB_COMMON IS NULL OR tIB_COMMON IS EMPTY) THEN
           PRAM_PLACE_HOLDER := '設置機器情報・設置機器共通情報の追加・更新に失敗しました。設置機器情報もしくは設置機器共通情報の変更項目が設定されていません。';
          RAISE PRAM_EXCEPTION;
        END IF;
        
        IF tIB_BASE IS NOT NULL OR tIB_BASE IS NOT EMPTY THEN
          -- *******************************************************************
          -- ・設置機器情報履歴テーブルの追加
          -- *******************************************************************
          FOR row_CSG_M_IB_INFO IN c_CSG_M_IB_INFO
            LOOP
            -- *************************************************************************
            -- 品目コードの追加チェック
            -- 更新処理の場合
            -- ①品目コードが設定されていてプラントが設定されていない場合に、引数の品目コードとDBのプラントで存在チェックを行う
            -- ②プラントが設定されていて品目コードが設定されていない場合に、引数のプラントとDBの品目コードで存在チェックを行う
            -- ③バンドル品目コードにNULL以外が設定されているか、設定されていない場合で、プラントが設定されていない場合に、
            -- 　引数のバンドル品目コードとDBのプラントで存在チェックを行う
            -- ※品目コードがNULLかつプラントがNULLの場合はインサート時にNOTNULL制約でエラーとなる
            -- *************************************************************************
            IF p_INVENTORY_ITEM_CODE_IBI IS NOT NULL AND p_ORG_ID_IBI IS NULL THEN
              IF FUNC_SNV_M_ITEM_CHK(P_INVENTORY_ITEM_CODE_IBI, row_CSG_M_IB_INFO.ORG_ID) = 1 THEN
                PRAM_PLACE_HOLDER := 'マスタに存在しない品目コードが設定されています。';
                RAISE MASTER_EXCEPTION;
              END IF;
            END IF;
    
            IF p_ORG_ID_IBI IS NOT NULL AND p_INVENTORY_ITEM_CODE_IBI IS NULL THEN
              IF FUNC_SNV_M_ITEM_CHK(row_CSG_M_IB_INFO.INVENTORY_ITEM_CODE, p_ORG_ID_IBI) = 1 THEN
                PRAM_PLACE_HOLDER := 'マスタに存在しない品目コードが設定されています。';
                RAISE MASTER_EXCEPTION;
              END IF;
              IF row_CSG_M_IB_INFO.BUNDLE_ITEM_CODE IS NOT NULL THEN
                IF FUNC_SNV_M_ITEM_CHK(row_CSG_M_IB_INFO.BUNDLE_ITEM_CODE, p_ORG_ID_IBI) = 1 THEN
                  PRAM_PLACE_HOLDER := 'マスタに存在しないバンドル品目コードが設定されています。';
                  RAISE MASTER_EXCEPTION;
                END IF;
              END IF;
            END IF;
    
            IF p_BUNDLE_ITEM_CODE IS NOT NULL AND p_ORG_ID_IBI IS NULL AND p_BUNDLE_ITEM_CODE_NULL_FLAG = 'N' THEN
              IF FUNC_SNV_M_ITEM_CHK(p_BUNDLE_ITEM_CODE, row_CSG_M_IB_INFO.ORG_ID) = 1 THEN
                PRAM_PLACE_HOLDER := 'マスタに存在しないバンドル品目コードが設定されています。';
                RAISE MASTER_EXCEPTION;
              END IF;
            END IF;
            -- *************************************************************************
            PRAM_PLACE_HOLDER := '設置機器情報履歴の挿入';
            table_name        := 'CSG_M_IB_INFO_HIS';
            INSERT
            INTO CSG_M_IB_INFO_HIS
              (
                INSTANCE_HIS_ID,              --インスタンス履歴ID
                INSTANCE_ID,                  --インスタンス番号
                PARENT_INSTANCE_ID,           --親インスタンス番号
                TOP_INSTANCE_ID,              --最上位インスタンス番号
                INVENTORY_ITEM_CODE,          --品目コード
                INVENTORY_ITEM,               --品目
                ORG_ID,                       --プラント
                INVENTORY_ITEM_NAME,          --品目名
                SERIAL_NO,                    --シリアル番号
                MAIN_OPTION_TYPE,             --本体オプション区分
                MAIN_OPTION_TYPE_NAME,        --本体オプション区分名
                IB_SYNC_STATUS,               --IBステータス
                IB_SYNC_STATUS_NAME,          --IBステータス名
                QUANTITY,                     --数量
                INSTALL_DATE,                 --納入日
                SALES_DATE,                   --売上日
                CUSTOMER_ORDER_NO,            --客先注文番号
                MAKER_ORDER_NO,               --メーカー発注番号
                ORDER_NO,                     --受注番号
                TRANSFER_FLAG,                --移管品フラグ
                TRANSFER_MAINTENANCE_FROM,    --保守移管元
                TRANSFER_MAINTENANCE_TO,      --保守移管先
                TRANSFER_MAINTENANCE_DATE,    --保守移管日
                TRANSFER_MAINTNANCE_REASON,   --保守移管理由
                SALES_OWNER_CODE,             --販売元
                SALES_OWNER_CODE_NAME,        --販売元名
                MAINTENANCE_TYPE,             --保守種別
                MAINTENANCE_TYPE_NAME,        --保守種別名
                IMPORTANT_ITEM_FLAG,          --重要案件
                SERVICE_CONDITION,            --サービス形態
                SERVICE_CONDITION_NAME,       --サービス形態名
                OUT_SOURCING_FLAG,            --外注フラグ
                OUT_SOURCING_FLAG_NAME,       --外注フラグ名
                SHIPPING_INSPECTION_FLAG,     --出荷検査実施フラグ
                HOST_NAME,                    --ホスト名
                SYSTEM_NAME,                  --システム名
                SUPPORT_START_DATE,           --要サポート開始日
                SUPPORT_END_DATE,             --要サポート終了日
                SUPPORT_INSTRUCT_CODE,        --要サポートフラグ
                SUPPORT_INSTRUCT_NAME,        --要サポートフラグ名
                FIRST_SALE_PARTY_CODE,        --初期販売会社コード
                FIRST_SALE_PARTY_NAME,        --初期販売会社名
                FIRST_SALE_PARTY_LOCATION,    --初期販売会社住所
                FIRST_SALE_DEPT_NAME,         --初期販売部署名
                FIRST_SALE_TEL,               --初期販売会社TEL
                FIRST_SALE_FAX,               --初期販売会社FAX
                FIRST_SALE_PERSON_NAME,       --初期販売担当者名
                FIRST_SALE_MAIL_ADDRESS,      --初期販売メールアドレス
                FIRST_COVERAGE,               --初回ワランティ条件
                FIRST_COVERAGE_COMMENT,       --初回ワランティ条件(摘要)
                FIRST_MONTHS,                 --初回ワランティ月数
                FIRST_START_DATE,             --初回期間(自)
                FIRST_END_DATE,               --初回期間(至)
                NEXT_COVERAGE,                --次回ワランティ条件
                NEXT_COVERAGE_COMMENT,        --次回ワランティ条件(摘要)
                NEXT_MONTHS,                  --次回ワランティ月数
                NEXT_START_DATE,              --次回期間(自)
                NEXT_END_DATE,                --次回期間(至)
--                COVERAGE_START_BASE,          --ワランティ開始日基準
--                COVERAGE_START_BASE_COMMENT,  --ワランティ開始日基準(摘要)
                AGENT_FLAG,                   --販社フラグ
                AGENT_FLAG_NAME,              --販社名
                SECONDARY_INVENTORY_CODE,     --委託先コード
                SECONDARY_INVENTORY_NAME,     --委託先名
                BUNDLE_ITEM_CODE,             --バンドル品目コード
                BUNDLE_ITEM,                  --バンドル品目
                BUNDLE_ITEM_NAME,             --バンドル品目名
                BUNDLE_SERIAL_NO,             --バンドルシリアル
                HOST_ID,                      --ホストID
                KEEP_WATCH_SYSTEM_ID,         --監視システムID
                HP_CONFIG_CODE,               --HPコンフィグコード
                OS_TYPE,                      --OS種別
                OS_TYPE_NAME,                 --OS種別名
                OS_VERSION,                   --OSバージョン
                FIRMWARE_VERSION,             --Firmware Version
                REVISION,                     --リビジョン
                CPU_ROM_REVISION,             --CPU　ROMリビジョン
                DISK_CAPACITY,                --ディスク容量
                POWER_SUPPLY_TYPE,            --電源設備種類
                POWER_SUPPLY_TYPE_NAME,       --電源設備種類名
                POWER_SUPPLY_CAPACITY,        --電源容量
                USE_POWER_FREQUENCY,          --使用電源周波数
                USE_POWER_FREQUENCY_NAME,     --使用電源周波数名
                USE_POWER_VOLTAGE,            --使用電源電圧
                HAVING_EARTH_FLAG,            --アース有無フラグ
                MAC_ADDRESS,                  --MACアドレス
                IP_ADDRESS,                   --IPアドレス
                LICENSE_MANAGEMENT_NO,        --ライセンス管理番号
                SUPERINTENDE_MANAGE_NO,       --主管部管理番号
                LISENCE_START_DATE,           --ライセンス開始日
                LISENCE_END_DATE,             --ライセンス終了日
                REMOVE_ORDER_NO,              --移設受注番号
                REMOVE_PO_NO,                 --移設先発注番号
                REMOVE_DATE,                  --移設日
                REMOVE_REASON,                --移設理由
                SALES_DEPT_ORG_ID,            --F営業販売部署コード
                SALES_DEPT_ORG_NAME,          --F営業販売部署名
                SALES_DEPT_PERSON_ID,         --F営業販売担当者コード
                SALES_DEPT_PERSON_NAME,       --F営業販売担当者名
                PRESENT_DEPT_ORG_ID,          --F営業現在担当部署コード
                PRESENT_DEPT_ORG_NAME,        --F営業現在担当部署名
                CTC_SALESREP_PERSON_ID,       --F営業現在担当者コード
                CTC_SALESREP_PERSON_NAME,     --F営業現在担当者名
                MAINTE_BUS_DEPT_ORG_ID,       --保守営業担当部署コード
                MAINTE_BUS_DEPT_ORG_NAME,     --保守営業担当部署名
                MAINTE_BUS_PERSON_ID,         --保守営業担当者コード
                MAINTE_BUS_PERSON_NAME,       --保守営業担当者名
                PP_CONT_AK_NO,                --PP契約AK番号
                PP_CONT_START_DATE,           --契約期間(自)
                PP_CONT_END_DATE,             --契約期間(至)
                SN_CHANGE_REASON,             --シリアル番号変更理由
                X_DEPLOY_FLAG,                --X配備対象フラグ
                ACCEPTANCE_DATE,              --受入日
                OUT_WARRANTY_REGISTERED_FLAG, --外注契約ワランティ登録済フラグ
                PROGRAM_ID,                   --更新プログラムID
                PROCESS_ID,                   --処理ID
                CREATION_USER_ID,             --作成者
                CREATION_DATE,                --作成日時
                UPDATE_USER_ID,               --更新者
                UPDATE_DATE                   --更新日時
              )
              VALUES
              (
                CSG_M_IB_HIS_ID_SEQ.NEXTVAL,                    --インスタンス履歴ID
                row_CSG_M_IB_INFO.INSTANCE_ID,                  --インスタンス番号
                row_CSG_M_IB_INFO.PARENT_INSTANCE_ID,           --親インスタンス番号
                row_CSG_M_IB_INFO.TOP_INSTANCE_ID,              --最上位インスタンス番号
                row_CSG_M_IB_INFO.INVENTORY_ITEM_CODE,          --品目コード
                (
                SELECT
                  PROD_CD || '.' || MAKR_MDL_NO || '.' || BR_NO || '..'  --品目
                FROM
                  SNV_M_ITEM
                WHERE
                  ITEM_CD=row_CSG_M_IB_INFO.INVENTORY_ITEM_CODE AND
                  PLT=row_CSG_M_IB_INFO.ORG_ID AND
                  NVL(DEL_FLG,'N') <>'X'
                ),
                row_CSG_M_IB_INFO.ORG_ID,                       --プラント
                row_CSG_M_IB_INFO.INVENTORY_ITEM_NAME,          --品目名
                row_CSG_M_IB_INFO.SERIAL_NO,                    --シリアル番号
                row_CSG_M_IB_INFO.MAIN_OPTION_TYPE,             --本体オプション区分
                (
                SELECT
                  DTL_TXT_SHRT_NM
                FROM
                  SNV_M_GNRC_SNV
                WHERE
                  CLSFCTN='M' AND
                  KEY_ITEM='CSG_CONFIG_TYPE' AND                  --本体オプション区分名
                  CD_VAL=row_CSG_M_IB_INFO.MAIN_OPTION_TYPE AND
                  VALD_STRT_DT <= set_sysdate AND
                  NVL(VALD_END_DT,SYSDATE) >= set_sysdate AND
                  NVL(DEL_FLG,'N') <>'X'
                ),
                row_CSG_M_IB_INFO.IB_SYNC_STATUS,               --IBステータス
                (
                SELECT
                  DTL_TXT_SHRT_NM
                FROM
                  SNV_M_GNRC_SNV
                WHERE
                  CLSFCTN='M' AND
                  KEY_ITEM='CSG_INSTANCE_STATUSES' AND            --IBステータス名
                  CD_VAL=row_CSG_M_IB_INFO.IB_SYNC_STATUS AND
                  VALD_STRT_DT <= set_sysdate AND
                  NVL(VALD_END_DT,SYSDATE) >= set_sysdate AND
                  NVL(DEL_FLG,'N') <>'X'
                ),
                row_CSG_M_IB_INFO.QUANTITY,                     --数量
                row_CSG_M_IB_INFO.INSTALL_DATE,                 --納入日
                row_CSG_M_IB_INFO.SALES_DATE,                   --売上日
                row_CSG_M_IB_INFO.CUSTOMER_ORDER_NO,            --客先注文番号
                row_CSG_M_IB_INFO.MAKER_ORDER_NO,               --メーカー発注番号
                row_CSG_M_IB_INFO.ORDER_NO,                     --受注番号
                row_CSG_M_IB_INFO.TRANSFER_FLAG,                --移管品フラグ
                row_CSG_M_IB_INFO.TRANSFER_MAINTENANCE_FROM,    --保守移管元
                row_CSG_M_IB_INFO.TRANSFER_MAINTENANCE_TO,      --保守移管先
                row_CSG_M_IB_INFO.TRANSFER_MAINTENANCE_DATE,    --保守移管日
                row_CSG_M_IB_INFO.TRANSFER_MAINTNANCE_REASON,   --保守移管理由
                row_CSG_M_IB_INFO.SALES_OWNER_CODE,             --販売元
                (
                SELECT
                  DTL_TXT_SHRT_NM
                FROM
                  SNV_M_GNRC_SNV
                WHERE
                  CLSFCTN='M' AND
                  KEY_ITEM='CSG_INSTANCE_USE_COMPANY' AND         --販売元名
                  CD_VAL=row_CSG_M_IB_INFO.SALES_OWNER_CODE AND
                  VALD_STRT_DT <= set_sysdate AND
                  NVL(VALD_END_DT,SYSDATE) >= set_sysdate AND
                  PARM2='Y' AND
                  NVL(DEL_FLG,'N') <>'X'
                ),
                row_CSG_M_IB_INFO.MAINTENANCE_TYPE,             --保守種別
                (
                SELECT
                  DTL_TXT_SHRT_NM
                FROM
                  SNV_M_GNRC_SNV
                WHERE
                  CLSFCTN='M' AND
                  KEY_ITEM='CSG_INSTANCE_USE_COMPANY' AND         --保守種別名
                  CD_VAL=row_CSG_M_IB_INFO.MAINTENANCE_TYPE AND
                  VALD_STRT_DT <= set_sysdate AND
                  NVL(VALD_END_DT,SYSDATE) >= set_sysdate AND
                  PARM1='Y' AND
                  NVL(DEL_FLG,'N') <>'X'
                ),
                row_CSG_M_IB_INFO.IMPORTANT_ITEM_FLAG,          --重要案件
                row_CSG_M_IB_INFO.SERVICE_CONDITION,            --サービス形態
                (
                SELECT
                  DTL_TXT_SHRT_NM
                FROM
                  SNV_M_GNRC_SNV
                WHERE
                  CLSFCTN='V' AND
                  GRP_KEY='IBDATA' AND
                  KEY_ITEM='ZMMDESERVICE' AND                     --サービス形態名
                  CD_VAL=row_CSG_M_IB_INFO.SERVICE_CONDITION AND
                  VALD_STRT_DT <= set_sysdate AND
                  NVL(VALD_END_DT,SYSDATE) >= set_sysdate AND
                  NVL(DEL_FLG,'N') <>'X'
                ),
                row_CSG_M_IB_INFO.OUT_SOURCING_FLAG,            --外注フラグ
                (
                SELECT
                  DTL_TXT_SHRT_NM
                FROM
                  SNV_M_GNRC_SNV
                WHERE
                  CLSFCTN='M' AND
                  GRP_KEY='SNV' AND
                  KEY_ITEM='SBCN_FLAG' AND                        --外注フラグ名
                  CD_VAL=row_CSG_M_IB_INFO.OUT_SOURCING_FLAG AND
                  VALD_STRT_DT <= set_sysdate AND
                  NVL(VALD_END_DT,SYSDATE) >= set_sysdate AND
                  NVL(DEL_FLG,'N') <>'X'
                ),
                row_CSG_M_IB_INFO.SHIPPING_INSPECTION_FLAG,     --出荷検査実施フラグ
                row_CSG_M_IB_INFO.HOST_NAME,                    --ホスト名
                row_CSG_M_IB_INFO.SYSTEM_NAME,                  --システム名
                row_CSG_M_IB_INFO.SUPPORT_START_DATE,           --要サポート開始日
                row_CSG_M_IB_INFO.SUPPORT_END_DATE,             --要サポート終了日
                row_CSG_M_IB_INFO.SUPPORT_INSTRUCT_CODE,        --要サポートフラグ
                (
                SELECT
                  DTL_TXT_SHRT_NM
                FROM
                  SNV_M_GNRC_SNV
                WHERE
                  CLSFCTN='M' AND
                  KEY_ITEM='CSG_SUPPORT_INSTRUCT_CODE' AND        --要サポートフラグ名
                  CD_VAL=row_CSG_M_IB_INFO.SUPPORT_INSTRUCT_CODE AND
                  VALD_STRT_DT <= set_sysdate AND
                  NVL(VALD_END_DT,SYSDATE) >= set_sysdate AND
                  NVL(DEL_FLG,'N') <>'X'
                ),
                row_CSG_M_IB_INFO.FIRST_SALE_PARTY_CODE,        --初期販売会社コード
                (
                SELECT
                  CUST_FRML_NM                                    --初期販売会社名
                FROM
                  SNV_M_CUST
                WHERE
                  CUST_CD=row_CSG_M_IB_INFO.FIRST_SALE_PARTY_CODE AND
                  CUST_ACCT_GRP='Z001' AND
                  NVL(DEL_FLG,'N') <>'X'
                ),
                row_CSG_M_IB_INFO.FIRST_SALE_PARTY_LOCATION,    --初期販売会社住所
                row_CSG_M_IB_INFO.FIRST_SALE_DEPT_NAME,         --初期販売部署名
                row_CSG_M_IB_INFO.FIRST_SALE_TEL,               --初期販売会社TEL
                row_CSG_M_IB_INFO.FIRST_SALE_FAX,               --初期販売会社FAX
                row_CSG_M_IB_INFO.FIRST_SALE_PERSON_NAME,       --初期販売担当者名
                row_CSG_M_IB_INFO.FIRST_SALE_MAIL_ADDRESS,      --初期販売メールアドレス
                row_CSG_M_IB_INFO.FIRST_COVERAGE,               --初回ワランティ条件
                (
                SELECT
                  DTL_TXT_SHRT_NM
                FROM
                  SNV_M_GNRC_ERP
                WHERE
                  CLSFCTN='V' AND
                  GRP_KEY='MATERIAL' AND
                  KEY_ITEM='ZMMDEFIRST_WT_COND' AND               --初回ワランティ条件(摘要)
                  CD_VAL=row_CSG_M_IB_INFO.FIRST_COVERAGE AND
                  VALD_STRT_DT <= set_sysdate AND
                  NVL(VALD_END_DT,SYSDATE) >= set_sysdate AND
                  NVL(DEL_FLG,'N') <>'X'
                ),
                row_CSG_M_IB_INFO.FIRST_MONTHS,                 --初回ワランティ月数
                row_CSG_M_IB_INFO.FIRST_START_DATE,             --初回期間(自)
                row_CSG_M_IB_INFO.FIRST_END_DATE,               --初回期間(至)
                row_CSG_M_IB_INFO.NEXT_COVERAGE,                --次回ワランティ条件
                (
                SELECT
                  DTL_TXT_SHRT_NM
                FROM
                  SNV_M_GNRC_ERP
                WHERE
                  CLSFCTN='V' AND
                  GRP_KEY='MATERIAL' AND
                  KEY_ITEM='ZMMDENEXT_WT_COND' AND                --次回ワランティ条件(摘要)
                  CD_VAL=row_CSG_M_IB_INFO.NEXT_COVERAGE AND
                  VALD_STRT_DT <= set_sysdate AND
                  NVL(VALD_END_DT,SYSDATE) >= set_sysdate AND
                  NVL(DEL_FLG,'N') <>'X'
                ),
                row_CSG_M_IB_INFO.NEXT_MONTHS,                  --次回ワランティ月数
                row_CSG_M_IB_INFO.NEXT_START_DATE,              --次回期間(自)
                row_CSG_M_IB_INFO.NEXT_END_DATE,                --次回期間(至)
--                row_CSG_M_IB_INFO.COVERAGE_START_BASE,          --ワランティ開始日基準
--                row_CSG_M_IB_INFO.COVERAGE_START_BASE_COMMENT,  --ワランティ開始日基準(摘要)
                row_CSG_M_IB_INFO.AGENT_FLAG,                   --販社フラグ
                (
                SELECT
                  DTL_TXT_SHRT_NM
                FROM
                  SNV_M_GNRC_SNV
                WHERE
                  CLSFCTN='M' AND
                  KEY_ITEM='CSG_INSTANCE_USE_COMPANY' AND         --販社名
                  CD_VAL=row_CSG_M_IB_INFO.AGENT_FLAG AND
                  VALD_STRT_DT <= set_sysdate AND
                  NVL(VALD_END_DT,SYSDATE) >= set_sysdate AND
                  PARM3='Y' AND
                  NVL(DEL_FLG,'N') <>'X'
                ),
                row_CSG_M_IB_INFO.SECONDARY_INVENTORY_CODE,     --委託先コード
                (
                SELECT
                  DEPO_NAME                                       --委託先名
                FROM
                  CSL_M_DEPO
                WHERE
                  DEPO_SUM_TYPE='30' AND
                  INVALID_FLAG ='0' AND
                  DEPO_CD=row_CSG_M_IB_INFO.SECONDARY_INVENTORY_CODE
                ),
                row_CSG_M_IB_INFO.BUNDLE_ITEM_CODE,             --バンドル品目コード
                (
                SELECT
                  PROD_CD || '.' || MAKR_MDL_NO || '.' || BR_NO || '..'  --バンドル品目
                FROM
                  SNV_M_ITEM
                WHERE
                  ITEM_CD=row_CSG_M_IB_INFO.BUNDLE_ITEM_CODE AND
                  PLT=row_CSG_M_IB_INFO.ORG_ID AND
                  NVL(DEL_FLG,'N') <>'X'
                ),
                row_CSG_M_IB_INFO.BUNDLE_ITEM_NAME,             --バンドル品目名
                row_CSG_M_IB_INFO.BUNDLE_SERIAL_NO,             --バンドルシリアル
                row_CSG_M_IB_INFO.HOST_ID,                      --ホストID
                row_CSG_M_IB_INFO.KEEP_WATCH_SYSTEM_ID,         --監視システムID
                row_CSG_M_IB_INFO.HP_CONFIG_CODE,               --HPコンフィグコード
                row_CSG_M_IB_INFO.OS_TYPE,                      --OS種別
                (
                SELECT
                  DTL_TXT_SHRT_NM
                FROM
                  SNV_M_GNRC_SNV
                WHERE
                  CLSFCTN='M' AND
                  KEY_ITEM='CSG_OS_TYPE' AND                      --OS種別名
                  CD_VAL=row_CSG_M_IB_INFO.OS_TYPE AND
                  VALD_STRT_DT <= set_sysdate AND
                  NVL(VALD_END_DT,SYSDATE) >= set_sysdate AND
                  NVL(DEL_FLG,'N') <>'X'
                ),
                row_CSG_M_IB_INFO.OS_VERSION,                   --OSバージョン
                row_CSG_M_IB_INFO.FIRMWARE_VERSION,             --Firmware Version
                row_CSG_M_IB_INFO.REVISION,                     --リビジョン
                row_CSG_M_IB_INFO.CPU_ROM_REVISION,             --CPU　ROMリビジョン
                row_CSG_M_IB_INFO.DISK_CAPACITY,                --ディスク容量
                row_CSG_M_IB_INFO.POWER_SUPPLY_TYPE,            --電源設備種類
                (
                SELECT
                  DTL_TXT_SHRT_NM
                FROM
                  SNV_M_GNRC_SNV
                WHERE
                  CLSFCTN='M' AND
                  KEY_ITEM='CSG_POWER_SUPPLY_TYPE' AND            --電源設備種類名
                  CD_VAL=row_CSG_M_IB_INFO.POWER_SUPPLY_TYPE AND
                  VALD_STRT_DT <= set_sysdate AND
                  NVL(VALD_END_DT,SYSDATE) >= set_sysdate AND
                  NVL(DEL_FLG,'N') <>'X'
                ),
                row_CSG_M_IB_INFO.POWER_SUPPLY_CAPACITY,        --電源容量
                row_CSG_M_IB_INFO.USE_POWER_VOLTAGE,          --使用電源周波数
                (
                SELECT
                  DTL_TXT_SHRT_NM
                FROM
                  SNV_M_GNRC_SNV
                WHERE
                  CLSFCTN='M' AND
                  KEY_ITEM='CSG_USE_POWER_FREQUENCY' AND          --使用電源周波数名
                  CD_VAL=row_CSG_M_IB_INFO.USE_POWER_FREQUENCY AND
                  VALD_STRT_DT <= set_sysdate AND
                  NVL(VALD_END_DT,SYSDATE) >= set_sysdate AND
                  NVL(DEL_FLG,'N') <>'X'
                ),
                row_CSG_M_IB_INFO.USE_POWER_VOLTAGE,            --使用電源電圧
                row_CSG_M_IB_INFO.HAVING_EARTH_FLAG,            --アース有無フラグ
                row_CSG_M_IB_INFO.MAC_ADDRESS,                  --MACアドレス
                row_CSG_M_IB_INFO.IP_ADDRESS,                   --IPアドレス
                row_CSG_M_IB_INFO.LICENSE_MANAGEMENT_NO,        --ライセンス管理番号
                row_CSG_M_IB_INFO.SUPERINTENDE_MANAGE_NO,       --主管部管理番号
                row_CSG_M_IB_INFO.LISENCE_START_DATE,           --ライセンス開始日
                row_CSG_M_IB_INFO.LISENCE_END_DATE,             --ライセンス終了日
                row_CSG_M_IB_INFO.REMOVE_ORDER_NO,              --移設受注番号
                row_CSG_M_IB_INFO.REMOVE_PO_NO,                 --移設先発注番号
                row_CSG_M_IB_INFO.REMOVE_DATE,                  --移設日
                row_CSG_M_IB_INFO.REMOVE_REASON,                --移設理由
                row_CSG_M_IB_INFO.SALES_DEPT_ORG_ID,            --F営業販売部署コード
                (
                SELECT
                  DPT_NM                                          ----F営業販売部署名
                FROM
                  SNV_M_DPT
                WHERE
                  EXP_DPT_CD=row_CSG_M_IB_INFO.SALES_DEPT_ORG_ID
                ),
                row_CSG_M_IB_INFO.SALES_DEPT_PERSON_ID,         --F営業販売担当者コード
                (
                SELECT
                  FULL_NM                                          --F営業販売担当者名
                FROM
                  SNV_M_EMP
                WHERE
                  EMP_CD=row_CSG_M_IB_INFO.SALES_DEPT_PERSON_ID
                ),
                row_CSG_M_IB_INFO.PRESENT_DEPT_ORG_ID,          --F営業現在担当部署コード
                (
                SELECT
                  DPT_NM                                          --F営業現在担当部署名
                FROM
                  SNV_M_DPT
                WHERE
                  EXP_DPT_CD=row_CSG_M_IB_INFO.PRESENT_DEPT_ORG_ID AND
                  VALD_STRT_DT <= set_sysdate AND
                  NVL(VALD_END_DT,SYSDATE) >= set_sysdate AND
                  NVL(DEL_FLG,'N') <>'X'
                ),
                row_CSG_M_IB_INFO.CTC_SALESREP_PERSON_ID,       --F営業現在担当者コード
                (
                SELECT
                  FULL_NM                                         --F営業現在担当者名
                FROM
                  SNV_M_EMP
                WHERE
                  EMP_CD=row_CSG_M_IB_INFO.CTC_SALESREP_PERSON_ID AND 
                  VALD_STRT_DT <= set_sysdate AND
                  NVL(VALD_END_DT,SYSDATE) >= set_sysdate
                ),
                row_CSG_M_IB_INFO.MAINTE_BUS_DEPT_ORG_ID,       --保守営業担当部署コード
                (
                SELECT
                  DPT_NM                                          --保守営業担当部署名
                FROM
                  SNV_M_DPT
                WHERE
                  EXP_DPT_CD=row_CSG_M_IB_INFO.MAINTE_BUS_DEPT_ORG_ID
                ),
                row_CSG_M_IB_INFO.MAINTE_BUS_PERSON_ID,         --保守営業担当者コード
                (
                SELECT
                  FULL_NM                                         --保守営業担当者名
                FROM
                  SNV_M_EMP
                WHERE
                  EMP_CD=row_CSG_M_IB_INFO.MAINTE_BUS_PERSON_ID AND 
                  VALD_STRT_DT <= set_sysdate AND
                  NVL(VALD_END_DT,SYSDATE) >= set_sysdate
                ),
                row_CSG_M_IB_INFO.PP_CONT_AK_NO,                --PP契約AK番号
                row_CSG_M_IB_INFO.PP_CONT_START_DATE,           --契約期間(自)
                row_CSG_M_IB_INFO.PP_CONT_END_DATE,             --契約期間(至)
                row_CSG_M_IB_INFO.SN_CHANGE_REASON,             --シリアル番号変更理由
                row_CSG_M_IB_INFO.X_DEPLOY_FLAG,                --X配備対象フラグ
                row_CSG_M_IB_INFO.ACCEPTANCE_DATE,              --受入日
                row_CSG_M_IB_INFO.OUT_WARRANTY_REGISTERED_FLAG, --外注契約ワランティ登録済フラグ
                row_CSG_M_IB_INFO.PROGRAM_ID,                   --更新プログラムID
                row_CSG_M_IB_INFO.PROCESS_ID,                   --処理ID
                row_CSG_M_IB_INFO.CREATION_USER_ID,             --作成者
                row_CSG_M_IB_INFO.CREATION_DATE,                --作成日時
                row_CSG_M_IB_INFO.UPDATE_USER_ID,               --更新者
                row_CSG_M_IB_INFO.UPDATE_DATE                   --更新日時
              );
              -- ***************************************************************
              -- N ：楽観ロック比較なし
              -- Y ：楽観ロック比較あり
              -- ※「楽観ロック比較」とは、テーブルの更新タイムスタンプとの比較の事であり、行ロックは両値とも行う。
              -- ※追加の場合は「N」
              -- ***************************************************************
              PRAM_PLACE_HOLDER := '設置機器情報の更新';
              table_name        := 'CSG_M_IB_INFO';
              IF LOCK_FLG = 'Y' THEN
                IF LOCK_DATE <> row_CSG_M_IB_INFO.UPDATE_DATE THEN
                  v_END_CODE := '22';
                  RAISE LOCK_FLG_EXCEPTION;
                END IF;
              END IF;
              --（判定１）更新処理でパラメータの「設置機器情報」の項目が設定されている場合
              --         パラメータの「インスタンス番号」の対象行に対し、設置機器情報テーブルの更新を行う。
              IF tIB_BASE IS NOT NULL OR tIB_BASE IS NOT EMPTY THEN
                FOR i IN 1..tIB_BASE.COUNT
                LOOP
                  ib_base_obj       := tIB_BASE(i);
                  set_column_name   := set_column_name || ib_base_obj.COLUM_NAME || '=' || ':' || ib_base_obj.COLUM_NAME;
                  IF i < tIB_BASE.COUNT THEN
                    set_column_name := set_column_name || ', ';
                  END IF;
                END LOOP;
                
                -- 更新プログラムID || 処理ID || 更新者 || 更新日時のカラム名と更新データ
                IF NVL(LENGTH(set_column_name),0) = 0 THEN
                     set_column_name := 'PROGRAM_ID = :PROGRAM_ID, PROCESS_ID = :PROCESS_ID, UPDATE_USER_ID = :UPDATE_USER_ID, UPDATE_DATE = :UPDATE_DATE';
                ELSE 
                     set_column_name := set_column_name || ', ' || 'PROGRAM_ID = :PROGRAM_ID, PROCESS_ID = :PROCESS_ID, UPDATE_USER_ID = :UPDATE_USER_ID, UPDATE_DATE = :UPDATE_DATE';
                END IF;
                
                -- 設置機器情報テーブルの更新
                stmt_str := 'UPDATE ' || table_name || ' SET ' || set_column_name || '                                       
                             WHERE INSTANCE_ID        = :INSTANCE_ID                                       
                               AND TOP_INSTANCE_ID    = :TOP_INSTANCE_ID';
                cur_hdl  := DBMS_SQL.OPEN_CURSOR;
                DBMS_SQL.PARSE(cur_hdl, stmt_str, DBMS_SQL.NATIVE);
                -- supply binds
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':INSTANCE_ID', INPUT_INSTANCE_ID);
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':TOP_INSTANCE_ID', INPUT_TOP_INSTANCE_ID);
                FOR i IN 1..tIB_BASE.COUNT
                LOOP
                  ib_base_obj := tIB_BASE(i);
                  DBMS_SQL.BIND_VARIABLE(cur_hdl, ':' || ib_base_obj.COLUM_NAME, ib_base_obj.SET_VALUE);
                END LOOP;
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':PROGRAM_ID', PROGRAM_ID);
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':PROCESS_ID', PROCESS_ID);
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':UPDATE_USER_ID', USER_ID);
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':UPDATE_DATE', set_sysdate);
                rows_processed := dbms_sql.execute(cur_hdl);
                -- execute
                DBMS_SQL.CLOSE_CURSOR(cur_hdl);
              -- （判定２）更新処理かつ最上位インスタンス（単独インスタンス）で「設置機器情報」の項目が設定されていないが「設置機器共通情報」の項目が設定されている場合
              --          パラメータの「インスタンス番号」の対象行に対し、設置機器情報テーブルの更新を行う。
              --          ※（判定2）の場合は更新プログラムID、処理ID、更新日時、更新者のみ更新。
              ELSIF (tIB_BASE IS NULL OR tIB_BASE IS EMPTY) AND (tIB_COMMON IS NOT NULL OR tIB_COMMON IS NOT EMPTY) THEN
                -- 更新プログラムID || 処理ID || 更新者 || 更新日時のカラム名と更新データ
                set_column_name := 'PROGRAM_ID = :PROGRAM_ID, PROCESS_ID = :PROCESS_ID, UPDATE_USER_ID = :UPDATE_USER_ID, UPDATE_DATE = :UPDATE_DATE';
                -- 設置機器情報テーブルの更新
                stmt_str := 'UPDATE ' || table_name || ' SET ' || set_column_name || '                                     
                             WHERE INSTANCE_ID        = ' || row_CSG_M_IB_INFO.INSTANCE_ID || '                                     
                               AND PARENT_INSTANCE_ID = ' || row_CSG_M_IB_INFO.PARENT_INSTANCE_ID || '                                     
                               AND TOP_INSTANCE_ID    = ' || row_CSG_M_IB_INFO.TOP_INSTANCE_ID;
                cur_hdl  := DBMS_SQL.OPEN_CURSOR;
                DBMS_SQL.PARSE(cur_hdl, stmt_str, DBMS_SQL.NATIVE);
                -- supply binds
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':PROGRAM_ID', PROGRAM_ID);
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':PROCESS_ID', PROCESS_ID);
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':UPDATE_USER_ID', USER_ID);
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':UPDATE_DATE', LOCK_DATE);
                rows_processed := dbms_sql.execute(cur_hdl);
                -- execute
                DBMS_SQL.CLOSE_CURSOR(cur_hdl);
              END IF;
            END LOOP;
        END IF;
        -- *********************************************************************
        -- 5. 設置機器共通情報テーブルの更新
        -- （判定１）更新処理でパラメータの「設置機器共通情報」の項目が設定されている場合
        -- （判定２）更新処理かつ最上位インスタンス（単独インスタンス）で「設置機器共通情報」の項目が設定されていないが「設置機器情
        -- 【設置機器共通情報テーブル更新処理】
        -- ・設置機器共通情報テーブルの排他取得
        -- ・設置機器共通情報テーブルの更新　　　　　※（判定2）の場合は更新プログラムID、処理ID、更新日時、更新者のみ更新。
        -- ・設置機器共通情報履歴テーブルの追加
        -- *********************************************************************
        set_column_name       := '';
        set_value_column      := '';
        stmt_str              := '';
        IF tIB_COMMON IS NOT NULL OR tIB_COMMON IS NOT EMPTY THEN
          -- *******************************************************************
          -- ・設置機器共通情報履歴テーブルの追加
          -- *******************************************************************
          FOR row_CSG_M_IB_COMMON_INFO IN c_CSG_M_IB_COMMON_INFO
            LOOP
            INSERT
            INTO CSG_M_IB_COMMON_INFO_HIS
              (
                INSTANCE_HIS_ID,              -- 履歴ID
                TOP_INSTANCE_ID,              -- 最上位インスタンス番号
                CS_IN_CHARGE_CODE,            -- 担当CSコード
                CS_IN_CHARGE_NAME,            -- 担当CS名
                CE_CODE,                      -- 担当CEコード
                CE_NAME,                      -- 担当CE名
                INSTALL_CUSTOMER_CODE,        -- 設置先顧客コード
                INSTALL_CUSTOMER_NAME,        -- 設置先顧客名
--                INSTALL_CUSTOMER_AR_NAME,     -- 顧客略称
                INSTALL_LOCATION_CODE,        -- 設置先顧客住所コード
                INSTALL_LOCATION,             -- 設置先顧客住所
                INSTALL_LOCATION_DEPT_NAME,   -- 設置先顧客部署名
                INSTALL_LOCATION_PERSON_NAME, -- 設置先顧客担当者名
                INSTALL_LOCATION_TEL,         -- 設置先TEL
                INSTALL_LOCATION_FAX,         -- 設置先FAX
                INCIDENT_SERVIRITY_NAME,      -- 重要度
                USE_CONDITION,                -- 利用形態
                USE_PERPOSE,                  -- 利用目的
                ENDUSER_PARTY_ID,             -- エンドユーザ会社コード
                ENDUSER_PARTY_NAME,           -- エンドユーザ会社名
                ENDUSER_LOCATION,             -- エンドユーザ住所
                ENDUSER_CHRG_DEPT_NAME,       -- エンドユーザ部署名
                ENDUSER_CHRG_PERSON_NAME,     -- エンドユーザ担当者名
                ENDUSER_TEL,                  -- エンドユーザTEL
                ENDUSER_FAX,                  -- エンドユーザFAX
                ENDUSER_MAIL_ADDRESS,         -- エンドユーザメールアドレス
                PROGRAM_ID,                   -- 更新プログラムID
                PROCESS_ID,                   -- 処理ID
                CREATION_USER_ID,             -- 作成者
                CREATION_DATE,                -- 作成日時
                UPDATE_USER_ID,               -- 更新者
                UPDATE_DATE                   -- 更新日時
              )
              VALUES
              (
                CSG_M_IB_COMMON_HIS_ID_SEQ.NEXTVAL,                    -- 履歴ID
                row_CSG_M_IB_COMMON_INFO.TOP_INSTANCE_ID,              -- 最上位インスタンス番号
                row_CSG_M_IB_COMMON_INFO.CS_IN_CHARGE_CODE,            -- 担当CSコード
                (
                SELECT
                  GROUP_NAME -- 担当CS名
                FROM
                  CSG_M_GROUP_MANAGEMENT
                WHERE
                  GROUP_ID=row_CSG_M_IB_COMMON_INFO.CS_IN_CHARGE_CODE AND
                  START_DATE <= row_CSG_M_IB_COMMON_INFO.UPDATE_DATE AND
                  NVL(END_DATE,SYSDATE) >= row_CSG_M_IB_COMMON_INFO.UPDATE_DATE
                ),
                row_CSG_M_IB_COMMON_INFO.CE_CODE,                      -- 担当CEコード
                (
                SELECT
                  FULL_NM -- 担当CE名
                FROM
                  SNV_M_EMP
                WHERE
                  EMP_CD=row_CSG_M_IB_COMMON_INFO.CE_CODE AND
                  VALD_STRT_DT <= row_CSG_M_IB_COMMON_INFO.UPDATE_DATE AND
                  NVL(VALD_END_DT,SYSDATE) >= row_CSG_M_IB_COMMON_INFO.UPDATE_DATE
                ),
                row_CSG_M_IB_COMMON_INFO.INSTALL_CUSTOMER_CODE,        -- 設置先顧客コード
                (
                SELECT
                  CUST_FRML_NM -- 設置先顧客名
                FROM
                  SNV_M_CUST
                WHERE
                  CUST_CD=row_CSG_M_IB_COMMON_INFO.INSTALL_CUSTOMER_CODE AND
                  CUST_ACCT_GRP='Z001'
                ),
--                row_CSG_M_IB_COMMON_INFO.INSTALL_CUSTOMER_AR_NAME,     -- 顧客略称
                row_CSG_M_IB_COMMON_INFO.INSTALL_LOCATION_CODE,        -- 設置先顧客住所コード
                (
                SELECT
                  INSTALL_LOCATION -- 設置先顧客住所
                FROM
                  CSG_M_IB_ADDRESS
                WHERE
                  INSTALL_LOCATION_CODE=row_CSG_M_IB_COMMON_INFO.INSTALL_LOCATION_CODE
                ),
                row_CSG_M_IB_COMMON_INFO.INSTALL_LOCATION_DEPT_NAME,   -- 設置先顧客部署名
                row_CSG_M_IB_COMMON_INFO.INSTALL_LOCATION_PERSON_NAME, -- 設置先顧客担当者名
                row_CSG_M_IB_COMMON_INFO.INSTALL_LOCATION_TEL,         -- 設置先TEL
                row_CSG_M_IB_COMMON_INFO.INSTALL_LOCATION_FAX,         -- 設置先FAX
                row_CSG_M_IB_COMMON_INFO.INCIDENT_SERVIRITY_NAME,      -- 重要度
                row_CSG_M_IB_COMMON_INFO.USE_CONDITION,                -- 利用形態
                row_CSG_M_IB_COMMON_INFO.USE_PERPOSE,                  -- 利用目的
                row_CSG_M_IB_COMMON_INFO.ENDUSER_PARTY_CODE,             -- エンドユーザ会社コード
                (
                SELECT
                  CUST_FRML_NM -- エンドユーザ会社名
                FROM
                  SNV_M_CUST
                WHERE
                  CUST_CD=row_CSG_M_IB_COMMON_INFO.ENDUSER_PARTY_CODE AND
                  CUST_ACCT_GRP='Z001'
                ),
                row_CSG_M_IB_COMMON_INFO.ENDUSER_LOCATION,             -- エンドユーザ住所
                row_CSG_M_IB_COMMON_INFO.ENDUSER_CHRG_DEPT_NAME,       -- エンドユーザ部署名
                row_CSG_M_IB_COMMON_INFO.ENDUSER_CHRG_PERSON_NAME,     -- エンドユーザ担当者名
                row_CSG_M_IB_COMMON_INFO.ENDUSER_TEL,                  -- エンドユーザTEL
                row_CSG_M_IB_COMMON_INFO.ENDUSER_FAX,                  -- エンドユーザFAX
                row_CSG_M_IB_COMMON_INFO.ENDUSER_MAIL_ADDRESS,         -- エンドユーザメールアドレス
                row_CSG_M_IB_COMMON_INFO.PROGRAM_ID,                   -- 更新プログラムID
                row_CSG_M_IB_COMMON_INFO.PROCESS_ID,                   -- 処理ID
                row_CSG_M_IB_COMMON_INFO.CREATION_USER_ID,             -- 作成者
                row_CSG_M_IB_COMMON_INFO.CREATION_DATE,                -- 作成日時
                row_CSG_M_IB_COMMON_INFO.UPDATE_USER_ID,               -- 更新者
                row_CSG_M_IB_COMMON_INFO.UPDATE_DATE                   -- 更新日時
              );
              -- ***************************************************************
              -- N ：楽観ロック比較なし
              -- Y ：楽観ロック比較あり
              -- ※「楽観ロック比較」とは、テーブルの更新タイムスタンプとの比較の事であり、行ロックは両値とも行う。
              -- ※追加の場合は「N」
              -- ***************************************************************
              PRAM_PLACE_HOLDER := '設置機器共通情報の更新';
              table_name        := 'CSG_M_IB_COMMON_INFO';
              
              IF LOCK_FLG = 'Y' THEN
                IF LOCK_DATE <> row_CSG_M_IB_COMMON_INFO.UPDATE_DATE THEN
                  v_END_CODE := '22';
                  RAISE LOCK_FLG_EXCEPTION;
                END IF;
              END IF;
              -- （判定１）更新処理でパラメータの「設置機器共通情報」の項目が設定されている場合
              --          パラメータの「インスタンス番号」の対象行に対し、設置機器共通情報テーブルの更新を行う。　　　　
              IF tIB_COMMON IS NOT NULL OR tIB_COMMON IS NOT EMPTY THEN
                FOR i IN 1..tIB_COMMON.COUNT
                LOOP
                  ib_common_obj := tIB_COMMON(i);
                  set_column_name   := set_column_name || ib_common_obj.COLUM_NAME || '=' || ':' || ib_common_obj.COLUM_NAME;
                  IF i           < tIB_COMMON.COUNT THEN
                    set_column_name := set_column_name || ', ';
                  END IF;
                END LOOP;
                
                -- 更新プログラムID || 処理ID || 更新者 || 更新日時のカラム名と更新データ
                IF NVL(LENGTH(set_column_name),0) = 0 THEN
                     set_column_name := 'PROGRAM_ID = :PROGRAM_ID, PROCESS_ID = :PROCESS_ID, UPDATE_USER_ID = :UPDATE_USER_ID, UPDATE_DATE = :UPDATE_DATE';
                ELSE 
                     set_column_name := set_column_name || ', ' || 'PROGRAM_ID = :PROGRAM_ID, PROCESS_ID = :PROCESS_ID, UPDATE_USER_ID = :UPDATE_USER_ID, UPDATE_DATE = :UPDATE_DATE';
                END IF;
                -- 設置機器共通情報テーブルの更新
                stmt_str := 'UPDATE ' || table_name || ' SET ' || set_column_name || '                                         
                             WHERE TOP_INSTANCE_ID = :TOP_INSTANCE_ID';
                cur_hdl  := DBMS_SQL.OPEN_CURSOR;
                DBMS_SQL.PARSE(cur_hdl, stmt_str, DBMS_SQL.NATIVE);
                -- supply binds
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':TOP_INSTANCE_ID', INPUT_TOP_INSTANCE_ID);
                FOR i IN 1..tIB_COMMON.COUNT
                LOOP
                  ib_common_obj := tIB_COMMON(i);
                  DBMS_SQL.BIND_VARIABLE(cur_hdl, ':' || ib_common_obj.COLUM_NAME, ib_common_obj.SET_VALUE);
                END LOOP;
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':PROGRAM_ID', PROGRAM_ID);
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':PROCESS_ID', PROCESS_ID);
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':UPDATE_USER_ID', USER_ID);
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':UPDATE_DATE', set_sysdate);
                rows_processed := dbms_sql.execute(cur_hdl);
                -- execute
                DBMS_SQL.CLOSE_CURSOR(cur_hdl);
                -- （判定２）更新処理かつ最上位インスタンス（単独インスタンス）で「設置機器共通情報」の項目が設定されていないが「設置機器情報」の項目が設定されている場合
                --          パラメータの「インスタンス番号」の対象行に対し、設置機器情報テーブルの更新を行う。
                --          ※（判定2）の場合は更新プログラムID、処理ID、更新日時、更新者のみ更新。
              ELSIF (tIB_COMMON IS NULL OR tIB_COMMON IS EMPTY) AND (tIB_BASE IS NOT NULL OR tIB_BASE IS NOT EMPTY) THEN
                -- 更新プログラムID || 処理ID || 更新者 || 更新日時のカラム名と更新データ
                set_column_name := 'PROGRAM_ID = :PROGRAM_ID, PROCESS_ID = :PROCESS_ID, UPDATE_USER_ID = :UPDATE_USER_ID, UPDATE_DATE = :UPDATE_DATE';
                -- 設置機器共通情報テーブルの更新
                stmt_str := 'UPDATE ' || table_name || ' SET ' || set_column_name || '                                       
                             WHERE TOP_INSTANCE_ID = ' || row_CSG_M_IB_COMMON_INFO.TOP_INSTANCE_ID;
                cur_hdl  := DBMS_SQL.OPEN_CURSOR;
                DBMS_SQL.PARSE(cur_hdl, stmt_str, DBMS_SQL.NATIVE);
                -- supply binds
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':PROGRAM_ID', PROGRAM_ID);
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':PROCESS_ID', PROCESS_ID);
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':UPDATE_USER_ID', USER_ID);
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':UPDATE_DATE', LOCK_DATE);
                rows_processed := dbms_sql.execute(cur_hdl);
                -- execute
                DBMS_SQL.CLOSE_CURSOR(cur_hdl);
              END IF;
            END LOOP;
        END IF;
      END;
    END IF;
  --****************************************************************************
  -- 追加・・・払い出したインスタンス番号
  -- 更新・・・更新したインスタンス番号
  --****************************************************************************
  OUT_INSTANCE_ID := INPUT_INSTANCE_ID;
  END IF;
  --****************************************************************************
  -- コミット行きました。
  --****************************************************************************
--  COMMIT;
  --****************************************************************************
  -- 0 ：正常コード
  -- 10：警告コード(排他エラー)
  -- 20：異常コード
  -- 21：異常コード(マスタ存在チェックエラー)
  -- 22：異常コード(排他エラー)
  --****************************************************************************
  END_CODE := v_END_CODE; -- 0 ：正常コード
  --****************************************************************************
  -- テーブルに更新した更新日時を設定　（正常終了以外はNULLを設定）
  --****************************************************************************
  UPDATE_DATE := SYSDATE;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
    -- データの取得に失敗した場合、異常終了としエラーメッセージをログ出力し後続の処理を中断する。
    DBMS_OUTPUT.PUT_LINE(PRAM_PLACE_HOLDER || 'に失敗しました。');
    END_CODE        := '20';
    ERROR_MESSAGE   := PRAM_PLACE_HOLDER;
    OUT_INSTANCE_ID := INPUT_INSTANCE_ID;
    --************************************************************************
    -- テーブルに更新した更新日時を設定　（正常終了以外はNULLを設定）
    --************************************************************************
    UPDATE_DATE     := NULL;
    ROLLBACK;
    RETURN;
  WHEN PRAM_EXCEPTION THEN
    DBMS_OUTPUT.PUT_LINE(PRAM_PLACE_HOLDER);
    END_CODE        := '20';
    ERROR_MESSAGE   := PRAM_PLACE_HOLDER;
    OUT_INSTANCE_ID := INPUT_INSTANCE_ID;
    --************************************************************************
    -- テーブルに更新した更新日時を設定　（正常終了以外はNULLを設定）
    --************************************************************************
    UPDATE_DATE     := NULL;
    ROLLBACK;
    RETURN;
  WHEN MASTER_EXCEPTION THEN
    DBMS_OUTPUT.PUT_LINE(PRAM_PLACE_HOLDER);
    END_CODE        := '21';
    ERROR_MESSAGE   := PRAM_PLACE_HOLDER;
    OUT_INSTANCE_ID := INPUT_INSTANCE_ID;
    --************************************************************************
    -- テーブルに更新した更新日時を設定　（正常終了以外はNULLを設定）
    --************************************************************************
    UPDATE_DATE     := NULL;
    ROLLBACK;
    RETURN;
  WHEN LOCK_FLG_EXCEPTION THEN
    DBMS_OUTPUT.PUT_LINE(PRAM_PLACE_HOLDER || 'に失敗しました。');
    END_CODE        := '22';
    ERROR_MESSAGE   := PRAM_PLACE_HOLDER;
    OUT_INSTANCE_ID := INPUT_INSTANCE_ID;
    --************************************************************************
    -- テーブルに更新した更新日時を設定　（正常終了以外はNULLを設定）
    --************************************************************************
    UPDATE_DATE     := NULL;
    ROLLBACK;
    RETURN;
    -- その他未定義の例外の処理
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE(PRAM_PLACE_HOLDER || 'に失敗しました。');
    IF SQLCODE = -54 THEN
      END_CODE        := '21';
    ELSE
      END_CODE        := '20';
    END IF;
    ERROR_MESSAGE   := PRAM_PLACE_HOLDER;
    OUT_INSTANCE_ID := INPUT_INSTANCE_ID;
    --************************************************************************
    -- テーブルに更新した更新日時を設定　（正常終了以外はNULLを設定）
    --************************************************************************
    UPDATE_DATE     := NULL;
    DBMS_OUTPUT.PUT_LINE('ORACLE ERR_CODE    := ' || SQLCODE);          -- ＤＢエラーコード
    DBMS_OUTPUT.PUT_LINE('ORACLE ERR_MESSAGE := ' || sqlerrm(SQLCODE)); -- ＤＢエラーメッセージ
    DBMS_OUTPUT.PUT_LINE(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    ROLLBACK;
    RETURN;
  END CSG02_PROC_IB_TABLE_UPDATE;

  PROCEDURE CSG02_PROC_IB_SI_UPDATE(
      PROC_TYPE         IN NUMBER DEFAULT 0,     -- 追加・更新区分
      INPUT_INSTANCE_ID IN VARCHAR2,             -- インスタンス番号
      INPUT_SOFTWARE_ID IN VARCHAR2,             -- ソフトウェアID
      tSOFTWARE_INFO    IN ARRAY_IB_SOFTWARE,    -- ソフトウェア情報
      PROGRAM_ID        IN VARCHAR2,             -- 更新プログラムID
      PROCESS_ID        IN VARCHAR2,             -- 処理ID
      USER_ID           IN VARCHAR2,             -- ユーザID
      LOCK_FLG          IN VARCHAR2 DEFAULT 'N', -- 楽観ロック比較有無フラグ
      LOCK_DATE         IN DATE,                 -- 比較日時
      END_CODE          OUT VARCHAR2,            -- 終了コード
      ERROR_MESSAGE     OUT VARCHAR2,            -- エラーメッセージ
      OUT_INSTANCE_ID   OUT VARCHAR2,            -- インスタンス番号
      OUT_SOFTWARE_ID   OUT VARCHAR2,            -- ソフトウェアID
      UPDATE_DATE       OUT VARCHAR2             -- 更新日時
  )  AS
  -- ****************************************************************************
  -- 処理パラメータ
  -- ****************************************************************************
  PRAM_PLACE_HOLDER    VARCHAR2(32670); -- プレースホルダパラメータ
  NO_SEARCH_PROGRAM_ID EXCEPTION;
  PRAM_EXCEPTION       EXCEPTION;
  MASTER_EXCEPTION     EXCEPTION;
  LOCK_FLG_EXCEPTION   EXCEPTION;
  table_name           VARCHAR2(100);
  stmt_str             VARCHAR2(2000);
  set_sysdate          DATE;
  set_column_name      VARCHAR2(1000);
  set_value_column     VARCHAR2(1000);
  ib_software_obj      CONTACT_IB_SOFTWARE_OBJ;
  cur_hdl              NUMBER;
  rows_processed       NUMBER;
  v_END_CODE           VARCHAR2(10);
  CURSOR c_IB_SOFTWARE_INFO
  IS
    SELECT SOFTWARE_ID,     -- ソフトウェアID ○
      INSTANCE_ID,          -- インスタンス番号 ○
      SOFTWARE_LISENCE_KEY, -- ソフトウェアライセンスキー
      HOST_ID,              -- ホストID
      HOST_NAME,            -- ホスト名
      PLATFORM_NAME,        -- プラットフォーム名
      OS,                   -- OS
      END_DATE,             -- 終了日
      INVALID_FLAG,         -- 無効フラグ
      VERSION,              -- バージョン
      SW_SERIAL_NO,         -- シリアル番号
      USER_NO,              -- ユーザ数
      NOTE,                 -- 備考
      PROGRAM_ID,           -- 更新プログラムID
      PROCESS_ID,           -- 処理ID
      CREATION_USER_ID,     -- 作成者 ○
      CREATION_DATE,        -- 作成日時 ○
      UPDATE_USER_ID,       -- 更新者 ○
      UPDATE_DATE           -- 更新日時 ○
    FROM CSG_M_IB_SW_INFO
    WHERE SOFTWARE_ID = INPUT_SOFTWARE_ID
    AND INSTANCE_ID   = INPUT_INSTANCE_ID FOR UPDATE OF SOFTWARE_ID,
      INSTANCE_ID nowait;
  BEGIN
  -- ***************************************************************************
  -- 初期値
  -- ***************************************************************************
  set_column_name     := '';
  set_value_column    := '';
  stmt_str            := '';
  v_END_CODE          := '0';
  set_sysdate         := SYSDATE;
  -- ***************************************************************************
  -- 設置機器ソフトウェア情報の追加・更新における以下の内容を設定する。
  -- 0 ：追加
  -- ***************************************************************************
  IF PROC_TYPE = 0 THEN
  -- ***************************************************************************
  -- 2. 設置機器ソフトウェア情報テーブルの追加
  -- （判定１）追加処理でパラメータの「設置機器ソフトウェア情報」の項目が設定されている場合
  -- 【設置機器ソフトウェア情報テーブル追加処理】
  -- ・設置機器ソフトウェア情報テーブルの追加
  -- **************************************************************************
    BEGIN
      PRAM_PLACE_HOLDER := '設置機器ソフトウェア情報の挿入';
      table_name        := 'CSG_M_IB_SW_INFO';
      -- パーツID || インスタンス番号のカラム名
      set_column_name   := 'SOFTWARE_ID, INSTANCE_ID, ';
      -- パーツID || インスタンス番号の更新データ
      set_value_column  := ':SOFTWARE_ID, :INSTANCE_ID,';
      IF tSOFTWARE_INFO IS NULL OR tSOFTWARE_INFO IS EMPTY THEN
          RAISE PRAM_EXCEPTION;
      ELSE
        FOR i IN 1..tSOFTWARE_INFO.COUNT
          LOOP
            ib_software_obj     := tSOFTWARE_INFO(i);
            set_column_name     := set_column_name || ib_software_obj.COLUM_NAME;
            set_value_column    := set_value_column || ':' || ib_software_obj.COLUM_NAME;
            IF i < tSOFTWARE_INFO.COUNT THEN 
              set_column_name   := set_column_name || ', ';
              set_value_column  := set_value_column || ', ';
            END IF;
          END LOOP;
          -- 更新プログラムID || 処理ID || 作成者 || 作成日時 || 更新者 || 更新日時のカラム名
          set_column_name  := set_column_name || ', ' || 'PROGRAM_ID, PROCESS_ID, CREATION_USER_ID, CREATION_DATE, UPDATE_USER_ID, UPDATE_DATE';
          -- 更新プログラムID || 処理ID || 作成者 || 作成日時 || 更新者 || 更新日時の更新データ
          set_value_column := set_value_column || ', :PROGRAM_ID, :PROCESS_ID, :CREATION_USER_ID, :CREATION_DATE, :UPDATE_USER_ID, :UPDATE_DATE';
          -- 設置機器ソフトウェア情報テーブルの追加
          STMT_STR         := 'INSERT INTO ' || TABLE_NAME || '(' || SET_COLUMN_NAME || ') VALUES ('|| SET_VALUE_COLUMN ||')';
          cur_hdl          := DBMS_SQL.OPEN_CURSOR;
          DBMS_SQL.PARSE(cur_hdl, stmt_str, DBMS_SQL.NATIVE);
          -- supply binds
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':SOFTWARE_ID', INPUT_SOFTWARE_ID);
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':INSTANCE_ID', INPUT_INSTANCE_ID);
          FOR i IN 1..tSOFTWARE_INFO.COUNT
            LOOP
              ib_software_obj     := tSOFTWARE_INFO(i);
              DBMS_SQL.BIND_VARIABLE(cur_hdl, ':' || ib_software_obj.COLUM_NAME, ib_software_obj.SET_VALUE);
            END LOOP;
         
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':PROGRAM_ID', PROGRAM_ID);
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':PROCESS_ID', PROCESS_ID);
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':CREATION_USER_ID', USER_ID);
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':CREATION_DATE', set_sysdate);
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':UPDATE_USER_ID', USER_ID);
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':UPDATE_DATE', set_sysdate);
         
          rows_processed := dbms_sql.execute(cur_hdl);  
          -- execute
          DBMS_SQL.CLOSE_CURSOR(cur_hdl); -- close
      END IF;
    END;
  -- ***************************************************************************
  -- 設置機器ソフトウェア情報の追加・更新における以下の内容を設定する。
  -- 10：更新
  -- ***************************************************************************
  ELSIF PROC_TYPE = 10 THEN
  -- ***************************************************************************
  -- 3. 設置機器ソフトウェア情報テーブルの更新
  -- （判定１）更新処理でパラメータの「設置機器ソフトウェア情報」の項目が設定されている場合
  -- 【設置機器ソフトウェア情報テーブル更新処理】
  -- ・設置機器ソフトウェア情報テーブルの排他取得
  -- ・設置機器ソフトウェア情報テーブルの更新　　　　　※（判定2）の場合は更新プログラムID、処理ID、更新日時、更新者のみ更新。
  -- ・設置機器ソフトウェア情報履歴テーブルの追加
  -- ***************************************************************************
    BEGIN
      IF tSOFTWARE_INFO IS NULL OR tSOFTWARE_INFO IS EMPTY THEN
          RAISE PRAM_EXCEPTION;
      END IF;
      -- ***********************************************************************
      -- ・設置機器ソフトウェア情報履歴テーブルの追加
      -- ***********************************************************************
      IF tSOFTWARE_INFO IS NOT NULL OR tSOFTWARE_INFO IS NOT EMPTY THEN
        PRAM_PLACE_HOLDER     := '設置機器ソフトウェア情報履歴の挿入';
        table_name            := 'CSG_M_IB_SW_INFO_HIS';
        FOR row_IB_SOFTWARE_INFO IN c_IB_SOFTWARE_INFO 
          LOOP
          INSERT
          INTO CSG_M_IB_SW_INFO_HIS
            (
              SOFTWARE_HIS_ID,      -- ソフトウェア履歴ID
              SOFTWARE_ID,          -- ソフトウェアID
              INSTANCE_ID,          -- インスタンス番号
              SOFTWARE_LISENCE_KEY, -- ソフトウェアライセンスキー
              HOST_ID,              -- ホストID
              HOST_NAME,            -- ホスト名
              PLATFORM_NAME,        -- プラットフォーム名
              OS,                   -- OS
              END_DATE,             -- 終了日
              INVALID_FLAG,         -- 無効フラグ
              VERSION,              -- バージョン
              SW_SERIAL_NO,         -- シリアル番号
              USER_NO,              -- ユーザ数
              NOTE,                 -- 備考
              PROGRAM_ID,           -- 更新プログラムID
              PROCESS_ID,           -- 処理ID
              CREATION_USER_ID,     -- 作成者
              CREATION_DATE,        -- 作成日時
              UPDATE_USER_ID,       -- 更新者
              UPDATE_DATE           -- 更新日時
            )
            VALUES
            (
              CSG_M_IB_HIS_ID_SEQ.NEXTVAL,               -- ソフトウェア履歴ID
              row_IB_SOFTWARE_INFO.SOFTWARE_ID,          -- ソフトウェアID
              row_IB_SOFTWARE_INFO.INSTANCE_ID,          -- インスタンス番号
              row_IB_SOFTWARE_INFO.SOFTWARE_LISENCE_KEY, -- ソフトウェアライセンスキー
              row_IB_SOFTWARE_INFO.HOST_ID,              -- ホストID
              row_IB_SOFTWARE_INFO.HOST_NAME,            -- ホスト名
              row_IB_SOFTWARE_INFO.PLATFORM_NAME,        -- プラットフォーム名
              row_IB_SOFTWARE_INFO.OS,                   -- OS
              row_IB_SOFTWARE_INFO.END_DATE,             -- 終了日
              row_IB_SOFTWARE_INFO.INVALID_FLAG,         -- 無効フラグ
              row_IB_SOFTWARE_INFO.VERSION,              -- バージョン
              row_IB_SOFTWARE_INFO.SW_SERIAL_NO,         -- シリアル番号
              row_IB_SOFTWARE_INFO.USER_NO,              -- ユーザ数
              row_IB_SOFTWARE_INFO.NOTE,                 -- 備考
              row_IB_SOFTWARE_INFO.PROGRAM_ID,           -- 更新プログラムID
              row_IB_SOFTWARE_INFO.PROCESS_ID,           -- 処理ID
              row_IB_SOFTWARE_INFO.CREATION_USER_ID,     -- 作成者
              row_IB_SOFTWARE_INFO.CREATION_DATE,        -- 作成日時
              row_IB_SOFTWARE_INFO.UPDATE_USER_ID,       -- 更新者
              row_IB_SOFTWARE_INFO.UPDATE_DATE           -- 更新日時
            );
            -- *****************************************************************
            -- N ：楽観ロック比較なし
            -- Y ：楽観ロック比較あり
            -- ※「楽観ロック比較」とは、テーブルの更新タイムスタンプとの比較の事であり、行ロックは両値とも行う。
            -- ※追加の場合は「N」
            -- *****************************************************************
            PRAM_PLACE_HOLDER := '設置機器ソフトウェア情報の更新';
            table_name        := 'CSG_M_IB_SW_INFO';
            
            IF LOCK_FLG = 'Y' THEN
              IF LOCK_DATE <> row_IB_SOFTWARE_INFO.UPDATE_DATE THEN
                v_END_CODE   := '22';
                RAISE LOCK_FLG_EXCEPTION;
              END IF;
            END IF;
            FOR i IN 1..tSOFTWARE_INFO.COUNT
            LOOP
              ib_software_obj     := tSOFTWARE_INFO(i);
              set_column_name      := set_column_name || ib_software_obj.COLUM_NAME || '=' || ':' || ib_software_obj.COLUM_NAME;
              IF i < tSOFTWARE_INFO.COUNT THEN 
                set_column_name    := set_column_name || ', ';
              END IF;
            END LOOP;
            -- 更新プログラムID || 処理ID || 更新者 || 更新日時のカラム名と更新データ
            set_column_name         := set_column_name || ', ' || 'PROGRAM_ID = :PROGRAM_ID, PROCESS_ID = :PROCESS_ID, UPDATE_USER_ID = :UPDATE_USER_ID, UPDATE_DATE = :UPDATE_DATE';
            -- 設置機器パーツ情報テーブルの更新
            stmt_str            := 'UPDATE ' || table_name || ' SET ' || set_column_name || ' 
                                    WHERE SOFTWARE_ID = :SOFTWARE_ID 
                                      AND INSTANCE_ID = :INSTANCE_ID';
            cur_hdl             := DBMS_SQL.OPEN_CURSOR;
            DBMS_SQL.PARSE(cur_hdl, stmt_str, DBMS_SQL.NATIVE);
            -- supply binds
            DBMS_SQL.BIND_VARIABLE(cur_hdl, ':SOFTWARE_ID', INPUT_SOFTWARE_ID);
            DBMS_SQL.BIND_VARIABLE(cur_hdl, ':INSTANCE_ID', INPUT_INSTANCE_ID);
            FOR i IN 1..tSOFTWARE_INFO.COUNT
              LOOP
                ib_software_obj     := tSOFTWARE_INFO(i);
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':' || ib_software_obj.COLUM_NAME, ib_software_obj.SET_VALUE);
              END LOOP;         
            DBMS_SQL.BIND_VARIABLE(cur_hdl, ':PROGRAM_ID', PROGRAM_ID);
            DBMS_SQL.BIND_VARIABLE(cur_hdl, ':PROCESS_ID', PROCESS_ID);
            DBMS_SQL.BIND_VARIABLE(cur_hdl, ':UPDATE_USER_ID', USER_ID);
            DBMS_SQL.BIND_VARIABLE(cur_hdl, ':UPDATE_DATE', set_sysdate);
               
            rows_processed := DBMS_SQL.EXECUTE(cur_hdl);  
            -- execute
            DBMS_SQL.CLOSE_CURSOR(cur_hdl);
          END LOOP;
      END IF;
    END;
  END IF;
  --***************************************************************************
  -- コミット行きました。
  --***************************************************************************
--  COMMIT;
  --***************************************************************************
  -- 0 ：正常コード
  -- 10：警告コード(排他エラー)
  -- 20：異常コード
  -- 22：異常コード(排他エラー)
  --***************************************************************************
  END_CODE        := v_END_CODE; -- 0 ：正常コード
  --***************************************************************************
  -- 追加・・・払い出したインスタンス番号
  -- 更新・・・更新したインスタンス番号
  --***************************************************************************
  OUT_INSTANCE_ID := INPUT_INSTANCE_ID;
  --***************************************************************************
  -- 追加・・・払い出したソフトウェアID
  -- 更新・・・更新したソフトウェアID
  --***************************************************************************
  OUT_SOFTWARE_ID := INPUT_SOFTWARE_ID;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      -- データの取得に失敗した場合、異常終了としエラーメッセージをログ出力し後続の処理を中断する。
      DBMS_OUTPUT.PUT_LINE(PRAM_PLACE_HOLDER || 'に失敗しました。');
      END_CODE        := '20';
      ERROR_MESSAGE   := PRAM_PLACE_HOLDER;
      OUT_INSTANCE_ID := INPUT_INSTANCE_ID;
      OUT_SOFTWARE_ID := INPUT_SOFTWARE_ID;
      UPDATE_DATE     := NULL;
      ROLLBACK;
      RETURN;
    WHEN PRAM_EXCEPTION THEN
      DBMS_OUTPUT.PUT_LINE(PRAM_PLACE_HOLDER || 'のデータが設定されていません。');
      END_CODE        := '20';
      ERROR_MESSAGE   := PRAM_PLACE_HOLDER;
      OUT_INSTANCE_ID := INPUT_INSTANCE_ID;
      OUT_SOFTWARE_ID := INPUT_SOFTWARE_ID;
      UPDATE_DATE     := NULL;
      ROLLBACK;
      RETURN;
    WHEN MASTER_EXCEPTION THEN
      DBMS_OUTPUT.PUT_LINE(PRAM_PLACE_HOLDER);
      END_CODE        := '21';
      ERROR_MESSAGE   := PRAM_PLACE_HOLDER;
      OUT_INSTANCE_ID := INPUT_INSTANCE_ID;
      OUT_SOFTWARE_ID := INPUT_SOFTWARE_ID;
      --************************************************************************
      -- テーブルに更新した更新日時を設定　（正常終了以外はNULLを設定）
      --************************************************************************
      UPDATE_DATE     := NULL;
      ROLLBACK;
      RETURN;
    WHEN LOCK_FLG_EXCEPTION THEN
      DBMS_OUTPUT.PUT_LINE(PRAM_PLACE_HOLDER || 'に失敗しました。');
      END_CODE        := '22';
      ERROR_MESSAGE   := PRAM_PLACE_HOLDER;
      OUT_INSTANCE_ID := INPUT_INSTANCE_ID;
      OUT_SOFTWARE_ID := INPUT_SOFTWARE_ID;
      --************************************************************************
      -- テーブルに更新した更新日時を設定　（正常終了以外はNULLを設定）
      --************************************************************************
      UPDATE_DATE     := NULL;
      ROLLBACK;
      RETURN;
    -- その他未定義の例外の処理
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE(PRAM_PLACE_HOLDER || 'に失敗しました。');
      IF SQLCODE = -54 THEN
        END_CODE        := '21';
      ELSE
        END_CODE        := '20';
      END IF;
      ERROR_MESSAGE   := PRAM_PLACE_HOLDER;
      OUT_INSTANCE_ID := INPUT_INSTANCE_ID;
      OUT_SOFTWARE_ID := INPUT_SOFTWARE_ID;
      UPDATE_DATE     := NULL;
      DBMS_OUTPUT.PUT_LINE('ORACLE ERR_CODE    := ' || SQLCODE);            -- ＤＢエラーコード
      DBMS_OUTPUT.PUT_LINE('ORACLE ERR_MESSAGE := ' || SQLERRM(SQLCODE));   -- ＤＢエラーメッセージ
      ROLLBACK;
      RETURN;
  END CSG02_PROC_IB_SI_UPDATE;

  PROCEDURE CSG02_PR0C_IB_PI_UPDATE(
      PROC_TYPE         IN NUMBER DEFAULT 0,     -- 追加・更新区分
      INPUT_INSTANCE_ID IN VARCHAR2,             -- インスタンス番号
      INPUT_PARTS_ID    IN VARCHAR2,             -- パーツID
      tPARTS_INFO       IN ARRAY_IB_PARTS,       -- パーツ情報
      PROGRAM_ID        IN VARCHAR2,             -- 更新プログラムID
      PROCESS_ID        IN VARCHAR2,             -- 処理ID
      USER_ID           IN VARCHAR2,             -- ユーザID
      LOCK_FLG          IN VARCHAR2 DEFAULT 'N', -- 楽観ロック比較有無フラグ
      LOCK_DATE         IN DATE,                 -- 比較日時
      END_CODE          OUT VARCHAR2,            -- 終了コード
      ERROR_MESSAGE     OUT VARCHAR2,            -- エラーメッセージ
      OUT_INSTANCE_ID   OUT VARCHAR2,            -- インスタンス番号
      OUT_PARTS_ID      OUT VARCHAR2,            -- パーツID
      UPDATE_DATE       OUT DATE                 -- 更新日時
  ) AS
  -- ****************************************************************************
  -- 処理パラメータ
  -- ****************************************************************************
  PRAM_PLACE_HOLDER                   VARCHAR2(32670);    -- プレースホルダパラメータ
  NO_SEARCH_PROGRAM_ID                EXCEPTION;
  PRAM_EXCEPTION                      EXCEPTION;
  MASTER_EXCEPTION                    EXCEPTION;
  LOCK_FLG_EXCEPTION                  EXCEPTION;
  table_name                          VARCHAR2(100);
  stmt_str                            VARCHAR2(2000);
  set_sysdate                         DATE;
  set_column_name                     VARCHAR2(1000);
  set_value_column                    VARCHAR2(1000);
  
  ib_parts_obj                        CONTACT_IB_PARTS_OBJ;
  cur_hdl                             NUMBER;
  rows_processed                      NUMBER;
  
  v_END_CODE                          VARCHAR2(10);
  p_INVENTORY_ITEM_CODE               CSG_M_IB_PARTS_INFO.INVENTORY_ITEM_CODE%type ;         -- 品目コード
  CURSOR c_IB_PARTS_INFO IS 
    SELECT INSTANCE_PARTS_ID,      -- パーツID ○
           INSTANCE_ID,            -- インスタンス番号 ○
           INVENTORY_ITEM_CODE,    -- 品目コード ○
           ORG_ID,                 -- プラント ○
           SERIAL_NO,              -- シリアル番号
           REVISION,               -- リビジョン
           EXCHANGE_DATE,          -- 交換日
           SLOT_NO,                -- Slot No
           FIRMWARE_VERSION,       -- Firmware Version
           QUANTITY,               -- 個数 ○
           MAKER_CODE,             -- メーカーコード
           DATE_CODE,              -- デートコード
           RMA_NO,                 -- RMA番号
           SYSTEM_BATH,            -- システムバス
           CISCO_BATH,             -- シスコバス
           INVALID_FLAG,           -- 無効フラグ
           PROGRAM_ID,             -- 更新プログラムID
           PROCESS_ID,             -- 処理ID
           CREATION_USER_ID,       -- 作成者 ○
           CREATION_DATE,          -- 作成日時 ○
           UPDATE_USER_ID,         -- 更新者 ○
           UPDATE_DATE             -- 更新日時 ○
      FROM CSG_M_IB_PARTS_INFO
     WHERE INSTANCE_PARTS_ID   = INPUT_PARTS_ID
       AND INSTANCE_ID         = INPUT_INSTANCE_ID 
       FOR UPDATE OF INSTANCE_PARTS_ID, INSTANCE_ID nowait;
  BEGIN
  -- ***************************************************************************
  -- 初期値
  -- ***************************************************************************
  set_column_name           := '';
  set_value_column          := '';
  stmt_str                  := '';
  v_END_CODE                := '0';
  set_sysdate               := SYSDATE;
  p_INVENTORY_ITEM_CODE     := '';
  -- ***************************************************************************
  -- ２. 設置機器パーツ情報テーブルの更新
  -- （判定１）更新処理の場合
  -- 【設置機器パーツ情報テーブル更新処理】
  -- ・「【マスタチェック】設置機器パーツ情報」を実施する。（エラーとなった場合は返却値として、21：異常コード(マスタ存在チェックエラー)を返却）
  -- ***************************************************************************
  IF tPARTS_INFO IS NULL OR tPARTS_INFO IS EMPTY THEN
      RAISE PRAM_EXCEPTION;
  ELSE
    FOR i IN 1..tPARTS_INFO.COUNT
      LOOP
        ib_parts_obj        := tPARTS_INFO(i);
        set_column_name     := ib_parts_obj.COLUM_NAME;
        set_value_column    := ib_parts_obj.SET_VALUE;
        -- ?品目コードの存在チェック（品目マスタ）
        IF 'INVENTORY_ITEM_CODE' = set_column_name THEN
          p_INVENTORY_ITEM_CODE := set_value_column;
        END IF;
        
        -- ?品目コードの存在チェック（品目マスタ）
        IF 'ORG_ID' = set_column_name THEN
          IF FUNC_SNV_M_ITEM_CHK(p_INVENTORY_ITEM_CODE, set_value_column) = 1 THEN
             PRAM_PLACE_HOLDER := 'マスタに存在しない品目コードが設定されています。';
             RAISE MASTER_EXCEPTION;
          END IF;
        END IF;
      END LOOP;
  END IF;  
  -- ***************************************************************************
  set_column_name     := '';
  set_value_column    := '';
  -- ***************************************************************************
  -- 設置機器パーツ情報の追加・更新における以下の内容を設定する。
  -- 0 ：追加
  -- ***************************************************************************
  IF PROC_TYPE = 0 THEN
  -- ***************************************************************************
  -- 2. 設置機器パーツ情報テーブルの追加
  -- （判定１）追加処理でパラメータの「設置機器パーツ情報」の項目が設定されている場合
  -- 【設置機器パーツ情報テーブル追加処理】
  -- ・設置機器パーツ情報テーブルの追加
  -- ***************************************************************************
    BEGIN
      PRAM_PLACE_HOLDER     := '設置機器パーツ情報の挿入';
      table_name            := 'CSG_M_IB_PARTS_INFO';
      -- パーツID || インスタンス番号のカラム名
      set_column_name       := 'INSTANCE_PARTS_ID, INSTANCE_ID, ';
      -- パーツID || インスタンス番号の更新データ
      set_value_column      := ':INSTANCE_PARTS_ID, :INSTANCE_ID,';
      IF tPARTS_INFO IS NULL OR tPARTS_INFO IS EMPTY THEN
          RAISE PRAM_EXCEPTION;
      ELSE
        FOR i IN 1..tPARTS_INFO.COUNT
          LOOP
            ib_parts_obj        := tPARTS_INFO(i);
            set_column_name     := set_column_name || ib_parts_obj.COLUM_NAME;
            set_value_column    := set_value_column || ':' || ib_parts_obj.COLUM_NAME;
            IF i < tPARTS_INFO.COUNT THEN 
              set_column_name   := set_column_name || ', ';
              set_value_column  := set_value_column || ', ';
            END IF;
          END LOOP;
          -- 更新プログラムID || 処理ID || 作成者 || 作成日時 || 更新者 || 更新日時のカラム名
          set_column_name     := set_column_name || ', ' || 'PROGRAM_ID, PROCESS_ID, CREATION_USER_ID, CREATION_DATE, UPDATE_USER_ID, UPDATE_DATE';
          -- 更新プログラムID || 処理ID || 作成者 || 作成日時 || 更新者 || 更新日時の更新データ
          set_value_column    := set_value_column || ', :PROGRAM_ID, :PROCESS_ID, :CREATION_USER_ID, :CREATION_DATE, :UPDATE_USER_ID, :UPDATE_DATE';
          -- 設置機器パーツ情報テーブルの追加
          stmt_str        := 'INSERT INTO ' || table_name || '(' || set_column_name || ') VALUES ('|| set_value_column ||')';
          cur_hdl         := DBMS_SQL.OPEN_CURSOR;
          DBMS_SQL.PARSE(cur_hdl, stmt_str, DBMS_SQL.NATIVE);
          -- supply binds
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':INSTANCE_PARTS_ID', INPUT_PARTS_ID);
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':INSTANCE_ID', INPUT_INSTANCE_ID);
          FOR i IN 1..tPARTS_INFO.COUNT
            LOOP
              ib_parts_obj     := tPARTS_INFO(i);
              DBMS_SQL.BIND_VARIABLE(cur_hdl, ':' || ib_parts_obj.COLUM_NAME, ib_parts_obj.SET_VALUE);
            END LOOP;
         
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':PROGRAM_ID', PROGRAM_ID);
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':PROCESS_ID', PROCESS_ID);
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':CREATION_USER_ID', USER_ID);
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':CREATION_DATE', set_sysdate);
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':UPDATE_USER_ID', USER_ID);
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':UPDATE_DATE', set_sysdate);
         
          rows_processed := DBMS_SQL.EXECUTE(cur_hdl);  
          -- execute
          DBMS_SQL.CLOSE_CURSOR(cur_hdl);
      END IF;
    END;
  -- ***************************************************************************
  -- 設置機器パーツ情報の追加・更新における以下の内容を設定する。
  -- 10：更新
  -- ***************************************************************************
  ELSIF PROC_TYPE = 10 THEN
  -- ***************************************************************************
  -- 3. 設置機器パーツ情報テーブルの更新
  -- （判定１）更新処理でパラメータの「設置機器パーツ情報」の項目が設定されている場合
  -- 【設置機器パーツ情報テーブル更新処理】
  -- ・設置機器パーツ情報テーブルの排他取得
  -- ・設置機器パーツ情報テーブルの更新　　　　　※（判定2）の場合は更新プログラムID、処理ID、更新日時、更新者のみ更新。
  -- ・設置機器パーツ情報履歴テーブルの追加
  -- ***************************************************************************
    BEGIN
      IF tPARTS_INFO IS NULL OR tPARTS_INFO IS EMPTY THEN
          RAISE PRAM_EXCEPTION;
      END IF;
      
      IF tPARTS_INFO IS NOT NULL OR tPARTS_INFO IS NOT EMPTY THEN
      PRAM_PLACE_HOLDER     := '設置機器パーツ情報履歴の挿入';
      table_name            := 'CSG_M_IB_PARTS_INFO_HIS';
      -- ***********************************************************************
      -- ・設置機器パーツ情報履歴テーブルの追加
      -- ***********************************************************************
      FOR row_IB_PARTS_INFO IN c_IB_PARTS_INFO
        LOOP
        INSERT
        INTO CSG_M_IB_PARTS_INFO_HIS
          (
            INSTANCE_PARTS_HIS_ID, -- パーツ履歴ID
            INSTANCE_PARTS_ID,     -- パーツID
            INSTANCE_ID,           -- インスタンス番号
            INVENTORY_ITEM_CODE,   -- 品目コード
            INVENTORY_ITEM,        -- 品目
            ORG_ID,                -- プラント
            SERIAL_NO,             -- シリアル番号
            PARTS_NAME,            -- パーツ名称
            REVISION,              -- リビジョン
            EXCHANGE_DATE,         -- 交換日
            SLOT_NO,               -- Slot No
            FIRMWARE_VERSION,      -- Firmware Version
            QUANTITY,              -- 個数
            MAKER_CODE,            -- メーカーコード
            DATE_CODE,             -- デートコード
            RMA_NO,                -- RMA番号
            SYSTEM_BATH,           -- システムバス
            CISCO_BATH,            -- シスコバス
            INVALID_FLAG,          -- 無効フラグ
            PROGRAM_ID,            -- 更新プログラムID
            PROCESS_ID,            -- 処理ID
            CREATION_USER_ID,      -- 作成者
            CREATION_DATE,         -- 作成日時
            UPDATE_USER_ID,        -- 更新者
            UPDATE_DATE            -- 更新日時
          )
          VALUES
          (
            CSG_M_PARTS_HIS_ID_SEQ.NEXTVAL,        -- パーツ履歴ID
            row_IB_PARTS_INFO.INSTANCE_PARTS_ID,   -- パーツID
            row_IB_PARTS_INFO.INSTANCE_ID,         -- インスタンス番号
            row_IB_PARTS_INFO.INVENTORY_ITEM_CODE, -- 品目コード
            (
            SELECT
              PROD_CD || '.' || MAKR_MDL_NO || '.' || BR_NO || '..'  --品目
            FROM
              SNV_M_ITEM
            WHERE
              ITEM_CD=row_IB_PARTS_INFO.INVENTORY_ITEM_CODE AND
              PLT=row_IB_PARTS_INFO.ORG_ID
            ),
            row_IB_PARTS_INFO.ORG_ID,              -- プラント
            row_IB_PARTS_INFO.SERIAL_NO,           -- シリアル番号
            (
            SELECT
              REMARKS --パーツ名称
            FROM
              SNV_M_ITEM
            WHERE
              ITEM_CD=row_IB_PARTS_INFO.INVENTORY_ITEM_CODE AND
              PLT=row_IB_PARTS_INFO.ORG_ID
            ),
            row_IB_PARTS_INFO.REVISION,            -- リビジョン
            row_IB_PARTS_INFO.EXCHANGE_DATE,       -- 交換日
            row_IB_PARTS_INFO.SLOT_NO,             -- Slot No
            row_IB_PARTS_INFO.FIRMWARE_VERSION,    -- Firmware Version
            row_IB_PARTS_INFO.QUANTITY,            -- 個数
            row_IB_PARTS_INFO.MAKER_CODE,          -- メーカーコード
            row_IB_PARTS_INFO.DATE_CODE,           -- デートコード
            row_IB_PARTS_INFO.RMA_NO,              -- RMA番号
            row_IB_PARTS_INFO.SYSTEM_BATH,         -- システムバス
            row_IB_PARTS_INFO.CISCO_BATH,          -- シスコバス
            row_IB_PARTS_INFO.INVALID_FLAG,        -- 無効フラグ
            row_IB_PARTS_INFO.PROGRAM_ID,          -- 更新プログラムID
            row_IB_PARTS_INFO.PROCESS_ID,          -- 処理ID
            row_IB_PARTS_INFO.CREATION_USER_ID,    -- 作成者
            row_IB_PARTS_INFO.CREATION_DATE,       -- 作成日時
            row_IB_PARTS_INFO.UPDATE_USER_ID,      -- 更新者
            row_IB_PARTS_INFO.UPDATE_DATE          -- 更新日時
          );
          -- *******************************************************************
          -- N ：楽観ロック比較なし
          -- Y ：楽観ロック比較あり
          -- ※「楽観ロック比較」とは、テーブルの更新タイムスタンプとの比較の事であり、行ロックは両値とも行う。
          -- ※追加の場合は「N」
          -- *******************************************************************
          PRAM_PLACE_HOLDER := '設置機器パーツ情報の更新';
          table_name        := 'CSG_M_IB_PARTS_INFO';
          
          IF LOCK_FLG = 'Y' THEN
            IF LOCK_DATE <> row_IB_PARTS_INFO.UPDATE_DATE THEN
              v_END_CODE   := '22';
              RAISE LOCK_FLG_EXCEPTION;
            END IF;
          END IF;
          
          FOR i IN 1..tPARTS_INFO.COUNT
          LOOP
            ib_parts_obj     := tPARTS_INFO(i);
            set_column_name      := set_column_name || ib_parts_obj.COLUM_NAME || '=' || ':' || ib_parts_obj.COLUM_NAME;
            IF i < tPARTS_INFO.COUNT THEN 
              set_column_name    := set_column_name || ', ';
            END IF;
          END LOOP;
          -- 更新プログラムID || 処理ID || 更新者 || 更新日時のカラム名と更新データ
          set_column_name         := set_column_name || ', ' || 'PROGRAM_ID = :PROGRAM_ID, PROCESS_ID = :PROCESS_ID, UPDATE_USER_ID = :UPDATE_USER_ID, UPDATE_DATE = :UPDATE_DATE';
          -- 設置機器パーツ情報テーブルの更新
          stmt_str            := 'UPDATE ' || table_name || ' SET ' || set_column_name || ' 
                                  WHERE INSTANCE_PARTS_ID = :INSTANCE_PARTS_ID 
                                    AND INSTANCE_ID       = :INSTANCE_ID';
          cur_hdl             := DBMS_SQL.OPEN_CURSOR;
          DBMS_SQL.PARSE(cur_hdl, stmt_str, DBMS_SQL.NATIVE);
          -- supply binds
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':INSTANCE_PARTS_ID', INPUT_PARTS_ID);
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':INSTANCE_ID', INPUT_INSTANCE_ID);
          FOR i IN 1..tPARTS_INFO.COUNT
            LOOP
              ib_parts_obj     := tPARTS_INFO(i);
              DBMS_SQL.BIND_VARIABLE(cur_hdl, ':' || ib_parts_obj.COLUM_NAME, ib_parts_obj.SET_VALUE);
            END LOOP;         
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':PROGRAM_ID', PROGRAM_ID);
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':PROCESS_ID', PROCESS_ID);
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':UPDATE_USER_ID', USER_ID);
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':UPDATE_DATE', set_sysdate);
             
          rows_processed := dbms_sql.execute(cur_hdl);  
          -- execute
          DBMS_SQL.CLOSE_CURSOR(CUR_HDL);
        END LOOP;
      END IF;
    END;
  END IF;
  --***************************************************************************
  -- コミット行きました。
  --***************************************************************************
--  COMMIT;
  --***************************************************************************
  -- 0 ：正常コード
  -- 10：警告コード(排他エラー)
  -- 20：異常コード
  -- 21：異常コード(マスタ存在チェックエラー)
  -- 22：異常コード(排他エラー)
  --***************************************************************************
  END_CODE        := v_END_CODE; -- 0 ：正常コード
  --***************************************************************************
  -- 追加・・・払い出したインスタンス番号
  -- 更新・・・更新したインスタンス番号
  --***************************************************************************
  OUT_INSTANCE_ID := INPUT_INSTANCE_ID;
  --***************************************************************************
  -- 追加・・・払い出したパーツID
  -- 更新・・・更新したパーツID
  --***************************************************************************
  OUT_PARTS_ID := INPUT_PARTS_ID;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      -- データの取得に失敗した場合、異常終了としエラーメッセージをログ出力し後続の処理を中断する。
      DBMS_OUTPUT.PUT_LINE(PRAM_PLACE_HOLDER || 'に失敗しました。');
      END_CODE        := '20';
      ERROR_MESSAGE   := PRAM_PLACE_HOLDER;
      OUT_INSTANCE_ID := INPUT_INSTANCE_ID;
      OUT_PARTS_ID    := INPUT_PARTS_ID;
      UPDATE_DATE     := NULL;
      ROLLBACK;
      RETURN;
    WHEN PRAM_EXCEPTION THEN
      DBMS_OUTPUT.PUT_LINE(PRAM_PLACE_HOLDER || 'のデータが設定されていません。');
      END_CODE        := '20';
      ERROR_MESSAGE   := PRAM_PLACE_HOLDER;
      OUT_INSTANCE_ID := INPUT_INSTANCE_ID;
      OUT_PARTS_ID    := INPUT_PARTS_ID;
      UPDATE_DATE     := NULL;
      ROLLBACK;
      RETURN;
    WHEN MASTER_EXCEPTION THEN
      DBMS_OUTPUT.PUT_LINE(PRAM_PLACE_HOLDER);
      END_CODE        := '21';
      ERROR_MESSAGE   := PRAM_PLACE_HOLDER;
      OUT_INSTANCE_ID := INPUT_INSTANCE_ID;
      OUT_PARTS_ID    := INPUT_PARTS_ID;
      --************************************************************************
      -- テーブルに更新した更新日時を設定　（正常終了以外はNULLを設定）
      --************************************************************************
      UPDATE_DATE     := NULL;
      ROLLBACK;
      RETURN;
    WHEN LOCK_FLG_EXCEPTION THEN
      DBMS_OUTPUT.PUT_LINE(PRAM_PLACE_HOLDER || 'に失敗しました。');
      END_CODE        := '22';
      ERROR_MESSAGE   := PRAM_PLACE_HOLDER;
      OUT_INSTANCE_ID := INPUT_INSTANCE_ID;
      OUT_PARTS_ID    := INPUT_PARTS_ID;
      --************************************************************************
      -- テーブルに更新した更新日時を設定　（正常終了以外はNULLを設定）
      --************************************************************************
      UPDATE_DATE := NULL;
      ROLLBACK;
      RETURN;
    -- その他未定義の例外の処理
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE(PRAM_PLACE_HOLDER || 'に失敗しました。');
      IF SQLCODE = -54 THEN
        END_CODE        := '21';
      ELSE
        END_CODE        := '20';
      END IF;
      ERROR_MESSAGE   := PRAM_PLACE_HOLDER;
      OUT_INSTANCE_ID := INPUT_INSTANCE_ID;
      OUT_PARTS_ID    := INPUT_PARTS_ID;
      UPDATE_DATE     := NULL;
      DBMS_OUTPUT.PUT_LINE('ORACLE ERR_CODE    := ' || SQLCODE);            -- ＤＢエラーコード
      DBMS_OUTPUT.PUT_LINE('ORACLE ERR_MESSAGE := ' || SQLERRM(SQLCODE));   -- ＤＢエラーメッセージ
      ROLLBACK;
      RETURN;
  END CSG02_PR0C_IB_PI_UPDATE;

  PROCEDURE CSG02_PROC_IB_MEMO_INFO_UPDATE(
      PROC_TYPE         IN NUMBER DEFAULT 0,     -- 追加・更新区分
      INPUT_INSTANCE_ID IN VARCHAR2,             -- インスタンス番号
      MEMO_ID           IN VARCHAR2,             -- メモID
      tMEMO_INFO        IN ARRAY_IB_MEMO,        -- メモ情報
      PROGRAM_ID        IN VARCHAR2,             -- 更新プログラムID
      PROCESS_ID        IN VARCHAR2,             -- 処理ID
      USER_ID           IN VARCHAR2,             -- ユーザID
      LOCK_FLG          IN VARCHAR2 DEFAULT 'N', -- 楽観ロック比較有無フラグ
      LOCK_DATE         IN DATE,                 -- 比較日時
      END_CODE          OUT VARCHAR2,            -- 終了コード
      ERROR_MESSAGE     OUT VARCHAR2,            -- エラーメッセージ
      OUT_INSTANCE_ID   OUT VARCHAR2,            -- インスタンス番号
      OUT_MEMO_ID       OUT VARCHAR2,            -- メモID
      UPDATE_DATE       OUT DATE                 -- 更新日時
  ) AS
  -- ****************************************************************************
  -- 処理パラメータ
  -- ****************************************************************************
  PRAM_PLACE_HOLDER                   VARCHAR2(32670);    -- プレースホルダパラメータ
  NO_SEARCH_PROGRAM_ID                EXCEPTION;
  PRAM_EXCEPTION                      EXCEPTION;
  MASTER_EXCEPTION                    EXCEPTION;
  LOCK_FLG_EXCEPTION                  EXCEPTION;
  table_name                          VARCHAR2(100);
  stmt_str                            VARCHAR2(2000);
  set_sysdate                         DATE;
  set_column_name                     VARCHAR2(1000);
  set_value_column                    VARCHAR2(1000);
  
  ib_memo_obj                         CONTACT_IB_MEMO_OBJ;
  cur_hdl                             NUMBER;
  rows_processed                      NUMBER;
  
  v_END_CODE                          VARCHAR2(10);
  
  CURSOR c_IB_MEMO_INFO IS 
    SELECT INSTANCE_MEMO_ID,      -- メモID ○
           INSTANCE_ID,           -- インスタンス番号 ○
           MEMO_TYPE,             -- メモタイプ ○
           TITLE,                 -- タイトル
           MEMO,                  -- メモ
           SORT_NO,               -- ソート順
           PROGRAM_ID,            -- 更新プログラムID
           PROCESS_ID,            -- 処理ID
           CREATION_USER_ID,      -- 作成者 ○
           CREATION_DATE,         -- 作成日時 ○
           UPDATE_USER_ID,        -- 更新者 ○
           UPDATE_DATE            -- 更新日時 ○
      FROM CSG_M_IB_MEMO_INFO
     WHERE INSTANCE_MEMO_ID   = MEMO_ID
       AND INSTANCE_ID        = INPUT_INSTANCE_ID 
       FOR UPDATE OF INSTANCE_MEMO_ID, INSTANCE_ID nowait;
  BEGIN
  -- ***************************************************************************
  -- 初期値
  -- ***************************************************************************
  set_column_name     := '';
  set_value_column    := '';
  stmt_str            := '';
  v_END_CODE          := '0';
  set_sysdate         := SYSDATE;
  -- ***************************************************************************
  -- ２. 設置機器メモ情報テーブルの更新
  -- （判定１）更新処理の場合
  -- 【設置機器メモ情報テーブル更新処理】
  -- ・「【マスタチェック】設置機器メモ情報」を実施する。（エラーとなった場合は返却値として、21：異常コード(マスタ存在チェックエラー)を返却）
  -- ***************************************************************************
  IF tMEMO_INFO IS NULL OR tMEMO_INFO IS EMPTY THEN
      RAISE PRAM_EXCEPTION;
  ELSE
    FOR i IN 1..tMEMO_INFO.COUNT
      LOOP
        ib_memo_obj     := tMEMO_INFO(i);
        set_column_name     := ib_memo_obj.COLUM_NAME;
        set_value_column    := ib_memo_obj.SET_VALUE;
        
        IF set_value_column IS NOT NULL THEN
          -- ?メモタイプ（汎用マスタ（メモタイプ））
          IF 'MEMO_TYPE' = set_column_name THEN
            IF FUNC_SNV_M_GNRC_SNV_CHK('CSG_MEMO_TYPE', set_value_column) = 1 THEN
               PRAM_PLACE_HOLDER := 'マスタに存在しないメモタイプが設定されています。';
               RAISE MASTER_EXCEPTION;
            END IF;
          END IF;
        END IF;
      END LOOP;
  END IF;
  -- ***************************************************************************
  set_column_name     := '';
  set_value_column    := '';
  -- ***************************************************************************
  -- 設置機器メモ情報の追加・更新における以下の内容を設定する。
  -- 0 ：追加
  -- ***************************************************************************
  IF PROC_TYPE = 0 THEN
  -- ***************************************************************************
  -- 2. 設置機器メモ情報テーブルの追加
  -- （判定１）追加処理でパラメータの「設置機器メモ情報」の項目が設定されている場合
  -- 【設置機器メモ情報テーブル追加処理】
  -- ・設置機器メモ情報テーブルの追加
  -- ***************************************************************************
    BEGIN
      PRAM_PLACE_HOLDER := '設置機器メモ情報の挿入';
      table_name        := 'CSG_M_IB_MEMO_INFO';
      -- パーツID || インスタンス番号のカラム名
      set_column_name   := 'INSTANCE_MEMO_ID, INSTANCE_ID, ';
      -- パーツID || インスタンス番号の更新データ
      set_value_column  := ':INSTANCE_MEMO_ID, :INSTANCE_ID,';
      IF tMEMO_INFO IS NULL OR tMEMO_INFO IS EMPTY THEN
          RAISE PRAM_EXCEPTION;
      ELSE
        FOR i IN 1..tMEMO_INFO.COUNT
          LOOP
            ib_memo_obj     := tMEMO_INFO(i);
            set_column_name     := set_column_name || ib_memo_obj.COLUM_NAME;
            set_value_column    := set_value_column || ':' || ib_memo_obj.COLUM_NAME;
            IF i < tMEMO_INFO.COUNT THEN 
              set_column_name   := set_column_name || ', ';
              set_value_column  := set_value_column || ', ';
            END IF;
          END LOOP;
          -- 更新プログラムID || 処理ID || 作成者 || 作成日時 || 更新者 || 更新日時のカラム名
          set_column_name     := set_column_name || ', ' || 'PROGRAM_ID, PROCESS_ID, CREATION_USER_ID, CREATION_DATE, UPDATE_USER_ID, UPDATE_DATE';
          -- 更新プログラムID || 処理ID || 作成者 || 作成日時 || 更新者 || 更新日時の更新データ
          set_value_column    := set_value_column || ', :PROGRAM_ID, :PROCESS_ID, :CREATION_USER_ID, :CREATION_DATE, :UPDATE_USER_ID, :UPDATE_DATE';
          -- 設置機器メモ情報テーブルの追加
          stmt_str        := 'INSERT INTO ' || table_name || '(' || set_column_name || ') VALUES ('|| set_value_column ||')';
          cur_hdl         := DBMS_SQL.OPEN_CURSOR;
          DBMS_SQL.PARSE(cur_hdl, stmt_str, DBMS_SQL.NATIVE);
          -- supply binds
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':INSTANCE_MEMO_ID', CSG_M_MEMO_ID_SEQ.NEXTVAL);
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':INSTANCE_ID', INPUT_INSTANCE_ID);
          FOR i IN 1..tMEMO_INFO.COUNT
            LOOP
              ib_memo_obj     := tMEMO_INFO(i);
              DBMS_SQL.BIND_VARIABLE(cur_hdl, ':' || ib_memo_obj.COLUM_NAME, ib_memo_obj.SET_VALUE);
            END LOOP;
         
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':PROGRAM_ID', PROGRAM_ID);
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':PROCESS_ID', PROCESS_ID);
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':CREATION_USER_ID', USER_ID);
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':CREATION_DATE', set_sysdate);
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':UPDATE_USER_ID', USER_ID);
          DBMS_SQL.BIND_VARIABLE(cur_hdl, ':UPDATE_DATE', set_sysdate);
         
          rows_processed := dbms_sql.execute(cur_hdl);  
          -- execute
          DBMS_SQL.CLOSE_CURSOR(cur_hdl);
      END IF;
    END;
  -- ***************************************************************************
  -- 設置機器メモ情報の追加・更新における以下の内容を設定する。
  -- 10：更新
  -- ***************************************************************************
  ELSIF PROC_TYPE = 10 THEN
  -- ***************************************************************************
  -- 3. 設置機器メモ情報テーブルの更新
  -- （判定１）更新処理でパラメータの「設置機器メモ情報」の項目が設定されている場合
  -- 【設置機器メモ情報テーブル更新処理】
  -- ・設置機器メモ情報テーブルの排他取得
  -- ・設置機器メモ情報テーブルの更新　　　　　※（判定2）の場合は更新プログラムID、処理ID、更新日時、更新者のみ更新。
  -- ***************************************************************************
    BEGIN
      IF tMEMO_INFO IS NULL OR tMEMO_INFO IS EMPTY THEN
          RAISE PRAM_EXCEPTION;
      END IF;
      -- ***********************************************************************
      -- N ：楽観ロック比較なし
      -- Y ：楽観ロック比較あり
      -- ※「楽観ロック比較」とは、テーブルの更新タイムスタンプとの比較の事であり、行ロックは両値とも行う。
      -- ※追加の場合は「N」
      -- ***********************************************************************
      IF tMEMO_INFO IS NOT NULL OR tMEMO_INFO IS NOT EMPTY THEN
        PRAM_PLACE_HOLDER := '設置機器メモ情報の更新';
        table_name        := 'CSG_M_IB_MEMO_INFO';
        FOR row_IB_MEMO_INFO IN c_IB_MEMO_INFO 
          LOOP
            IF LOCK_FLG = 'Y' THEN
              IF LOCK_DATE <> row_IB_MEMO_INFO.UPDATE_DATE THEN
                v_END_CODE   := '22';
                RAISE LOCK_FLG_EXCEPTION;
              END IF;
            END IF;
            FOR i IN 1..tMEMO_INFO.COUNT
            LOOP
              ib_memo_obj     := tMEMO_INFO(i);
              set_column_name      := set_column_name || ib_memo_obj.COLUM_NAME || '=' || ':' || ib_memo_obj.COLUM_NAME;
              IF i < tMEMO_INFO.COUNT THEN 
                set_column_name    := set_column_name || ', ';
              END IF;
            END LOOP;
            -- 更新プログラムID || 処理ID || 更新者 || 更新日時のカラム名と更新データ
            set_column_name         := set_column_name || ', ' || 'PROGRAM_ID = :PROGRAM_ID, PROCESS_ID = :PROCESS_ID, UPDATE_USER_ID = :UPDATE_USER_ID, UPDATE_DATE = :UPDATE_DATE';
            -- 設置機器パーツ情報テーブルの更新
            stmt_str            := 'UPDATE ' || table_name || ' SET ' || set_column_name || ' 
                                    WHERE INSTANCE_MEMO_ID = :INSTANCE_MEMO_ID 
                                      AND INSTANCE_ID      = :INSTANCE_ID';
            cur_hdl             := DBMS_SQL.OPEN_CURSOR;
            DBMS_SQL.PARSE(cur_hdl, stmt_str, DBMS_SQL.NATIVE);
            -- supply binds
            DBMS_SQL.BIND_VARIABLE(cur_hdl, ':INSTANCE_MEMO_ID', MEMO_ID);
            DBMS_SQL.BIND_VARIABLE(cur_hdl, ':INSTANCE_ID', INPUT_INSTANCE_ID);
            FOR i IN 1..tMEMO_INFO.COUNT
              LOOP
                ib_memo_obj     := tMEMO_INFO(i);
                DBMS_SQL.BIND_VARIABLE(cur_hdl, ':' || ib_memo_obj.COLUM_NAME, ib_memo_obj.SET_VALUE);
              END LOOP;         
            DBMS_SQL.BIND_VARIABLE(cur_hdl, ':PROGRAM_ID', PROGRAM_ID);
            DBMS_SQL.BIND_VARIABLE(cur_hdl, ':PROCESS_ID', PROCESS_ID);
            DBMS_SQL.BIND_VARIABLE(cur_hdl, ':UPDATE_USER_ID', USER_ID);
            DBMS_SQL.BIND_VARIABLE(cur_hdl, ':UPDATE_DATE', set_sysdate);
               
            rows_processed := DBMS_SQL.EXECUTE(cur_hdl);  
            -- execute
            DBMS_SQL.CLOSE_CURSOR(cur_hdl);
          END LOOP;
      END IF;
    END;
  END IF;
  --***************************************************************************
  -- コミット行きました。
  --***************************************************************************
--  COMMIT;
  --***************************************************************************
  -- 0 ：正常コード
  -- 10：警告コード(排他エラー)
  -- 20：異常コード
  -- 21：異常コード(マスタ存在チェックエラー)
  -- 22：異常コード(排他エラー)
  --***************************************************************************
  END_CODE        := v_END_CODE; -- 0 ：正常コード
  --***************************************************************************
  -- 追加・・・払い出したメモID
  -- 更新・・・更新したメモID
  --***************************************************************************
  OUT_MEMO_ID     := MEMO_ID;
  OUT_INSTANCE_ID := INPUT_INSTANCE_ID;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      -- データの取得に失敗した場合、異常終了としエラーメッセージをログ出力し後続の処理を中断する。
      DBMS_OUTPUT.PUT_LINE(PRAM_PLACE_HOLDER || 'に失敗しました。');
      END_CODE        := '20';
      ERROR_MESSAGE   := PRAM_PLACE_HOLDER;
      OUT_INSTANCE_ID := INPUT_INSTANCE_ID;
      OUT_MEMO_ID     := MEMO_ID;
      UPDATE_DATE     := NULL;
      ROLLBACK;
      RETURN;
    WHEN PRAM_EXCEPTION THEN
      DBMS_OUTPUT.PUT_LINE(PRAM_PLACE_HOLDER || 'のデータが設定されていません。');
      END_CODE        := '20';
      ERROR_MESSAGE   := PRAM_PLACE_HOLDER;
      OUT_INSTANCE_ID := INPUT_INSTANCE_ID;
      OUT_MEMO_ID     := MEMO_ID;
      UPDATE_DATE     := NULL;
      ROLLBACK;
      RETURN;
    WHEN MASTER_EXCEPTION THEN
      DBMS_OUTPUT.PUT_LINE(PRAM_PLACE_HOLDER);
      END_CODE        := '21';
      ERROR_MESSAGE   := PRAM_PLACE_HOLDER;
      OUT_INSTANCE_ID := INPUT_INSTANCE_ID;
      OUT_MEMO_ID     := MEMO_ID;
      --************************************************************************
      -- テーブルに更新した更新日時を設定　（正常終了以外はNULLを設定）
      --************************************************************************
      UPDATE_DATE     := NULL;
      ROLLBACK;
      RETURN;
    WHEN LOCK_FLG_EXCEPTION THEN
      DBMS_OUTPUT.PUT_LINE(PRAM_PLACE_HOLDER || 'に失敗しました。');
      END_CODE        := '22';
      ERROR_MESSAGE   := PRAM_PLACE_HOLDER;
      OUT_INSTANCE_ID := INPUT_INSTANCE_ID;
      OUT_MEMO_ID     := MEMO_ID;
      --************************************************************************
      -- テーブルに更新した更新日時を設定　（正常終了以外はNULLを設定）
      --************************************************************************
      UPDATE_DATE     := NULL;
      ROLLBACK;
      RETURN;
    -- その他未定義の例外の処理
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE(PRAM_PLACE_HOLDER || 'に失敗しました。');
      IF SQLCODE = -54 THEN
        END_CODE        := '21';
      ELSE
        END_CODE        := '20';
      END IF;
      ERROR_MESSAGE   := PRAM_PLACE_HOLDER;
      OUT_INSTANCE_ID := INPUT_INSTANCE_ID;
      OUT_MEMO_ID     := MEMO_ID;
      UPDATE_DATE     := NULL;
      DBMS_OUTPUT.PUT_LINE('ORACLE ERR_CODE    := ' || SQLCODE);            -- ＤＢエラーコード
      DBMS_OUTPUT.PUT_LINE('ORACLE ERR_MESSAGE := ' || SQLERRM(SQLCODE));   -- ＤＢエラーメッセージ
      ROLLBACK;
      RETURN;
  END CSG02_PROC_IB_MEMO_INFO_UPDATE;
  
END CSG02_IB_COMMON_PKG;

/
