--------------------------------------------------------
--  DDL for Function FUNC_ENCHAR_CHK
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "CSNAVI"."FUNC_ENCHAR_CHK" (
      PARAM1 IN VARCHAR2 )
    RETURN NUMBER
  AS
    vLEN  NUMBER;
    vLENB NUMBER;
  BEGIN
    vLEN   := LENGTH(PARAM1);
    vLENB  :=LENGTHB(PARAM1);
    IF vLEN = vLENB THEN
      RETURN 0;
    ELSE
      RETURN 1;
    END IF;
    RETURN 1;
  END FUNC_ENCHAR_CHK;
