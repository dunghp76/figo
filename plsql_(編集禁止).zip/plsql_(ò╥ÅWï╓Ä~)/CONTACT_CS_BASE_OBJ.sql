--------------------------------------------------------
--  DDL for Type CONTACT_CS_BASE_OBJ
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TYPE "CSNAVI"."CONTACT_CS_BASE_OBJ" 
AS
  OBJECT
  (
    COLUM_NAME VARCHAR2(30) ,
    SET_VALUE  VARCHAR2(2000) );

/
