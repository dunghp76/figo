--------------------------------------------------------
--  DDL for Function FUNC_LENGTH_CHK
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "CSNAVI"."FUNC_LENGTH_CHK" (
      PARAM1 IN VARCHAR2,
      LEN    IN NUMBER )
    RETURN NUMBER
  AS
  BEGIN
	IF LEN < LENGTH(PARAM1) THEN
		RETURN 1;
	ELSE
	    RETURN 0;
	END IF;
  RETURN 1;
  END FUNC_LENGTH_CHK;
