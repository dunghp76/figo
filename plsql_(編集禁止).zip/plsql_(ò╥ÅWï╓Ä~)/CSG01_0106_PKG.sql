CREATE OR REPLACE PACKAGE CSG01_0106_PKG
AS

-----------------------------------------------------------------------------------
--  DDL for Procedure CSG01-0106 サービス要求作成
-----------------------------------------------------------------------------------

-----------------------------------------------------------------------------------
--  DDL for Procedure CSG01_PROC_REGIST_SR サービス要求情報作成バッチ
-----------------------------------------------------------------------------------

/**
 * サービス要求情報作成処理
 *
 * パラメータで指定された情報を元に、サービス要求情報の作成、及び更新処理を行う。
 *
 * @param INPUT_ADD_UPD_DIV:追加・更新区分
 * @param INPUT_SERVICE_REQ_INFO:サービス要求情報
 * @param INPUT_LOGIN_USER_INFO:ログインユーザ情報
 * @param INPUT_UPD_PROGRAM_INFO:更新プログラム情報
 * @param INPUT_LOCK_COM_FLG:楽観ロック比較有無フラグ
 * @param RESULT_CD:終了コード
 * @param SR_NO:SR番号
 * @param UPDATE_DATE:更新日時
 */
PROCEDURE CSG01_PROC_REGIST_SR (
    --追加・更新区分
    INPUT_ADD_UPD_DIV IN VARCHAR2,
    --サービス要求情報
    ISRI_SERVICE_REQUEST_NO         IN VARCHAR2,   --SR番号
    ISRI_SERVICE_REQUEST_TYPE_ID    IN VARCHAR2,   --SRタイプ
    ISRI_SERVICE_REQUEST_STATUS     IN VARCHAR2,   --SRステータス
    ISRI_IMPORTANCE_LEVEL           IN VARCHAR2,   --重要度
    ISRI_SR_CREATION_CHANNEL        IN VARCHAR2,   --受付チャネル
    ISRI_SERVICE_REQUEST_GROUP_ID   IN VARCHAR2,   --SR担当グループ
    ISRI_SERVICE_REQUEST_PERSON_ID  IN VARCHAR2,   --SR担当者
    ISRI_SERIAL_NO                  IN VARCHAR2,   --シリアル番号
    ISRI_INSTANCE_ID                IN VARCHAR2,   --インスタンス番号
    ISRI_INVENTORY_ITEM_CODE        IN VARCHAR2,   --品目コード
    ISRI_ORG_ID                     IN VARCHAR2,   --プラント
    ISRI_INSTALL_PARTY_NO           IN VARCHAR2,   --設置先顧客番号
    ISRI_CONTRACT_ID                IN VARCHAR2,   --契約ID
    ISRI_CONTRACT_NO                IN VARCHAR2,   --契約番号
    ISRI_CONTRACT_PARTY_ID          IN VARCHAR2,   --契約先顧客番号
    ISRI_EXTENDED_ID                IN VARCHAR2,   --拡張ID
    ISRI_MODEL_CODE                 IN VARCHAR2,   --機種コード
    ISRI_GROUP_ID                   IN VARCHAR2,   --担当CS
    ISRI_RECEIPT_DATE               IN VARCHAR2,   --受付日時
    ISRI_FAILURE_OCCUR_DATE         IN VARCHAR2,   --障害発生日時
    ISRI_CLOSE_DATE                 IN VARCHAR2,   --クローズ日時
    ISRI_RECEIPT_GROUP_ID           IN VARCHAR2,   --受付グループ
    ISRI_RECEIPT_PERSON_ID          IN VARCHAR2,   --受付者
    ISRI_CALLER_COMPANY_NAME        IN VARCHAR2,   --Caller会社名
    ISRI_CALLER_DEPT_NAME           IN VARCHAR2,   --Caller部署
    ISRI_CALLER_CONTACTOR_PERSON    IN VARCHAR2,   --Caller担当者
    ISRI_CALLER_TEL                 IN VARCHAR2,   --CallerTEL
    ISRI_CALLER_FAX                 IN VARCHAR2,   --CallerFAX
    ISRI_CALLER_MAIL_ADDRESS        IN VARCHAR2,   --CallerE-Mail-To
    ISRI_CALLER_MAIL_ADDRESS_CC     IN VARCHAR2,   --CallerE-Mail-Cc
    ISRI_CALLER_EMPLOYEE            IN VARCHAR2,   --Caller社員番号
    ISRI_SERVICE_REPORT_TYPE        IN VARCHAR2,   --サービスタイプ
    ISRI_CORRESPONDING_TIME_LIMIT   IN VARCHAR2,   --対応期限
    ISRI_AUTO_CLOSE_RECORD_DATE     IN VARCHAR2,   --自動クローズ基準日
    ISRI_EXTERNAL_KIND              IN VARCHAR2,   --外部種別
    ISRI_EXTERNAL_ID                IN VARCHAR2,   --外部ID
    ISRI_SUMMARY                    IN VARCHAR2,   --問題要約
    ISRI_INQUIRY_OUTLINE            IN VARCHAR2,   --問題内容
    ISRI_CUSTOMER_ID                IN VARCHAR2,   --カスタマID
    ISRI_WAIT_TYPE                  IN VARCHAR2,   --待機区分
    ISRI_WORK_TYPE                  IN VARCHAR2,   --作業区分
    ISRI_SR_SEND_MAIL_FLAG          IN VARCHAR2,   --通知済フラグ
    ISRI_SALES_CONFIRMED_FLAG       IN VARCHAR2,   --営業確認済フラグ
    ISRI_WORK_DAY_UNDECIDED_FLAG    IN VARCHAR2,   --作業日未定フラグ
    ISRI_CORRESPOND_FLAG            IN VARCHAR2,   --要対応フラグ
    ISRI_IMPORTANT_OBSTACLES_FLAG   IN VARCHAR2,   --重要障害フラグ
    ISRI_REPEAT_CALL                IN VARCHAR2,   --リピートコール
    ISRI_EXTERNAL_SYSTEM_URL        IN VARCHAR2,   --外部システム用URL
    ISRI_EXTERNAL_SYSTEM_ID         IN VARCHAR2,   --外部システム用ID
    ISRI_ALERT_MAIL_ESCALATION_NO   IN VARCHAR2,   --エスカレーションポイント番号
    ISRI_PRODUCT_ID                 IN VARCHAR2,   --プロダクト
    ISRI_CATEGORY1_ID               IN VARCHAR2,   --カテゴリ１
    ISRI_CATEGORY2_ID               IN VARCHAR2,   --カテゴリ２
    ISRI_CATEGORY3_ID               IN VARCHAR2,   --カテゴリ３
    ISRI_DIFFICULITY                IN VARCHAR2,   --難易度
    ISRI_ESCALATION_DESTINATION     IN VARCHAR2,   --エスカレーション先
    ISRI_CASE_ID1                   IN VARCHAR2,   --CASE　ID１
    ISRI_CASE_ID2                   IN VARCHAR2,   --CASE　ID２
    ISRI_CASE_ID3                   IN VARCHAR2,   --CASE　ID３
    ISRI_CASE_ID4                   IN VARCHAR2,   --CASE　ID４
    ISRI_CASE_ID5                   IN VARCHAR2,   --CASE　ID５
    ISRI_KNOWLEDGE_COOPERATION_FG IN VARCHAR2,   --ナレッジ連携有無フラグ
    ISRI_AUTO_CLOSE_SEND_MAIL_DT  IN VARCHAR2,   --自動クローズ通知日時
    ISRI_PROGRAM_ID                 IN VARCHAR2,   --更新プログラムID
    ISRI_PROCESS_ID                 IN VARCHAR2,   --処理ID
    ISRI_UPDATE_DATE                IN VARCHAR2,   --更新日時
    ISRI_ADD_INFO1                  IN VARCHAR2,   --付加情報１
    ISRI_ADD_INFO2                  IN VARCHAR2,   --付加情報２
    ISRI_ADD_INFO3                  IN VARCHAR2,   --付加情報３
    ISRI_ADD_INFO4                  IN VARCHAR2,   --付加情報４
    ISRI_ADD_INFO5                  IN VARCHAR2,   --付加情報５
    --ログインユーザ情報
    INPUT_USER_ID IN VARCHAR2,      --ユーザID
    --更新プログラム情報
    INPUT_UPD_PROGRAM IN  VARCHAR2, --更新プログラム
    INPUT_PROC_ID     IN  VARCHAR2, --処理ID
    --楽観ロック比較有無フラグ
    INPUT_LOCK_COM_FLG IN VARCHAR2,
    --終了コード
    RESULT_CD OUT VARCHAR2,
    --SR番号
    SR_NO OUT VARCHAR2,
    --更新日時
    UPDATE_DATE OUT DATE );

-----------------------------------------------------------------------------------
--  DDL for Procedure CSG01_PROC_REGIST_SR_RERATION 関連SR情報作成バッチ
-----------------------------------------------------------------------------------

/**
 * 関連SR情報作成処理
 *
 * パラメータで指定された情報を元に、関連SR情報の作成、及び削除処理(論理削除)を行う。
 *
 * @param INPUT_PROC_DIV:処理区分
 * @param INPUT_SR_RERATION_INFO:関連SR情報
 * @param INPUT_TWO_WAYS_LINKAGE_FLG:双方向関連付けフラグ
 * @param INPUT_LOGIN_USER_INFO:ログインユーザ情報
 * @param INPUT_UPD_PROGRAM_INFO:更新プログラム情報
 * @param INPUT_LOCK_COM_FLG:楽観ロック比較有無フラグ
 * @param RESULT_CD:終了コード
 * @param UPDATE_DATE:更新日時
 */
PROCEDURE CSG01_PROC_REGIST_SR_RERATION (
    --処理区分
    INPUT_PROC_DIV IN VARCHAR2,
    --関連SR情報
    ILSI_SERVICE_REQUEST_NO         IN VARCHAR2,      --SR番号
    ILSI_LINK_SERVICE_REQUEST_NO    IN VARCHAR2,      --関連SR番号
    ILSI_LINK_TYPE_ID               IN VARCHAR2,      --関連タイプ
    ILSI_UPDATE_DATE                IN VARCHAR2,      --更新日時
    --双方向関連付けフラグ
    INPUT_TWO_WAYS_LINKAGE_FLG IN VARCHAR2,
    --ログインユーザ情報
    INPUT_USER_ID IN VARCHAR2,      --ユーザID
    --更新プログラム情報
    INPUT_UPD_PROGRAM IN  VARCHAR2, --更新プログラム
    INPUT_PROC_ID     IN  VARCHAR2, --処理ID
    --楽観ロック比較有無フラグ
    INPUT_LOCK_COM_FLG IN VARCHAR2,
    --終了コード
    RESULT_CD OUT VARCHAR2,
    --更新日時
    UPDATE_DATE OUT DATE );

-----------------------------------------------------------------------------------
--  DDL for Procedure CSG01_PROC_REGIST_QST 質問管理情報作成バッチ
-----------------------------------------------------------------------------------

/**
 * 質問管理情報作成処理
 *
 * パラメータで指定された情報を元に、質問情報の作成、及び更新を行う。
 *
 * @param INPUT_UPD_DIV:更新区分
 * @param INPUT_QST_CTL_INFO:質問管理情報
 * @param INPUT_BASE_INFO_DATE:基本情報更新日時
 * @param INPUT_LOGIN_USER_INFO:ログインユーザ情報
 * @param INPUT_UPD_PROGRAM_INFO:更新プログラム情報
 * @param INPUT_LOCK_COM_FLG:楽観ロック比較有無フラグ
 * @param RESULT_CD:終了コード
 * @param QST_UPDATE_DATE:質問管理情報更新日時
 * @param BASE_UPDATE_DATE:基本情報更新日時
 */
PROCEDURE CSG01_PROC_REGIST_QST (
    --更新区分
    INPUT_UPD_DIV IN VARCHAR2,
    --質問管理情報
    IQCI_REQUEST_ID                 IN VARCHAR2,   --質問ID
    IQCI_SERVICE_REQUEST_NO         IN VARCHAR2,   --SR番号
    IQCI_NO                         IN VARCHAR2,   --No
    IQCI_DIVISION                   IN VARCHAR2,   --区分
    IQCI_QUESTION_STATUS            IN VARCHAR2,   --ステータス
    IQCI_QUESTION_TYPE_ID           IN VARCHAR2,   --質問タイプ
    IQCI_TITLE                      IN VARCHAR2,   --タイトル
    IQCI_QUESTION_CONTENTS          IN VARCHAR2,   --内容
    IQCI_ANSWER_TIME_LIMIT          IN VARCHAR2,   --希望回答期限
    IQCI_ATTACHED_FILE              IN VARCHAR2,   --添付有フラグ
    IQCI_START_DATE                 IN VARCHAR2,   --作成開始日時
    IQCI_COMPLETION_DATE            IN VARCHAR2,   --作成完了日時
    IQCI_UPDATE_DATE                IN VARCHAR2,   --更新日時
    IQCI_ADDRESS_CHANGE_ID          IN VARCHAR2,   --宛先変更ID
    --基本情報更新日時
    INPUT_BASE_INFO_DATE IN VARCHAR2,
    --ログインユーザ情報
    INPUT_USER_ID IN VARCHAR2,      --ユーザID
    --更新プログラム情報
    INPUT_UPD_PROGRAM IN  VARCHAR2, --更新プログラム
    INPUT_PROC_ID     IN  VARCHAR2, --処理ID
    --楽観ロック比較有無フラグ
    INPUT_LOCK_COM_FLG IN VARCHAR2,
    --終了コード
    RESULT_CD OUT VARCHAR2,
    --質問管理情報更新日時
    QST_UPDATE_DATE OUT DATE,
    --基本情報更新日時
    BASE_UPDATE_DATE OUT DATE );

-----------------------------------------------------------------------------------
--  DDL for Procedure CSG01_PROC_REGIST_ANS 回答管理情報作成バッチ
-----------------------------------------------------------------------------------

/**
 * 回答管理情報作成処理
 *
 * パラメータで指定された情報を元に、回答情報の作成、及び更新を行う。
 *
 * @param INPUT_UPD_DIV:更新区分
 * @param INPUT_ANS_CTL_INFO:回答管理情報
 * @param INPUT_BASE_INFO_DATE:基本情報更新日時
 * @param INPUT_LOGIN_USER_INFO:ログインユーザ情報
 * @param INPUT_UPD_PROGRAM_INFO:更新プログラム情報
 * @param INPUT_LOCK_COM_FLG:楽観ロック比較有無フラグ
 * @param RESULT_CD:終了コード
 * @param ANS_UPDATE_DATE:回答管理情報更新日時
 * @param BASE_UPDATE_DATE:基本情報更新日時
 */
PROCEDURE CSG01_PROC_REGIST_ANS (
    --更新区分
    INPUT_UPD_DIV IN VARCHAR2,
    --回答管理情報
    IACI_ANSWER_ID                  IN VARCHAR2,   --回答ID
    IACI_SERVICE_REQUEST_NO         IN VARCHAR2,   --SR番号
    IACI_QUESTION_NO                IN VARCHAR2,   --質問No
    IACI_NO                         IN VARCHAR2,   --No
    IACI_ANSWER_STATUS              IN VARCHAR2,   --ステータス
    IACI_TITLE                      IN VARCHAR2,   --タイトル
    IACI_ANSWER_CONTENTS            IN VARCHAR2,   --回答内容
    IACI_MEMO                       IN VARCHAR2,   --メモ
    IACI_ATTACHED_FILE              IN VARCHAR2,   --添付有フラグ
    IACI_ATTACHED_FILE_BUTTON_FLAG  IN VARCHAR2,   --アップロード実行フラグ
    IACI_ATTACHED_FILE_NAME         IN VARCHAR2,   --添付ファイル名
    IACI_DOWNLOAD_KEY               IN VARCHAR2,   --ダウンロードキー
    IACI_START_DATE                 IN VARCHAR2,   --作成開始日時
    IACI_COMPLETION_DATE            IN VARCHAR2,   --作成完了日時
    IACI_UPDATE_DATE                IN VARCHAR2,   --更新日時
    --基本情報更新日時
    INPUT_BASE_INFO_DATE IN VARCHAR2,
    --ログインユーザ情報
    INPUT_USER_ID IN VARCHAR2,      --ユーザID
    --更新プログラム情報
    INPUT_UPD_PROGRAM IN  VARCHAR2, --更新プログラム
    INPUT_PROC_ID     IN  VARCHAR2, --処理ID
    --楽観ロック比較有無フラグ
    INPUT_LOCK_COM_FLG IN VARCHAR2,
    --終了コード
    RESULT_CD OUT VARCHAR2,
    --回答管理情報更新日時
    ANS_UPDATE_DATE OUT DATE,
    --基本情報更新日時
    BASE_UPDATE_DATE OUT DATE );

-----------------------------------------------------------------------------------
--  DDL for Procedure CSG01_PROC_REGIST_SO サービスオーダー情報作成バッチ
-----------------------------------------------------------------------------------

/**
 * サービスオーダー情報作成処理
 *
 * パラメータで指定された情報を元に、サービスオーダー情報の作成、及び更新を行う。
 *
 * @param INPUT_UPD_DIV:更新区分
 * @param INPUT_SO_INFO:サービスオーダー情報
 * @param INPUT_LOGIN_USER_INFO:ログインユーザ情報
 * @param INPUT_UPD_PROGRAM_INFO:更新プログラム情報
 * @param INPUT_LOCK_COM_FLG:楽観ロック比較有無フラグ
 * @param RESULT_CD:終了コード
 * @param SERVICE_ORDER_NO:SO番号
 * @param UPDATE_DATE:更新日時
 */
PROCEDURE CSG01_PROC_REGIST_SO (
    --更新区分
    INPUT_UPD_DIV IN VARCHAR2,
    --サービスオーダー情報
    ISI_SERVICE_REQUEST_NO          IN VARCHAR2,   --SR番号
    ISI_SERVICE_ORDER_NO            IN VARCHAR2,   --SO番号
    ISI_SERVICE_ORDER_TYPE_ID       IN VARCHAR2,   --SOタイプ
    ISI_SERVICE_ORDER_STATUS        IN VARCHAR2,   --SOステータス
    ISI_CORRESPONDING_TIME_LIMIT    IN VARCHAR2,   --対応期限
    ISI_WORK_GROUP_ID               IN VARCHAR2,   --作業グループ
    ISI_WORK_MAIN_PERSON_ID         IN VARCHAR2,   --作業主担当
    ISI_WORK_NAME                   IN VARCHAR2,   --作業名
    ISI_WORK_OVERVIEW               IN VARCHAR2,   --作業概要
    ISI_SCHEDULED_START_DATE        IN VARCHAR2,   --開始予定日時
    ISI_SCHEDULED_END_DATE          IN VARCHAR2,   --終了予定日時
    ISI_ACTUAL_START_DATE           IN VARCHAR2,   --開始日時(実績)
    ISI_ACTUAL_END_DATE             IN VARCHAR2,   --終了日時(実績)
    ISI_SECONDARY_INVENTORY_NAME    IN VARCHAR2,   --委託先名
    ISI_SECONDARY_INVENTORY_PERSON  IN VARCHAR2,   --委託先担当者
    ISI_SECONDARY_INVENTORY_TEL     IN VARCHAR2,   --委託先TEL
    ISI_SECONDARY_INVENTORY_MAIL    IN VARCHAR2,   --委託先MAIL
    ISI_CLOSE_DATE                  IN VARCHAR2,   --クローズ日時
    ISI_UPDATE_DATE                 IN VARCHAR2,   --更新日時
    --ログインユーザ情報
    INPUT_USER_ID IN VARCHAR2,      --ユーザID
    --更新プログラム情報
    INPUT_UPD_PROGRAM IN  VARCHAR2, --更新プログラム
    INPUT_PROC_ID     IN  VARCHAR2, --処理ID
    --楽観ロック比較有無フラグ
    INPUT_LOCK_COM_FLG IN VARCHAR2,
    --終了コード
    RESULT_CD OUT VARCHAR2,
    --SO番号
    SERVICE_ORDER_NO OUT VARCHAR2,
    --更新日時
    UPDATE_DATE OUT DATE );

-----------------------------------------------------------------------------------
--  DDL for Procedure CSG01_PROC_REGIST_TASK タスク情報作成バッチ
-----------------------------------------------------------------------------------

/**
 * タスク情報作成処理
 *
 * パラメータで指定された情報を元に、タスク情報の作成、及び更新を行う。
 *
 * @param INPUT_ADD_UPD_DIV:追加・更新区分
 * @param INPUT_TASK_INFO:タスク情報
 * @param INPUT_LOGIN_USER_INFO:ログインユーザ情報
 * @param INPUT_UPD_PROGRAM_INFO:更新プログラム情報
 * @param INPUT_LOCK_COM_FLG:楽観ロック比較有無フラグ
 * @param RESULT_CD:終了コード
 * @param TASK_NO:タスク番号
 * @param UPDATE_DATE:更新日時
 */
PROCEDURE CSG01_PROC_REGIST_TASK (
    --追加・更新区分
    INPUT_ADD_UPD_DIV IN VARCHAR2,
    --タスク情報
    ITI_SERVICE_ORDER_NO            IN VARCHAR2,    --SO番号
    ITI_TASK_NO                     IN VARCHAR2,    --タスク番号
    ITI_SERVICE_REQUEST_NO          IN VARCHAR2,    --SR番号
    ITI_TASK_STATUS                 IN VARCHAR2,    --ステータス
    ITI_WORK_PERSON_ID              IN VARCHAR2,    --担当者
    ITI_SCHEDULED_START_DATE        IN VARCHAR2,    --開始予定日時
    ITI_SCHEDULED_END_DATE          IN VARCHAR2,    --終了予定日時
    ITI_ACTUAL_START_DATE           IN VARCHAR2,    --実績開始日時
    ITI_ACTUAL_END_DATE             IN VARCHAR2,    --実績終了日時
    ITI_UPDATE_DATE                 IN VARCHAR2,    --更新日時
    --ログインユーザ情報
    INPUT_USER_ID IN VARCHAR2,      --ユーザID
    --更新プログラム情報
    INPUT_UPD_PROGRAM IN  VARCHAR2, --更新プログラム
    INPUT_PROC_ID     IN  VARCHAR2, --処理ID
    --楽観ロック比較有無フラグ
    INPUT_LOCK_COM_FLG IN VARCHAR2,
    --終了コード
    RESULT_CD OUT VARCHAR2,
    --タスク番号
    TASK_NO OUT VARCHAR2,
    --更新日時
    UPDATE_DATE OUT DATE );

-----------------------------------------------------------------------------------
--  DDL for Procedure CSG01_PROC_REGIST_TSR 内部QA作成バッチ
-----------------------------------------------------------------------------------

/**
 * 内部QA作成処理
 *
 * パラメータで指定された情報を元に、内部QA情報の作成、及び更新処理を行う。
 *
 * @param INPUT_UPD_DIV:更新区分
 * @param INPUT_TSR_INFO:内部QA情報
 * @param INPUT_LOGIN_USER_INFO:ログインユーザ情報
 * @param INPUT_UPD_PROGRAM_INFO:更新プログラム情報
 * @param INPUT_LOCK_COM_FLG:楽観ロック比較有無フラグ
 * @param RESULT_CD:終了コード
 * @param TECH_SUPPORT_REQUEST_NO:内部QA番号
 * @param UPDATE_DATE:更新日時
 */
PROCEDURE CSG01_PROC_REGIST_TSR (
    --更新区分
    INPUT_UPD_DIV IN VARCHAR2,
    --内部QA情報
    ITSRI_SERVICE_REQUEST_NO IN  VARCHAR2,              --SR番号
    ITSRI_TECH_SUPPORT_REQUEST_NO IN  VARCHAR2,         --内部QA番号
    ITSRI_TECH_SPRT_REQ_TYPE_ID IN  VARCHAR2,    --タイプ
    ITSRI_TECH_SPRT_REQ_STATUS IN  VARCHAR2,     --ステータス
    ITSRI_GROUP_ID IN  VARCHAR2,                        --担当グループ
    ITSRI_PERSON_ID IN  VARCHAR2,                       --担当者
    ITSRI_TECH_SPRT_REQ_CRE_U_ID IN  VARCHAR2,  --作成者
    ITSRI_CORRESPONDING_TIME_LIMIT IN  VARCHAR2,        --対応期限
    ITSRI_RECEIPT_DATE IN  VARCHAR2,                    --受付日時
    ITSRI_CALLER_COMPANY_NAME IN  VARCHAR2,             --Caller会社名
    ITSRI_CALLER_DEPT_NAME IN  VARCHAR2,                --Caller部署
    ITSRI_CALLER_CONTACTOR_PERSON IN  VARCHAR2,         --Caller担当者
    ITSRI_CALLER_TEL IN  VARCHAR2,                      --CallerTEL
    ITSRI_CALLER_FAX IN  VARCHAR2,                      --CallerFAX
    ITSRI_CALLER_MAIL_ADDRESS IN  VARCHAR2,             --CallerE-Mail-To
    ITSRI_CALLER_MAIL_ADDRESS_CC IN  VARCHAR2,          --CallerE-Mail-Cc
    ITSRI_CALLER_EMPLOYEE IN  VARCHAR2,                 --Caller社員番号
    ITSRI_TITLE IN  VARCHAR2,                           --タイトル
    ITSRI_WORK_OVERVIEW IN  VARCHAR2,                   --質問概要
    ITSRI_PRODUCT_ID IN  VARCHAR2,                      --プロダクト
    ITSRI_CATEGORY1_ID IN  VARCHAR2,                    --カテゴリ１
    ITSRI_CATEGORY2_ID IN  VARCHAR2,                    --カテゴリ２
    ITSRI_CATEGORY3_ID IN  VARCHAR2,                    --カテゴリ３
    ITSRI_DIFFICULITY IN  VARCHAR2,                     --難易度
    ITSRI_ESCALATION_DESTINATION IN  VARCHAR2,          --エスカレーション先
    ITSRI_CASE_ID1 IN  VARCHAR2,                        --CASE　ID１
    ITSRI_CASE_ID2 IN  VARCHAR2,                        --CASE　ID２
    ITSRI_CASE_ID3 IN  VARCHAR2,                        --CASE　ID３
    ITSRI_CASE_ID4 IN  VARCHAR2,                        --CASE　ID４
    ITSRI_CASE_ID5 IN  VARCHAR2,                        --CASE　ID５
    ITSRI_SR_SEND_MAIL_FLAG IN  VARCHAR2,               --通知済フラグ
    ITSRI_EXTERNAL_SYSTEM_ID IN  VARCHAR2,              --外部システム用ID
    ITSRI_CLOSE_DATE IN  VARCHAR2,                      --クローズ日時
    ITSRI_UPDATE_DATE IN  VARCHAR2,                     --更新日時
    --ログインユーザ情報
    INPUT_USER_ID IN VARCHAR2,      --ユーザID
    --更新プログラム情報
    INPUT_UPD_PROGRAM IN  VARCHAR2, --更新プログラム
    INPUT_PROC_ID     IN  VARCHAR2, --処理ID
    --楽観ロック比較有無フラグ
    INPUT_LOCK_COM_FLG IN VARCHAR2,
    --終了コード
    RESULT_CD OUT VARCHAR2,
    --内部QA番号
    TECH_SUPPORT_REQUEST_NO OUT VARCHAR2,
    --更新日時
    UPDATE_DATE OUT DATE );

-----------------------------------------------------------------------------------
--  DDL for Procedure CSG01_PROC_REGIST_NOTE ノート情報作成バッチ
-----------------------------------------------------------------------------------

/**
 * ノート情報作成処理
 *
 * パラメータで指定された情報を元に、ノート情報の作成処理を行う。
 *
 * @param INPUT_NOTE_INFO:ノート情報
 * @param INPUT_LOGIN_USER_INFO:ログインユーザ情報
 * @param INPUT_UPD_PROGRAM_INFO:更新プログラム情報
 * @param RESULT_CD:終了コード
 * @param UPDATE_DATE:更新日時
 */
PROCEDURE CSG01_PROC_REGIST_NOTE (
    --ノート情報
    INI_SERVICE_REQUEST_NO  IN  VARCHAR2,         --SR番号
    INI_NOTES               IN  VARCHAR2,         --ノート
    --ログインユーザ情報
    INPUT_USER_ID IN VARCHAR2,      --ユーザID
    --更新プログラム情報
    INPUT_UPD_PROGRAM IN  VARCHAR2, --更新プログラム
    INPUT_PROC_ID     IN  VARCHAR2, --処理ID
    --終了コード
    RESULT_CD OUT VARCHAR2,
    --更新日時
    UPDATE_DATE OUT DATE );

-----------------------------------------------------------------------------------
--  DDL for Procedure CSG01_PROC_CREATE_SR_INFO サービス要求受付登録ラッピングバッチ
-----------------------------------------------------------------------------------

/**
 * サービス要求受付登録ラッピング処理
 *
 * パラメータで指定された情報を元に、以下の情報の作成、及び更新を行う。
 * ・サービス要求情報
 * ・関連SR情報
 *
 * @param INPUT_SERVICE_REQ_INFO:サービス要求情報
 * @param INPUT_SR_RERATION_INFO:関連SR情報
 * @param INPUT_LOGIN_USER_INFO:ログインユーザ情報
 * @param INPUT_UPD_PROGRAM_INFO:更新プログラム情報
 * @param RESULT_CD:終了コード
 * @param SR_NO:SR番号
 * @param SR_UPDATE_DATE:サービス要求更新日時
 * @param SR_RRT_UPDATE_DATE:関連SR更新日時
 */
PROCEDURE CSG01_PROC_CREATE_SR_INFO (
    --サービス要求情報
    ISRI_SERVICE_REQUEST_NO         IN VARCHAR2,   --SR番号
    ISRI_SERVICE_REQUEST_TYPE_ID    IN VARCHAR2,   --SRタイプ
    ISRI_SERVICE_REQUEST_STATUS     IN VARCHAR2,   --SRステータス
    ISRI_IMPORTANCE_LEVEL           IN VARCHAR2,   --重要度
    ISRI_SR_CREATION_CHANNEL        IN VARCHAR2,   --受付チャネル
    ISRI_SERVICE_REQUEST_GROUP_ID   IN VARCHAR2,   --SR担当グループ
    ISRI_SERVICE_REQUEST_PERSON_ID  IN VARCHAR2,   --SR担当者
    ISRI_SERIAL_NO                  IN VARCHAR2,   --シリアル番号
    ISRI_INSTANCE_ID                IN VARCHAR2,   --インスタンス番号
    ISRI_INVENTORY_ITEM_CODE        IN VARCHAR2,   --品目コード
    ISRI_ORG_ID                     IN VARCHAR2,   --プラント
    ISRI_INSTALL_PARTY_NO           IN VARCHAR2,   --設置先顧客番号
    ISRI_CONTRACT_ID                IN VARCHAR2,   --契約ID
    ISRI_CONTRACT_NO                IN VARCHAR2,   --契約番号
    ISRI_CONTRACT_PARTY_ID          IN VARCHAR2,   --契約先顧客番号
    ISRI_EXTENDED_ID                IN VARCHAR2,   --拡張ID
    ISRI_MODEL_CODE                 IN VARCHAR2,   --機種コード
    ISRI_GROUP_ID                   IN VARCHAR2,   --担当CS
    ISRI_RECEIPT_DATE               IN VARCHAR2,   --受付日時
    ISRI_FAILURE_OCCUR_DATE         IN VARCHAR2,   --障害発生日時
    ISRI_CLOSE_DATE                 IN VARCHAR2,   --クローズ日時
    ISRI_RECEIPT_GROUP_ID           IN VARCHAR2,   --受付グループ
    ISRI_RECEIPT_PERSON_ID          IN VARCHAR2,   --受付者
    ISRI_CALLER_COMPANY_NAME        IN VARCHAR2,   --Caller会社名
    ISRI_CALLER_DEPT_NAME           IN VARCHAR2,   --Caller部署
    ISRI_CALLER_CONTACTOR_PERSON    IN VARCHAR2,   --Caller担当者
    ISRI_CALLER_TEL                 IN VARCHAR2,   --CallerTEL
    ISRI_CALLER_FAX                 IN VARCHAR2,   --CallerFAX
    ISRI_CALLER_MAIL_ADDRESS        IN VARCHAR2,   --CallerE-Mail-To
    ISRI_CALLER_MAIL_ADDRESS_CC     IN VARCHAR2,   --CallerE-Mail-Cc
    ISRI_CALLER_EMPLOYEE            IN VARCHAR2,   --Caller社員番号
    ISRI_SERVICE_REPORT_TYPE        IN VARCHAR2,   --サービスタイプ
    ISRI_CORRESPONDING_TIME_LIMIT   IN VARCHAR2,   --対応期限
    ISRI_AUTO_CLOSE_RECORD_DATE     IN VARCHAR2,   --自動クローズ基準日
    ISRI_EXTERNAL_KIND              IN VARCHAR2,   --外部種別
    ISRI_EXTERNAL_ID                IN VARCHAR2,   --外部ID
    ISRI_SUMMARY                    IN VARCHAR2,   --問題要約
    ISRI_INQUIRY_OUTLINE            IN VARCHAR2,   --問題内容
    ISRI_CUSTOMER_ID                IN VARCHAR2,   --カスタマID
    ISRI_WAIT_TYPE                  IN VARCHAR2,   --待機区分
    ISRI_WORK_TYPE                  IN VARCHAR2,   --作業区分
    ISRI_SR_SEND_MAIL_FLAG          IN VARCHAR2,   --通知済フラグ
    ISRI_SALES_CONFIRMED_FLAG       IN VARCHAR2,   --営業確認済フラグ
    ISRI_WORK_DAY_UNDECIDED_FLAG    IN VARCHAR2,   --作業日未定フラグ
    ISRI_CORRESPOND_FLAG            IN VARCHAR2,   --要対応フラグ
    ISRI_IMPORTANT_OBSTACLES_FLAG   IN VARCHAR2,   --重要障害フラグ
    ISRI_REPEAT_CALL                IN VARCHAR2,   --リピートコール
    ISRI_EXTERNAL_SYSTEM_URL        IN VARCHAR2,   --外部システム用URL
    ISRI_EXTERNAL_SYSTEM_ID         IN VARCHAR2,   --外部システム用ID
    ISRI_ALERT_MAIL_ESCALATION_NO   IN VARCHAR2,   --エスカレーションポイント番号
    ISRI_PRODUCT_ID                 IN VARCHAR2,   --プロダクト
    ISRI_CATEGORY1_ID               IN VARCHAR2,   --カテゴリ１
    ISRI_CATEGORY2_ID               IN VARCHAR2,   --カテゴリ２
    ISRI_CATEGORY3_ID               IN VARCHAR2,   --カテゴリ３
    ISRI_DIFFICULITY                IN VARCHAR2,   --難易度
    ISRI_ESCALATION_DESTINATION     IN VARCHAR2,   --エスカレーション先
    ISRI_CASE_ID1                   IN VARCHAR2,   --CASE　ID１
    ISRI_CASE_ID2                   IN VARCHAR2,   --CASE　ID２
    ISRI_CASE_ID3                   IN VARCHAR2,   --CASE　ID３
    ISRI_CASE_ID4                   IN VARCHAR2,   --CASE　ID４
    ISRI_CASE_ID5                   IN VARCHAR2,   --CASE　ID５
    ISRI_KNOWLEDGE_COOPERATION_FG IN VARCHAR2,   --ナレッジ連携有無フラグ
    ISRI_AUTO_CLOSE_SEND_MAIL_DT  IN VARCHAR2,   --自動クローズ通知日時
    ISRI_PROGRAM_ID                 IN VARCHAR2,   --更新プログラムID
    ISRI_PROCESS_ID                 IN VARCHAR2,   --処理ID
    ISRI_UPDATE_DATE                IN VARCHAR2,   --更新日時
    ISRI_ADD_INFO1                  IN VARCHAR2,   --付加情報１
    ISRI_ADD_INFO2                  IN VARCHAR2,   --付加情報２
    ISRI_ADD_INFO3                  IN VARCHAR2,   --付加情報３
    ISRI_ADD_INFO4                  IN VARCHAR2,   --付加情報４
    ISRI_ADD_INFO5                  IN VARCHAR2,   --付加情報５
    --関連SR情報
    ILSI_SERVICE_REQUEST_NO         IN VARCHAR2,      --SR番号
    ILSI_LINK_SERVICE_REQUEST_NO    IN VARCHAR2,      --関連SR番号
    ILSI_LINK_TYPE_ID               IN VARCHAR2,      --関連タイプ
    ILSI_UPDATE_DATE                IN VARCHAR2,      --更新日時
    --ログインユーザ情報
    INPUT_USER_ID IN VARCHAR2,      --ユーザID
    --更新プログラム情報
    INPUT_UPD_PROGRAM IN  VARCHAR2, --更新プログラム
    INPUT_PROC_ID     IN  VARCHAR2, --処理ID
    --終了コード
    RESULT_CD OUT VARCHAR2,
    --SR番号
    SR_NO OUT VARCHAR2,
    --サービス要求更新日時
    SR_UPDATE_DATE OUT DATE,
    --関連SR更新日時
    SR_RRT_UPDATE_DATE OUT DATE );

-----------------------------------------------------------------------------------
--  DDL for Procedure CSG01_PROC_CREATE_TASK_INFO タスク登録ラッピングバッチ
-----------------------------------------------------------------------------------

/**
 * タスク登録ラッピング処理
 *
 * パラメータで指定された情報を元に、以下の情報の作成、及び更新を行う。
 * ・タスク情報
 * ・サービスオーダー情報
 *
 * @param INPUT_SO_INFO:サービスオーダー情報
 * @param INPUT_TASK_INFO:タスク情報
 * @param INPUT_LOGIN_USER_INFO:ログインユーザ情報
 * @param INPUT_UPD_PROGRAM_INFO:更新プログラム情報
 * @param RESULT_CD:終了コード
 * @param TASK_NO:タスク番号
 * @param SERVICE_ORDER_NO:SO番号
 * @param TASK_UPDATE_DATE:タスク情報更新日時
 * @param SO_UPDATE_DATE:サービスオーダー情報更新日時
 */
PROCEDURE CSG01_PROC_CREATE_TASK_INFO (
    --サービスオーダー情報
    ISI_SERVICE_REQUEST_NO          IN VARCHAR2,   --SR番号
    ISI_SERVICE_ORDER_NO            IN VARCHAR2,   --SO番号
    ISI_SERVICE_ORDER_TYPE_ID       IN VARCHAR2,   --SOタイプ
    ISI_SERVICE_ORDER_STATUS        IN VARCHAR2,   --SOステータス
    ISI_CORRESPONDING_TIME_LIMIT    IN VARCHAR2,   --対応期限
    ISI_WORK_GROUP_ID               IN VARCHAR2,   --作業グループ
    ISI_WORK_MAIN_PERSON_ID         IN VARCHAR2,   --作業主担当
    ISI_WORK_NAME                   IN VARCHAR2,   --作業名
    ISI_WORK_OVERVIEW               IN VARCHAR2,   --作業概要
    ISI_SCHEDULED_START_DATE        IN VARCHAR2,   --開始予定日時
    ISI_SCHEDULED_END_DATE          IN VARCHAR2,   --終了予定日時
    ISI_ACTUAL_START_DATE           IN VARCHAR2,   --開始日時(実績)
    ISI_ACTUAL_END_DATE             IN VARCHAR2,   --終了日時(実績)
    ISI_SECONDARY_INVENTORY_NAME    IN VARCHAR2,   --委託先名
    ISI_SECONDARY_INVENTORY_PERSON  IN VARCHAR2,   --委託先担当者
    ISI_SECONDARY_INVENTORY_TEL     IN VARCHAR2,   --委託先TEL
    ISI_SECONDARY_INVENTORY_MAIL    IN VARCHAR2,   --委託先MAIL
    ISI_CLOSE_DATE                  IN VARCHAR2,   --クローズ日時
    ISI_UPDATE_DATE                 IN VARCHAR2,   --更新日時
    --タスク情報
    ITI_SERVICE_ORDER_NO            IN VARCHAR2,    --SO番号
    ITI_TASK_NO                     IN VARCHAR2,    --タスク番号
    ITI_SERVICE_REQUEST_NO          IN VARCHAR2,    --SR番号
    ITI_TASK_STATUS                 IN VARCHAR2,    --ステータス
    ITI_WORK_PERSON_ID              IN VARCHAR2,    --担当者
    ITI_SCHEDULED_START_DATE        IN VARCHAR2,    --開始予定日時
    ITI_SCHEDULED_END_DATE          IN VARCHAR2,    --終了予定日時
    ITI_ACTUAL_START_DATE           IN VARCHAR2,    --実績開始日時
    ITI_ACTUAL_END_DATE             IN VARCHAR2,    --実績終了日時
    ITI_UPDATE_DATE                 IN VARCHAR2,    --更新日時
    --ログインユーザ情報
    INPUT_USER_ID IN VARCHAR2,      --ユーザID
    --更新プログラム情報
    INPUT_UPD_PROGRAM IN  VARCHAR2, --更新プログラム
    INPUT_PROC_ID     IN  VARCHAR2, --処理ID
    --終了コード
    RESULT_CD OUT VARCHAR2,
    --タスク番号
    TASK_NO OUT VARCHAR2,
    --SO番号
    SERVICE_ORDER_NO OUT VARCHAR2,
    --タスク情報更新日時
    TASK_UPDATE_DATE OUT DATE,
    --サービスオーダー情報更新日時
    SO_UPDATE_DATE OUT DATE );


-----------------------------------------------------------------------------------
--  以降、内部処理用
-----------------------------------------------------------------------------------

-----------------------------------------------------------------------------------
--  DDL for Procedure CSG01-0106 サービス要求作成
-----------------------------------------------------------------------------------


TYPE T_SERVICE_REQ_INFO_REC IS RECORD ( -- サービス要求情報
  SERVICE_REQUEST_NO         CSG_T_SRVC_REQ_INFO.SERVICE_REQUEST_NO%TYPE,          --SR番号
  SERVICE_REQUEST_TYPE_ID    CSG_T_SRVC_REQ_INFO.SERVICE_REQUEST_TYPE_ID%TYPE,     --SRタイプ
  SERVICE_REQUEST_STATUS     CSG_T_SRVC_REQ_INFO.SERVICE_REQUEST_STATUS%TYPE,      --SRステータス
  IMPORTANCE_LEVEL           CSG_T_SRVC_REQ_INFO.IMPORTANCE_LEVEL%TYPE,            --重要度
  SR_CREATION_CHANNEL        CSG_T_SRVC_REQ_INFO.SR_CREATION_CHANNEL%TYPE,         --受付チャネル
  SERVICE_REQUEST_GROUP_ID   CSG_T_SRVC_REQ_INFO.SERVICE_REQUEST_GROUP_ID%TYPE,    --SR担当グループ
  SERVICE_REQUEST_PERSON_ID  CSG_T_SRVC_REQ_INFO.SERVICE_REQUEST_PERSON_ID%TYPE,   --SR担当者
  SERIAL_NO                  CSG_T_SRVC_REQ_INFO.SERIAL_NO%TYPE,                   --シリアル番号
  INSTANCE_ID                CSG_T_SRVC_REQ_INFO.INSTANCE_ID%TYPE,                 --インスタンス番号
  INVENTORY_ITEM_CODE        CSG_T_SRVC_REQ_INFO.INVENTORY_ITEM_CODE%TYPE,         --品目コード
  ORG_ID                     CSG_T_SRVC_REQ_INFO.ORG_ID%TYPE,                      --プラント
  INSTALL_PARTY_NO           CSG_T_SRVC_REQ_INFO.INSTALL_PARTY_NO%TYPE,            --設置先顧客番号
  CONTRACT_ID                CSG_T_SRVC_REQ_INFO.CONTRACT_ID%TYPE,                 --契約ID
  CONTRACT_NO                CSG_T_SRVC_REQ_INFO.CONTRACT_NO%TYPE,                 --契約番号
  CONTRACT_PARTY_ID          CSG_T_SRVC_REQ_INFO.CONTRACT_PARTY_ID%TYPE,           --契約先顧客番号
  EXTENDED_ID                CSG_T_SRVC_REQ_INFO.EXTENDED_ID%TYPE,                 --拡張ID
  MODEL_CODE                 CSG_T_SRVC_REQ_INFO.MODEL_CODE%TYPE,                  --機種コード
  GROUP_ID                   CSG_T_SRVC_REQ_INFO.GROUP_ID%TYPE,                    --担当CS
  RECEIPT_DATE               CSG_T_SRVC_REQ_INFO.RECEIPT_DATE%TYPE,                --受付日時
  FAILURE_OCCUR_DATE         CSG_T_SRVC_REQ_INFO.FAILURE_OCCUR_DATE%TYPE,          --障害発生日時
  CLOSE_DATE                 CSG_T_SRVC_REQ_INFO.CLOSE_DATE%TYPE,                  --クローズ日時
  RECEIPT_GROUP_ID           CSG_T_SRVC_REQ_INFO.RECEIPT_GROUP_ID%TYPE,            --受付グループ
  RECEIPT_PERSON_ID          CSG_T_SRVC_REQ_INFO.RECEIPT_PERSON_ID%TYPE,           --受付者
  CALLER_COMPANY_NAME        CSG_T_SRVC_REQ_INFO.CALLER_COMPANY_NAME%TYPE,         --Caller会社名
  CALLER_DEPT_NAME           CSG_T_SRVC_REQ_INFO.CALLER_DEPT_NAME%TYPE,            --Caller部署
  CALLER_CONTACTOR_PERSON    CSG_T_SRVC_REQ_INFO.CALLER_CONTACTOR_PERSON%TYPE,     --Caller担当者
  CALLER_TEL                 CSG_T_SRVC_REQ_INFO.CALLER_TEL%TYPE,                  --CallerTEL
  CALLER_FAX                 CSG_T_SRVC_REQ_INFO.CALLER_FAX%TYPE,                  --CallerFAX
  CALLER_MAIL_ADDRESS        CSG_T_SRVC_REQ_INFO.CALLER_MAIL_ADDRESS%TYPE,         --CallerE-Mail-To
  CALLER_MAIL_ADDRESS_CC     CSG_T_SRVC_REQ_INFO.CALLER_MAIL_ADDRESS_CC%TYPE,      --CallerE-Mail-Cc
  CALLER_EMPLOYEE            CSG_T_SRVC_REQ_INFO.CALLER_EMPLOYEE%TYPE,             --Caller社員番号
  SERVICE_REPORT_TYPE        CSG_T_SRVC_REQ_INFO.SERVICE_REPORT_TYPE%TYPE,         --サービスタイプ
  CORRESPONDING_TIME_LIMIT   CSG_T_SRVC_REQ_INFO.CORRESPONDING_TIME_LIMIT%TYPE,    --対応期限
  AUTO_CLOSE_RECORD_DATE     CSG_T_SRVC_REQ_INFO.AUTO_CLOSE_RECORD_DATE%TYPE,      --自動クローズ基準日
  EXTERNAL_KIND              CSG_T_SRVC_REQ_INFO.EXTERNAL_KIND%TYPE,               --外部種別
  EXTERNAL_ID                CSG_T_SRVC_REQ_INFO.EXTERNAL_ID%TYPE,                 --外部ID
  SUMMARY                    CSG_T_SRVC_REQ_INFO.SUMMARY%TYPE,                     --問題要約
  INQUIRY_OUTLINE            CSG_T_SRVC_REQ_INFO.INQUIRY_OUTLINE%TYPE,             --問題内容
  CUSTOMER_ID                CSG_T_SRVC_REQ_INFO.CUSTOMER_ID%TYPE,                 --カスタマID
  WAIT_TYPE                  CSG_T_SRVC_REQ_INFO.WAIT_TYPE%TYPE,                   --待機区分
  WORK_TYPE                  CSG_T_SRVC_REQ_INFO.WORK_TYPE%TYPE,                   --作業区分
  SR_SEND_MAIL_FLAG          CSG_T_SRVC_REQ_INFO.SR_SEND_MAIL_FLAG%TYPE,           --通知済フラグ
  SALES_CONFIRMED_FLAG       CSG_T_SRVC_REQ_INFO.SALES_CONFIRMED_FLAG%TYPE,        --営業確認済フラグ
  WORK_DAY_UNDECIDED_FLAG    CSG_T_SRVC_REQ_INFO.WORK_DAY_UNDECIDED_FLAG%TYPE,     --作業日未定フラグ
  CORRESPOND_FLAG            CSG_T_SRVC_REQ_INFO.CORRESPOND_FLAG%TYPE,             --要対応フラグ
  IMPORTANT_OBSTACLES_FLAG   CSG_T_SRVC_REQ_INFO.IMPORTANT_OBSTACLES_FLAG%TYPE,    --重要障害フラグ
  REPEAT_CALL                CSG_T_SRVC_REQ_INFO.REPEAT_CALL%TYPE,                 --リピートコール
  EXTERNAL_SYSTEM_URL        CSG_T_SRVC_REQ_INFO.EXTERNAL_SYSTEM_URL%TYPE,         --外部システム用URL
  EXTERNAL_SYSTEM_ID         CSG_T_SRVC_REQ_INFO.EXTERNAL_SYSTEM_ID%TYPE,          --外部システム用ID
  ALERT_MAIL_ESCALATION_NO   CSG_T_SRVC_REQ_INFO.ALERT_MAIL_ESCALATION_NO%TYPE,    --エスカレーションポイント番号
  PRODUCT_ID                 CSG_T_SRVC_REQ_INFO.PRODUCT_ID%TYPE,                  --プロダクト
  CATEGORY1_ID               CSG_T_SRVC_REQ_INFO.CATEGORY1_ID%TYPE,                --カテゴリ１
  CATEGORY2_ID               CSG_T_SRVC_REQ_INFO.CATEGORY2_ID%TYPE,                --カテゴリ２
  CATEGORY3_ID               CSG_T_SRVC_REQ_INFO.CATEGORY3_ID%TYPE,                --カテゴリ３
  DIFFICULITY                CSG_T_SRVC_REQ_INFO.DIFFICULITY%TYPE,                 --難易度
  ESCALATION_DESTINATION     CSG_T_SRVC_REQ_INFO.ESCALATION_DESTINATION%TYPE,      --エスカレーション先
  CASE_ID1                   CSG_T_SRVC_REQ_INFO.CASE_ID1%TYPE,                    --CASE　ID１
  CASE_ID2                   CSG_T_SRVC_REQ_INFO.CASE_ID2%TYPE,                    --CASE　ID２
  CASE_ID3                   CSG_T_SRVC_REQ_INFO.CASE_ID3%TYPE,                    --CASE　ID３
  CASE_ID4                   CSG_T_SRVC_REQ_INFO.CASE_ID4%TYPE,                    --CASE　ID４
  CASE_ID5                   CSG_T_SRVC_REQ_INFO.CASE_ID5%TYPE,                    --CASE　ID５
  KNOWLEDGE_COOPERATION_FLAG CSG_T_SRVC_REQ_INFO.KNOWLEDGE_COOPERATION_FLAG%TYPE,  --ナレッジ連携有無フラグ
  AUTO_CLOSE_SEND_MAIL_DATE  CSG_T_SRVC_REQ_INFO.AUTO_CLOSE_SEND_MAIL_DATE%TYPE,   --自動クローズ通知日時
  PROGRAM_ID                 CSG_T_SRVC_REQ_INFO.PROGRAM_ID%TYPE,                  --更新プログラムID
  PROCESS_ID                 CSG_T_SRVC_REQ_INFO.PROCESS_ID%TYPE,                  --処理ID
  UPDATE_DATE                CSG_T_SRVC_REQ_INFO.UPDATE_DATE%TYPE,                 --更新日時
  ADD_INFO1                  CSG_T_SRVC_REQ_INFO.ADD_INFO1%TYPE,                   --付加情報１
  ADD_INFO2                  CSG_T_SRVC_REQ_INFO.ADD_INFO2%TYPE,                   --付加情報２
  ADD_INFO3                  CSG_T_SRVC_REQ_INFO.ADD_INFO3%TYPE,                   --付加情報３
  ADD_INFO4                  CSG_T_SRVC_REQ_INFO.ADD_INFO4%TYPE,                   --付加情報４
  ADD_INFO5                  CSG_T_SRVC_REQ_INFO.ADD_INFO5%TYPE                    --付加情報５
);

TYPE T_LOGIN_USER_INFO_REC IS RECORD ( -- ログインユーザ情報
  USER_ID       VARCHAR2(20)  --ユーザID
);


TYPE T_UPD_PROGRAM_INFO_REC IS RECORD ( -- 更新プログラム情報
  UPD_PROGRAM   VARCHAR2(20), --更新プログラム
  PROC_ID       VARCHAR2(20)  --処理ID
);

TYPE T_SR_RERATION_INFO_REC IS RECORD ( -- 関連SR情報
  SERVICE_REQUEST_NO         CSG_T_LINK_SR_INFO.SERVICE_REQUEST_NO%TYPE,      --SR番号
  LINK_SERVICE_REQUEST_NO    CSG_T_LINK_SR_INFO.LINK_SERVICE_REQUEST_NO%TYPE, --関連SR番号
  LINK_TYPE_ID               CSG_T_LINK_SR_INFO.LINK_TYPE_ID%TYPE,            --関連タイプ
  UPDATE_DATE                CSG_T_LINK_SR_INFO.UPDATE_DATE%TYPE              --更新日時
);

TYPE T_QST_CTL_INFO_REC IS RECORD ( -- 質問管理情報
  REQUEST_ID                 CSG_T_QUESTIONS.REQUEST_ID%TYPE,           --質問ID
  SERVICE_REQUEST_NO         CSG_T_QUESTIONS.SERVICE_REQUEST_NO%TYPE,   --SR番号
  NO                         CSG_T_QUESTIONS.NO%TYPE,                   --No
  DIVISION                   CSG_T_QUESTIONS.DIVISION%TYPE,             --区分
  QUESTION_STATUS            CSG_T_QUESTIONS.QUESTION_STATUS%TYPE,      --ステータス
  QUESTION_TYPE_ID           CSG_T_QUESTIONS.QUESTION_TYPE_ID%TYPE,     --質問タイプ
  TITLE                      CSG_T_QUESTIONS.TITLE%TYPE,                --タイトル
  QUESTION_CONTENTS          CSG_T_QUESTIONS.QUESTION_CONTENTS%TYPE,    --内容
  ANSWER_TIME_LIMIT          CSG_T_QUESTIONS.ANSWER_TIME_LIMIT%TYPE,    --希望回答期限
  ATTACHED_FILE              CSG_T_QUESTIONS.ATTACHED_FILE%TYPE,        --添付有フラグ
  START_DATE                 CSG_T_QUESTIONS.START_DATE%TYPE,           --作成開始日時
  COMPLETION_DATE            CSG_T_QUESTIONS.COMPLETION_DATE%TYPE,      --作成完了日時
  UPDATE_DATE                CSG_T_QUESTIONS.UPDATE_DATE%TYPE,          --更新日時
  ADDRESS_CHANGE_ID          CSG_T_QUESTIONS.ADDRESS_CHANGE_ID%TYPE     --宛先変更ID
);

TYPE T_ANS_CTL_INFO_REC IS RECORD ( -- 回答管理情報
  ANSWER_ID                  CSG_T_ANSWERS.ANSWER_ID%TYPE,                  --回答ID
  SERVICE_REQUEST_NO         CSG_T_ANSWERS.SERVICE_REQUEST_NO%TYPE,         --SR番号
  QUESTION_NO                CSG_T_ANSWERS.QUESTION_NO%TYPE,                --質問No
  NO                         CSG_T_ANSWERS.NO%TYPE,                         --No
  ANSWER_STATUS              CSG_T_ANSWERS.ANSWER_STATUS%TYPE,              --ステータス
  TITLE                      CSG_T_ANSWERS.TITLE%TYPE,                      --タイトル
  ANSWER_CONTENTS            CSG_T_ANSWERS.ANSWER_CONTENTS%TYPE,            --回答内容
  MEMO                       CSG_T_ANSWERS.MEMO%TYPE,                       --メモ
  ATTACHED_FILE              CSG_T_ANSWERS.ATTACHED_FILE%TYPE,              --添付有フラグ
  ATTACHED_FILE_BUTTON_FLAG  CSG_T_ANSWERS.ATTACHED_FILE_BUTTON_FLAG%TYPE,  --アップロード実行フラグ
  ATTACHED_FILE_NAME         CSG_T_ANSWERS.ATTACHED_FILE_NAME%TYPE,         --添付ファイル名
  DOWNLOAD_KEY               CSG_T_ANSWERS.DOWNLOAD_KEY%TYPE,               --ダウンロードキー
  START_DATE                 CSG_T_ANSWERS.START_DATE%TYPE,                 --作成開始日時
  COMPLETION_DATE            CSG_T_ANSWERS.COMPLETION_DATE%TYPE,            --作成完了日時
  UPDATE_DATE                CSG_T_ANSWERS.UPDATE_DATE%TYPE                 --更新日時
);

TYPE T_SO_INFO_REC IS RECORD ( -- サービスオーダー情報
  SERVICE_REQUEST_NO          CSG_T_SERVICE_ORDER_INFO.SERVICE_REQUEST_NO%TYPE,          --SR番号
  SERVICE_ORDER_NO            CSG_T_SERVICE_ORDER_INFO.SERVICE_ORDER_NO%TYPE,            --SO番号
  SERVICE_ORDER_TYPE_ID       CSG_T_SERVICE_ORDER_INFO.SERVICE_ORDER_TYPE_ID%TYPE,       --SOタイプ
  SERVICE_ORDER_STATUS        CSG_T_SERVICE_ORDER_INFO.SERVICE_ORDER_STATUS%TYPE,        --SOステータス
  CORRESPONDING_TIME_LIMIT    CSG_T_SERVICE_ORDER_INFO.CORRESPONDING_TIME_LIMIT%TYPE,    --対応期限
  WORK_GROUP_ID               CSG_T_SERVICE_ORDER_INFO.WORK_GROUP_ID%TYPE,               --作業グループ
  WORK_MAIN_PERSON_ID         CSG_T_SERVICE_ORDER_INFO.WORK_MAIN_PERSON_ID%TYPE,         --作業主担当
  WORK_NAME                   CSG_T_SERVICE_ORDER_INFO.WORK_NAME%TYPE,                   --作業名
  WORK_OVERVIEW               CSG_T_SERVICE_ORDER_INFO.WORK_OVERVIEW%TYPE,               --作業概要
  SCHEDULED_START_DATE        CSG_T_SERVICE_ORDER_INFO.SCHEDULED_START_DATE%TYPE,        --開始予定日時
  SCHEDULED_END_DATE          CSG_T_SERVICE_ORDER_INFO.SCHEDULED_END_DATE%TYPE,          --終了予定日時
  ACTUAL_START_DATE           CSG_T_SERVICE_ORDER_INFO.ACTUAL_START_DATE%TYPE,           --開始日時(実績)
  ACTUAL_END_DATE             CSG_T_SERVICE_ORDER_INFO.ACTUAL_END_DATE%TYPE,             --終了日時(実績)
  SECONDARY_INVENTORY_NAME    CSG_T_SERVICE_ORDER_INFO.SECONDARY_INVENTORY_NAME%TYPE,    --委託先名
  SECONDARY_INVENTORY_PERSON  CSG_T_SERVICE_ORDER_INFO.SECONDARY_INVENTORY_PERSON%TYPE,  --委託先担当者
  SECONDARY_INVENTORY_TEL     CSG_T_SERVICE_ORDER_INFO.SECONDARY_INVENTORY_TEL%TYPE,     --委託先TEL
  SECONDARY_INVENTORY_MAIL    CSG_T_SERVICE_ORDER_INFO.SECONDARY_INVENTORY_MAIL%TYPE,    --委託先MAIL
  CLOSE_DATE                  CSG_T_SERVICE_ORDER_INFO.CLOSE_DATE%TYPE,                  --クローズ日時
  UPDATE_DATE                 CSG_T_SERVICE_ORDER_INFO.UPDATE_DATE%TYPE                  --更新日時
);

TYPE T_TASK_P_INFO_REC IS RECORD ( -- タスク情報
  SERVICE_ORDER_NO            CSG_T_TASK_INFO.SERVICE_ORDER_NO%TYPE,            --SO番号
  TASK_NO                     CSG_T_TASK_INFO.TASK_NO%TYPE,                     --タスク番号
  SERVICE_REQUEST_NO          CSG_T_TASK_INFO.SERVICE_REQUEST_NO%TYPE,          --SR番号
  TASK_STATUS                 CSG_T_TASK_INFO.TASK_STATUS%TYPE,                 --ステータス
  WORK_PERSON_ID              CSG_T_TASK_INFO.WORK_PERSON_ID%TYPE,              --担当者
  SCHEDULED_START_DATE        CSG_T_TASK_INFO.SCHEDULED_START_DATE%TYPE,        --開始予定日時
  SCHEDULED_END_DATE          CSG_T_TASK_INFO.SCHEDULED_END_DATE%TYPE,          --終了予定日時
  ACTUAL_START_DATE           CSG_T_TASK_INFO.ACTUAL_START_DATE%TYPE,           --実績開始日時
  ACTUAL_END_DATE             CSG_T_TASK_INFO.ACTUAL_END_DATE%TYPE,             --実績終了日時
  UPDATE_DATE                 CSG_T_TASK_INFO.UPDATE_DATE%TYPE                  --更新日時
);

TYPE T_TSR_INFO_REC IS RECORD ( -- 内部QA情報
  SERVICE_REQUEST_NO               CSG_T_TECH_SPRT_REQ_INFO.SERVICE_REQUEST_NO%TYPE,             --SR番号
  TECH_SUPPORT_REQUEST_NO          CSG_T_TECH_SPRT_REQ_INFO.TECH_SUPPORT_REQUEST_NO%TYPE,        --内部QA番号
  TECH_SUPPORT_REQUEST_TYPE_ID     CSG_T_TECH_SPRT_REQ_INFO.TECH_SUPPORT_REQUEST_TYPE_ID%TYPE,   --タイプ
  TECH_SUPPORT_REQUEST_STATUS      CSG_T_TECH_SPRT_REQ_INFO.TECH_SUPPORT_REQUEST_STATUS%TYPE,    --ステータス
  GROUP_ID                         CSG_T_TECH_SPRT_REQ_INFO.GROUP_ID%TYPE,                       --担当グループ
  PERSON_ID                        CSG_T_TECH_SPRT_REQ_INFO.PERSON_ID%TYPE,                      --担当者
  TECH_SPRT_REQ_CREATION_USER_ID   CSG_T_TECH_SPRT_REQ_INFO.TECH_SPRT_REQ_CREATION_USER_ID%TYPE, --作成者
  CORRESPONDING_TIME_LIMIT         CSG_T_TECH_SPRT_REQ_INFO.CORRESPONDING_TIME_LIMIT%TYPE,       --対応期限
  RECEIPT_DATE                     CSG_T_TECH_SPRT_REQ_INFO.RECEIPT_DATE%TYPE,                   --受付日時
  CALLER_COMPANY_NAME              CSG_T_TECH_SPRT_REQ_INFO.CALLER_COMPANY_NAME%TYPE,            --Caller会社名
  CALLER_DEPT_NAME                 CSG_T_TECH_SPRT_REQ_INFO.CALLER_DEPT_NAME%TYPE,               --Caller部署
  CALLER_CONTACTOR_PERSON          CSG_T_TECH_SPRT_REQ_INFO.CALLER_CONTACTOR_PERSON%TYPE,        --Caller担当者
  CALLER_TEL                       CSG_T_TECH_SPRT_REQ_INFO.CALLER_TEL%TYPE,                     --CallerTEL
  CALLER_FAX                       CSG_T_TECH_SPRT_REQ_INFO.CALLER_FAX%TYPE,                     --CallerFAX
  CALLER_MAIL_ADDRESS              CSG_T_TECH_SPRT_REQ_INFO.CALLER_MAIL_ADDRESS%TYPE,            --CallerE-Mail-To
  CALLER_MAIL_ADDRESS_CC           CSG_T_TECH_SPRT_REQ_INFO.CALLER_MAIL_ADDRESS_CC%TYPE,         --CallerE-Mail-Cc
  CALLER_EMPLOYEE                  CSG_T_TECH_SPRT_REQ_INFO.CALLER_EMPLOYEE%TYPE,                --Caller社員番号
  TITLE                            CSG_T_TECH_SPRT_REQ_INFO.TITLE%TYPE,                          --タイトル
  WORK_OVERVIEW                    CSG_T_TECH_SPRT_REQ_INFO.WORK_OVERVIEW%TYPE,                  --質問概要
  PRODUCT_ID                       CSG_T_TECH_SPRT_REQ_INFO.PRODUCT_ID%TYPE,                     --プロダクト
  CATEGORY1_ID                     CSG_T_TECH_SPRT_REQ_INFO.CATEGORY1_ID%TYPE,                   --カテゴリ１
  CATEGORY2_ID                     CSG_T_TECH_SPRT_REQ_INFO.CATEGORY2_ID%TYPE,                   --カテゴリ２
  CATEGORY3_ID                     CSG_T_TECH_SPRT_REQ_INFO.CATEGORY3_ID%TYPE,                   --カテゴリ３
  DIFFICULITY                      CSG_T_TECH_SPRT_REQ_INFO.DIFFICULITY%TYPE,                    --難易度
  ESCALATION_DESTINATION           CSG_T_TECH_SPRT_REQ_INFO.ESCALATION_DESTINATION%TYPE,         --エスカレーション先
  CASE_ID1                         CSG_T_TECH_SPRT_REQ_INFO.CASE_ID1%TYPE,                       --CASE　ID１
  CASE_ID2                         CSG_T_TECH_SPRT_REQ_INFO.CASE_ID2%TYPE,                       --CASE　ID２
  CASE_ID3                         CSG_T_TECH_SPRT_REQ_INFO.CASE_ID3%TYPE,                       --CASE　ID３
  CASE_ID4                         CSG_T_TECH_SPRT_REQ_INFO.CASE_ID4%TYPE,                       --CASE　ID４
  CASE_ID5                         CSG_T_TECH_SPRT_REQ_INFO.CASE_ID5%TYPE,                       --CASE　ID５
  SR_SEND_MAIL_FLAG                CSG_T_TECH_SPRT_REQ_INFO.SR_SEND_MAIL_FLAG%TYPE,              --通知済フラグ
  EXTERNAL_SYSTEM_ID               CSG_T_TECH_SPRT_REQ_INFO.EXTERNAL_SYSTEM_ID%TYPE,             --外部システム用ID
  CLOSE_DATE                       CSG_T_TECH_SPRT_REQ_INFO.CLOSE_DATE%TYPE,                     --クローズ日時
  UPDATE_DATE                      CSG_T_TECH_SPRT_REQ_INFO.UPDATE_DATE%TYPE                     --更新日時
);

TYPE T_NOTE_INFO_REC IS RECORD ( -- ノート情報
  SERVICE_REQUEST_NO               CSG_T_NOTE_INFO.SERVICE_REQUEST_NO%TYPE,         --SR番号
  NOTES                            CSG_T_NOTE_INFO.NOTES%TYPE                       --ノート
);

-----------------------------------------------------------------------------------
--  定数宣言
-----------------------------------------------------------------------------------

-- 追加・更新区分
ADD_UPD_DIV_ADD               CONSTANT VARCHAR2(2) := '0';  -- 追加
ADD_UPD_DIV_UPD_ALL           CONSTANT VARCHAR2(2) := '10'; -- 更新（全項目更新）
ADD_UPD_DIV_UPD_PRT           CONSTANT VARCHAR2(2) := '11'; -- 更新（一部更新）
ADD_UPD_DIV_UPD_RNW           CONSTANT VARCHAR2(2) := '12'; -- 更新（更新者・更新日時のみ更新）

-- 処理区分
PROC_DIV_INS                  CONSTANT VARCHAR2(1) := 'I';  -- 追加
PROC_DIV_DEL                  CONSTANT VARCHAR2(1) := 'D';  -- 削除

-- 更新区分
UPD_DIV_ADD                   CONSTANT VARCHAR2(2) := '0';  -- 追加
UPD_DIV_UPD_ALL               CONSTANT VARCHAR2(2) := '10'; -- 更新（全項目更新）
UPD_DIV_UPD_PRT               CONSTANT VARCHAR2(2) := '11'; -- 更新（一部更新）

-- 楽観ロック比較有無フラグ
LOCK_COM_FLG_NO_CMP           CONSTANT VARCHAR2(1) := 'N';  -- 楽観ロック比較なし
LOCK_COM_FLG_CMP              CONSTANT VARCHAR2(1) := 'Y';  -- 楽観ロック比較あり

-- 双方向関連付けフラグ
TWO_WAYS_LINKAGE_FLG_ONE_WAY  CONSTANT VARCHAR2(1) := 'N';  -- 関連SR情報のSR番号から関連SR番号に対してのみ、関連付けを行う。
TWO_WAYS_LINKAGE_FLG_TWO_WAYS CONSTANT VARCHAR2(1) := 'Y';  -- 関連SR情報のSR番号から関連SR番号、関連SR番号からSR番号 の双方向の関連付けの登録を行う

-- 終了コード
RESULT_CD_OK                  CONSTANT VARCHAR2(2) := '0';  -- 正常コード
RESULT_CD_WAR_EXC             CONSTANT VARCHAR2(2) := '10'; -- 警告コード(排他エラー)
RESULT_CD_WAR_SO_CLS          CONSTANT VARCHAR2(2) := '11'; -- 警告コード(サービスオーダークローズチェックエラー)
RESULT_CD_WAR_ITQA_CLS        CONSTANT VARCHAR2(2) := '12'; -- 警告コード(内部QAクローズチェックエラー)
RESULT_CD_WAR_ANS             CONSTANT VARCHAR2(2) := '13'; -- 警告コード(回答送信済チェックエラー)
RESULT_CD_ERR                 CONSTANT VARCHAR2(2) := '20'; -- 異常コード
RESULT_CD_ERR_LOCAL           CONSTANT VARCHAR2(2) := '99'; -- 異常コード(内部用)

-- リピートコール元判定
REPEAT_CALL_TARGET            CONSTANT VARCHAR2(1) := 'Y';  -- リピートコール元判定対象
REPEAT_CALL_NO_TARGET         CONSTANT VARCHAR2(1) := 'N';  -- リピートコール元判定対象外

--採番管理コード 取得キー
NUM_MNG_CD_CSG_SR             CONSTANT VARCHAR2(64) := 'NUM_MNG_CD_CSG_SR'; -- SR番号用

-- タスクステータス
TASK_STS_WRK_STT              CONSTANT VARCHAR2(15) := '11067'; -- 作業開始
TASK_STS_WRK_END              CONSTANT VARCHAR2(15) := '11071'; -- 作業終了

-- SOステータス
SO_STS_WRK_STT                CONSTANT VARCHAR2(15) := '11067'; -- 作業開始
SO_STS_WRK_END                CONSTANT VARCHAR2(15) := '11071'; -- 作業終了


-----------------------------------------------------------------------------------
--  DDL for Procedure CSG01_PROC_REGIST_SR サービス要求情報作成バッチ
-----------------------------------------------------------------------------------

TYPE T_RPTC_INFO IS RECORD ( -- リピートコール判定情報
  SR_NO CSG_T_SRVC_REQ_INFO.SERVICE_REQUEST_NO%TYPE    --SR番号
);

TYPE TB_RPTC_INFO IS TABLE OF T_RPTC_INFO INDEX BY BINARY_INTEGER;


SUBTYPE T_SRV_REQ_INFO IS CSG_T_SRVC_REQ_INFO%ROWTYPE; --サービス要求情報

/**
 * サービス要求情報作成処理
 *
 * パラメータで指定された情報を元に、サービス要求情報の作成、及び更新処理を行う。
 *
 * @param INPUT_ADD_UPD_DIV:追加・更新区分
 * @param INPUT_SERVICE_REQ_INFO:サービス要求情報
 * @param INPUT_LOGIN_USER_INFO:ログインユーザ情報
 * @param INPUT_UPD_PROGRAM_INFO:更新プログラム情報
 * @param INPUT_LOCK_COM_FLG:楽観ロック比較有無フラグ
 * @param RESULT_CD:終了コード
 * @param SR_NO:SR番号
 * @param UPDATE_DATE:更新日時
 */
PROCEDURE CSG01_PROC_REGIST_SR_INN (
    --追加・更新区分
    INPUT_ADD_UPD_DIV IN VARCHAR2 DEFAULT ADD_UPD_DIV_ADD,
    --サービス要求情報
    INPUT_SERVICE_REQ_INFO IN T_SERVICE_REQ_INFO_REC,
    --ログインユーザ情報
    INPUT_LOGIN_USER_INFO IN T_LOGIN_USER_INFO_REC,
    --更新プログラム情報
    INPUT_UPD_PROGRAM_INFO IN T_UPD_PROGRAM_INFO_REC,
    --楽観ロック比較有無フラグ
    INPUT_LOCK_COM_FLG IN VARCHAR2 DEFAULT LOCK_COM_FLG_NO_CMP,
    --終了コード
    RESULT_CD OUT VARCHAR2,
    --SR番号
    SR_NO OUT VARCHAR2,
    --更新日時
    UPDATE_DATE OUT DATE );

PROCEDURE GET_REPEAT_CALL_JUDGMENT (
    INSTANCE_ID IN VARCHAR2 DEFAULT 0,     --「サービス要求情報」のインスタンス番号
    RECEIPT_DATE IN DATE,                  --受付日時
    SYSTEM_DATE IN DATE,                   --「0.2.システム日時取得」で取得したシステム日時
    RESULT_CD OUT VARCHAR2,                --終了コード
    RPTC_INFO OUT TB_RPTC_INFO );          --リピートコール判定情報

PROCEDURE INS_SERVICE_REQ_INFO (
    SERVICE_REQ_INFO IN T_SERVICE_REQ_INFO_REC, --サービス要求情報
    SR_NO IN VARCHAR2,                      --SR番号
    REPEAT_CALL IN VARCHAR2,                --リピートコール
    SYSTEM_DATE IN DATE,                    --「0.2.システム日時取得」で取得したシステム日時
    UPD_PROGRAM_INFO IN T_UPD_PROGRAM_INFO_REC, --更新プログラム情報
    LOGIN_USER_INFO IN T_LOGIN_USER_INFO_REC,   --ログインユーザ情報
    RESULT_CD OUT VARCHAR2 );               --終了コード

PROCEDURE GET_SRV_REQ_INFO (
    SR_NO IN VARCHAR2,                --SR番号
    RESULT_CD OUT VARCHAR2,           --終了コード
    SRV_REQ_INFO OUT T_SRV_REQ_INFO ); --サービス要求情報

PROCEDURE GET_SR_STATUS (
    SR_STATUS IN VARCHAR2,               --SRステータス
    SYSTEM_DATE IN DATE,                 --「0.2.システム日時取得」で取得したシステム日時
    RESULT_CD OUT VARCHAR2,              --終了コード
    SR_STATUS_CLOSE_FLG OUT VARCHAR2,    --クローズフラグ
    SR_STATUS_CANCEL_STS OUT VARCHAR2 ); --キャンセルステータス

PROCEDURE GET_SRV_ORDER (
    SR_NO IN VARCHAR2,                --SR番号
    SYSTEM_DATE IN DATE,              --「0.2.システム日時取得」で取得したシステム日時
    RESULT_CD OUT VARCHAR2,           --終了コード
    NON_CLS_ODR_NUM OUT NUMBER );     --クローズされていないサービスオーダー数

PROCEDURE GET_INT_QA(
    SR_NO IN VARCHAR2,                --SR番号
    SYSTEM_DATE IN DATE,              --「0.2.システム日時取得」で取得したシステム日時
    RESULT_CD OUT VARCHAR2,           --終了コード
    NON_CLS_QA_NUM OUT NUMBER );      --クローズされていない内部QA数

PROCEDURE GET_ANS_STATUS (
    SR_NO IN VARCHAR2,                --SR番号
    RESULT_CD OUT VARCHAR2,           --終了コード
    ANSWER_STATUS OUT VARCHAR2);      --回答ステータス情報

PROCEDURE EDT_SRV_REQ_INFO (
    ADD_UPD_DIV IN VARCHAR2,                  --更新区分
    RED_SRV_REQ_INFO IN T_SRV_REQ_INFO,       --事前読み込みサービス要求情報
    INPUT_SRV_REQ_INFO IN T_SERVICE_REQ_INFO_REC, --入力パラメータの読み込みサービス要求情報
    SRV_REQ_INFO OUT T_SERVICE_REQ_INFO_REC );    --編集後、サービス要求情報

PROCEDURE UPD_SERVICE_REQ_INFO (
    SERVICE_REQ_INFO IN T_SERVICE_REQ_INFO_REC, --サービス要求情報
    SR_NO IN VARCHAR2,                      --SR番号
    SYSTEM_DATE IN DATE,                    --「0.2.システム日時取得」で取得したシステム日時
    UPD_PROGRAM_INFO IN T_UPD_PROGRAM_INFO_REC, --更新プログラム情報
    LOGIN_USER_INFO IN T_LOGIN_USER_INFO_REC,   --ログインユーザ情報
    RESULT_CD OUT VARCHAR2 );               --終了コード

PROCEDURE GET_RRT_TYPE (
    SYSTEM_DATE IN DATE,                    --「0.2.システム日時取得」で取得したシステム日時
    RESULT_CD OUT VARCHAR2,                 --終了コード
    LINK_TYPE_ID OUT CSG_T_LINK_SR_INFO.LINK_TYPE_ID%TYPE ); --関連タイプ

PROCEDURE EDT_SRV_REQ_INFO_HIS (
    ADD_UPD_DIV IN VARCHAR2,                  --更新区分
    SR_NO IN VARCHAR2,                        --SR番号
    RED_SRV_REQ_INFO IN T_SRV_REQ_INFO,       --事前読み込みサービス要求情報
    EDT_SRV_REQ_INFO IN T_SERVICE_REQ_INFO_REC,   --編集後、サービス要求情報
    SYSTEM_DATE IN DATE,                      --「0.2.システム日時取得」で取得したシステム日時
    RESULT_CD OUT VARCHAR2,                   --終了コード
    SR_HIS_ID OUT CSG_T_SRVC_REQ_INFO_HIS.SR_HIS_ID%TYPE,            --履歴ID
    HISTORY_NOTE OUT CSG_T_SRVC_REQ_INFO_HIS.HISTORY_NOTE%TYPE );    --変更内容

PROCEDURE INS_SRV_REQ_INFO_HIST (
    SR_NO IN VARCHAR2,                      --SR番号
    SR_HIS_ID IN CSG_T_SRVC_REQ_INFO_HIS.SR_HIS_ID%TYPE,             --履歴ID
    HISTORY_NOTE IN CSG_T_SRVC_REQ_INFO_HIS.HISTORY_NOTE%TYPE,       --変更内容
    SRV_REQ_INFO IN T_SERVICE_REQ_INFO_REC,     --編集後、サービス要求情報
    SYSTEM_DATE IN DATE,                    --「0.2.システム日時取得」で取得したシステム日時
    UPD_PROGRAM_INFO IN T_UPD_PROGRAM_INFO_REC, --更新プログラム情報
    LOGIN_USER_INFO IN T_LOGIN_USER_INFO_REC,   --ログインユーザ情報
    RESULT_CD OUT VARCHAR2 );               --終了コード

-----------------------------------------------------------------------------------
--  DDL for Procedure CSG01_PROC_REGIST_SR_RERATION 関連SR情報作成バッチ
-----------------------------------------------------------------------------------

SUBTYPE T_LINK_SR_INFO IS CSG_T_LINK_SR_INFO%ROWTYPE; --関連SR情報

/**
 * 関連SR情報作成処理
 *
 * パラメータで指定された情報を元に、関連SR情報の作成、及び削除処理(論理削除)を行う。
 *
 * @param INPUT_PROC_DIV:処理区分
 * @param INPUT_SR_RERATION_INFO:関連SR情報
 * @param INPUT_TWO_WAYS_LINKAGE_FLG:双方向関連付けフラグ
 * @param INPUT_LOGIN_USER_INFO:ログインユーザ情報
 * @param INPUT_UPD_PROGRAM_INFO:更新プログラム情報
 * @param INPUT_LOCK_COM_FLG:楽観ロック比較有無フラグ
 * @param RESULT_CD:終了コード
 * @param UPDATE_DATE:更新日時
 */
PROCEDURE CSG01_PROC_REGIST_SR_RERA_INN (
    --処理区分
    INPUT_PROC_DIV IN VARCHAR2,
    --関連SR情報
    INPUT_SR_RERATION_INFO IN T_SR_RERATION_INFO_REC,
    --双方向関連付けフラグ
    INPUT_TWO_WAYS_LINKAGE_FLG IN VARCHAR2,
    --ログインユーザ情報
    INPUT_LOGIN_USER_INFO IN T_LOGIN_USER_INFO_REC,
    --更新プログラム情報
    INPUT_UPD_PROGRAM_INFO IN T_UPD_PROGRAM_INFO_REC,
    --楽観ロック比較有無フラグ
    INPUT_LOCK_COM_FLG IN VARCHAR2 DEFAULT LOCK_COM_FLG_NO_CMP,
    --終了コード
    RESULT_CD OUT VARCHAR2,
    --更新日時
    UPDATE_DATE OUT DATE );

PROCEDURE GET_LINK_SR_INFO (
    SR_RERATION_INFO IN T_SR_RERATION_INFO_REC, --関連SR情報
    TWO_WAYS_LINKAGE_FLG IN VARCHAR2, --双方向関連付けフラグ
    RESULT_CD OUT VARCHAR2,           --終了コード
    LINK_NO_NUM OUT NUMBER );          --関連番号件数

PROCEDURE GET_LINK_SR_INFO (
    SR_RERATION_INFO IN T_SR_RERATION_INFO_REC, --関連SR情報
    TWO_WAYS_LINKAGE_FLG IN VARCHAR2, --双方向関連付けフラグ
    RESULT_CD OUT VARCHAR2,           --終了コード
    LINK_SR_UPDATE_DATE OUT CSG_T_LINK_SR_INFO.UPDATE_DATE%TYPE ); --更新日時

PROCEDURE INS_LINK_SR_INFO (
    SR_RERATION_INFO IN T_SR_RERATION_INFO_REC, --関連SR情報
    SYSTEM_DATE IN DATE,                    --「0.2.システム日時取得」で取得したシステム日時
    UPD_PROGRAM_INFO IN T_UPD_PROGRAM_INFO_REC, --更新プログラム情報
    LOGIN_USER_INFO IN T_LOGIN_USER_INFO_REC,   --ログインユーザ情報
    RESULT_CD OUT VARCHAR2 );                --終了コード

PROCEDURE GET_LINK_SR_INFO (
    SR_RERATION_INFO IN T_SR_RERATION_INFO_REC, --入力パラメータの関連SR情報
    RESULT_CD OUT VARCHAR2,                 --終了コード
    LINK_SR_INFO OUT T_LINK_SR_INFO );      --関連SR情報

PROCEDURE UPD_LINK_SR_INFO (
    SR_RERATION_INFO IN T_SR_RERATION_INFO_REC, --入力パラメータの関連SR情報
    SYSTEM_DATE IN DATE,                    --「0.2.システム日時取得」で取得したシステム日時
    UPD_PROGRAM_INFO IN T_UPD_PROGRAM_INFO_REC, --更新プログラム情報
    LOGIN_USER_INFO IN T_LOGIN_USER_INFO_REC,   --ログインユーザ情報
    RESULT_CD OUT VARCHAR2 );               --終了コード

-----------------------------------------------------------------------------------
--  DDL for Procedure CSG01_PROC_REGIST_QST 質問管理情報作成バッチ
-----------------------------------------------------------------------------------

SUBTYPE T_QUESTIONS IS CSG_T_QUESTIONS%ROWTYPE; --質問管理情報

/**
 * 質問管理情報作成処理
 *
 * パラメータで指定された情報を元に、質問情報の作成、及び更新を行う。
 *
 * @param INPUT_UPD_DIV:更新区分
 * @param INPUT_QST_CTL_INFO:質問管理情報
 * @param INPUT_BASE_INFO_DATE:基本情報更新日時
 * @param INPUT_LOGIN_USER_INFO:ログインユーザ情報
 * @param INPUT_UPD_PROGRAM_INFO:更新プログラム情報
 * @param INPUT_LOCK_COM_FLG:楽観ロック比較有無フラグ
 * @param RESULT_CD:終了コード
 * @param QST_UPDATE_DATE:質問管理情報更新日時
 * @param BASE_UPDATE_DATE:基本情報更新日時
 */
PROCEDURE CSG01_PROC_REGIST_QST_INN (
    --更新区分
    INPUT_UPD_DIV IN VARCHAR2,
    --質問管理情報
    INPUT_QST_CTL_INFO IN T_QST_CTL_INFO_REC,
    --基本情報更新日時
    INPUT_BASE_INFO_DATE IN DATE,
    --ログインユーザ情報
    INPUT_LOGIN_USER_INFO IN T_LOGIN_USER_INFO_REC,
    --更新プログラム情報
    INPUT_UPD_PROGRAM_INFO IN T_UPD_PROGRAM_INFO_REC,
    --楽観ロック比較有無フラグ
    INPUT_LOCK_COM_FLG IN VARCHAR2 DEFAULT LOCK_COM_FLG_NO_CMP,
    --終了コード
    RESULT_CD OUT VARCHAR2,
    --質問管理情報更新日時
    QST_UPDATE_DATE OUT DATE,
    --基本情報更新日時
    BASE_UPDATE_DATE OUT DATE );

PROCEDURE INS_QUESTIONS (
    REQUEST_ID IN CSG_T_QUESTIONS.REQUEST_ID%TYPE,   --質問ID
    QST_CTL_INFO IN T_QST_CTL_INFO_REC,                  --質問管理情報
    NO IN  CSG_T_QUESTIONS.NO%TYPE,                  --No
    SYSTEM_DATE IN DATE,                             --「0.2.システム日時取得」で取得したシステム日時
    UPD_PROGRAM_INFO IN T_UPD_PROGRAM_INFO_REC,          --更新プログラム情報
    LOGIN_USER_INFO IN T_LOGIN_USER_INFO_REC,            --ログインユーザ情報
    RESULT_CD OUT VARCHAR2 );                        --終了コード

PROCEDURE GET_QUESTIONS (
    QST_CTL_INFO IN T_QST_CTL_INFO_REC,           --入力パラメータ「質問管理情報」
    RESULT_CD OUT VARCHAR2,                   --終了コード
    QUESTIONS OUT T_QUESTIONS );              --質問管理情報

PROCEDURE EDT_QUESTIONS (
    INPUT_UPD_DIV IN VARCHAR2,                --入力パラメータ「更新区分」
    RED_QUESTIONS IN T_QUESTIONS,             --事前読み込み質問管理情報
    INPUT_QST_CTL_INFO IN T_QST_CTL_INFO_REC,     --入力パラメータ「質問管理情報」
    QUESTIONS OUT T_QUESTIONS );              --編集後、質問管理情報

PROCEDURE UPD_QUESTIONS (
    QUESTIONS IN T_QUESTIONS,                 --質問管理情報
    SYSTEM_DATE IN DATE,                      --「0.2.システム日時取得」で取得したシステム日時
    UPD_PROGRAM_INFO IN T_UPD_PROGRAM_INFO_REC,   --更新プログラム情報
    LOGIN_USER_INFO IN T_LOGIN_USER_INFO_REC,     --ログインユーザ情報
    RESULT_CD OUT VARCHAR2 );                 --終了コード

-----------------------------------------------------------------------------------
--  DDL for Procedure CSG01_PROC_REGIST_ANS 回答管理情報作成バッチ
-----------------------------------------------------------------------------------

SUBTYPE T_ANSWERS IS CSG_T_ANSWERS%ROWTYPE; --回答管理情報

/**
 * 回答管理情報作成処理
 *
 * パラメータで指定された情報を元に、回答情報の作成、及び更新を行う。
 *
 * @param INPUT_UPD_DIV:更新区分
 * @param INPUT_ANS_CTL_INFO:回答管理情報
 * @param INPUT_BASE_INFO_DATE:基本情報更新日時
 * @param INPUT_LOGIN_USER_INFO:ログインユーザ情報
 * @param INPUT_UPD_PROGRAM_INFO:更新プログラム情報
 * @param INPUT_LOCK_COM_FLG:楽観ロック比較有無フラグ
 * @param RESULT_CD:終了コード
 * @param ANS_UPDATE_DATE:回答管理情報更新日時
 * @param BASE_UPDATE_DATE:基本情報更新日時
 */
PROCEDURE CSG01_PROC_REGIST_ANS_INN (
    --更新区分
    INPUT_UPD_DIV IN VARCHAR2,
    --回答管理情報
    INPUT_ANS_CTL_INFO IN T_ANS_CTL_INFO_REC,
    --基本情報更新日時
    INPUT_BASE_INFO_DATE IN DATE,
    --ログインユーザ情報
    INPUT_LOGIN_USER_INFO IN T_LOGIN_USER_INFO_REC,
    --更新プログラム情報
    INPUT_UPD_PROGRAM_INFO IN T_UPD_PROGRAM_INFO_REC,
    --楽観ロック比較有無フラグ
    INPUT_LOCK_COM_FLG IN VARCHAR2 DEFAULT LOCK_COM_FLG_NO_CMP,
    --終了コード
    RESULT_CD OUT VARCHAR2,
    --回答管理情報更新日時
    ANS_UPDATE_DATE OUT DATE,
    --基本情報更新日時
    BASE_UPDATE_DATE OUT DATE );

PROCEDURE INS_ANSWERS (
    ANSWER_ID IN CSG_T_ANSWERS.ANSWER_ID%TYPE,   --回答ID
    ANS_CTL_INFO IN T_ANS_CTL_INFO_REC,              --回答管理情報
    NO IN  CSG_T_ANSWERS.NO%TYPE,                --No
    SYSTEM_DATE IN DATE,                         --「0.2.システム日時取得」で取得したシステム日時
    UPD_PROGRAM_INFO IN T_UPD_PROGRAM_INFO_REC,      --更新プログラム情報
    LOGIN_USER_INFO IN T_LOGIN_USER_INFO_REC,        --ログインユーザ情報
    RESULT_CD OUT VARCHAR2 );                    --終了コード

PROCEDURE GET_ANSWERS (
    ANS_CTL_INFO IN T_ANS_CTL_INFO_REC,           --入力パラメータ「回答管理情報」
    RESULT_CD OUT VARCHAR2,                   --終了コード
    ANSWERS OUT T_ANSWERS );                  --回答管理情報

PROCEDURE EDT_ANSWERS (
    INPUT_UPD_DIV IN VARCHAR2,                --入力パラメータ「更新区分」
    RED_ANSWERS IN T_ANSWERS,                 --事前読み込み回答管理情報
    INPUT_ANS_CTL_INFO IN T_ANS_CTL_INFO_REC,     --入力パラメータ「回答管理情報」
    ANSWERS OUT T_ANSWERS );                  --編集後、回答管理情報

PROCEDURE UPD_ANSWERS (
    ANSWERS IN T_ANSWERS,                    --回答管理情報
    SYSTEM_DATE IN DATE,                      --「0.2.システム日時取得」で取得したシステム日時
    UPD_PROGRAM_INFO IN T_UPD_PROGRAM_INFO_REC,   --更新プログラム情報
    LOGIN_USER_INFO IN T_LOGIN_USER_INFO_REC,     --ログインユーザ情報
    RESULT_CD OUT VARCHAR2 );                 --終了コード

-----------------------------------------------------------------------------------
--  DDL for Procedure CSG01_PROC_REGIST_SO サービスオーダー情報作成バッチ
-----------------------------------------------------------------------------------

SUBTYPE T_SERVICE_ORDER_INFO IS CSG_T_SERVICE_ORDER_INFO%ROWTYPE; --サービスオーダー情報

/**
 * サービスオーダー情報作成処理
 *
 * パラメータで指定された情報を元に、サービスオーダー情報の作成、及び更新を行う。
 *
 * @param INPUT_UPD_DIV:更新区分
 * @param INPUT_SO_INFO:サービスオーダー情報
 * @param INPUT_LOGIN_USER_INFO:ログインユーザ情報
 * @param INPUT_UPD_PROGRAM_INFO:更新プログラム情報
 * @param INPUT_LOCK_COM_FLG:楽観ロック比較有無フラグ
 * @param RESULT_CD:終了コード
 * @param SERVICE_ORDER_NO:SO番号
 * @param UPDATE_DATE:更新日時
 */
PROCEDURE CSG01_PROC_REGIST_SO_INN (
    --更新区分
    INPUT_UPD_DIV IN VARCHAR2,
    --サービスオーダー情報
    INPUT_SO_INFO IN T_SO_INFO_REC,
    --ログインユーザ情報
    INPUT_LOGIN_USER_INFO IN T_LOGIN_USER_INFO_REC,
    --更新プログラム情報
    INPUT_UPD_PROGRAM_INFO IN T_UPD_PROGRAM_INFO_REC,
    --楽観ロック比較有無フラグ
    INPUT_LOCK_COM_FLG IN VARCHAR2 DEFAULT LOCK_COM_FLG_NO_CMP,
    --終了コード
    RESULT_CD OUT VARCHAR2,
    --SO番号
    SERVICE_ORDER_NO OUT CSG_T_SERVICE_ORDER_INFO.SERVICE_ORDER_NO%TYPE,
    --更新日時
    UPDATE_DATE OUT DATE );

PROCEDURE GET_SO_NO (
    SR_NO IN    CSG_T_SERVICE_ORDER_INFO.SERVICE_REQUEST_NO%TYPE,      --入力パラメータのSR番号
    SO_NO_MAX OUT   CSG_T_SERVICE_ORDER_INFO.SERVICE_ORDER_NO%TYPE,    --SO番号最大
    RESULT_CD OUT VARCHAR2 );                                          --終了コード

PROCEDURE INS_SO_INFO (
    SO_NO IN CSG_T_SERVICE_ORDER_INFO.SERVICE_ORDER_NO%TYPE,    --SO番号
    SO_INFO IN T_SO_INFO_REC,                          --入力パラメータ「サービスオーダー情報」
    SYSTEM_DATE IN DATE,                           --「0.2.システム日時取得」で取得したシステム日時
    UPD_PROGRAM_INFO IN T_UPD_PROGRAM_INFO_REC,        --更新プログラム情報
    LOGIN_USER_INFO IN T_LOGIN_USER_INFO_REC,          --ログインユーザ情報
    EDT_SO_INFO OUT T_SERVICE_ORDER_INFO,          --編集後、サービスオーダー情報
    RESULT_CD OUT VARCHAR2 );                      --終了コード


PROCEDURE GET_SO_INFO (
    SO_INFO IN T_SO_INFO_REC,                          --入力パラメータ「サービスオーダー情報」
    RESULT_CD OUT VARCHAR2,                        --終了コード
    SERVICE_ORDER_INFO OUT T_SERVICE_ORDER_INFO ); --サービスオーダー情報


PROCEDURE EDT_SO_INFO (
    INPUT_UPD_DIV IN VARCHAR2,              --入力パラメータ「更新区分」
    RED_SO_INFO IN T_SERVICE_ORDER_INFO,    --事前読み込みサービスオーダー情報
    INPUT_SO_INFO IN T_SO_INFO_REC,             --入力パラメータ「サービスオーダー情報」
    SO_INFO OUT T_SERVICE_ORDER_INFO );     --編集後、サービスオーダー情報


PROCEDURE UPD_SO_INF (
    SO_INFO IN T_SERVICE_ORDER_INFO,          --サービスオーダー情報
    SYSTEM_DATE IN DATE,                      --「0.2.システム日時取得」で取得したシステム日時
    UPD_PROGRAM_INFO IN T_UPD_PROGRAM_INFO_REC,   --更新プログラム情報
    LOGIN_USER_INFO IN T_LOGIN_USER_INFO_REC,     --ログインユーザ情報
    RESULT_CD OUT VARCHAR2 );                 --終了コード


PROCEDURE EDT_SO_INFO_HIS (
    UPD_DIV IN VARCHAR2,                      --更新区分
    SO_NO IN VARCHAR2,                        --SO番号
    RED_SO_INFO_INFO IN T_SERVICE_ORDER_INFO, --事前読み込みサービスオーダー情報
    SO_INFO IN T_SERVICE_ORDER_INFO,          --編集後、サービスオーダー情報
    SYSTEM_DATE IN DATE,                      --「0.2.システム日時取得」で取得したシステム日時
    RESULT_CD OUT VARCHAR2,                   --終了コード
    SO_HIS_ID OUT CSG_T_SRVC_OD_INFO_HIS.SO_HIS_ID%TYPE,           --履歴ID
    HISTORY_NOTE OUT CSG_T_SRVC_OD_INFO_HIS.HISTORY_NOTE%TYPE );   --変更内容

PROCEDURE INS_SO_INFO_HIST (
    SO_NO IN VARCHAR2,                       --SO番号
    SO_HIS_ID IN CSG_T_SRVC_OD_INFO_HIS.SO_HIS_ID%TYPE,           --履歴ID
    HISTORY_NOTE IN CSG_T_SRVC_OD_INFO_HIS.HISTORY_NOTE%TYPE,     --変更内容
    SO_INFO IN T_SERVICE_ORDER_INFO,        --編集後、サービスオーダー情報
    SYSTEM_DATE IN DATE,                    --「0.2.システム日時取得」で取得したシステム日時
    UPD_PROGRAM_INFO IN T_UPD_PROGRAM_INFO_REC, --更新プログラム情報
    LOGIN_USER_INFO IN T_LOGIN_USER_INFO_REC,   --ログインユーザ情報
    RESULT_CD OUT VARCHAR2 );               --終了コード

-----------------------------------------------------------------------------------
--  DDL for Procedure CSG01_PROC_REGIST_TASK タスク情報作成バッチ
-----------------------------------------------------------------------------------

SUBTYPE T_TASK_INFO IS CSG_T_TASK_INFO%ROWTYPE; --タスク情報

/**
 * タスク情報作成処理
 *
 * パラメータで指定された情報を元に、タスク情報の作成、及び更新を行う。
 *
 * @param INPUT_ADD_UPD_DIV:追加・更新区分
 * @param INPUT_TASK_INFO:タスク情報
 * @param INPUT_LOGIN_USER_INFO:ログインユーザ情報
 * @param INPUT_UPD_PROGRAM_INFO:更新プログラム情報
 * @param INPUT_LOCK_COM_FLG:楽観ロック比較有無フラグ
 * @param RESULT_CD:終了コード
 * @param TASK_NO:タスク番号
 * @param UPDATE_DATE:更新日時
 */
PROCEDURE CSG01_PROC_REGIST_TASK_INN (
    --追加・更新区分
    INPUT_ADD_UPD_DIV IN VARCHAR2 DEFAULT ADD_UPD_DIV_ADD,
    --タスク情報
    INPUT_TASK_INFO IN T_TASK_P_INFO_REC,
    --ログインユーザ情報
    INPUT_LOGIN_USER_INFO IN T_LOGIN_USER_INFO_REC,
    --更新プログラム情報
    INPUT_UPD_PROGRAM_INFO IN T_UPD_PROGRAM_INFO_REC,
    --楽観ロック比較有無フラグ
    INPUT_LOCK_COM_FLG IN VARCHAR2 DEFAULT LOCK_COM_FLG_NO_CMP,
    --終了コード
    RESULT_CD OUT VARCHAR2,
    --タスク番号
    TASK_NO OUT CSG_T_TASK_INFO.TASK_NO%TYPE,
    --更新日時
    UPDATE_DATE OUT DATE );

PROCEDURE INS_TASK_INFO (
    TASK_NO IN CSG_T_TASK_INFO.TASK_NO%TYPE,       --タスク番号
    TASK_INFO IN T_TASK_P_INFO_REC,                    --入力パラメータ「タスク情報」
    SYSTEM_DATE IN DATE,                           --「0.2.システム日時取得」で取得したシステム日時
    UPD_PROGRAM_INFO IN T_UPD_PROGRAM_INFO_REC,        --更新プログラム情報
    LOGIN_USER_INFO IN T_LOGIN_USER_INFO_REC,          --ログインユーザ情報
    EDT_TASK_INFO OUT T_TASK_INFO,                 --編集後、タスク情報
    RESULT_CD OUT VARCHAR2 );                      --終了コード


PROCEDURE GET_TASK_INFO (
    TASK_INFO IN T_TASK_P_INFO_REC,                    --入力パラメータ「タスク情報」
    RESULT_CD OUT VARCHAR2,                        --終了コード
    RED_TASK_INFO OUT T_TASK_INFO );               --タスク情報

PROCEDURE EDT_TASK_INFO (
    INPUT_ADD_UPD_DIV IN VARCHAR2,          --入力パラメータ「追加・更新区分」
    RED_TASK_INFO IN T_TASK_INFO,           --事前読み込みタスク情報
    INPUT_TASK_INFO IN T_TASK_P_INFO_REC,   --入力パラメータ「タスク情報」
    EDT_TASK_INFO OUT T_TASK_INFO );        --編集後、タスク情報


PROCEDURE UPD_TASK_INF (
    EDT_TASK_INFO IN T_TASK_INFO,                 --タスク情報
    SYSTEM_DATE IN DATE,                          --「0.2.システム日時取得」で取得したシステム日時
    UPD_PROGRAM_INFO IN T_UPD_PROGRAM_INFO_REC,   --更新プログラム情報
    LOGIN_USER_INFO IN T_LOGIN_USER_INFO_REC,     --ログインユーザ情報
    RESULT_CD OUT VARCHAR2 );                     --終了コード


PROCEDURE EDT_TASK_INFO_HIS (
    INPUT_ADD_UPD_DIV IN VARCHAR2,            --入力パラメータ「追加・更新区分」
    RED_TASK_INFO IN T_TASK_INFO,             --事前読み込みタスク情報
    EDT_TASK_INFO IN T_TASK_INFO,             --編集後、タスク情報
    SYSTEM_DATE IN DATE,                      --「0.2.システム日時取得」で取得したシステム日時
    RESULT_CD OUT VARCHAR2,                   --終了コード
    TASK_HIS_ID OUT   CSG_T_TASK_INFO_HIS.TASK_HIS_ID%TYPE,         --履歴ID
    HISTORY_NOTE OUT  CSG_T_TASK_INFO_HIS.HISTORY_NOTE%TYPE );      --変更内容


PROCEDURE INS_TASK_INFO_HIST (
    TASK_NO IN       CSG_T_TASK_INFO.TASK_NO%TYPE,                 --タスク番号
    TASK_HIS_ID IN   CSG_T_TASK_INFO_HIS.TASK_HIS_ID%TYPE,         --履歴ID
    HISTORY_NOTE IN  CSG_T_TASK_INFO_HIS.HISTORY_NOTE%TYPE,        --変更内容
    EDT_TASK_INFO IN T_TASK_INFO,           --編集後、タスク情報
    SYSTEM_DATE IN DATE,                    --「0.2.システム日時取得」で取得したシステム日時
    UPD_PROGRAM_INFO IN T_UPD_PROGRAM_INFO_REC, --更新プログラム情報
    LOGIN_USER_INFO IN T_LOGIN_USER_INFO_REC,   --ログインユーザ情報
    RESULT_CD OUT VARCHAR2 );               --終了コード

-----------------------------------------------------------------------------------
--  DDL for Procedure CSG01_PROC_REGIST_TSR 内部QA作成バッチ
-----------------------------------------------------------------------------------

SUBTYPE T_TECH_SPRT_REQ_INFO IS CSG_T_TECH_SPRT_REQ_INFO%ROWTYPE; --内部QA情報

/**
 * 内部QA作成処理
 *
 * パラメータで指定された情報を元に、内部QA情報の作成、及び更新処理を行う。
 *
 * @param INPUT_UPD_DIV:更新区分
 * @param INPUT_TSR_INFO:内部QA情報
 * @param INPUT_LOGIN_USER_INFO:ログインユーザ情報
 * @param INPUT_UPD_PROGRAM_INFO:更新プログラム情報
 * @param INPUT_LOCK_COM_FLG:楽観ロック比較有無フラグ
 * @param RESULT_CD:終了コード
 * @param TECH_SUPPORT_REQUEST_NO:内部QA番号
 * @param UPDATE_DATE:更新日時
 */
PROCEDURE CSG01_PROC_REGIST_TSR_INN (
    --更新区分
    INPUT_UPD_DIV IN VARCHAR2,
    --内部QA情報
    INPUT_TSR_INFO IN T_TSR_INFO_REC,
    --ログインユーザ情報
    INPUT_LOGIN_USER_INFO IN T_LOGIN_USER_INFO_REC,
    --更新プログラム情報
    INPUT_UPD_PROGRAM_INFO IN T_UPD_PROGRAM_INFO_REC,
    --楽観ロック比較有無フラグ
    INPUT_LOCK_COM_FLG IN VARCHAR2 DEFAULT LOCK_COM_FLG_NO_CMP,
    --終了コード
    RESULT_CD OUT VARCHAR2,
    --内部QA番号
    TECH_SUPPORT_REQUEST_NO OUT CSG_T_TECH_SPRT_REQ_INFO.TECH_SUPPORT_REQUEST_NO%TYPE,
    --更新日時
    UPDATE_DATE OUT DATE );

PROCEDURE INS_TSR_INFO (
    TECH_SUPPORT_REQUEST_NO IN CSG_T_TECH_SPRT_REQ_INFO.TECH_SUPPORT_REQUEST_NO%TYPE, --内部QA番号
    INPUT_TSR_INFO IN T_TSR_INFO_REC,                  --入力パラメータ「内部QA情報」
    SYSTEM_DATE IN DATE,                           --「0.2.システム日時取得」で取得したシステム日時
    UPD_PROGRAM_INFO IN T_UPD_PROGRAM_INFO_REC,        --更新プログラム情報
    LOGIN_USER_INFO IN T_LOGIN_USER_INFO_REC,          --ログインユーザ情報
    EDT_TSR_INFO OUT T_TECH_SPRT_REQ_INFO,         --編集後、内部QA情報
    RESULT_CD OUT VARCHAR2 );                      --終了コード

PROCEDURE GET_TSR_INFO (
    INPUT_TSR_INFO IN T_TSR_INFO_REC,                  --入力パラメータ「内部QA情報」
    RESULT_CD OUT VARCHAR2,                        --終了コード
    RED_TSR_INFO OUT T_TECH_SPRT_REQ_INFO );       --内部QA情報

PROCEDURE EDT_TSR_INFO (
    INPUT_UPD_DIV IN VARCHAR2,               --入力パラメータ「更新区分」
    RED_TSR_INFO IN T_TECH_SPRT_REQ_INFO,    --事前読み込み内部QA情報
    INPUT_TSR_INFO IN T_TSR_INFO_REC,            --入力パラメータ「内部QA情報」
    EDT_TSR_INFO OUT T_TECH_SPRT_REQ_INFO ); --編集後、内部QA情報

PROCEDURE UPD_TSR_INF (
    EDT_TSR_INFO IN T_TECH_SPRT_REQ_INFO,     --編集後、内部QA情報
    SYSTEM_DATE IN DATE,                      --「0.2.システム日時取得」で取得したシステム日時
    UPD_PROGRAM_INFO IN T_UPD_PROGRAM_INFO_REC,   --更新プログラム情報
    LOGIN_USER_INFO IN T_LOGIN_USER_INFO_REC,     --ログインユーザ情報
    RESULT_CD OUT VARCHAR2 );                 --終了コード

PROCEDURE EDT_TSR_INFO_HIS (
    UPD_DIV IN VARCHAR2,                      --更新区分
    TECH_SUPPORT_REQUEST_NO IN CSG_T_TECH_SPRT_REQ_INFO.TECH_SUPPORT_REQUEST_NO%TYPE,                --内部QA番号
    RED_TSR_INFO IN T_TECH_SPRT_REQ_INFO,     --事前読み込み内部QA情報
    EDT_TSR_INFO IN T_TECH_SPRT_REQ_INFO,     --編集後、内部QA情報
    SYSTEM_DATE IN DATE,                      --「0.2.システム日時取得」で取得したシステム日時
    RESULT_CD OUT VARCHAR2,                   --終了コード
    TECH_SUPPORT_REQUEST_HIS_ID OUT  CSG_T_TSR_INFO_HIS.TECH_SUPPORT_REQUEST_HIS_ID%TYPE,   --履歴ID
    HISTORY_NOTE OUT CSG_T_TSR_INFO_HIS.HISTORY_NOTE%TYPE );                                --変更内容

PROCEDURE INS_SO_INFO_HIST (
    TECH_SUPPORT_REQUEST_NO IN CSG_T_TECH_SPRT_REQ_INFO.TECH_SUPPORT_REQUEST_NO%TYPE,                --内部QA番号
    TECH_SUPPORT_REQUEST_HIS_ID IN  CSG_T_TSR_INFO_HIS.TECH_SUPPORT_REQUEST_HIS_ID%TYPE,   --履歴ID
    HISTORY_NOTE IN CSG_T_TSR_INFO_HIS.HISTORY_NOTE%TYPE,                                  --変更内容
    EDT_TSR_INFO IN T_TECH_SPRT_REQ_INFO,   --編集後、内部QA情報
    SYSTEM_DATE IN DATE,                    --「0.2.システム日時取得」で取得したシステム日時
    UPD_PROGRAM_INFO IN T_UPD_PROGRAM_INFO_REC, --更新プログラム情報
    LOGIN_USER_INFO IN T_LOGIN_USER_INFO_REC,   --ログインユーザ情報
    RESULT_CD OUT VARCHAR2 );               --終了コード

-----------------------------------------------------------------------------------
--  DDL for Procedure CSG01_PROC_REGIST_NOTE ノート情報作成バッチ
-----------------------------------------------------------------------------------

/**
 * ノート情報作成処理
 *
 * パラメータで指定された情報を元に、ノート情報の作成処理を行う。
 *
 * @param INPUT_NOTE_INFO:ノート情報
 * @param INPUT_LOGIN_USER_INFO:ログインユーザ情報
 * @param INPUT_UPD_PROGRAM_INFO:更新プログラム情報
 * @param RESULT_CD:終了コード
 * @param UPDATE_DATE:更新日時
 */
PROCEDURE CSG01_PROC_REGIST_NOTE_INN (
    --ノート情報
    INPUT_NOTE_INFO IN T_NOTE_INFO_REC,
    --ログインユーザ情報
    INPUT_LOGIN_USER_INFO IN T_LOGIN_USER_INFO_REC,
    --更新プログラム情報
    INPUT_UPD_PROGRAM_INFO IN T_UPD_PROGRAM_INFO_REC,
    --終了コード
    RESULT_CD OUT VARCHAR2,
    --更新日時
    UPDATE_DATE OUT DATE );

PROCEDURE CALNOTE_NO (
    NOTE_INFO IN T_NOTE_INFO_REC,                    --ノート情報
    NO OUT CSG_T_NOTE_INFO.NO%TYPE,              --NO
    RESULT_CD OUT VARCHAR2 ) ;                   --終了コード

PROCEDURE INS_NOTE_INFO (
    NOTE_INFO IN T_NOTE_INFO_REC,                    --ノート情報
    NO IN  CSG_T_NOTE_INFO.NO%TYPE,                --No
    SYSTEM_DATE IN DATE,                         --「0.2.システム日時取得」で取得したシステム日時
    UPD_PROGRAM_INFO IN T_UPD_PROGRAM_INFO_REC,      --更新プログラム情報
    LOGIN_USER_INFO IN T_LOGIN_USER_INFO_REC,        --ログインユーザ情報
    RESULT_CD OUT VARCHAR2 );                    --終了コード

-----------------------------------------------------------------------------------
--  DDL for Procedure CSG01_PROC_CREATE_SR_INFO サービス要求受付登録ラッピングバッチ
-----------------------------------------------------------------------------------

/**
 * サービス要求受付登録ラッピング処理
 *
 * パラメータで指定された情報を元に、以下の情報の作成、及び更新を行う。
 * ・サービス要求情報
 * ・関連SR情報
 *
 * @param INPUT_SERVICE_REQ_INFO:サービス要求情報
 * @param INPUT_SR_RERATION_INFO:関連SR情報
 * @param INPUT_LOGIN_USER_INFO:ログインユーザ情報
 * @param INPUT_UPD_PROGRAM_INFO:更新プログラム情報
 * @param RESULT_CD:終了コード
 * @param SR_NO:SR番号
 * @param SR_UPDATE_DATE:サービス要求更新日時
 * @param SR_RRT_UPDATE_DATE:関連SR更新日時
 */
PROCEDURE CSG01_PROC_CREATE_SR_INFO_INN (
    --サービス要求情報
    INPUT_SERVICE_REQ_INFO IN T_SERVICE_REQ_INFO_REC,
    --関連SR情報
    INPUT_SR_RERATION_INFO IN T_SR_RERATION_INFO_REC,
    --ログインユーザ情報
    INPUT_LOGIN_USER_INFO IN T_LOGIN_USER_INFO_REC,
    --更新プログラム情報
    INPUT_UPD_PROGRAM_INFO IN T_UPD_PROGRAM_INFO_REC,
    --終了コード
    RESULT_CD OUT VARCHAR2,
    --SR番号
    SR_NO OUT VARCHAR2,
    --サービス要求更新日時
    SR_UPDATE_DATE OUT DATE,
    --関連SR更新日時
    SR_RRT_UPDATE_DATE OUT DATE );

-----------------------------------------------------------------------------------
--  DDL for Procedure CSG01_PROC_CREATE_TASK_INFO タスク登録ラッピングバッチ
-----------------------------------------------------------------------------------

TYPE T_TASK_CRE_INFO IS RECORD ( -- タスク情報(タスク登録ラッピング)
  SCHEDULED_START_DATE        CSG_T_TASK_INFO.SCHEDULED_START_DATE%TYPE,        --開始予定日時
  SCHEDULED_END_DATE          CSG_T_TASK_INFO.SCHEDULED_END_DATE%TYPE,          --終了予定日時
  ACTUAL_START_DATE           CSG_T_TASK_INFO.ACTUAL_START_DATE%TYPE,           --実績開始日時
  ACTUAL_END_DATE             CSG_T_TASK_INFO.ACTUAL_END_DATE%TYPE,             --実績終了日時
  TASK_STATUS                 CSG_T_TASK_INFO.TASK_STATUS%TYPE,                 --ステータス
  WORK_PERSON_ID              CSG_T_TASK_INFO.WORK_PERSON_ID%TYPE               --担当者
);

TYPE TB_TASK_CRE_INFO IS TABLE OF T_TASK_CRE_INFO INDEX BY BINARY_INTEGER;

/**
 * タスク登録ラッピング処理
 *
 * パラメータで指定された情報を元に、以下の情報の作成、及び更新を行う。
 * ・タスク情報
 * ・サービスオーダー情報
 *
 * @param INPUT_SO_INFO:サービスオーダー情報
 * @param INPUT_TASK_INFO:タスク情報
 * @param INPUT_LOGIN_USER_INFO:ログインユーザ情報
 * @param INPUT_UPD_PROGRAM_INFO:更新プログラム情報
 * @param RESULT_CD:終了コード
 * @param TASK_NO:タスク番号
 * @param SERVICE_ORDER_NO:SO番号
 * @param TASK_UPDATE_DATE:タスク情報更新日時
 * @param SO_UPDATE_DATE:サービスオーダー情報更新日時
 */
PROCEDURE CSG01_PROC_CREATE_TASK_INFO_I (
    --サービスオーダー情報
    INPUT_SO_INFO IN T_SO_INFO_REC,
    --タスク情報
    INPUT_TASK_INFO IN T_TASK_P_INFO_REC,
    --ログインユーザ情報
    INPUT_LOGIN_USER_INFO IN T_LOGIN_USER_INFO_REC,
    --更新プログラム情報
    INPUT_UPD_PROGRAM_INFO IN T_UPD_PROGRAM_INFO_REC,
    --終了コード
    RESULT_CD OUT VARCHAR2,
    --タスク番号
    TASK_NO OUT CSG_T_TASK_INFO.TASK_NO%TYPE,
    --SO番号
    SERVICE_ORDER_NO OUT  CSG_T_SERVICE_ORDER_INFO.SERVICE_ORDER_NO%TYPE,
    --タスク情報更新日時
    TASK_UPDATE_DATE OUT DATE,
    --サービスオーダー情報更新日時
    SO_UPDATE_DATE OUT DATE );

PROCEDURE GET_COUNT_TASK_INFO (
    SERVICE_ORDER_NO IN CSG_T_SERVICE_ORDER_INFO.SERVICE_ORDER_NO%TYPE,  --入力パラメータ「タスク情報」のSO番号
    RESULT_CD OUT VARCHAR2,                                              --終了コード
    RED_TASK_CRE_INFO OUT TB_TASK_CRE_INFO );                            --タスク情報

PROCEDURE GET_TASK_INFO (
    TASK_NO          IN CSG_T_TASK_INFO.TASK_NO%TYPE,                    --タスク番号
    RESULT_CD OUT VARCHAR2,                                              --終了コード
    RED_TASK_CRE_INFO OUT T_TASK_INFO );                                 --タスク情報

PROCEDURE EDT_SO_INFO_UPD_DATA (
    INPUT_SO_INFO IN T_SO_INFO_REC,             --入力パラメータ「サービスオーダー情報」
    RED_COUNT_TASK_INFO IN TB_TASK_CRE_INFO,    --タスク情報テーブルから抽出したレコード
    RED_TASK_INFO IN T_TASK_INFO,               --タスク情報
    EDT_SO_INFO OUT T_SO_INFO_REC );            --編集後、サービスオーダー情報


FUNCTION EDT_HISTORY_NOTE (
    NI_UPD IN NUMBER,                  --重要項目以外が更新フラグ(1:更新あり)
    I_UPD IN NUMBER,                   --重要項目が更新フラグ(1:更新あり)
    NAME IN VARCHAR2,                  --変更対象の項目名
    BEFORE IN VARCHAR2,                --変更前の設定値
    AFTER IN VARCHAR2                  --変更後の設定値
)
/* 戻り値の定義 */
RETURN VARCHAR2;                       --設定内容

FUNCTION CMP_CHK (
    BEFORE IN VARCHAR2,                --変更前の設定値
    AFTER  IN VARCHAR2                 --変更後の設定値
)
/* 戻り値の定義 */
RETURN NUMBER;                         --比較結果 0:同じ 1:異なる

FUNCTION CMP_CHK (
    BEFORE IN NUMBER,                  --変更前の設定値
    AFTER  IN NUMBER                   --変更後の設定値
)
/* 戻り値の定義 */
RETURN NUMBER;                         --比較結果 0:同じ 1:異なる

FUNCTION CMP_CHK (
    BEFORE IN DATE,                    --変更前の設定値
    AFTER  IN DATE                     --変更後の設定値
)
/* 戻り値の定義 */
RETURN NUMBER;                         --比較結果 0:同じ 1:異なる

PROCEDURE GET_PROPERTY (
    INPUT_CD_VAL IN VARCHAR2,           --コード値
    SYSTEM_DATE IN DATE,                --「0.2.システム日時取得」で取得したシステム日時
    RESULT_CD OUT VARCHAR2,             --終了コード
    MNG_CD OUT VARCHAR2 );              --採番管理コード

PROCEDURE GET_IMPORTANCE_LEVEL_NAME (
    CD_VAL IN VARCHAR2,                     --コード値
    SYSTEM_DATE IN DATE,                    --「0.2.システム日時取得」で取得したシステム日時
    RESULT_CD OUT VARCHAR2,                 --終了コード
    NAME OUT VARCHAR2 );                    --名称

PROCEDURE GET_GROUP_NAME (
    GROUP_ID IN NUMBER,                     --グループID
    SYSTEM_DATE IN DATE,                    --「0.2.システム日時取得」で取得したシステム日時
    RESULT_CD OUT VARCHAR2,                 --終了コード
    NAME OUT VARCHAR2 );                    --名称

PROCEDURE GET_PERSON_NAME (
    EMP_CD IN NUMBER,                       --従業員ID
    SYSTEM_DATE IN DATE,                    --「0.2.システム日時取得」で取得したシステム日時
    RESULT_CD OUT VARCHAR2,                 --終了コード
    NAME OUT VARCHAR2 );                    --名称

PROCEDURE GET_PERSON_NAME (
    EMP_CD IN VARCHAR2,                     --従業員ID
    SYSTEM_DATE IN DATE,                    --「0.2.システム日時取得」で取得したシステム日時
    RESULT_CD OUT VARCHAR2,                 --終了コード
    NAME OUT VARCHAR2 );                    --名称

PROCEDURE GET_SO_STATUS_NAME (
    CD_VAL IN VARCHAR2,                     --コード値
    SYSTEM_DATE IN DATE,                    --「0.2.システム日時取得」で取得したシステム日時
    RESULT_CD OUT VARCHAR2,                 --終了コード
    NAME OUT VARCHAR2 );                    --名称

PROCEDURE GET_TASK_STATUS_NAME (
    CD_VAL IN VARCHAR2,                     --コード値
    SYSTEM_DATE IN DATE,                    --「0.2.システム日時取得」で取得したシステム日時
    RESULT_CD OUT VARCHAR2,                 --終了コード
    NAME OUT VARCHAR2 );                    --名称

PROCEDURE GET_INTERNAL_QA_STATUS_NAME (
    CD_VAL IN VARCHAR2,                     --コード値
    SYSTEM_DATE IN DATE,                    --「0.2.システム日時取得」で取得したシステム日時
    RESULT_CD OUT VARCHAR2,                 --終了コード
    NAME OUT VARCHAR2 );                    --名称

PROCEDURE GET_SR_STATUS_NAME (
    CD_VAL IN VARCHAR2,                     --コード値
    SYSTEM_DATE IN DATE,                    --「0.2.システム日時取得」で取得したシステム日時
    RESULT_CD OUT VARCHAR2,                 --終了コード
    NAME OUT VARCHAR2 );                    --名称

PROCEDURE PUT_LOG (
    INPUT_MSG_ID IN VARCHAR2,           --エラーメッセージ
    PLACE_HOLDER1 IN VARCHAR2,          --プレースホルダ1
    PLACE_HOLDER2 IN VARCHAR2,          --プレースホルダ2
    PLACE_HOLDER3 IN VARCHAR2 );        --プレースホルダ3

PROCEDURE DEBUG_LOG (
    INPUT_MSG     IN VARCHAR2 );        --メッセージ


-- エラーメッセージ　プレースホルダー
PH1_PROV_DIV                  CONSTANT VARCHAR2(64) := '処理区分';
PH2_PROV_DIV                  CONSTANT VARCHAR2(64) := q'<'I'、'D'>';
PH1_TWO_WAYS_LINKAGE_FLG      CONSTANT VARCHAR2(64) := '双方向関連付けフラグ';
PH2_TWO_WAYS_LINKAGE_FLG      CONSTANT VARCHAR2(64) := q'<'Y'、'N'>';
PH1_LOCK_COM_FLG              CONSTANT VARCHAR2(64) := '楽観ロック比較有無フラグ';
PH2_LOCK_COM_FLG              CONSTANT VARCHAR2(64) := q'<'Y'、'N'>';
PH1_UPD_PRG                   CONSTANT VARCHAR2(64) := '更新プログラムID';
PH1_UPD_DIV                   CONSTANT VARCHAR2(64) := '更新区分';
PH2_UPD_DIV                   CONSTANT VARCHAR2(64) := q'<'0'、'10'、'11'>';
PH1_ADD_UPD_DIV_3             CONSTANT VARCHAR2(64) := '追加・更新区分';
PH2_ADD_UPD_DIV_3             CONSTANT VARCHAR2(64) := q'<'0'、'10'、'11'>';
PH1_ADD_UPD_DIV_4             CONSTANT VARCHAR2(64) := '更新区分';
PH2_ADD_UPD_DIV_4             CONSTANT VARCHAR2(64) := q'<'0'、'10'、'11'、'12'>';
PH1_LOGIN                     CONSTANT VARCHAR2(64) := 'ログインユーザ情報';

PH1_GET_SO_NUM                CONSTANT VARCHAR2(64) := 'SO番号の取得';
PH1_GET_SR_NUM                CONSTANT VARCHAR2(64) := 'SR番号の取得';
PH1_SO                        CONSTANT VARCHAR2(64) := 'サービスオーダー情報';
PH1_UPD_SO                    CONSTANT VARCHAR2(64) := 'サービスオーダー情報更新';
PH1_INS_SO                    CONSTANT VARCHAR2(64) := 'サービスオーダー情報登録';
PH1_SR                        CONSTANT VARCHAR2(64) := 'サービス要求情報';
PH1_UPD_SR                    CONSTANT VARCHAR2(64) := 'サービス要求情報更新';
PH1_INS_SR                    CONSTANT VARCHAR2(64) := 'サービス要求情報登録';
PH1_TASK                      CONSTANT VARCHAR2(64) := 'タスク情報';
PH1_UPD_TASK                  CONSTANT VARCHAR2(64) := 'タスク情報更新';
PH1_INS_TASK                  CONSTANT VARCHAR2(64) := 'タスク情報登録';
PH1_INS_NOTE                  CONSTANT VARCHAR2(64) := 'ノート情報登録';
PH1_GET_REPC                  CONSTANT VARCHAR2(64) := 'リピートコール判定情報の取得';
PH1_ANS                       CONSTANT VARCHAR2(64) := '回答管理情報';
PH1_UPD_ANS                   CONSTANT VARCHAR2(64) := '回答管理情報更新';
PH1_INS_ANS                   CONSTANT VARCHAR2(64) := '回答管理情報登録';
PH1_SR_RRT                    CONSTANT VARCHAR2(64) := '関連SR情報';
PH1_GET_SR_RRT                CONSTANT VARCHAR2(64) := '関連SR情報の取得';
PH1_UPD_SR_RRT                CONSTANT VARCHAR2(64) := '関連SR情報更新';
PH1_SR_RRT_UPD_DATE           CONSTANT VARCHAR2(64) := '関連SR情報更新日時';
PH1_INS_SR_RRT                CONSTANT VARCHAR2(64) := '関連SR情報登録';
PH1_BASE_UPD_DATE             CONSTANT VARCHAR2(64) := '基本情報更新日時';
PH1_QST                       CONSTANT VARCHAR2(64) := '質問管理情報';
PH1_UPD_QST                   CONSTANT VARCHAR2(64) := '質問管理情報更新';
PH1_INS_QST                   CONSTANT VARCHAR2(64) := '質問管理情報登録';
PH1_ITQA                      CONSTANT VARCHAR2(64) := '内部QA情報';
PH1_UPD_ITQA                  CONSTANT VARCHAR2(64) := '内部QA情報更新';
PH1_INS_ITQA                  CONSTANT VARCHAR2(64) := '内部QA情報登録';
PH1_GET_ITQA_NUM              CONSTANT VARCHAR2(64) := '内部QA番号の取得';
PH1_INS_SO_HIS                CONSTANT VARCHAR2(64) := 'サービスオーダー情報履歴登録';
PH1_INS_SR_HIS                CONSTANT VARCHAR2(64) := 'サービス要求情報履歴登録';
PH1_INS_TASK_HIS              CONSTANT VARCHAR2(64) := 'タスク情報履歴登録';
PH1_INS_ITQA_HIS              CONSTANT VARCHAR2(64) := '内部QA情報履歴登録';

NOT_EXPECT_ERR                CONSTANT VARCHAR2(64) := '予期せぬエラーが発生しました。';

-- 設定内容変更
HISTORY_NOTE_NOT_IMP          CONSTANT VARCHAR2(64) := '項目内容の変更がありました。'; -- 重要項目以外が更新時
HISTORY_NOTE_CHG              CONSTANT VARCHAR2(64) := 'の変更がありました。';         -- 重要項目が更新時
HISTORY_NOTE_FRM_TO           CONSTANT VARCHAR2(64) := '　⇒　';

-- サービス要求情報履歴編集 重要項目名
SR_HIS_SR_STATUS       CONSTANT VARCHAR2(64) := 'SRステータス';
SR_HIS_IMPORTANCE_LEVEL             CONSTANT VARCHAR2(64) := '重要度';
SR_HIS_SR_GROUP_ID     CONSTANT VARCHAR2(64) := 'サービス要求担当グループ';
SR_HIS_SR_PERSON_ID    CONSTANT VARCHAR2(64) := 'サービス要求担当者';
SR_HIS_RECEIPT_GROUP_ID             CONSTANT VARCHAR2(64) := '受付グループ';
SR_HIS_RECEIPT_PERSON_ID            CONSTANT VARCHAR2(64) := '受付者';
SR_HIS_CALLER_DEPT_NAME             CONSTANT VARCHAR2(64) := 'Caller部署';
SR_HIS_CALLER_CONTACTOR_PERSON      CONSTANT VARCHAR2(64) := 'Caller担当者';

-- サービスオーダー情報履歴編集 重要項目名
SO_HIS_SERVICE_ORDER_STATUS         CONSTANT VARCHAR2(64) := 'SOステータス';
SO_HIS_WORK_GROUP_ID                CONSTANT VARCHAR2(64) := '作業グループ';
SO_HIS_WORK_MAIN_PERSON_ID          CONSTANT VARCHAR2(64) := '作業主担当';
SR_HIS_SEC_INV_NAME     CONSTANT VARCHAR2(64) := '委託先名';
SR_HIS_SEC_INV_PERSON   CONSTANT VARCHAR2(64) := '委託先担当者';

-- タスク情報履歴編集 重要項目名
TASK_HIS_TASK_STATUS                CONSTANT VARCHAR2(64) := 'ステータス';
TASK_HIS_WORK_PERSON_ID             CONSTANT VARCHAR2(64) := '主担当';

-- 内部QA情報履歴編集 重要項目名
ITQA_HIS_TSR_STATUS    CONSTANT VARCHAR2(64) := 'ステータス';
ITQA_HIS_GROUP_ID                       CONSTANT VARCHAR2(64) := '担当グループ';
ITQA_HIS_PERSON_ID                      CONSTANT VARCHAR2(64) := '担当者';
ITQA_HIS_TSR_CREATION_USER_ID CONSTANT VARCHAR2(64) := '作成者';


END CSG01_0106_PKG;
/
