--------------------------------------------------------
--  DDL for Function FUNC_NUMBER_CHK
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "CSNAVI"."FUNC_NUMBER_CHK" (
      PARAM1 IN VARCHAR2 )
    RETURN NUMBER
  AS
    vNUM NUMBER;
  BEGIN
    vNUM := TO_NUMBER(PARAM1);
    RETURN 0;
  EXCEPTION
  WHEN OTHERS THEN
    RETURN 1;
  END FUNC_NUMBER_CHK;
