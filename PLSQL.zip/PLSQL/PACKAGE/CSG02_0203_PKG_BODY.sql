CREATE OR REPLACE PACKAGE BODY "CSG02_0203_PKG" AS
/*******************************************************************************
* 設置機器一括登録の移行                                                           *
*-------------------------------------------------------------------------------*
* <更新履歴>                                                                     *
* <Version>   <日付>      <更新概要>                             <更新者>         *
*   1.0     2016/04/01      新規                                FOCUS_LTBINH    *
*   1.01    2016/05/19      修正                                FOCUS_AOKI
********************************************************************************/
  g_shori_point                 VARCHAR2(250);    -- 処理ポイント
  set_sysdate                   DATE;             -- システム日時
  g_target_sel_cnt              NUMBER;           -- 入力定義（設置機器構成情報ワークの単独機器）の読込件数
  g_normal_sel_cnt              NUMBER;           -- 入力定義（設置機器構成情報ワークの単独機器）の読込件数
  g_warnings_sel_cnt            NUMBER;           -- 入力定義（設置機器構成情報ワークの単独機器）の読込件数
  l_cnt                         NUMBER;           -- ループカウント
  /******************************************************************************
  * 設置機器一括登録（PL/SQL）                                                     *
  * CSG02-0203 (MAIN)                                                           *
  *******************************************************************************/
  PROCEDURE MAIN_CSG02_0203(
      INPUT_USER_ID    IN VARCHAR2,                   --ユーザID
      INPUT_PATH_FILE  IN VARCHAR2,                   --CSVファイルパス
      OUT_PROCESS_ID OUT VARCHAR2,                    --処理ID
      OUT_STATUS OUT VARCHAR2,                        --ステータス
      OUT_ERR_CONTENT OUT NVARCHAR2,                  --エラー内容
      OUT_ERR_DETAIL OUT NVARCHAR2,                   --エラー詳細
      OUT_RESULT_CD OUT VARCHAR2                      --終了コード
    ) AS
    v_DTL_TXT_FRML_NM             SNV_M_GNRC_SNV.DTL_TXT_FRML_NM%TYPE; -- 汎用マスタ.明細テキスト(正式名)（バッチ実行ユーザID）
    PRAM_EXCEPTION                EXCEPTION;
    P_EXCEPTION                   EXCEPTION;
  BEGIN
    g_shori_point             := 'MAIN_CSG02_0203';
    g_target_sel_cnt          := 0; -- 対象データは単独機器(第1階層)がない。
    g_normal_sel_cnt          := 0; -- 対象データは単独機器(第1階層)がない。
    g_warnings_sel_cnt        := 0; -- 対象データは単独機器(第1階層)がない。
  --******************************************************************************
  -- 0.開始処理
  -- 0.1.システム日時の取得
  -- システム日時を取得する。
  --******************************************************************************
    set_sysdate               := SYSDATE;
  ----******************************************************************************
  ---- 0.2.バッチ実行ユーザID 取得
  ---- 汎用マスタより、バッチ実行ユーザIDを取得する。
  ----******************************************************************************
  --  SELECT SMGS.DTL_TXT_FRML_NM                  -- 汎用マスタ.明細テキスト(正式名)（バッチ実行ユーザID）
  --    INTO v_DTL_TXT_FRML_NM
  --    FROM SNV_M_GNRC_SNV SMGS                   -- 汎用マスタ
  --   where SMGS.KEY_ITEM   = 'CSG_GENERAL_PROP'  -- 汎用マスタ.コード区分
  --     AND SMGS.CD_VAL     = 'BATCH_USER';       -- 汎用マスタ.コード値

  -- *************************************************************************
  -- 0.3.処理IDの取得
  -- 開始時バックグラウンド処理を呼び出す。
  -- *************************************************************************
    CSG05_0101_PKG.CSG05_PROC_BG_PROCESS_START
    (
      'BAT-CSG02-0203-01',
      INPUT_PATH_FILE,
      set_sysdate,
      INPUT_USER_ID, --v_DTL_TXT_FRML_NM,
      OUT_PROCESS_ID,
      OUT_RESULT_CD
    );
  -- *************************************************************************
  -- 処理結果 = "20"（異常終了）の場合
  -- エラーメッセージ[MSG-CSG-F-0003]をログ出力し、後続の処理を中断する。
  -- *************************************************************************
    IF OUT_RESULT_CD = '20' THEN
        DBMS_OUTPUT.PUT_LINE('処理IDが取得できませんでした。システム管理者に問い合わせてください。');
        RAISE PRAM_EXCEPTION;
    END IF;

  --******************************************************************************
  -- 設置機器一括登録
  -- CSG02_PROC_INS_EQUI_SHELF_REG
  --******************************************************************************
    CSG02_PROC_INS_EQUI_SHELF_REG(
                                   INPUT_USER_ID, --v_DTL_TXT_FRML_NM,
                                   OUT_PROCESS_ID,
                                   INPUT_PATH_FILE,
                                   OUT_STATUS,
                                   OUT_ERR_CONTENT,
                                   OUT_ERR_DETAIL,
                                   OUT_RESULT_CD
                                 );


  /***************************************************************************
  * 14_バッチ設計_1408050_終了時バックグラウンド処理（PL/SQL）
  * BAT-CSG05-0101-02
  ***************************************************************************/
    CSG05_0101_PKG.CSG05_PROC_BG_PROCESS_UPD
    (
      OUT_PROCESS_ID,
      OUT_STATUS,
      SYSDATE,
      OUT_ERR_CONTENT,
      OUT_ERR_DETAIL,
      '-',
      OUT_RESULT_CD
    );
  -- *************************************************************************
  -- 処理結果 ≠ 0（正常終了でない）の場合
  -- エラーメッセージ[MSG-CSG-W-0033]をログ出力し、呼び出し元に警告終了コードを返却する
  -- *************************************************************************
    IF OUT_RESULT_CD <> '0' THEN
        DBMS_OUTPUT.PUT_LINE('処理結果の登録に失敗しました。ダウンロード、エラーログ参照ができない可能性がありますので、処理結果を確認してください。');
        OUT_RESULT_CD   := '10';
        OUT_STATUS      := '2';
    END IF;

  EXCEPTION
    WHEN P_EXCEPTION THEN
      OUT_RESULT_CD   := '20';
      OUT_STATUS      := '3';
      OUT_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
      OUT_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
      ROLLBACK;
      RETURN;
    -- その他未定義の例外の処理
    WHEN OTHERS THEN
      OUT_RESULT_CD := '20';
      DBMS_OUTPUT.PUT_LINE('ORACLE ERR_CODE    := ' || SQLCODE);          -- ＤＢエラーコード
      DBMS_OUTPUT.PUT_LINE('ORACLE ERR_MESSAGE := ' || SQLERRM(SQLCODE)); -- ＤＢエラーメッセージ
      DBMS_OUTPUT.PUT_LINE('PROC POINT         := ' || g_shori_point);    -- 処理ポイント
      OUT_STATUS      := '3';
      OUT_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
      OUT_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
      ROLLBACK;
      RETURN;
    END MAIN_CSG02_0203;


  /******************************************************************************
  * 設置機器一括登録（PL/SQL）                                                     *
  * CSG02-0203                                                                  *
  *******************************************************************************/
  PROCEDURE CSG02_PROC_INS_EQUI_SHELF_REG(
      INPUT_USER_ID    IN VARCHAR2,                   --ユーザID
      INPUT_PROCESS_ID IN VARCHAR2 DEFAULT NULL,      --処理ID
      INPUT_PATH_FILE  IN VARCHAR2,                   --CSVファイルパス
      OUT_STATUS OUT VARCHAR2,                        --ステータス
      OUT_ERR_CONTENT OUT NVARCHAR2,                  --エラー内容
      OUT_ERR_DETAIL OUT NVARCHAR2,                   --エラー詳細
      OUT_RESULT_CD OUT VARCHAR2                      --終了コード
    ) AS
    F UTL_FILE.FILE_TYPE;
    V_LINE               VARCHAR2(32760);
    v_Content            VARCHAR2(1000);           -- 内容
    v_DirPath            VARCHAR2(1000);           -- フォルダパス
    v_FileName           VARCHAR2(200);            -- ファイル名
    stmt_str             VARCHAR2(2000);
    str_value            VARCHAR2(32760);
    PRAM_PLACE_HOLDER    VARCHAR2(100);             -- プレースホルダパラメータ
    NO_CHECK_DATA        EXCEPTION;
    PRAM_EXCEPTION       EXCEPTION;
    P_EXCEPTION          EXCEPTION;

    tIB_BASE                      ARRAY_IB_BASE;
    tIB_COMMON                    ARRAY_IB_COMMON;
    tIB_MEMO                      ARRAY_IB_MEMO;
  --******************************************************************************
  -- 設置機器構成情報ワークのパラメータ
  --******************************************************************************
    --v_IbConstId                      CSG_P_IB_CONST_WK.IB_CONST_ID%type ;                  -- {1} 設置機器構成ID DEFAULT NOT NULL
    --v_InstanceId                     CSG_P_IB_CONST_WK.INSTANCE_ID%type ;                  -- {2} インスタンス番号 ⇒一括変更
    --v_MainOptionType                 CSG_P_IB_CONST_WK.MAIN_OPTION_TYPE%type ;             -- {3} 本体オプション区分 ⇒一括変更
    --v_InventoryItemCode              CSG_P_IB_CONST_WK.INVENTORY_ITEM_CODE%type ;          -- {4} 品目コード ⇒一括登録
    v_OrgId                          CSG_P_IB_CONST_WK.ORG_ID%type ;                       -- {5} プラント ⇒一括登録
    v_ItemMachineCd                  CSG_P_IB_CONST_WK.ITEM_MACHINE_CD%type ;              -- {6} 品目.機種コード ⇒一括登録
    v_ItemMakerNo                    CSG_P_IB_CONST_WK.ITEM_MAKER_NO%type ;                -- {7} 品目.メーカー型番 ⇒一括登録
    v_ItemBranchNo                   CSG_P_IB_CONST_WK.ITEM_BRANCH_NO%type ;               -- {8} 品目.枝番 ⇒一括登録
    v_SerialNo                       CSG_P_IB_CONST_WK.SERIAL_NO%type ;                    -- {9} シリアル番号 ⇒一括登録⇒一括変更
    --v_SnChangeReason                 CSG_P_IB_CONST_WK.SN_CHANGE_REASON%type ;             -- {10} シリアル番号変更理由 ⇒一括変更
    --v_ItemRemarks                    CSG_P_IB_CONST_WK.ITEM_REMARKS%type ;                 -- {11} 品目摘要 ⇒一括変更
    --v_ParentInventoryItemCode        CSG_P_IB_CONST_WK.PARENT_INVENTORY_ITEM_CODE%type ;   -- {12} 親品目コード
    v_ParentMachineCd                CSG_P_IB_CONST_WK.PARENT_MACHINE_CD%type ;            -- {13} 親品目.機種コード ⇒一括登録
    v_ParentMakerNo                  CSG_P_IB_CONST_WK.PARENT_MAKER_NO%type ;              -- {14} 親品目.メーカー型番 ⇒一括登録
    v_ParentBranchNo                 CSG_P_IB_CONST_WK.PARENT_BRANCH_NO%type ;             -- {15} 親品目.枝番 ⇒一括登録
    v_ParentSrialNo                  CSG_P_IB_CONST_WK.PARENT_SRIAL_NO%type ;              -- {16} 親シリアル番号 ⇒一括登録
    v_Quantity                       CSG_P_IB_CONST_WK.QUANTITY%type ;                     -- {17} 数量 ⇒一括登録⇒一括変更
    v_TransferFlag                   CSG_P_IB_CONST_WK.TRANSFER_FLAG%type ;                -- {18} 移管品フラグ ⇒一括登録⇒一括変更
    v_TransferMaintenanceFrom        CSG_P_IB_CONST_WK.TRANSFER_MAINTENANCE_FROM%type ;    -- {19} 保守移管元 ⇒一括登録⇒一括変更
    --v_TransferMaintenanceTo          CSG_P_IB_CONST_WK.TRANSFER_MAINTENANCE_TO%type ;      -- {20} 保守移管先 ⇒一括変更
    v_TransferMaintenanceDate        CSG_P_IB_CONST_WK.TRANSFER_MAINTENANCE_DATE%type ;    -- {21} 保守移管日 ⇒一括登録⇒一括変更
    v_TransferMaintenanceReason      CSG_P_IB_CONST_WK.TRANSFER_MAINTENANCE_REASON%type ;  -- {22} 保守移管理由 ⇒一括登録⇒一括変更
    v_CsInChargeCd                   CSG_P_IB_CONST_WK.CS_IN_CHARGE_CD%type ;              -- {23} 担当CSコード ⇒一括登録⇒一括変更
    v_IncidentSaverityName           CSG_P_IB_CONST_WK.INCIDENT_SAVERITY_NAME%type ;       -- {24} 重要度 ⇒一括登録⇒一括変更
    v_SecondaryInventoryName         CSG_P_IB_CONST_WK.SECONDARY_INVENTORY_NAME%type ;     -- {25} 委託先コード ⇒一括登録⇒一括変更
    v_InstallLocationCode            CSG_P_IB_CONST_WK.INSTALL_LOCATION_CODE%type ;        -- {26} 設置先住所ID ⇒一括登録⇒一括変更
    v_InstallLocationDeptName        CSG_P_IB_CONST_WK.INSTALL_LOCATION_DEPT_NAME%type ;   -- {27} 設置先部署名 ⇒一括登録⇒一括変更
    v_InstallLocationPersonName      CSG_P_IB_CONST_WK.INSTALL_LOCATION_PERSON_NAME%type ; -- {28} 設置先担当者名 ⇒一括登録⇒一括変更
    v_InstallLocationTel             CSG_P_IB_CONST_WK.INSTALL_LOCATION_TEL%type ;         -- {29} 設置先TEL ⇒一括登録⇒一括変更
    v_InstallLocationFax             CSG_P_IB_CONST_WK.INSTALL_LOCATION_FAX%type ;         -- {30} 設置先FAX ⇒一括登録⇒一括変更
    v_InstallDate                    CSG_P_IB_CONST_WK.INSTALL_DATE%type ;                 -- {31} 納入日 ⇒一括登録⇒一括変更
    v_SalesDate                      CSG_P_IB_CONST_WK.SALES_DATE%type ;                   -- {32} 売上日 ⇒一括登録⇒一括変更
    v_SalesOwnerCode                 CSG_P_IB_CONST_WK.SALES_OWNER_CODE%type ;             -- {33} 販売元 ⇒一括登録⇒一括変更
    --v_OrderNo                        CSG_P_IB_CONST_WK.ORDER_NO%type ;                     -- {34} 受注番号 ⇒一括変更
    --v_CustomerOrderNo                CSG_P_IB_CONST_WK.CUSTOMER_ORDER_NO%type ;            -- {35} 客先注文番号 ⇒一括変更
    --v_MakerOrderNo                   CSG_P_IB_CONST_WK.MAKER_ORDER_NO%type ;               -- {36} メーカー発注番号 ⇒一括変更
    v_ServiceCondition               CSG_P_IB_CONST_WK.SERVICE_CONDITION%type ;            -- {37} サービス形態 ⇒一括登録⇒一括変更
    v_OutSourcingFlag                CSG_P_IB_CONST_WK.OUT_SOURCING_FLAG%type ;            -- {38} 外注フラグ ⇒一括登録⇒一括変更
    --v_ShippingInspectionFlag         CSG_P_IB_CONST_WK.SHIPPING_INSPECTION_FLAG%type ;     -- {39} 出荷検査実施フラグ ⇒一括登録⇒一括変更
    --v_BundleItemCode                 CSG_P_IB_CONST_WK.BUNDLE_ITEM_CODE%type ;             -- {40} バンドル品目コード ⇒一括登録⇒一括変更
    --v_BundleItemName                 CSG_P_IB_CONST_WK.BUNDLE_ITEM_NAME%type ;             -- {41} バンドル品目名 ⇒一括登録⇒一括変更
    v_BundleMachineCd                CSG_P_IB_CONST_WK.BUNDLE_MACHINE_CD%type ;            -- {42} バンドル品.機種コード ⇒一括登録⇒一括変更
    v_BundleMakerNo                  CSG_P_IB_CONST_WK.BUNDLE_MAKER_NO%type ;              -- {43} バンドル品.メーカー型番 ⇒一括登録⇒一括変更
    v_BundleBranchNo                 CSG_P_IB_CONST_WK.BUNDLE_BRANCH_NO%type ;             -- {44} バンドル品.枝番 ⇒一括登録⇒一括変更
    v_BundleSerailNo                 CSG_P_IB_CONST_WK.BUNDLE_SERAIL_NO%type ;             -- {45} バンドルシリアル番号 ⇒一括登録⇒一括変更
    v_FirstCoverage                  CSG_P_IB_CONST_WK.FIRST_COVERAGE%type ;               -- {46} 初回ワランティ条件 ⇒一括登録⇒一括変更
    v_FirstMonths                    CSG_P_IB_CONST_WK.FIRST_MONTHS%type ;                 -- {47} 初回ワランティ月数 ⇒一括登録⇒一括変更
    v_FirstStartDate                 CSG_P_IB_CONST_WK.FIRST_START_DATE%type ;             -- {48} 初回ワランティ期間(自) ⇒一括登録⇒一括変更
    v_NextCoverage                   CSG_P_IB_CONST_WK.NEXT_COVERAGE%type ;                -- {49} 次回ワランティ条件 ⇒一括登録⇒一括変更
    v_NextMonths                     CSG_P_IB_CONST_WK.NEXT_MONTHS%type ;                  -- {50} 次回ワランティ月数 ⇒一括登録⇒一括変更
    v_HostId                         CSG_P_IB_CONST_WK.HOST_ID%type ;                      -- {51} ホストID ⇒一括登録⇒一括変更
    v_HostName                       CSG_P_IB_CONST_WK.HOST_NAME%type ;                    -- {52} ホスト名 ⇒一括登録⇒一括変更
    --v_KeepWatchSystemId              CSG_P_IB_CONST_WK.KEEP_WATCH_SYSTEM_ID%type ;         -- {53} 監視システムID ⇒一括登録⇒一括変更
    v_OsType                         CSG_P_IB_CONST_WK.OS_TYPE%type ;                      -- {54} OS種別 ⇒一括登録⇒一括変更
    v_OsVersion                      CSG_P_IB_CONST_WK.OS_VERSION%type ;                   -- {55} OSバージョン ⇒一括登録⇒一括変更
    v_SystemName                     CSG_P_IB_CONST_WK.SYSTEM_NAME%type ;                  -- {56} システム名 ⇒一括登録⇒一括変更
    --v_FirmwareVersion                CSG_P_IB_CONST_WK.FIRMWARE_VERSION%type ;             -- {57} ファームウェアVer ⇒一括変更
    v_Revision                       CSG_P_IB_CONST_WK.REVISION%type ;                     -- {58} リビジョン ⇒一括登録⇒一括変更
    v_UseCondition                   CSG_P_IB_CONST_WK.USE_CONDITION%type ;                -- {59} 利用形態 ⇒一括登録⇒一括変更
    --v_CpuRomRevision                 CSG_P_IB_CONST_WK.CPU_ROM_REVISION%type ;             -- {60} CPU ROMリビジョン ⇒一括変更
    --v_DiskCapacity                   CSG_P_IB_CONST_WK.DISK_CAPACITY%type ;                -- {61} ディスク容量 ⇒一括変更
    v_UsePerpose                     CSG_P_IB_CONST_WK.USE_PERPOSE%type ;                  -- {62} 利用目的 ⇒一括登録⇒一括変更
    --v_PowerSupplyType                CSG_P_IB_CONST_WK.POWER_SUPPLY_TYPE%type ;            -- {63} 電源設備種類 ⇒一括変更
    --v_PowerSupplyCapacity            CSG_P_IB_CONST_WK.POWER_SUPPLY_CAPACITY%type ;        -- {64} 電源容量 ⇒一括変更
    --v_PpContAkNo                     CSG_P_IB_CONST_WK.PP_CONT_AK_NO%type ;                -- {65} PP契約AK番号 ⇒一括変更
    --v_UsePowerFrequency              CSG_P_IB_CONST_WK.USE_POWER_FREQUENCY%type ;          -- {66} 使用電源周波数 ⇒一括変更
    --v_UsePowerVoltage                CSG_P_IB_CONST_WK.USE_POWER_VOLTAGE%type ;            -- {67} 使用電源電圧 ⇒一括変更
    --v_PpContStartDate                CSG_P_IB_CONST_WK.PP_CONT_START_DATE%type ;           -- {68} 契約期間(自) ⇒一括変更
    --v_PpContEndDate                  CSG_P_IB_CONST_WK.PP_CONT_END_DATE%type ;             -- {69} 契約期間(至) ⇒一括変更
    --v_MacAddress                     CSG_P_IB_CONST_WK.MAC_ADDRESS%type ;                  -- {70} MACアドレス ⇒一括変更
    --v_IpAddress                      CSG_P_IB_CONST_WK.IP_ADDRESS%type ;                   -- {71} IPアドレス ⇒一括変更
    --v_HpConfigCode                   CSG_P_IB_CONST_WK.HP_CONFIG_CODE%type ;               -- {72} HPコンフィグコード ⇒一括変更
    --v_HavingEarthFlag                CSG_P_IB_CONST_WK.HAVING_EARTH_FLAG%type ;            -- {73} アース有無フラグ ⇒一括変更
    v_SupportInstructCode            CSG_P_IB_CONST_WK.SUPPORT_INSTRUCT_CODE%type ;        -- {74} 要サポートフラグ ⇒一括登録⇒一括変更
    v_SupportStartDate               CSG_P_IB_CONST_WK.SUPPORT_START_DATE%type ;           -- {75} 要サポート開始日 ⇒一括登録⇒一括変更
    v_SupportEndDate                 CSG_P_IB_CONST_WK.SUPPORT_END_DATE%type ;             -- {76} 要サポート終了日 ⇒一括登録⇒一括変更
    v_SalesDeptOrgId                 CSG_P_IB_CONST_WK.SALES_DEPT_ORG_ID%type ;            -- {77} F営業販売部署(部課コード) ⇒一括登録⇒一括変更
    v_SalesDeptPersonId              CSG_P_IB_CONST_WK.SALES_DEPT_PERSON_ID%type ;         -- {78} F営業販売担当者(Zなし社員番号) ⇒一括登録⇒一括変更
    v_PresentDeptOrgId               CSG_P_IB_CONST_WK.PRESENT_DEPT_ORG_ID%type ;          -- {79} F営業現在部署(部課コード) ⇒一括登録⇒一括変更
    v_CtcSalesrepPersonId            CSG_P_IB_CONST_WK.CTC_SALESREP_PERSON_ID%type ;       -- {80} F営業現在担当者(Zなし社員番号) ⇒一括登録⇒一括変更
    v_MainteBusDeptOrgId             CSG_P_IB_CONST_WK.MAINTE_BUS_DEPT_ORG_ID%type ;       -- {81} 保守営業担当部署(部課コード) ⇒一括登録⇒一括変更
    v_MainteBusPersonId              CSG_P_IB_CONST_WK.MAINTE_BUS_PERSON_ID%type ;         -- {82} 保守営業担当者(Zなし社員番号) ⇒一括登録⇒一括変更
    --v_CeCode                         CSG_P_IB_CONST_WK.CE_CODE%type ;                      -- {83} 保守担当CE ⇒一括変更
    v_MaintenanceType                CSG_P_IB_CONST_WK.MAINTENANCE_TYPE%type ;             -- {84} 保守種別 ⇒一括登録⇒一括変更
    --v_ImportantItemFlag              CSG_P_IB_CONST_WK.IMPORTANT_ITEM_FLAG%type ;          -- {85} 重要案件 ⇒一括変更
    v_AgentFlag                      CSG_P_IB_CONST_WK.AGENT_FLAG%type ;                   -- {86} 販社フラグ ⇒一括登録⇒一括変更
    --v_FirstSaleDeptName              CSG_P_IB_CONST_WK.FIRST_SALE_DEPT_NAME%type ;         -- {87} 初期販売部署名 ⇒一括変更
    --v_FirstSalePersonName            CSG_P_IB_CONST_WK.FIRST_SALE_PERSON_NAME%type ;       -- {88} 初期販売担当者名 ⇒一括変更
    --v_FirstSalePartyLocation         CSG_P_IB_CONST_WK.FIRST_SALE_PARTY_LOCATION%type ;    -- {89} 初期販売住所コード ⇒一括変更
    --v_FirstSaleTel                   CSG_P_IB_CONST_WK.FIRST_SALE_TEL%type ;               -- {90} 初期販売TEL ⇒一括変更
    --v_FirstSaleFax                   CSG_P_IB_CONST_WK.FIRST_SALE_FAX%type ;               -- {91} 初期販売FAX ⇒一括変更
    --v_FirstSaleMailAddress           CSG_P_IB_CONST_WK.FIRST_SALE_MAIL_ADDRESS%type ;      -- {92} 初期販売メールアドレス ⇒一括変更
    v_EnduserPartyCode               CSG_P_IB_CONST_WK.ENDUSER_PARTY_CODE%type ;           -- {93} エンドユーザ会社コード ⇒一括登録⇒一括変更
    v_EnduserLocation                CSG_P_IB_CONST_WK.ENDUSER_LOCATION%type ;             -- {94} エンドユーザ住所 ⇒一括登録⇒一括変更
    v_EnduserChrgDeptName            CSG_P_IB_CONST_WK.ENDUSER_CHRG_DEPT_NAME%type ;       -- {95} エンドユーザ部署 ⇒一括登録⇒一括変更
    v_EnduserTel                     CSG_P_IB_CONST_WK.ENDUSER_TEL%type ;                  -- {96} エンドユーザTEL ⇒一括登録⇒一括変更
    v_EnduserFax                     CSG_P_IB_CONST_WK.ENDUSER_FAX%type ;                  -- {97} エンドユーザFAX ⇒一括登録⇒一括変更
    v_EnduserChrgPersonName          CSG_P_IB_CONST_WK.ENDUSER_CHRG_PERSON_NAME%type ;     -- {98} エンドユーザ担当者 ⇒一括登録⇒一括変更
    --v_EnduserMailAddress             CSG_P_IB_CONST_WK.ENDUSER_MAIL_ADDRESS%type ;         -- {99} エンドユーザメールアドレス ⇒一括変更
    v_LicenseManagementNo            CSG_P_IB_CONST_WK.LICENSE_MANAGEMENT_NO%type ;        -- {100} ライセンス管理番号 ⇒一括登録⇒一括変更
    v_LisenceStartDate               CSG_P_IB_CONST_WK.LISENCE_START_DATE%type ;           -- {101} ライセンス開始日 ⇒一括登録⇒一括変更
    v_LisenceEndDate                 CSG_P_IB_CONST_WK.LISENCE_END_DATE%type ;             -- {102} ライセンス終了日 ⇒一括登録⇒一括変更
    v_SuperintendeManageNo           CSG_P_IB_CONST_WK.SUPERINTENDE_MANAGE_NO%type ;       -- {103} 主管部管理番号 ⇒一括登録⇒一括変更
    v_RemoveDate                     CSG_P_IB_CONST_WK.REMOVE_DATE%type ;                  -- {104} ソフトウェア移設日 ⇒一括登録⇒一括変更
    v_RemoveOrderNo                  CSG_P_IB_CONST_WK.REMOVE_ORDER_NO%type ;              -- {105} ソフトウェア移設受注番号 ⇒一括登録⇒一括変更
    v_RemovePoNo                     CSG_P_IB_CONST_WK.REMOVE_PO_NO%type ;                 -- {106} ソフトウェア移設先発注番号 ⇒一括登録⇒一括変更
    v_RemoveReason                   CSG_P_IB_CONST_WK.REMOVE_REASON%type ;                -- {107} ソフトウェア移設理由 ⇒一括登録⇒一括変更
    v_MemoType                       CSG_P_IB_CONST_WK.MEMO_TYPE%type ;                    -- {108} メモタイプ ⇒一括登録
    v_Title                          CSG_P_IB_CONST_WK.TITLE%type ;                        -- {109} タイトル ⇒一括登録
    v_Memo                           CSG_P_IB_CONST_WK.MEMO%type ;                         -- {110} メモ ⇒一括登録
    --v_AssignFlag                     CSG_P_IB_CONST_WK.ASSIGN_FLAG%type ;                  -- {111} 紐付済フラグ
    --v_ProgramId                      CSG_P_IB_CONST_WK.PROGRAM_ID%type ;                   -- {112} 更新プログラムID
    --v_ProcessId                      CSG_P_IB_CONST_WK.PROCESS_ID%type ;                   -- {113} 処理ID
    --v_CreationUserId                 CSG_P_IB_CONST_WK.CREATION_USER_ID%type ;             -- {114} 作成者 DEFAULT NOT NULL
    --v_CreationDate                   CSG_P_IB_CONST_WK.CREATION_DATE%type ;                -- {115} 作成日時 DEFAULT NOT NULL
    --v_UpdateUserId                   CSG_P_IB_CONST_WK.UPDATE_USER_ID%type ;               -- {116} 更新者 DEFAULT NOT NULL
    --v_UpdateDate                     CSG_P_IB_CONST_WK.UPDATE_DATE%TYPE ;                  -- {117} 更新日時 DEFAULT NOT NULL
  --******************************************************************************
    --p_IB_CONST_ID                       CSG_P_IB_CONST_WK.IB_CONST_ID%type ;                  --  設置機器構成ID
    p_INSTANCE_ID                       CSG_P_IB_CONST_WK.INSTANCE_ID%type ;                  --  インスタンス番号
    --p_MAIN_OPTION_TYPE                  CSG_P_IB_CONST_WK.MAIN_OPTION_TYPE%type ;             --  本体オプション区分
    p_INVENTORY_ITEM_CODE               CSG_P_IB_CONST_WK.INVENTORY_ITEM_CODE%type ;          --  品目コード
    --p_ORG_ID                            CSG_P_IB_CONST_WK.ORG_ID%type ;                       --  プラント
    --p_ITEM_MACHINE_CD                   CSG_P_IB_CONST_WK.ITEM_MACHINE_CD%type ;              --  品目.機種コード
    --p_ITEM_MAKER_NO                     CSG_P_IB_CONST_WK.ITEM_MAKER_NO%type ;                --  品目.メーカー型番
    --p_ITEM_BRANCH_NO                    CSG_P_IB_CONST_WK.ITEM_BRANCH_NO%type ;               --  品目.枝番
    p_SERIAL_NO                         CSG_P_IB_CONST_WK.SERIAL_NO%type ;                    --  シリアル番号
    --p_SN_CHANGE_REASON                  CSG_P_IB_CONST_WK.SN_CHANGE_REASON%type ;             --  シリアル番号変更理由
    --p_ITEM_REMARKS                      CSG_P_IB_CONST_WK.ITEM_REMARKS%type ;                 --  品目摘要
    --p_PARENT_INVENTORY_ITEM_CODE        CSG_P_IB_CONST_WK.PARENT_INVENTORY_ITEM_CODE%type ;   --  親品目コード
    --p_PARENT_MACHINE_CD                 CSG_P_IB_CONST_WK.PARENT_MACHINE_CD%type ;            --  親品目.機種コード
    --p_PARENT_MAKER_NO                   CSG_P_IB_CONST_WK.PARENT_MAKER_NO%type ;              --  親品目.メーカー型番
    --p_PARENT_BRANCH_NO                  CSG_P_IB_CONST_WK.PARENT_BRANCH_NO%type ;             --  親品目.枝番
    --p_PARENT_SRIAL_NO                   CSG_P_IB_CONST_WK.PARENT_SRIAL_NO%type ;              --  親シリアル番号
    --p_QUANTITY                          CSG_P_IB_CONST_WK.QUANTITY%type ;                     --  数量
    --p_TRANSFER_FLAG                     CSG_P_IB_CONST_WK.TRANSFER_FLAG%type ;                --  移管品フラグ
    --p_TRANSFER_MAINTENANCE_FROM         CSG_P_IB_CONST_WK.TRANSFER_MAINTENANCE_FROM%type ;    --  保守移管元
    --p_TRANSFER_MAINTENANCE_TO           CSG_P_IB_CONST_WK.TRANSFER_MAINTENANCE_TO%type ;      --  保守移管先
    --p_TRANSFER_MAINTENANCE_DATE         CSG_P_IB_CONST_WK.TRANSFER_MAINTENANCE_DATE%type ;    --  保守移管日
    --p_TRANSFER_MAINTENANCE_REASON       CSG_P_IB_CONST_WK.TRANSFER_MAINTENANCE_REASON%type ;  --  保守移管理由
    --p_CS_IN_CHARGE_CD                   CSG_P_IB_CONST_WK.CS_IN_CHARGE_CD%type ;              --  担当CSコード
    --p_INCIDENT_SAVERITY_NAME            CSG_P_IB_CONST_WK.INCIDENT_SAVERITY_NAME%type ;       --  重要度
    --p_SECONDARY_INVENTORY_NAME          CSG_P_IB_CONST_WK.SECONDARY_INVENTORY_NAME%type ;     --  委託先コード
    --p_INSTALL_LOCATION_CODE             CSG_P_IB_CONST_WK.INSTALL_LOCATION_CODE%type ;        --  設置先住所ID
    --p_INSTALL_LOCATION_DEPT_NAME        CSG_P_IB_CONST_WK.INSTALL_LOCATION_DEPT_NAME%type ;   --  設置先部署名
    --p_INSTALL_LOCATION_PERSON_NAME      CSG_P_IB_CONST_WK.INSTALL_LOCATION_PERSON_NAME%type ; --  設置先担当者名
    --p_INSTALL_LOCATION_TEL              CSG_P_IB_CONST_WK.INSTALL_LOCATION_TEL%type ;         --  設置先TEL
    --p_INSTALL_LOCATION_FAX              CSG_P_IB_CONST_WK.INSTALL_LOCATION_FAX%type ;         --  設置先FAX
    --p_INSTALL_DATE                      CSG_P_IB_CONST_WK.INSTALL_DATE%type ;                 --  納入日
    --p_SALES_DATE                        CSG_P_IB_CONST_WK.SALES_DATE%type ;                   --  売上日
    --p_SALES_OWNER_CODE                  CSG_P_IB_CONST_WK.SALES_OWNER_CODE%type ;             --  販売元
    --p_ORDER_NO                          CSG_P_IB_CONST_WK.ORDER_NO%type ;                     --  受注番号
    --p_CUSTOMER_ORDER_NO                 CSG_P_IB_CONST_WK.CUSTOMER_ORDER_NO%type ;            --  客先注文番号
    --p_MAKER_ORDER_NO                    CSG_P_IB_CONST_WK.MAKER_ORDER_NO%type ;               --  メーカー発注番号
    --p_SERVICE_CONDITION                 CSG_P_IB_CONST_WK.SERVICE_CONDITION%type ;            --  サービス形態
    --p_OUT_SOURCING_FLAG                 CSG_P_IB_CONST_WK.OUT_SOURCING_FLAG%type ;            --  外注フラグ
    --p_SHIPPING_INSPECTION_FLAG          CSG_P_IB_CONST_WK.SHIPPING_INSPECTION_FLAG%type ;     --  出荷検査実施フラグ
    --p_BUNDLE_ITEM_CODE                  CSG_P_IB_CONST_WK.BUNDLE_ITEM_CODE%type ;             --  バンドル品目コード
    --p_BUNDLE_ITEM_NAME                  CSG_P_IB_CONST_WK.BUNDLE_ITEM_NAME%type ;             --  バンドル品目名
    --p_BUNDLE_MACHINE_CD                 CSG_P_IB_CONST_WK.BUNDLE_MACHINE_CD%type ;            --  バンドル品.機種コード
    --p_BUNDLE_MAKER_NO                   CSG_P_IB_CONST_WK.BUNDLE_MAKER_NO%type ;              --  バンドル品.メーカー型番
    --p_BUNDLE_BRANCH_NO                  CSG_P_IB_CONST_WK.BUNDLE_BRANCH_NO%type ;             --  バンドル品.枝番
    --p_BUNDLE_SERAIL_NO                  CSG_P_IB_CONST_WK.BUNDLE_SERAIL_NO%type ;             --  バンドルシリアル番号
    --p_FIRST_COVERAGE                    CSG_P_IB_CONST_WK.FIRST_COVERAGE%type ;               --  初回ワランティ条件
    --p_FIRST_MONTHS                      CSG_P_IB_CONST_WK.FIRST_MONTHS%type ;                 --  初回ワランティ月数
    --p_FIRST_START_DATE                  CSG_P_IB_CONST_WK.FIRST_START_DATE%type ;             --  初回ワランティ期間(自)
    --p_NEXT_COVERAGE                     CSG_P_IB_CONST_WK.NEXT_COVERAGE%type ;                --  次回ワランティ条件
    --p_NEXT_MONTHS                       CSG_P_IB_CONST_WK.NEXT_MONTHS%type ;                  --  次回ワランティ月数
    --p_HOST_ID                           CSG_P_IB_CONST_WK.HOST_ID%type ;                      --  ホストID
    --p_HOST_NAME                         CSG_P_IB_CONST_WK.HOST_NAME%type ;                    --  ホスト名
    --p_KEEP_WATCH_SYSTEM_ID              CSG_P_IB_CONST_WK.KEEP_WATCH_SYSTEM_ID%type ;         --  監視システムID
    --p_OS_TYPE                           CSG_P_IB_CONST_WK.OS_TYPE%type ;                      --  OS種別
    --p_OS_VERSION                        CSG_P_IB_CONST_WK.OS_VERSION%type ;                   --  OSバージョン
    --p_SYSTEM_NAME                       CSG_P_IB_CONST_WK.SYSTEM_NAME%type ;                  --  システム名
    --p_FIRMWARE_VERSION                  CSG_P_IB_CONST_WK.FIRMWARE_VERSION%type ;             --  ファームウェアVer
    --p_REVISION                          CSG_P_IB_CONST_WK.REVISION%type ;                     --  リビジョン
    --p_USE_CONDITION                     CSG_P_IB_CONST_WK.USE_CONDITION%type ;                --  利用形態
    --p_CPU_ROM_REVISION                  CSG_P_IB_CONST_WK.CPU_ROM_REVISION%type ;             --  CPU ROMリビジョン
    --p_DISK_CAPACITY                     CSG_P_IB_CONST_WK.DISK_CAPACITY%type ;                --  ディスク容量
    --p_USE_PERPOSE                       CSG_P_IB_CONST_WK.USE_PERPOSE%type ;                  --  利用目的
    --p_POWER_SUPPLY_TYPE                 CSG_P_IB_CONST_WK.POWER_SUPPLY_TYPE%type ;            --  電源設備種類
    --p_POWER_SUPPLY_CAPACITY             CSG_P_IB_CONST_WK.POWER_SUPPLY_CAPACITY%type ;        --  電源容量
    --p_PP_CONT_AK_NO                     CSG_P_IB_CONST_WK.PP_CONT_AK_NO%type ;                --  PP契約AK番号
    --p_USE_POWER_FREQUENCY               CSG_P_IB_CONST_WK.USE_POWER_FREQUENCY%type ;          --  使用電源周波数
    --p_USE_POWER_VOLTAGE                 CSG_P_IB_CONST_WK.USE_POWER_VOLTAGE%type ;            --  使用電源電圧
    --p_PP_CONT_START_DATE                CSG_P_IB_CONST_WK.PP_CONT_START_DATE%type ;           --  契約期間(自)
    --p_PP_CONT_END_DATE                  CSG_P_IB_CONST_WK.PP_CONT_END_DATE%type ;             --  契約期間(至)
    --p_MAC_ADDRESS                       CSG_P_IB_CONST_WK.MAC_ADDRESS%type ;                  --  MACアドレス
    --p_IP_ADDRESS                        CSG_P_IB_CONST_WK.IP_ADDRESS%type ;                   --  IPアドレス
    --p_HP_CONFIG_CODE                    CSG_P_IB_CONST_WK.HP_CONFIG_CODE%type ;               --  HPコンフィグコード
    --p_HAVING_EARTH_FLAG                 CSG_P_IB_CONST_WK.HAVING_EARTH_FLAG%type ;            --  アース有無フラグ
    --p_SUPPORT_INSTRUCT_CODE             CSG_P_IB_CONST_WK.SUPPORT_INSTRUCT_CODE%type ;        --  要サポートフラグ
    --p_SUPPORT_START_DATE                CSG_P_IB_CONST_WK.SUPPORT_START_DATE%type ;           --  要サポート開始日
    --p_SUPPORT_END_DATE                  CSG_P_IB_CONST_WK.SUPPORT_END_DATE%type ;             --  要サポート終了日
    --p_SALES_DEPT_ORG_ID                 CSG_P_IB_CONST_WK.SALES_DEPT_ORG_ID%type ;            --  F営業販売部署(部課コード)
    --p_SALES_DEPT_PERSON_ID              CSG_P_IB_CONST_WK.SALES_DEPT_PERSON_ID%type ;         --  F営業販売担当者(Zなし社員番号)
    --p_PRESENT_DEPT_ORG_ID               CSG_P_IB_CONST_WK.PRESENT_DEPT_ORG_ID%type ;          --  F営業現在部署(部課コード)
    --p_CTC_SALESREP_PERSON_ID            CSG_P_IB_CONST_WK.CTC_SALESREP_PERSON_ID%type ;       --  F営業現在担当者(Zなし社員番号)
    --p_MAINTE_BUS_DEPT_ORG_ID            CSG_P_IB_CONST_WK.MAINTE_BUS_DEPT_ORG_ID%type ;       --  保守営業担当部署(部課コード)
    --p_MAINTE_BUS_PERSON_ID              CSG_P_IB_CONST_WK.MAINTE_BUS_PERSON_ID%type ;         --  保守営業担当者(Zなし社員番号)
    --p_CE_CODE                           CSG_P_IB_CONST_WK.CE_CODE%type ;                      --  保守担当CE
    --p_MAINTENANCE_TYPE                  CSG_P_IB_CONST_WK.MAINTENANCE_TYPE%type ;             --  保守種別
    --p_IMPORTANT_ITEM_FLAG               CSG_P_IB_CONST_WK.IMPORTANT_ITEM_FLAG%type ;          --  重要案件
    --p_AGENT_FLAG                        CSG_P_IB_CONST_WK.AGENT_FLAG%type ;                   --  販社フラグ
    --p_FIRST_SALE_DEPT_NAME              CSG_P_IB_CONST_WK.FIRST_SALE_DEPT_NAME%type ;         --  初期販売部署名
    --p_FIRST_SALE_PERSON_NAME            CSG_P_IB_CONST_WK.FIRST_SALE_PERSON_NAME%type ;       --  初期販売担当者名
    --p_FIRST_SALE_PARTY_LOCATION         CSG_P_IB_CONST_WK.FIRST_SALE_PARTY_LOCATION%type ;    --  初期販売住所コード
    --p_FIRST_SALE_TEL                    CSG_P_IB_CONST_WK.FIRST_SALE_TEL%type ;               --  初期販売TEL
    --p_FIRST_SALE_FAX                    CSG_P_IB_CONST_WK.FIRST_SALE_FAX%type ;               --  初期販売FAX
    --p_FIRST_SALE_MAIL_ADDRESS           CSG_P_IB_CONST_WK.FIRST_SALE_MAIL_ADDRESS%type ;      --  初期販売メールアドレス
    p_ENDUSER_PARTY_CODE                CSG_P_IB_CONST_WK.ENDUSER_PARTY_CODE%type ;           --  エンドユーザ会社コード
    --p_ENDUSER_LOCATION                  CSG_P_IB_CONST_WK.ENDUSER_LOCATION%type ;             --  エンドユーザ住所
    --p_ENDUSER_CHRG_DEPT_NAME            CSG_P_IB_CONST_WK.ENDUSER_CHRG_DEPT_NAME%type ;       --  エンドユーザ部署
    --p_ENDUSER_TEL                       CSG_P_IB_CONST_WK.ENDUSER_TEL%type ;                  --  エンドユーザTEL
    --p_ENDUSER_FAX                       CSG_P_IB_CONST_WK.ENDUSER_FAX%type ;                  --  エンドユーザFAX
    --p_ENDUSER_CHRG_PERSON_NAME          CSG_P_IB_CONST_WK.ENDUSER_CHRG_PERSON_NAME%type ;     --  エンドユーザ担当者
    --p_ENDUSER_MAIL_ADDRESS              CSG_P_IB_CONST_WK.ENDUSER_MAIL_ADDRESS%type ;         --  エンドユーザメールアドレス
    --p_LICENSE_MANAGEMENT_NO             CSG_P_IB_CONST_WK.LICENSE_MANAGEMENT_NO%type ;        --  ライセンス管理番号
    --p_LISENCE_START_DATE                CSG_P_IB_CONST_WK.LISENCE_START_DATE%type ;           --  ライセンス開始日
    --p_LISENCE_END_DATE                  CSG_P_IB_CONST_WK.LISENCE_END_DATE%type ;             --  ライセンス終了日
    --p_SUPERINTENDE_MANAGE_NO            CSG_P_IB_CONST_WK.SUPERINTENDE_MANAGE_NO%type ;       --  主管部管理番号
    --p_REMOVE_DATE                       CSG_P_IB_CONST_WK.REMOVE_DATE%type ;                  --  ソフトウェア移設日
    --p_REMOVE_ORDER_NO                   CSG_P_IB_CONST_WK.REMOVE_ORDER_NO%type ;              --  ソフトウェア移設受注番号
    --p_REMOVE_PO_NO                      CSG_P_IB_CONST_WK.REMOVE_PO_NO%type ;                 --  ソフトウェア移設先発注番号
    --p_REMOVE_REASON                     CSG_P_IB_CONST_WK.REMOVE_REASON%type ;                --  ソフトウェア移設理由
    --p_MEMO_TYPE                         CSG_P_IB_CONST_WK.MEMO_TYPE%type ;                    --  メモタイプ
    --p_TITLE                             CSG_P_IB_CONST_WK.TITLE%type ;                        --  タイトル
    --p_MEMO                              CSG_P_IB_CONST_WK.MEMO%type ;                         --  メモ
    p_ASSIGN_FLAG                       CSG_P_IB_CONST_WK.ASSIGN_FLAG%type ;                  --  紐付済フラグ
    --p_PROGRAM_ID                        CSG_P_IB_CONST_WK.PROGRAM_ID%type ;                   --  更新プログラムID
    --p_PROCESS_ID                        CSG_P_IB_CONST_WK.PROCESS_ID%type ;                   --  処理ID
    --p_CREATION_USER_ID                  CSG_P_IB_CONST_WK.CREATION_USER_ID%type ;             --  作成者
    --p_CREATION_DATE                     CSG_P_IB_CONST_WK.CREATION_DATE%type ;                --  作成日時
    --p_UPDATE_USER_ID                    CSG_P_IB_CONST_WK.UPDATE_USER_ID%type ;               --  更新者
    --p_UPDATE_DATE                       CSG_P_IB_CONST_WK.UPDATE_DATE%TYPE ;                  --  更新日時
  --******************************************************************************
  -- 設置機器情報のパラメータ
  --******************************************************************************
    p_INSTANCE_ID_IBI                       CSG_M_IB_INFO.INSTANCE_ID%type ;                  -- インスタンス番号
    p_PARENT_INSTANCE_ID_IBI                CSG_M_IB_INFO.PARENT_INSTANCE_ID%type ;           -- 親インスタンス番号
    p_TOP_INSTANCE_ID_IBI                   CSG_M_IB_INFO.TOP_INSTANCE_ID%type ;              -- 最上位インスタンス番号
    p_INVENTORY_ITEM_CODE_IBI               CSG_M_IB_INFO.INVENTORY_ITEM_CODE%type ;          -- 品目コード
    --p_ORG_ID_IBI                            CSG_M_IB_INFO.ORG_ID%type ;                       -- プラント
    --p_INVENTORY_ITEM_NAME_IBI               CSG_M_IB_INFO.INVENTORY_ITEM_NAME%type ;          -- 品目名
    p_SERIAL_NO_IBI                         CSG_M_IB_INFO.SERIAL_NO%type ;                    -- シリアル番号
    --p_MAIN_OPTION_TYPE_IBI                  CSG_M_IB_INFO.MAIN_OPTION_TYPE%type ;             -- 本体オプション区分
    --p_IB_SYNC_STATUS_IBI                    CSG_M_IB_INFO.IB_SYNC_STATUS%type ;               -- IBステータス
    --p_QUANTITY_IBI                          CSG_M_IB_INFO.QUANTITY%type ;                     -- 数量
    --p_INSTALL_DATE_IBI                      CSG_M_IB_INFO.INSTALL_DATE%type ;                 -- 納入日
    --p_SALES_DATE_IBI                        CSG_M_IB_INFO.SALES_DATE%type ;                   -- 売上日
    --p_CUSTOMER_ORDER_NO_IBI                 CSG_M_IB_INFO.CUSTOMER_ORDER_NO%type ;            -- 客先注文番号
    --p_MAKER_ORDER_NO_IBI                    CSG_M_IB_INFO.MAKER_ORDER_NO%type ;               -- メーカー発注番号
    --p_ORDER_NO_IBI                          CSG_M_IB_INFO.ORDER_NO%type ;                     -- 受注番号
    --p_TRANSFER_FLAG_IBI                     CSG_M_IB_INFO.TRANSFER_FLAG%TYPE ;                -- 移管品フラグ
    --p_TRANSFER_MAINTENANCE_FROM             CSG_M_IB_INFO.TRANSFER_MAINTENANCE_FROM%type ;    -- 保守移管元
    --p_TRANSFER_MAINTENANCE_TO_IBI           CSG_M_IB_INFO.TRANSFER_MAINTENANCE_TO%type ;      -- 保守移管先
    --p_TRANSFER_MAINTENANCE_DATE             CSG_M_IB_INFO.TRANSFER_MAINTENANCE_DATE%type ;    -- 保守移管日
    --p_TRANSFER_MAINTNANCE_REASON            CSG_M_IB_INFO.TRANSFER_MAINTNANCE_REASON%type ;   -- 保守移管理由
    --p_SALES_OWNER_CODE_IBI                  CSG_M_IB_INFO.SALES_OWNER_CODE%type ;             -- 販売元
    --p_MAINTENANCE_TYPE_IBI                  CSG_M_IB_INFO.MAINTENANCE_TYPE%type ;             -- 保守種別
    --p_IMPORTANT_ITEM_FLAG_IBI               CSG_M_IB_INFO.IMPORTANT_ITEM_FLAG%type ;          -- 重要案件
    --p_SERVICE_CONDITION_IBI                 CSG_M_IB_INFO.SERVICE_CONDITION%type ;            -- サービス形態
    --p_OUT_SOURCING_FLAG_IBI                 CSG_M_IB_INFO.OUT_SOURCING_FLAG%type ;            -- 外注フラグ
    --p_SHIPPING_INSPECTION_FLAG_IBI          CSG_M_IB_INFO.SHIPPING_INSPECTION_FLAG%type ;     -- 出荷検査実施フラグ
    --p_HOST_NAME_IBI                         CSG_M_IB_INFO.HOST_NAME%type ;                    -- ホスト名
    --p_SYSTEM_NAME_IBI                       CSG_M_IB_INFO.SYSTEM_NAME%type ;                  -- システム名
    --p_SUPPORT_START_DATE_IBI                CSG_M_IB_INFO.SUPPORT_START_DATE%type ;           -- 要サポート開始日
    --p_SUPPORT_END_DATE_IBI                  CSG_M_IB_INFO.SUPPORT_END_DATE%type ;             -- 要サポート終了日
    --p_SUPPORT_INSTRUCT_CODE_IBI             CSG_M_IB_INFO.SUPPORT_INSTRUCT_CODE%type ;        -- 要サポートフラグ
    --p_FIRST_SALE_PARTY_CODE_IBI             CSG_M_IB_INFO.FIRST_SALE_PARTY_CODE%type ;        -- 初期販売会社コード
    --p_FIRST_SALE_PARTY_LOCATION             CSG_M_IB_INFO.FIRST_SALE_PARTY_LOCATION%type ;    -- 初期販売会社住所
    --p_FIRST_SALE_DEPT_NAME_IBI              CSG_M_IB_INFO.FIRST_SALE_DEPT_NAME%type ;         -- 初期販売部署名
    --p_FIRST_SALE_TEL_IBI                    CSG_M_IB_INFO.FIRST_SALE_TEL%type ;               -- 初期販売会社TEL
    --p_FIRST_SALE_FAX_IBI                    CSG_M_IB_INFO.FIRST_SALE_FAX%type ;               -- 初期販売会社FAX
    --p_FIRST_SALE_PERSON_NAME_IBI            CSG_M_IB_INFO.FIRST_SALE_PERSON_NAME%type ;       -- 初期販売担当者名
    --p_FIRST_SALE_MAIL_ADDRESS_IBI           CSG_M_IB_INFO.FIRST_SALE_MAIL_ADDRESS%type ;      -- 初期販売メールアドレス
    --p_FIRST_COVERAGE_IBI                    CSG_M_IB_INFO.FIRST_COVERAGE%type ;               -- 初回ワランティ条件
    --p_FIRST_MONTHS_IBI                      CSG_M_IB_INFO.FIRST_MONTHS%type ;                 -- 初回ワランティ月数
    --p_FIRST_START_DATE_IBI                  CSG_M_IB_INFO.FIRST_START_DATE%type ;             -- 初回期間(自)
    p_FIRST_END_DATE_IBI                    CSG_M_IB_INFO.FIRST_END_DATE%type ;               -- 初回期間(至)
    --p_NEXT_COVERAGE_IBI                     CSG_M_IB_INFO.NEXT_COVERAGE%type ;                -- 次回ワランティ条件
    --p_NEXT_MONTHS_IBI                       CSG_M_IB_INFO.NEXT_MONTHS%type ;                  -- 次回ワランティ月数
    p_NEXT_START_DATE_IBI                   CSG_M_IB_INFO.NEXT_START_DATE%type ;              -- 次回期間(自)
    p_NEXT_END_DATE_IBI                     CSG_M_IB_INFO.NEXT_END_DATE%type ;                -- 次回期間(至)
    --p_AGENT_FLAG_IBI                        CSG_M_IB_INFO.AGENT_FLAG%type ;                   -- 販社フラグ
    --p_SECONDARY_INVENTORY_CODE_IBI          CSG_M_IB_INFO.SECONDARY_INVENTORY_CODE%type ;     -- 委託先コード
    --p_BUNDLE_ITEM_CODE_IBI                  CSG_M_IB_INFO.BUNDLE_ITEM_CODE%type ;             -- バンドル品目コード
    --p_BUNDLE_ITEM_NAME_IBI                  CSG_M_IB_INFO.BUNDLE_ITEM_NAME%type ;             -- バンドル品目名
    --p_BUNDLE_SERIAL_NO_IBI                  CSG_M_IB_INFO.BUNDLE_SERIAL_NO%type ;             -- バンドルシリアル
    --p_HOST_ID_IBI                           CSG_M_IB_INFO.HOST_ID%type ;                      -- ホストID
    --p_KEEP_WATCH_SYSTEM_ID_IBI              CSG_M_IB_INFO.KEEP_WATCH_SYSTEM_ID%type ;         -- 監視システムID
    --p_HP_CONFIG_CODE_IBI                    CSG_M_IB_INFO.HP_CONFIG_CODE%type ;               -- HPコンフィグコード
    --p_OS_TYPE_IBI                           CSG_M_IB_INFO.OS_TYPE%type ;                      -- OS種別
    --p_OS_VERSION_IBI                        CSG_M_IB_INFO.OS_VERSION%type ;                   -- OSバージョン
    --p_FIRMWARE_VERSION_IBI                  CSG_M_IB_INFO.FIRMWARE_VERSION%type ;             -- Firmware Version
    --p_REVISION_IBI                          CSG_M_IB_INFO.REVISION%type ;                     -- リビジョン
    --p_CPU_ROM_REVISION_IBI                  CSG_M_IB_INFO.CPU_ROM_REVISION%type ;             -- CPU　ROMリビジョン
    --p_DISK_CAPACITY_IBI                     CSG_M_IB_INFO.DISK_CAPACITY%type ;                -- ディスク容量
    --p_POWER_SUPPLY_TYPE_IBI                 CSG_M_IB_INFO.POWER_SUPPLY_TYPE%type ;            -- 電源設備種類
    --p_POWER_SUPPLY_CAPACITY_IBI             CSG_M_IB_INFO.POWER_SUPPLY_CAPACITY%type ;        -- 電源容量
    --p_USE_POWER_FREQUENCY_IBI               CSG_M_IB_INFO.USE_POWER_FREQUENCY%type ;          -- 使用電源周波数
    --p_USE_POWER_VOLTAGE_IBI                 CSG_M_IB_INFO.USE_POWER_VOLTAGE%type ;            -- 使用電源電圧
    --p_HAVING_EARTH_FLAG_IBI                 CSG_M_IB_INFO.HAVING_EARTH_FLAG%type ;            -- アース有無フラグ
    --p_MAC_ADDRESS_IBI                       CSG_M_IB_INFO.MAC_ADDRESS%type ;                  -- MACアドレス
    --p_IP_ADDRESS_IBI                        CSG_M_IB_INFO.IP_ADDRESS%type ;                   -- IPアドレス
    --p_LICENSE_MANAGEMENT_NO_IBI             CSG_M_IB_INFO.LICENSE_MANAGEMENT_NO%type ;        -- ライセンス管理番号
    --p_SUPERINTENDE_MANAGE_NO_IBI            CSG_M_IB_INFO.SUPERINTENDE_MANAGE_NO%type ;       -- 主管部管理番号
    --p_LISENCE_START_DATE_IBI                CSG_M_IB_INFO.LISENCE_START_DATE%type ;           -- ライセンス開始日
    --p_LISENCE_END_DATE_IBI                  CSG_M_IB_INFO.LISENCE_END_DATE%type ;             -- ライセンス終了日
    --p_REMOVE_ORDER_NO_IBI                   CSG_M_IB_INFO.REMOVE_ORDER_NO%type ;              -- 移設受注番号
    --p_REMOVE_PO_NO_IBI                      CSG_M_IB_INFO.REMOVE_PO_NO%type ;                 -- 移設先発注番号
    --p_REMOVE_DATE_IBI                       CSG_M_IB_INFO.REMOVE_DATE%type ;                  -- 移設日
    --p_REMOVE_REASON_IBI                     CSG_M_IB_INFO.REMOVE_REASON%type ;                -- 移設理由
    --p_SALES_DEPT_ORG_ID_IBI                 CSG_M_IB_INFO.SALES_DEPT_ORG_ID%type ;            -- F営業販売部署コード
    --p_SALES_DEPT_PERSON_ID_IBI              CSG_M_IB_INFO.SALES_DEPT_PERSON_ID%type ;         -- F営業販売担当者コード
    --p_PRESENT_DEPT_ORG_ID_IBI               CSG_M_IB_INFO.PRESENT_DEPT_ORG_ID%type ;          -- F営業現在担当部署コード
    --p_CTC_SALESREP_PERSON_ID_IBI            CSG_M_IB_INFO.CTC_SALESREP_PERSON_ID%type ;       -- F営業現在担当者コード
    --p_MAINTE_BUS_DEPT_ORG_ID_IBI            CSG_M_IB_INFO.MAINTE_BUS_DEPT_ORG_ID%type ;       -- 保守営業担当部署コード
    --p_MAINTE_BUS_PERSON_ID_IBI              CSG_M_IB_INFO.MAINTE_BUS_PERSON_ID%type ;         -- 保守営業担当者コード
    --p_PP_CONT_AK_NO_IBI                     CSG_M_IB_INFO.PP_CONT_AK_NO%type ;                -- PP契約AK番号
    --p_PP_CONT_START_DATE_IBI                CSG_M_IB_INFO.PP_CONT_START_DATE%type ;           -- 契約期間(自)
    --p_PP_CONT_END_DATE_IBI                  CSG_M_IB_INFO.PP_CONT_END_DATE%type ;             -- 契約期間(至)
    --p_SN_CHANGE_REASON_IBI                  CSG_M_IB_INFO.SN_CHANGE_REASON%type ;             -- シリアル番号変更理由
    --p_X_DEPLOY_FLAG_IBI                     CSG_M_IB_INFO.X_DEPLOY_FLAG%type ;                -- X配備対象フラグ
    --p_ACCEPTANCE_DATE_IBI                   CSG_M_IB_INFO.ACCEPTANCE_DATE%type ;              -- 受入日
    --p_OUT_WARRANTY_REGISTERED_FLAG          CSG_M_IB_INFO.OUT_WARRANTY_REGISTERED_FLAG%type ; -- 外注契約ワランティ登録済フラグ
    --p_PROGRAM_ID_IBI                        CSG_M_IB_INFO.PROGRAM_ID%type ;                   -- 更新プログラムID
    --p_PROCESS_ID_IBI                        CSG_M_IB_INFO.PROCESS_ID%type ;                   -- 処理ID
    --p_CREATION_USER_ID_IBI                  CSG_M_IB_INFO.CREATION_USER_ID%type ;             -- 作成者
    --p_CREATION_DATE_IBI                     CSG_M_IB_INFO.CREATION_DATE%type ;                -- 作成日時
    --p_UPDATE_USER_ID_IBI                    CSG_M_IB_INFO.UPDATE_USER_ID%type ;               -- 更新者
    p_UPDATE_DATE_IBI                       CSG_M_IB_INFO.UPDATE_DATE%TYPE ;                  -- 更新日時
  
--  v_INSTANCE_ID_SEQ                       CSG_M_IB_INFO.INSTANCE_ID%type ;                  -- インスタンス番号
  --******************************************************************************
  -- 設置機器共通情報のパラメータ
  --******************************************************************************
    --p_TOP_INSTANCE_ID_ICI                   CSG_M_IB_COMMON_INFO.TOP_INSTANCE_ID%type ;                          -- 最上位インスタンス番号
    --p_CS_IN_CHARGE_CODE_ICI                 CSG_M_IB_COMMON_INFO.CS_IN_CHARGE_CODE%type ;                        -- 担当CSコード
    --p_CE_CODE_ICI                           CSG_M_IB_COMMON_INFO.CE_CODE%type DEFAULT NULL;                      -- 担当CEコード
    p_INSTALL_CUSTOMER_CODE_ICI             CSG_M_IB_COMMON_INFO.INSTALL_CUSTOMER_CODE%type ;                    -- 設置先顧客コード
    --p_INSTALL_LOCATION_CODE_ICI             CSG_M_IB_COMMON_INFO.INSTALL_LOCATION_CODE%type ;                    -- 設置先顧客住所コード
    --p_INSTALL_LOCATION_DEPT_NAME            CSG_M_IB_COMMON_INFO.INSTALL_LOCATION_DEPT_NAME%type DEFAULT NULL;   -- 設置先顧客部署名
    --p_INSTALL_LOCATION_PERSON_NAME          CSG_M_IB_COMMON_INFO.INSTALL_LOCATION_PERSON_NAME%type DEFAULT NULL; -- 設置先顧客担当者名
    --p_INSTALL_LOCATION_TEL_ICI              CSG_M_IB_COMMON_INFO.INSTALL_LOCATION_TEL%type DEFAULT NULL;         -- 設置先TEL
    --p_INSTALL_LOCATION_FAX_ICI              CSG_M_IB_COMMON_INFO.INSTALL_LOCATION_FAX%type DEFAULT NULL;         -- 設置先FAX
    --p_INCIDENT_SERVIRITY_NAME_ICI           CSG_M_IB_COMMON_INFO.INCIDENT_SERVIRITY_NAME%type ;                  -- 重要度
    --p_USE_CONDITION_ICI                     CSG_M_IB_COMMON_INFO.USE_CONDITION%type DEFAULT NULL;                -- 利用形態
    --p_USE_PERPOSE_ICI                       CSG_M_IB_COMMON_INFO.USE_PERPOSE%type DEFAULT NULL;                  -- 利用目的
    --p_ENDUSER_PARTY_CODE_ICI                CSG_M_IB_COMMON_INFO.ENDUSER_PARTY_CODE%type DEFAULT NULL;           -- エンドユーザ会社コード
    --p_ENDUSER_PARTY_NAME_ICI                CSG_M_IB_COMMON_INFO.ENDUSER_PARTY_NAME%type DEFAULT NULL;           -- エンドユーザ会社名
    --p_ENDUSER_LOCATION_ICI                  CSG_M_IB_COMMON_INFO.ENDUSER_LOCATION%type DEFAULT NULL;             -- エンドユーザ住所
    --p_ENDUSER_CHRG_DEPT_NAME_ICI            CSG_M_IB_COMMON_INFO.ENDUSER_CHRG_DEPT_NAME%type DEFAULT NULL;       -- エンドユーザ部署名
    --p_ENDUSER_CHRG_PERSON_NAME_ICI          CSG_M_IB_COMMON_INFO.ENDUSER_CHRG_PERSON_NAME%type DEFAULT NULL;     -- エンドユーザ担当者名
    --p_ENDUSER_TEL_ICI                       CSG_M_IB_COMMON_INFO.ENDUSER_TEL%type DEFAULT NULL;                  -- エンドユーザTEL
    --p_ENDUSER_FAX_ICI                       CSG_M_IB_COMMON_INFO.ENDUSER_FAX%type DEFAULT NULL;                  -- エンドユーザFAX
    --p_ENDUSER_MAIL_ADDRESS_ICI              CSG_M_IB_COMMON_INFO.ENDUSER_MAIL_ADDRESS%type DEFAULT NULL;         -- エンドユーザメールアドレス
    --p_PROGRAM_ID_ICI                        CSG_M_IB_COMMON_INFO.PROGRAM_ID%type DEFAULT NULL;                   -- 更新プログラムID
    --p_PROCESS_ID_ICI                        CSG_M_IB_COMMON_INFO.PROCESS_ID%type DEFAULT NULL;                   -- 処理ID
    --p_CREATION_USER_ID_ICI                  CSG_M_IB_COMMON_INFO.CREATION_USER_ID%type ;                         -- 作成者
    --p_CREATION_DATE_ICI                     CSG_M_IB_COMMON_INFO.CREATION_DATE%type ;                            -- 作成日時
    --p_UPDATE_USER_ID_ICI                    CSG_M_IB_COMMON_INFO.UPDATE_USER_ID%type ;                           -- 更新者
    --p_UPDATE_DATE_ICI                       CSG_M_IB_COMMON_INFO.UPDATE_DATE%TYPE ;                              -- 更新日時
  --******************************************************************************
  -- 設置機器メモ情報のパラメータ
  --******************************************************************************
    --p_INSTANCE_MEMO_ID_CMIMI           CSG_M_IB_MEMO_INFO.INSTANCE_MEMO_ID%type ;       -- メモID
    p_INSTANCE_ID_CMIMI                CSG_M_IB_MEMO_INFO.INSTANCE_ID%type ;            -- インスタンス番号
    --p_MEMO_TYPE_CMIMI                  CSG_M_IB_MEMO_INFO.MEMO_TYPE%type ;              -- メモタイプ
    --p_TITLE_CMIMI                      CSG_M_IB_MEMO_INFO.TITLE%type DEFAULT NULL;      -- タイトル
    p_MEMO_CMIMI                       CSG_M_IB_MEMO_INFO.MEMO%type DEFAULT NULL;       -- メモ
    --p_SORT_NO_CMIMI                    CSG_M_IB_MEMO_INFO.SORT_NO%type DEFAULT NULL;    -- ソート順
    --p_PROGRAM_ID_CMIMI                 CSG_M_IB_MEMO_INFO.PROGRAM_ID%type DEFAULT NULL; -- 更新プログラムID
    --p_PROCESS_ID_CMIMI                 CSG_M_IB_MEMO_INFO.PROCESS_ID%type DEFAULT NULL; -- 処理ID
    --p_CREATION_USER_ID_CMIMI           CSG_M_IB_MEMO_INFO.CREATION_USER_ID%type ;       -- 作成者
    --p_CREATION_DATE_CMIMI              CSG_M_IB_MEMO_INFO.CREATION_DATE%type ;          -- 作成日時
    --p_UPDATE_USER_ID_CMIMI             CSG_M_IB_MEMO_INFO.UPDATE_USER_ID%TYPE ;         -- 更新者
    p_UPDATE_DATE_CMIMI                CSG_M_IB_MEMO_INFO.UPDATE_DATE%TYPE ;            -- 更新日時

    v_INSTANCE_MEMO_ID_CMIMI           CSG_M_IB_MEMO_INFO.INSTANCE_MEMO_ID%TYPE ;       -- メモID
--******************************************************************************
    v_ItemCd02                       SNV_M_ITEM.ITEM_CD%type ;                             -- 品目コード
    v_ItemCd03                       SNV_M_ITEM.ITEM_CD%type ;                             -- 品目コード
    v_ItemCd04                       SNV_M_ITEM.ITEM_CD%type ;                             -- 品目コード

    v_ItemRemarks02                  SNV_M_ITEM.REMARKS%type ;                             -- 摘要
    V_ItemRemarks03                  SNV_M_ITEM.REMARKS%type ;                             -- 摘要
    v_ItemRemarks04                  SNV_M_ITEM.REMARKS%type ;                             -- 摘要

  --******************************************************************************
  -- 4.処理対象データの取得(最上位)
  -- 4.1.最上位インスタンスの取得
  -- 以下の条件に合致するデータを設置機器構成情報ワークより取得する。
  --******************************************************************************
    CURSOR CUR_IB_CONST_WK 
    IS
      SELECT IBI.INSTANCE_ID,                                          -- 設置機器情報テーブルのインスタンス番号（登録済み判定用）
        IBCW.IB_CONST_ID,                                              -- 設置機器構成ID
        IBCW.INVENTORY_ITEM_CODE,                                      -- 品目コード
        IBCW.ORG_ID,                                                   -- プラント
        IBCW.ITEM_MACHINE_CD,                                          -- 品目.機種コード
        IBCW.ITEM_MAKER_NO,                                            -- 品目.メーカー型番
        IBCW.ITEM_BRANCH_NO,                                           -- 品目.枝番
        IBCW.SERIAL_NO,                                                -- シリアル番号
        IBCW.SN_CHANGE_REASON,                                         -- シリアル番号変更理由
        IBCW.ITEM_REMARKS,                                             -- 品目摘要
        IBCW.PARENT_INVENTORY_ITEM_CODE,                               -- 親品目コード
        IBCW.PARENT_MACHINE_CD,                                        -- 親品目.機種コード
        IBCW.PARENT_MAKER_NO,                                          -- 親品目.メーカー型番
        IBCW.PARENT_BRANCH_NO,                                         -- 親品目.枝番
        IBCW.PARENT_SRIAL_NO,                                          -- 親シリアル番号
        IBCW.QUANTITY,                                                 -- 数量
        IBCW.TRANSFER_FLAG,                                            -- 移管品フラグ
        IBCW.TRANSFER_MAINTENANCE_FROM,                                -- 保守移管元
        IBCW.TRANSFER_MAINTENANCE_DATE,                                -- 保守移管日
        IBCW.TRANSFER_MAINTENANCE_REASON,                              -- 保守移管理由
        IBCW.CS_IN_CHARGE_CD,                                          -- 担当CSコード
        IBCW.INCIDENT_SAVERITY_NAME,                                   -- 重要度
        IBCW.SECONDARY_INVENTORY_NAME,                                 -- 委託先コード
        IBCW.INSTALL_LOCATION_CODE,                                    -- 設置先住所ID
        IBCW.INSTALL_LOCATION_DEPT_NAME,                               -- 設置先部署名
        IBCW.INSTALL_LOCATION_PERSON_NAME,                             -- 設置先担当者名
        IBCW.INSTALL_LOCATION_TEL,                                     -- 設置先TEL
        IBCW.INSTALL_LOCATION_FAX,                                     -- 設置先FAX
        IBCW.INSTALL_DATE,                                             -- 納入日
        IBCW.SALES_DATE,                                               -- 売上否
        IBCW.SALES_OWNER_CODE,                                         -- 販売元
        IBCW.SERVICE_CONDITION,                                        -- サービス形態
        IBCW.OUT_SOURCING_FLAG,                                        -- 外注フラグ
        IBCW.BUNDLE_ITEM_CODE,                                         -- バンドル品目コード
        IBCW.BUNDLE_ITEM_NAME,                                         -- バンドル品目名
        IBCW.BUNDLE_MACHINE_CD,                                        -- バンドル品.機種コード
        IBCW.BUNDLE_MAKER_NO,                                          -- バンドル品.メーカー型番
        IBCW.BUNDLE_BRANCH_NO,                                         -- バンドル品.枝番
        IBCW.BUNDLE_SERAIL_NO,                                         -- バンドルシリアル番号
        IBCW.FIRST_COVERAGE,                                           -- 初回ワランティ条件
        IBCW.FIRST_MONTHS,                                             -- 初回ワランティ月数
        IBCW.FIRST_START_DATE,                                         -- 初回期間(自)
        IBCW.NEXT_COVERAGE,                                            -- 次回ワランティ条件
        IBCW.NEXT_MONTHS,                                              -- 次回ワランティ月数
        IBCW.HOST_ID,                                                  -- ホストID
        IBCW.HOST_NAME,                                                -- ホスト名
        IBCW.KEEP_WATCH_SYSTEM_ID,                                     -- 監視システムID
        IBCW.OS_TYPE,                                                  -- OS種別
        IBCW.OS_VERSION,                                               -- OSバージョン
        IBCW.SySTEM_NAME,                                              -- システム名
        IBCW.REVISION,                                                 -- リビジョン
        IBCW.USE_CONDITION,                                            -- 利用形態
        IBCW.USE_PERPOSE,                                              -- 利用目的
        IBCW.SUPPORT_INSTRUCT_CODE,                                    -- 要サポートフラグ
        IBCW.SUPPORT_START_DATE,                                       -- 要サポート開始日
        IBCW.SUPPORT_END_DATE,                                         -- 要サポート終了日
        IBCW.SALES_DEPT_ORG_ID,                                        -- F営業販売部署(部課コード)
        IBCW.SALES_DEPT_PERSON_ID,                                     -- F営業販売担当者(Zなし社員番号)
        IBCW.PRESENT_DEPT_ORG_ID,                                      -- F営業現在部署(部課コード)
        IBCW.CTC_SALESREP_PERSON_ID,                                   -- F営業現在担当者(Zなし社員番号)
        IBCW.MAINTE_BUS_DEPT_ORG_ID,                                   -- 保守営業担当部署(部課コード)
        IBCW.MAINTE_BUS_PERSON_ID,                                     -- 保守営業担当者(Zなし社員番号)
        IBCW.MAINTENANCE_TYPE,                                         -- 保守種別
        IBCW.AGENT_FLAG,                                               -- 販社フラグ
        IBCW.ENDUSER_PARTY_CODE,                                       -- エンドユーザ会社コード
        IBCW.ENDUSER_LOCATION,                                         -- エンドユーザ住所
        IBCW.ENDUSER_CHRG_DEPT_NAME,                                   -- エンドユーザ部署
        IBCW.ENDUSER_TEL,                                              -- エンドユーザTEL
        IBCW.ENDUSER_FAX,                                              -- エンドユーザFAX
        IBCW.ENDUSER_CHRG_PERSON_NAME,                                 -- エンドユーザ担当者
        IBCW.ENDUSER_MAIL_ADDRESS,                                    -- エンドユーザメールアドレス
        IBCW.LICENSE_MANAGEMENT_NO,                                    -- ライセンス管理番号
        IBCW.LISENCE_START_DATE,                                       -- ライセンス開始日
        IBCW.LISENCE_END_DATE,                                         -- ライセンス終了日
        IBCW.SUPERINTENDE_MANAGE_NO,                                   -- 主管部管理番号
        IBCW.REMOVE_DATE,                                              -- ソフトウェア移設日
        IBCW.REMOVE_ORDER_NO,                                          -- ソフトウェア移設受注番号
        IBCW.REMOVE_PO_NO,                                             -- ソフトウェア移設先発注番号
        IBCW.REMOVE_REASON,                                            -- ソフトウェア移設理由
        IBCW.MEMO_TYPE,                                                -- メモタイプ
        IBCW.TITLE,                                                    -- タイトル
        IBCW.MEMO                                                      -- メモ
      FROM CSG_P_IB_CONST_WK IBCW                                            -- 設置機器構成情報ワーク
      LEFT OUTER JOIN CSG_M_IB_INFO IBI                                      -- 設置機器情報
      ON IBCW.INVENTORY_ITEM_CODE          = IBI.INVENTORY_ITEM_CODE         -- ワーク.品目コード＝設置.品目コード
      AND IBCW.SERIAL_NO                   = IBI.SERIAL_NO                   -- ワーク.シリアル番号＝設置.シリアル番号
      WHERE (IBCW.INVENTORY_ITEM_CODE      = IBCW.PARENT_INVENTORY_ITEM_CODE -- ワーク.品目コード＝ワーク.親品目コード
      AND IBCW.SERIAL_NO                   = IBCW.PARENT_SRIAL_NO)           -- ワーク.シリアル番号＝ワーク.親シリアル番号
      OR (IBCW.PARENT_INVENTORY_ITEM_CODE IS NULL                            -- ワーク.親品目コードが未設定
      AND IBCW.PARENT_SRIAL_NO            IS NULL)                           -- ワーク.親シリアル番号が未設定
      AND IBCW.ASSIGN_FLAG                 = '0';                            -- ワーク.紐付済フラグ

  --******************************************************************************
  -- 6.処理対象データの取得(第2階層、第3階層)
  -- 6.1.子インスタンスの取得
  -- 以下の条件に合致するデータを設置機器情報中間ワークより取得する。
  --******************************************************************************
    CURSOR CUR_IB_CONST_WK02 
    IS
      SELECT IBI.INSTANCE_ID,                                          -- 設置機器情報テーブルのインスタンス番号（登録済み判定用）
        IBCW.IB_CONST_ID,                                              -- 設置機器構成ID
        IBCW.INVENTORY_ITEM_CODE,                                      -- 品目コード
        IBCW.ORG_ID,                                                   -- プラント
        IBCW.ITEM_MACHINE_CD,                                          -- 品目.機種コード
        IBCW.ITEM_MAKER_NO,                                            -- 品目.メーカー型番
        IBCW.ITEM_BRANCH_NO,                                           -- 品目.枝番
        IBCW.SERIAL_NO,                                                -- シリアル番号
        IBCW.SN_CHANGE_REASON,                                         -- シリアル番号変更理由
        IBCW.ITEM_REMARKS,                                             -- 品目摘要
        IBCW.PARENT_INVENTORY_ITEM_CODE,                               -- 親品目コード
        IBCW.PARENT_MACHINE_CD,                                        -- 親品目.機種コード
        IBCW.PARENT_MAKER_NO,                                          -- 親品目.メーカー型番
        IBCW.PARENT_BRANCH_NO,                                         -- 親品目.枝番
        IBCW.PARENT_SRIAL_NO,                                          -- 親シリアル番号
        IBCW.QUANTITY,                                                 -- 数量
        IBCW.TRANSFER_FLAG,                                            -- 移管品フラグ
        IBCW.TRANSFER_MAINTENANCE_FROM,                                -- 保守移管元
        IBCW.TRANSFER_MAINTENANCE_DATE,                                -- 保守移管日
        IBCW.TRANSFER_MAINTENANCE_REASON,                              -- 保守移管理由
        IBCW.CS_IN_CHARGE_CD,                                          -- 担当CSコード
        IBCW.INCIDENT_SAVERITY_NAME,                                   -- 重要度
        IBCW.SECONDARY_INVENTORY_NAME,                                 -- 委託先コード
        IBCW.INSTALL_LOCATION_CODE,                                    -- 設置先住所ID
        IBCW.INSTALL_LOCATION_DEPT_NAME,                               -- 設置先部署名
        IBCW.INSTALL_LOCATION_PERSON_NAME,                             -- 設置先担当者名
        IBCW.INSTALL_LOCATION_TEL,                                     -- 設置先TEL
        IBCW.INSTALL_LOCATION_FAX,                                     -- 設置先FAX
        IBCW.INSTALL_DATE,                                             -- 納入日
        IBCW.SALES_DATE,                                               -- 売上否
        IBCW.SALES_OWNER_CODE,                                         -- 販売元
        IBCW.SERVICE_CONDITION,                                        -- サービス形態
        IBCW.OUT_SOURCING_FLAG,                                        -- 外注フラグ
        IBCW.BUNDLE_ITEM_CODE,                                         -- バンドル品目コード
        IBCW.BUNDLE_ITEM_NAME,                                         -- バンドル品目名
        IBCW.BUNDLE_MACHINE_CD,                                        -- バンドル品.機種コード
        IBCW.BUNDLE_MAKER_NO,                                          -- バンドル品.メーカー型番
        IBCW.BUNDLE_BRANCH_NO,                                         -- バンドル品.枝番
        IBCW.BUNDLE_SERAIL_NO,                                         -- バンドルシリアル番号
        IBCW.FIRST_COVERAGE,                                           -- 初回ワランティ条件
        IBCW.FIRST_MONTHS,                                             -- 初回ワランティ月数
        IBCW.FIRST_START_DATE,                                         -- 初回期間(自)
        IBCW.NEXT_COVERAGE,                                            -- 次回ワランティ条件
        IBCW.NEXT_MONTHS,                                              -- 次回ワランティ月数
        IBCW.HOST_ID,                                                  -- ホストID
        IBCW.HOST_NAME,                                                -- ホスト名
        IBCW.KEEP_WATCH_SYSTEM_ID,                                     -- 監視システムID
        IBCW.OS_TYPE,                                                  -- OS種別
        IBCW.OS_VERSION,                                               -- OSバージョン
        IBCW.SySTEM_NAME,                                              -- システム名
        IBCW.REVISION,                                                 -- リビジョン
        IBCW.USE_CONDITION,                                            -- 利用形態
        IBCW.USE_PERPOSE,                                              -- 利用目的
        IBCW.SUPPORT_INSTRUCT_CODE,                                    -- 要サポートフラグ
        IBCW.SUPPORT_START_DATE,                                       -- 要サポート開始日
        IBCW.SUPPORT_END_DATE,                                         -- 要サポート終了日
        IBCW.SALES_DEPT_ORG_ID,                                        -- F営業販売部署(部課コード)
        IBCW.SALES_DEPT_PERSON_ID,                                     -- F営業販売担当者(Zなし社員番号)
        IBCW.PRESENT_DEPT_ORG_ID,                                      -- F営業現在部署(部課コード)
        IBCW.CTC_SALESREP_PERSON_ID,                                   -- F営業現在担当者(Zなし社員番号)
        IBCW.MAINTE_BUS_DEPT_ORG_ID,                                   -- 保守営業担当部署(部課コード)
        IBCW.MAINTE_BUS_PERSON_ID,                                     -- 保守営業担当者(Zなし社員番号)
        IBCW.MAINTENANCE_TYPE,                                         -- 保守種別
        IBCW.AGENT_FLAG,                                               -- 販社フラグ
        IBCW.ENDUSER_PARTY_CODE,                                       -- エンドユーザ会社コード
        IBCW.ENDUSER_LOCATION,                                         -- エンドユーザ住所
        IBCW.ENDUSER_CHRG_DEPT_NAME,                                   -- エンドユーザ部署
        IBCW.ENDUSER_TEL,                                              -- エンドユーザTEL
        IBCW.ENDUSER_FAX,                                              -- エンドユーザFAX
        IBCW.ENDUSER_CHRG_PERSON_NAME,                                 -- エンドユーザ担当者
        IBCW.ENDUSER_MAIL_ADDRESS,                                    -- エンドユーザメールアドレス
        IBCW.LICENSE_MANAGEMENT_NO,                                    -- ライセンス管理番号
        IBCW.LISENCE_START_DATE,                                       -- ライセンス開始日
        IBCW.LISENCE_END_DATE,                                         -- ライセンス終了日
        IBCW.SUPERINTENDE_MANAGE_NO,                                   -- 主管部管理番号
        IBCW.REMOVE_DATE,                                              -- ソフトウェア移設日
        IBCW.REMOVE_ORDER_NO,                                          -- ソフトウェア移設受注番号
        IBCW.REMOVE_PO_NO,                                             -- ソフトウェア移設先発注番号
        IBCW.REMOVE_REASON,                                            -- ソフトウェア移設理由
        IBCW.MEMO_TYPE,                                                -- メモタイプ
        IBCW.TITLE,                                                    -- タイトル
        IBCW.MEMO                                                      -- メモ
      FROM CSG_P_IB_CONST_WK IBCW                                            -- 設置機器構成情報ワーク
      LEFT OUTER JOIN CSG_M_IB_INFO IBI                                      -- 設置機器情報
      ON IBCW.INVENTORY_ITEM_CODE          = IBI.INVENTORY_ITEM_CODE         -- ワーク.品目コード＝設置.品目コード
      AND IBCW.SERIAL_NO                   = IBI.SERIAL_NO                   -- ワーク.シリアル番号＝設置.シリアル番号
      WHERE (IBCW.INVENTORY_ITEM_CODE     <> IBCW.PARENT_INVENTORY_ITEM_CODE -- ワーク.品目コード<>ワーク.親品目コード
      OR IBCW.SERIAL_NO                   <> IBCW.PARENT_SRIAL_NO)           -- ワーク.シリアル番号<>ワーク.親シリアル番号
      AND IBCW.ASSIGN_FLAG                 = '0';                            -- ワーク.紐付済フラグ
  --******************************************************************************
  -- 8.残件データの取得
  -- 8.1.紐付きなしデータの取得
  -- 上記の処理で残ってしまったデータ（紐付かないレコード）はエラーとしてログに出力する。
  -- 以下の条件に合致するデータを設置機器構成情報ワークより取得する。
  --******************************************************************************
    CURSOR CUR_IB_CONST_WK03 
    IS
      SELECT IBCW.INVENTORY_ITEM_CODE,      -- 品目コード
             IBCW.ITEM_MACHINE_CD,          -- 品目.機種コード
             IBCW.ITEM_MAKER_NO,            -- 品目.メーカー型番
             IBCW.ITEM_BRANCH_NO,           -- 品目.枝番
             IBCW.SERIAL_NO                 -- シリアル番号
        FROM CSG_P_IB_CONST_WK IBCW         -- 設置機器構成情報ワーク
       WHERE IBCW.ASSIGN_FLAG = '0';        -- ワーク.紐付済フラグ
     row_IB_CONST_WK03              CUR_IB_CONST_WK03%ROWTYPE;
  BEGIN
    g_shori_point             := 'PROCESS_MAIN';
    str_value                 := '';
    PRAM_PLACE_HOLDER         := 'データの取得';
    g_target_sel_cnt          := 0; -- 対象データは単独機器(第1階層)がない。
    g_normal_sel_cnt          := 0; -- 対象データは単独機器(第1階層)がない。
    g_warnings_sel_cnt        := 0; -- 対象データは単独機器(第1階層)がない。

    IF INPUT_PATH_FILE IS NULL OR INPUT_PATH_FILE = '' THEN
      RAISE PRAM_EXCEPTION;
    ELSE
      v_DirPath :=  GET_DIR_PATH(INPUT_PATH_FILE);
      v_FileName := GET_FILE_NAME(INPUT_PATH_FILE, v_DirPath);
    END IF;

  --******************************************************************************
    PRAM_PLACE_HOLDER := '設置機器構成情報の削除';
  --******************************************************************************
  -- 1.1.　設置機器構成情報ワークのレコード全件削除
  -- 設置機器構成情報ワークに存在するレコード（前回実行分のデータ）を全件削除する。（TRUNCATE TABLE）
  --******************************************************************************
    stmt_str          := 'TRUNCATE TABLE CSG_P_IB_CONST_WK';
    EXECUTE IMMEDIATE stmt_str;
  --******************************************************************************
  -- 1.　CSVファイル取込
  -- 1.1.　CSVファイル取込
  -- 設置機器一括登録CSVファイルを読み込む。
  --******************************************************************************

    set_sysdate               := SYSDATE;

    PRAM_PLACE_HOLDER := 'ファイル読み込み';
    F := UTL_FILE.FOPEN (v_DirPath, v_FileName, 'R', 32760);
    IF UTL_FILE.IS_OPEN(F) THEN
      LOOP
        BEGIN
          UTL_FILE.GET_LINE(F, V_LINE, 32760);
          IF V_LINE IS NULL THEN
            RAISE PRAM_EXCEPTION;
          END IF;

          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 1);
          v_ItemMachineCd             := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 2);
          v_ItemMakerNo               := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 3);
          v_ItemBranchNo              := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 4);
          v_SerialNo                  := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 5);
          v_ParentMachineCd           := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 6);
          v_ParentMakerNo             := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 7);
          v_ParentBranchNo            := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 8);
          v_ParentSrialNo             := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 9);
          v_Quantity                  := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 10);
          v_TransferFlag              := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 11);
          v_TransferMaintenanceFrom   := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 12);
          v_TransferMaintenanceDate   := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 13);
          v_TransferMaintenanceReason := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 14);
          v_CsInChargeCd              := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 15);
          v_IncidentSaverityName      := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 16);
          v_SecondaryInventoryName    := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 17);
          v_InstallLocationCode       := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 18);
          v_InstallLocationDeptName   := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 19);
          v_InstallLocationPersonName := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 20);
          v_InstallLocationTel        := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 21);
          v_InstallLocationFax        := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 22);
          v_InstallDate               := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 23);
          v_SalesDate                 := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 24);
          v_SalesOwnerCode            := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 25);
          v_ServiceCondition          := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 26);
          v_OutSourcingFlag           := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 27);
          v_BundleMachineCd           := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 28);
          v_BundleMakerNo             := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 29);
          v_BundleBranchNo            := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 30);
          v_BundleSerailNo            := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 31);
          v_FirstCoverage             := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 32);
          v_FirstMonths               := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 33);
          v_FirstStartDate            := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 34);
          v_NextCoverage              := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 35);
          v_NextMonths                := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 36);
          v_HostId                    := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 37);
          v_HostName                  := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 38);
          v_OsType                    := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 39);
          v_OsVersion                 := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 40);
          v_SystemName                := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 41);
          v_Revision                  := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 42);
          v_UseCondition              := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 43);
          v_UsePerpose                := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 44);
          v_SupportInstructCode       := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 45);
          v_SupportStartDate          := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 46);
          v_SupportEndDate            := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 47);
          v_SalesDeptOrgId            := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 48);
          v_SalesDeptPersonId         := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 49);
          v_PresentDeptOrgId          := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 50);
          v_CtcSalesrepPersonId       := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 51);
          v_MainteBusDeptOrgId        := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 52);
          v_MainteBusPersonId         := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 53);
          v_MaintenanceType           := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 54);
          v_AgentFlag                 := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 55);
          v_EnduserPartyCode          := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 56);
          v_EnduserLocation           := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 57);
          v_EnduserChrgDeptName       := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 58);
          v_EnduserTel                := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 59);
          v_EnduserFax                := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 60);
          v_EnduserChrgPersonName     := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 61);
          v_LicenseManagementNo       := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 62);
          v_LisenceStartDate          := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 63);
          v_LisenceEndDate            := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 64);
          v_SuperintendeManageNo      := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 65);
          v_RemoveDate                := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 66);
          v_RemoveOrderNo             := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 67);
          v_RemovePoNo                := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 68);
          v_RemoveReason              := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 69);
          v_MemoType                  := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 70);
          v_Title                     := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 71);
          v_Memo                      := REGEXP_SUBSTR(str_value, '[^"]+', 1);

        --********************************************************************
        -- レコードの読込み件数カウンター
        --********************************************************************
          g_target_sel_cnt          := g_target_sel_cnt + 1;

        --********************************************************************
          PRAM_PLACE_HOLDER         := 'チェック処理';
        --********************************************************************
        -- 2.　チェック処理
        -- 2.1.　対象データをチェックする。（単項目）
        --********************************************************************

        -- 必須項目チェック　--  シリアル番号
          IF v_SerialNo IS NULL THEN
            OUT_ERR_CONTENT := 'シリアル番号は必須入力です。';
            RAISE NO_CHECK_DATA;
          END IF;
          
          -- 妥当性チェック -- 数量
          IF FUNC_NUMBER_CHK(v_Quantity) = 1 THEN
            OUT_ERR_CONTENT := '1-999の数字を入力してください。';
            RAISE NO_CHECK_DATA;
          END IF;
          
          
        --********************************************************************
        -- 2.　チェック処理
        -- 2.2.　対象データをチェックする。（相関チェック）
        -- ※ ツールでチェックを行うためここではチェックしない
        --********************************************************************
          
          
        --********************************************************************
        -- ※１　プラントの取得　（販売元が”CTCT”の場合、”CTC”と同じプラントを参照する。）
        -- CSVファイルの「販売元」が設定されいる場合のみ、実施する。
        --********************************************************************
          IF v_SalesOwnerCode IS NOT NULL THEN
            BEGIN
              SELECT SVN.PARM4                                                 -- パラメータ4 (プラント)
                INTO v_OrgId                                                    -- プラント
                FROM SNV_M_GNRC_SNV SVN                                        -- 汎用マスタ(SNV)
               WHERE SVN.KEY_ITEM          ='CSG_ROLE_CLASS'                   -- (設置機器使用会社) 汎用マスタ(SNV).キー項目
                 AND SVN.VALD_STRT_DT     <= TRUNC(set_sysdate)                -- 汎用マスタ(SNV).有効開始日
                 AND NVL(SVN.VALD_END_DT,TRUNC(set_sysdate)) >= TRUNC(set_sysdate)        -- 汎用マスタ(SNV).有効終了日
                 AND NVL(SVN.DEL_FLG,'N') <> 'X'                               -- 汎用マスタ(SNV).削除フラグ
                 AND SVN.CD_VAL            = v_SalesOwnerCode;                 -- 汎用マスタ(SNV).コード値 CSVファイルの販売元「SALES_OWNER_CODE」
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_ERR_CONTENT := 'プラントが取得できませんでした。';
                RAISE NO_CHECK_DATA;
            END;
          END IF;
        --********************************************************************
        -- ※2　品目コード、品目名の取得　
        -- CSVファイルの「販売元」、「機種コード」、「メーカ型番」が設定されいる場合のみ、実施する。
        --********************************************************************
          IF v_SalesOwnerCode IS NOT NULL AND v_ItemMachineCd IS NOT NULL AND v_ItemMakerNo IS NOT NULL THEN
            BEGIN
              SELECT SMI.ITEM_CD,                            -- 品目コード
                     SMI.REMARKS                             -- 摘要　（品目名）
                INTO v_ItemCd02,                             -- 品目コード
                     v_ItemRemarks02                         -- バンドル品目コード
                FROM SNV_M_ITEM SMI                          -- 品目マスタ
               WHERE SMI.PLT               = v_OrgId         -- 品目マスタ.プラント ※１で取得したプラント
                 AND SMI.PROD_CD           = v_ItemMachineCd -- 品目マスタ.機種コード CSVファイルの品目.機種コード「ITEM_MACHINE_CD」
                 AND SMI.MAKR_MDL_NO       = v_ItemMakerNo   -- 品目マスタ.メーカ型番 CSVファイルの品目.メーカー型番「ITEM_MAKER_NO」
                 AND SMI.BR_NO             = v_ItemBranchNo  -- 品目マスタ.枝番 CSVファイルの品目.枝番「ITEM_BRANCH_NO」
                 AND NVL(SMI.DEL_FLG,'N') <> 'X';            -- 品目マスタ.削除フラグ
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_ERR_CONTENT := '品目コード、品目名が取得できませんでした。';
                RAISE NO_CHECK_DATA;
            END;
          END IF;
        --********************************************************************
        -- ※3　親品目コードの取得　
        -- [1.1.]で取得した「販売元」、「バンドル品.機種コード」、「バンドル品.メーカ型番」が設定されいる場合のみ、実施する。
        --********************************************************************
          IF v_SalesOwnerCode IS NOT NULL AND v_ParentMachineCd IS NOT NULL AND v_ParentMakerNo IS NOT NULL THEN
            BEGIN
              SELECT SMI.ITEM_CD                               -- 品目コード
                INTO v_ItemCd03                                -- 品目コード
                FROM SNV_M_ITEM SMI                            -- 品目マスタ
               WHERE SMI.PLT               = v_OrgId           -- 品目マスタ.プラント ※１で取得したプラント
                 AND SMI.PROD_CD           = v_ParentMachineCd -- 品目マスタ.機種コード CSVファイルの親品目.機種コード「PARENT_MACHINE_CD」
                 AND SMI.MAKR_MDL_NO       = v_ParentMakerNo   -- 品目マスタ.メーカ型番 CSVファイルの親品目.メーカー型番「PARENT_MAKER_NO」
                 AND SMI.BR_NO             = v_ParentBranchNo  -- 品目マスタ.枝番 CSVファイルの親品目.枝番「PARENT_BRANCH_NO」
                 AND NVL(SMI.DEL_FLG,'N') <> 'X';              -- 品目マスタ.削除フラグ
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_ERR_CONTENT := '親品目コードが取得できませんでした。';
                RAISE NO_CHECK_DATA;
            END;
          END IF;
        --********************************************************************
        -- ※4　バンドル品目コード、バンドル品目名の取得　
        -- [1.1.]で取得した「販売元」、「バンドル品.機種コード」、「バンドル品.メーカ型番」が設定されいる場合のみ、実施する。
        --********************************************************************
          IF v_SalesOwnerCode IS NOT NULL AND v_BundleMachineCd IS NOT NULL AND v_BundleMakerNo IS NOT NULL THEN
            BEGIN
              SELECT SMI.ITEM_CD,                              -- 品目コード
                     SMI.REMARKS                               -- 摘要　（品目名）
                INTO v_ItemCd04,                               -- 品目コード
                     v_ItemRemarks04                           -- バンドル品目コード
                FROM SNV_M_ITEM SMI                            -- 品目マスタ
               WHERE SMI.PLT               = v_OrgId           -- 品目マスタ.プラント ※１で取得したプラント
                 AND SMI.PROD_CD           = v_BundleMachineCd -- 品目マスタ.機種コード CSVファイルのバンドル品.機種コード「BUNDLE_MACHINE_CD」
                 AND SMI.MAKR_MDL_NO       = v_BundleMakerNo   -- 品目マスタ.メーカ型番 CSVファイルのバンドル品.メーカー型番「BUNDLE_MAKER_NO」
                 and SMI.BR_NO             = v_BundleBranchNo  -- 品目マスタ.枝番 CSVファイルのバンドル品.枝番「BUNDLE_BRANCH_NO」
                 AND NVL(SMI.DEL_FLG,'N') <> 'X';              -- 品目マスタ.削除フラグ
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_ERR_CONTENT := 'バンドル品目コード、バンドル品目名が取得できませんでした。';
                RAISE NO_CHECK_DATA;
            END;
          END IF;

        --********************************************************************
          PRAM_PLACE_HOLDER := '設置機器構成情報の登録';
        --********************************************************************
        -- 3. 登録処理
        -- 3.1. 設置機器構成情報の登録
        -- CSVから読み込んだ設置機器一括登録情報を設置機器構成情報ワークテーブルに挿入する。
        --********************************************************************
          INSERT
          INTO CSG_P_IB_CONST_WK
            (
              IB_CONST_ID,                  -- 設置機器構成ID
              INVENTORY_ITEM_CODE,          -- 品目コード
              ORG_ID,                       -- プラント
              ITEM_MACHINE_CD,              -- 品目.機種コード
              ITEM_MAKER_NO,                -- 品目.メーカー型番
              ITEM_BRANCH_NO,               -- 品目.枝番
              SERIAL_NO,                    -- シリアル番号
              ITEM_REMARKS,                 -- 品目摘要
              PARENT_INVENTORY_ITEM_CODE,   -- 親品目コード
              PARENT_MACHINE_CD,            -- 親品目.機種コード
              PARENT_MAKER_NO,              -- 親品目.メーカー型番
              PARENT_BRANCH_NO,             -- 親品目.枝番
              PARENT_SRIAL_NO,              -- 親シリアル番号
              QUANTITY,                     -- 数量
              TRANSFER_FLAG,                -- 移管品フラグ
              TRANSFER_MAINTENANCE_FROM,    -- 保守移管元
              TRANSFER_MAINTENANCE_DATE,    -- 保守移管日
              TRANSFER_MAINTENANCE_REASON,  -- 保守移管理由
              CS_IN_CHARGE_CD,              -- 担当CSコード
              INCIDENT_SAVERITY_NAME,       -- 重要度
              SECONDARY_INVENTORY_NAME,     -- 委託先コード
              INSTALL_LOCATION_CODE,        -- 設置先住所ID
              INSTALL_LOCATION_DEPT_NAME,   -- 設置先部署名
              INSTALL_LOCATION_PERSON_NAME, -- 設置先担当者名
              INSTALL_LOCATION_TEL,         -- 設置先TEL
              INSTALL_LOCATION_FAX,         -- 設置先FAX
              INSTALL_DATE,                 -- 納入日
              SALES_DATE,                   -- 売上日
              SALES_OWNER_CODE,             -- 販売元
              SERVICE_CONDITION,            -- サービス形態
              OUT_SOURCING_FLAG,            -- 外注フラグ
              BUNDLE_ITEM_CODE,             -- バンドル品目コード
              BUNDLE_ITEM_NAME,             -- バンドル品目名
              BUNDLE_MACHINE_CD,            -- バンドル品.機種コード
              BUNDLE_MAKER_NO,              -- バンドル品.メーカー型番
              BUNDLE_BRANCH_NO,             -- バンドル品.枝番
              BUNDLE_SERAIL_NO,             -- バンドルシリアル番号
              FIRST_COVERAGE,               -- 初回ワランティ条件
              FIRST_MONTHS,                 -- 初回ワランティ月数
              FIRST_START_DATE,             -- 初回ワランティ期間(自)
              NEXT_COVERAGE,                -- 次回ワランティ条件
              NEXT_MONTHS,                  -- 次回ワランティ月数
              HOST_ID,                      -- ホストID
              HOST_NAME,                    -- ホスト名
              OS_TYPE,                      -- OS種別
              OS_VERSION,                   -- OSバージョン
              SySTEM_NAME,                  -- システム名
              REVISION,                     -- リビジョン
              USE_CONDITION,                -- 利用形態
              USE_PERPOSE,                  -- 利用目的
              SUPPORT_INSTRUCT_CODE,        -- 要サポートフラグ
              SUPPORT_START_DATE,           -- 要サポート開始日
              SUPPORT_END_DATE,             -- 要サポート終了日
              SALES_DEPT_ORG_ID,            -- F営業販売部署(部課コード)
              SALES_DEPT_PERSON_ID,         -- F営業販売担当者(Zなし社員番号)
              PRESENT_DEPT_ORG_ID,          -- F営業現在部署(部課コード)
              CTC_SALESREP_PERSON_ID,       -- F営業現在担当者(Zなし社員番号)
              MAINTE_BUS_DEPT_ORG_ID,       -- 保守営業担当部署(部課コード)
              MAINTE_BUS_PERSON_ID,         -- 保守営業担当者(Zなし社員番号)
              MAINTENANCE_TYPE,             -- 保守種別
              AGENT_FLAG,                   -- 販社フラグ
              ENDUSER_PARTY_CODE,           -- エンドユーザ会社コード
              ENDUSER_LOCATION,             -- エンドユーザ住所
              ENDUSER_CHRG_DEPT_NAME,       -- エンドユーザ部署
              ENDUSER_TEL,                  -- エンドユーザTEL
              ENDUSER_FAX,                  -- エンドユーザFAX
              ENDUSER_CHRG_PERSON_NAME,     -- エンドユーザ担当者
              LICENSE_MANAGEMENT_NO,        -- ライセンス管理番号
              LISENCE_START_DATE,           -- ライセンス開始日
              LISENCE_END_DATE,             -- ライセンス終了日
              SUPERINTENDE_MANAGE_NO,       -- 主管部管理番号
              REMOVE_DATE,                  -- ソフトウェア移設日
              REMOVE_ORDER_NO,              -- ソフトウェア移設受注番号
              REMOVE_PO_NO,                 -- ソフトウェア移設先発注番号
              REMOVE_REASON,                -- ソフトウェア移設理由
              MEMO_TYPE,                    -- メモタイプ
              TITLE,                        -- タイトル
              MEMO,                         -- メモ
              ASSIGN_FLAG,                  -- 紐付済フラグ
              PROGRAM_ID,                   -- 更新プログラムID
              PROCESS_ID,                   -- 処理ID
              CREATION_USER_ID,             -- 作成者
              CREATION_DATE,                -- 作成日時
              UPDATE_USER_ID,               -- 更新者
              UPDATE_DATE                   -- 更新日時
            )
            VALUES
            (
              CSG_W_IB_CONST_ID_SEQ.NEXTVAL, -- Oracleシーケンス（SEQUENCE）
              v_ItemCd02,                  -- 品目コード（品目マスタから取得 ※2参照）
              v_OrgId,                     -- プラント（販売元より、汎用マスタから取得　※1参照）
              v_ItemMachineCd,             -- 品目.機種コード
              v_ItemMakerNo,               -- 品目.メーカー型番
              v_ItemBranchNo,              -- 品目.枝番
              v_SerialNo,                  -- シリアル番号
              v_ItemRemarks02,             -- 品目摘要（品目マスタから取得 ※2参照）
              v_ItemCd03,                  -- 親品目コード（品目マスタから取得 ※3参照）
              v_ParentMachineCd,           -- 親品目.機種コード
              v_ParentMakerNo,             -- 親品目.メーカー型番
              v_ParentBranchNo,            -- 親品目.枝番
              v_ParentSrialNo,             -- 親シリアル番号
              v_Quantity,                  -- 数量
              v_TransferFlag,              -- 移管品フラグ
              v_TransferMaintenanceFrom,   -- 保守移管元
              v_TransferMaintenanceDate,   -- 保守移管日
              v_TransferMaintenanceReason, -- 保守移管理由
              v_CsInChargeCd,              -- 担当CSコード
              v_IncidentSaverityName,      -- 重要度
              v_SecondaryInventoryName,    -- 委託先コード
              v_InstallLocationCode,       -- 設置先住所ID
              v_InstallLocationDeptName,   -- 設置先部署名
              v_InstallLocationPersonName, -- 設置先担当者名
              v_InstallLocationTel,        -- 設置先TEL
              v_InstallLocationFax,        -- 設置先FAX
              v_InstallDate,               -- 納入日
              v_SalesDate,                 -- 売上否
              v_SalesOwnerCode,            -- 販売元
              v_ServiceCondition,          -- サービス形態
              v_OutSourcingFlag,           -- 外注フラグ
              v_ItemCd04,                  -- バンドル品目コード（品目マスタから取得 ※4参照）
              v_ItemRemarks04,             -- バンドル品目名（品目マスタから取得 ※4参照）
              v_BundleMachineCd,           -- バンドル品.機種コード
              v_BundleMakerNo,             -- バンドル品.メーカー型番
              v_BundleBranchNo,            -- バンドル品.枝番
              v_BundleSerailNo,            -- バンドルシリアル番号
              v_FirstCoverage,             -- 初回ワランティ条件
              v_FirstMonths,               -- 初回ワランティ月数
              v_FirstStartDate,            -- 初回期間(自)
              v_NextCoverage,              -- 次回ワランティ条件
              v_NextMonths,                -- 次回ワランティ月数
              v_HostId,                    -- ホストID
              v_HostName,                  -- ホスト名
              v_OsType,                    -- OS種別
              v_OsVersion,                 -- OSバージョン
              v_SystemName,                -- システム名
              v_Revision,                  -- リビジョン
              v_UseCondition,              -- 利用形態
              v_UsePerpose,                -- 利用目的
              v_SupportInstructCode,       -- 要サポートフラグ
              v_SupportStartDate,          -- 要サポート開始日
              v_SupportEndDate,            -- 要サポート終了日
              v_SalesDeptOrgId,            -- F営業販売部署(部課コード)
              v_SalesDeptPersonId,         -- F営業販売担当者(Zなし社員番号)
              v_PresentDeptOrgId,          -- F営業現在部署(部課コード)
              v_CtcSalesrepPersonId,       -- F営業現在担当者(Zなし社員番号)
              v_MainteBusDeptOrgId,        -- 保守営業担当部署(部課コード)
              v_MainteBusPersonId,         -- 保守営業担当者(Zなし社員番号)
              v_MaintenanceType,           -- 保守種別
              v_AgentFlag,                 -- 販社フラグ
              v_EnduserPartyCode,          -- エンドユーザ会社コード
              v_EnduserLocation,           -- エンドユーザ住所
              v_EnduserChrgDeptName,       -- エンドユーザ部署
              v_EnduserTel,                -- エンドユーザTEL
              v_EnduserFax,                -- エンドユーザFAX
              v_EnduserChrgPersonName,     -- エンドユーザ担当者
              v_LicenseManagementNo,       -- ライセンス管理番号
              v_LisenceStartDate,          -- ライセンス開始日
              v_LisenceEndDate,            -- ライセンス終了日
              v_SuperintendeManageNo,      -- 主管部管理番号
              v_RemoveDate,                -- ソフトウェア移設日
              v_RemoveOrderNo,             -- ソフトウェア移設受注番号
              v_RemovePoNo,                -- ソフトウェア移設先発注番号
              v_RemoveReason,              -- ソフトウェア移設理由
              v_MemoType,                  -- メモタイプ
              v_Title,                     -- タイトル
              v_Memo,                      -- メモ
              '0',                         -- 紐付済フラグ：'０’（固定）
              'CSG02-0203',                -- CSG02-0203
              INPUT_PROCESS_ID,            -- 
              INPUT_USER_ID,               -- ログインユーザID
              set_sysdate,                 -- SYSDATE
              INPUT_USER_ID,               -- ログインユーザID
              set_sysdate                  -- SYSDATE
            );
        EXCEPTION
          WHEN NO_CHECK_DATA THEN
            OUT_RESULT_CD   := '10';
            OUT_STATUS      := '2'; -- 2:警告終了
            OUT_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(g_target_sel_cnt) || '行目： ' || OUT_ERR_CONTENT;--TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
            DBMS_OUTPUT.PUT_LINE(OUT_ERR_DETAIL);
            ROLLBACK;
            RETURN;
          WHEN NO_DATA_FOUND THEN
            EXIT;
          WHEN OTHERS THEN
            OUT_RESULT_CD   := '20';
            OUT_STATUS      := '3'; -- 3:エラー
            OUT_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
            OUT_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
            ROLLBACK;
            RETURN;
          END;
      END LOOP;
    END IF;
    UTL_FILE.FCLOSE(F);
  --****************************************************************************
  -- コミットの実行
  --****************************************************************************
    COMMIT;

  --****************************************************************************
  -- 4.処理対象データの取得(最上位)
  -- 4.1.最上位インスタンスの取得
  -- 以下の条件に合致するデータを設置機器構成情報ワークより取得する。
  --****************************************************************************          
  <<CUR_IB_CONST_WK_LOOP>>
    FOR row_IB_CONST_WK IN CUR_IB_CONST_WK
      LOOP
        BEGIN
          p_ASSIGN_FLAG             := '1';                        -- 紐付済フラグ

        --**********************************************************************
        -- 5.2.重複チェック
        -- 処理４.1で取得した「設置機器情報テーブルのインスタンス番号」がNULLでない場合、以下のメッセージを出力する。
        -- ・処理結果の警告件数としてカウントアップ（保持）する。
        -- ・中間ワークの紐付済フラグを「2:エラー」に更新し、次のレコードの処理に遷移する。（「5.9.中間ワーク更新」に遷移）
        --**********************************************************************
          IF row_IB_CONST_WK.INSTANCE_ID IS NOT NULL THEN
              p_INVENTORY_ITEM_CODE := row_IB_CONST_WK.INVENTORY_ITEM_CODE; -- 品目コード
              p_SERIAL_NO           := row_IB_CONST_WK.SERIAL_NO;           -- シリアル番号
              v_Content             := '「既に登録されています」';
              OUT_ERR_DETAIL  := '登録できなかったレコードが存在します。 品目コード： ' 
                                  || p_INVENTORY_ITEM_CODE || ' シリアル番号： ' 
                                  || p_SERIAL_NO || ' エラー内容: ' || v_Content;
              DBMS_OUTPUT.PUT_LINE(OUT_ERR_DETAIL);
              g_warnings_sel_cnt          := g_warnings_sel_cnt + 1;
              p_ASSIGN_FLAG               := '2';                    -- 紐付済フラグ "1" (紐付済)　／　"2"(エラー)

          ELSE
            --********************************************************************
            -- 5.3.設置機器情報の設定
            -- 対象データを設置機器情報に設定する。
            -- ※以下の内容は、設置機器・共通テーブル追加更新APIのパラメータ「設置機器情報」として、設定する。
            -- （NULL項目は追加・更新APIに渡す項目として、不要な項目とする。）
            --********************************************************************
            PRAM_PLACE_HOLDER   := '設置機器情報の設定';

            -- ※１ 初回期間(至)
            -- 初回ワランティ期間(自)と初回ワランティ月数に値が設定されている場合
            -- ・初回期間(至)＝初回ワランティ期間(自)＋初回ワランティ月数を自動計算して設定
              IF row_IB_CONST_WK.FIRST_START_DATE IS NOT NULL AND 
                 row_IB_CONST_WK.FIRST_MONTHS IS NOT NULL THEN
                 p_FIRST_END_DATE_IBI :=  TO_DATE(ADD_MONTHS(row_IB_CONST_WK.FIRST_START_DATE, TO_NUMBER(row_IB_CONST_WK.FIRST_MONTHS)), 'YYYY/MM/DD');
              END IF;

            -- ※2 次回期間(自)／次回期間(至)
            -- 初回ワランティ期間(至)と次回ワランティ月数に値が設定されている場合
            -- ・次回期間(自)＝初回ワランティ期間(至)＋1日を自動計算して設定
            -- ・次回期間(至)＝次回ワランティ期間(自)＋次回ワランティ月数を自動計算して設定
              IF row_IB_CONST_WK.FIRST_START_DATE IS NOT NULL AND 
                 row_IB_CONST_WK.NEXT_MONTHS IS NOT NULL THEN
                 p_NEXT_START_DATE_IBI := TO_DATE(row_IB_CONST_WK.FIRST_START_DATE, 'YYYY/MM/DD') + 1;
                 p_NEXT_END_DATE_IBI   := TO_DATE(ADD_MONTHS(p_NEXT_START_DATE_IBI, TO_NUMBER(row_IB_CONST_WK.NEXT_MONTHS)), 'YYYY/MM/DD');
              END IF;

              tIB_BASE               := NEW ARRAY_IB_BASE(
                                        NEW CONTACT_IB_BASE_OBJ('INVENTORY_ITEM_CODE', row_IB_CONST_WK.INVENTORY_ITEM_CODE),               -- [4.1.]で取得したINVENTORY_ITEM_CODE
                                        new CONTACT_IB_BASE_OBJ('ORG_ID', ROW_IB_CONST_WK.ORG_ID),                                         -- [4.1.]で取得したORG_ID
                                        NEW CONTACT_IB_BASE_OBJ('INVENTORY_ITEM_NAME', row_IB_CONST_WK.ITEM_REMARKS),                      -- [4.1.]で取得したITEM_REMARKS
                                        NEW CONTACT_IB_BASE_OBJ('SERIAL_NO', row_IB_CONST_WK.SERIAL_NO),                                   -- [4.1.]で取得したSERIAL_NO
                                        NEW CONTACT_IB_BASE_OBJ('MAIN_OPTION_TYPE', '1'),                                                 -- NULL
                                        NEW CONTACT_IB_BASE_OBJ('IB_SYNC_STATUS', '10009'),                                                -- Normalのコード「10009」を設定
                                        NEW CONTACT_IB_BASE_OBJ('QUANTITY', row_IB_CONST_WK.QUANTITY),                                     -- [4.1.]で取得したQUANTITY
                                        NEW CONTACT_IB_BASE_OBJ('INSTALL_DATE', TO_DATE(row_IB_CONST_WK.INSTALL_DATE, 'YYYY/MM/DD')),      -- [4.1.]で取得したINSTALL_DATE
                                        NEW CONTACT_IB_BASE_OBJ('SALES_DATE', TO_DATE(row_IB_CONST_WK.SALES_DATE, 'YYYY/MM/DD')),          -- [4.1.]で取得したSALES_DATE
                                        NEW CONTACT_IB_BASE_OBJ('TRANSFER_FLAG', row_IB_CONST_WK.TRANSFER_FLAG),                           -- [4.1.]で取得したTRANSFER_FLAG
                                        NEW CONTACT_IB_BASE_OBJ('TRANSFER_MAINTENANCE_FROM', row_IB_CONST_WK.TRANSFER_MAINTENANCE_FROM),   -- [4.1.]で取得したTRANSFER_MAINTENANCE_FROM
                                        NEW CONTACT_IB_BASE_OBJ('TRANSFER_MAINTENANCE_DATE', TO_DATE(row_IB_CONST_WK.TRANSFER_MAINTENANCE_DATE, 'YYYY/MM/DD')), -- [4.1.]で取得したTRANSFER_MAINTENANCE_DATE
                                        NEW CONTACT_IB_BASE_OBJ('TRANSFER_MAINTNANCE_REASON', row_IB_CONST_WK.TRANSFER_MAINTENANCE_REASON),-- [4.1.]で取得したTRANSFER_MAINTENANCE_REASON
                                        NEW CONTACT_IB_BASE_OBJ('SALES_OWNER_CODE', row_IB_CONST_WK.SALES_OWNER_CODE),                     -- [4.1.]で取得したSALES_OWNER_CODE
                                        NEW CONTACT_IB_BASE_OBJ('MAINTENANCE_TYPE', row_IB_CONST_WK.MAINTENANCE_TYPE),                     -- [4.1.]で取得したMAINTENANCE_TYPE
                                        NEW CONTACT_IB_BASE_OBJ('SERVICE_CONDITION', row_IB_CONST_WK.SERVICE_CONDITION),                   -- [4.1.]で取得したSERVICE_CONDITION
                                        NEW CONTACT_IB_BASE_OBJ('OUT_SOURCING_FLAG', row_IB_CONST_WK.OUT_SOURCING_FLAG),                   -- [4.1.]で取得したOUT_SOURCING_FLAG
                                        NEW CONTACT_IB_BASE_OBJ('HOST_NAME', row_IB_CONST_WK.HOST_NAME),                                   -- [4.1.]で取得したHOST_NAME
                                        NEW CONTACT_IB_BASE_OBJ('SYSTEM_NAME', row_IB_CONST_WK.SYSTEM_NAME),                               -- [4.1.]で取得したSYSTEM_NAME
                                        NEW CONTACT_IB_BASE_OBJ('SUPPORT_START_DATE', TO_DATE(row_IB_CONST_WK.SUPPORT_START_DATE, 'YYYY/MM/DD')), -- [4.1.]で取得したSUPPORT_START_DATE
                                        NEW CONTACT_IB_BASE_OBJ('SUPPORT_END_DATE', TO_DATE(row_IB_CONST_WK.SUPPORT_END_DATE, 'YYYY/MM/DD')), -- [4.1.]で取得したSUPPORT_END_DATE
                                        NEW CONTACT_IB_BASE_OBJ('SUPPORT_INSTRUCT_CODE', row_IB_CONST_WK.SUPPORT_INSTRUCT_CODE),           -- [4.1.]で取得したSUPPORT_INSTRUCT_CODE
                                        NEW CONTACT_IB_BASE_OBJ('FIRST_COVERAGE', row_IB_CONST_WK.FIRST_COVERAGE),                         -- [4.1.]で取得したFIRST_COVERAGE
                                        NEW CONTACT_IB_BASE_OBJ('FIRST_MONTHS', TO_NUMBER(row_IB_CONST_WK.FIRST_MONTHS)),                  -- [4.1.]で取得したFIRST_MONTHS
                                        NEW CONTACT_IB_BASE_OBJ('FIRST_START_DATE', TO_DATE(row_IB_CONST_WK.FIRST_START_DATE, 'YYYY/MM/DD')), -- [4.1.]で取得したFIRST_START_DATE
                                        NEW CONTACT_IB_BASE_OBJ('FIRST_END_DATE', p_FIRST_END_DATE_IBI),                                   -- ※１　参照
                                        NEW CONTACT_IB_BASE_OBJ('NEXT_COVERAGE', row_IB_CONST_WK.NEXT_COVERAGE),                           -- [4.1.]で取得したNEXT_COVERAGE
                                        NEW CONTACT_IB_BASE_OBJ('NEXT_MONTHS', TO_NUMBER(row_IB_CONST_WK.NEXT_MONTHS)),                    -- [4.1.]で取得したNEXT_MONTHS
                                        NEW CONTACT_IB_BASE_OBJ('NEXT_START_DATE', p_NEXT_START_DATE_IBI),                                 -- ※2　参照
                                        NEW CONTACT_IB_BASE_OBJ('NEXT_END_DATE', p_NEXT_END_DATE_IBI),                                     -- ※2　参照
                                        NEW CONTACT_IB_BASE_OBJ('AGENT_FLAG', row_IB_CONST_WK.AGENT_FLAG),                                 -- [4.1.]で取得したAGENT_FLAG
                                        NEW CONTACT_IB_BASE_OBJ('BUNDLE_ITEM_CODE', row_IB_CONST_WK.BUNDLE_ITEM_CODE),                     -- [4.1.]で取得したBUNDLE_ITEM_CODE
                                        NEW CONTACT_IB_BASE_OBJ('BUNDLE_ITEM_NAME', row_IB_CONST_WK.BUNDLE_ITEM_NAME),                     -- [4.1.]で取得したBUNDLE_ITEM_NAME
                                        NEW CONTACT_IB_BASE_OBJ('BUNDLE_SERIAL_NO', row_IB_CONST_WK.BUNDLE_SERAIL_NO),                     -- [4.1.]で取得したBUNDLE_SERAIL_NO
                                        NEW CONTACT_IB_BASE_OBJ('HOST_ID', row_IB_CONST_WK.HOST_ID),                                       -- [4.1.]で取得したHOST_ID
                                        NEW CONTACT_IB_BASE_OBJ('KEEP_WATCH_SYSTEM_ID', row_IB_CONST_WK.KEEP_WATCH_SYSTEM_ID),             -- [4.1.]で取得したKEEP_WATCH_SYSTEM_ID
                                        NEW CONTACT_IB_BASE_OBJ('OS_TYPE', row_IB_CONST_WK.OS_TYPE),                                       -- [4.1.]で取得したOS_TYPE
                                        NEW CONTACT_IB_BASE_OBJ('OS_VERSION', row_IB_CONST_WK.OS_VERSION),                                 -- [4.1.]で取得したOS_VERSION
                                        NEW CONTACT_IB_BASE_OBJ('REVISION', row_IB_CONST_WK.REVISION),                                     -- [4.1.]で取得したREVISION
                                        NEW CONTACT_IB_BASE_OBJ('LICENSE_MANAGEMENT_NO', row_IB_CONST_WK.LICENSE_MANAGEMENT_NO),           -- [4.1.]で取得したLICENSE_MANAGEMENT_NO
                                        NEW CONTACT_IB_BASE_OBJ('SUPERINTENDE_MANAGE_NO', row_IB_CONST_WK.SUPERINTENDE_MANAGE_NO),         -- [4.1.]で取得したSUPERINTENDE_MANAGE_NO
                                        NEW CONTACT_IB_BASE_OBJ('LISENCE_START_DATE', TO_DATE(row_IB_CONST_WK.LISENCE_START_DATE, 'YYYY/MM/DD')), -- [4.1.]で取得したLISENCE_START_DATE
                                        NEW CONTACT_IB_BASE_OBJ('LISENCE_END_DATE', TO_DATE(row_IB_CONST_WK.LISENCE_END_DATE, 'YYYY/MM/DD')), -- [4.1.]で取得したLISENCE_END_DATE
                                        NEW CONTACT_IB_BASE_OBJ('REMOVE_ORDER_NO', row_IB_CONST_WK.REMOVE_ORDER_NO),                       -- [4.1.]で取得したREMOVE_ORDER_NO
                                        NEW CONTACT_IB_BASE_OBJ('REMOVE_PO_NO', row_IB_CONST_WK.REMOVE_PO_NO),                             -- [4.1.]で取得したREMOVE_PO_NO
                                        NEW CONTACT_IB_BASE_OBJ('REMOVE_DATE', TO_DATE(row_IB_CONST_WK.REMOVE_DATE, 'YYYY/MM/DD')),        -- [4.1.]で取得したREMOVE_DATE
                                        NEW CONTACT_IB_BASE_OBJ('REMOVE_REASON', row_IB_CONST_WK.REMOVE_REASON),                           -- [4.1.]で取得したREMOVE_REASON
                                        NEW CONTACT_IB_BASE_OBJ('SALES_DEPT_ORG_ID', row_IB_CONST_WK.SALES_DEPT_ORG_ID),                   -- [4.1.]で取得したSALES_DEPT_ORG_ID
                                        NEW CONTACT_IB_BASE_OBJ('SALES_DEPT_PERSON_ID', row_IB_CONST_WK.SALES_DEPT_PERSON_ID),             -- [4.1.]で取得したSALES_DEPT_PERSON_ID
                                        NEW CONTACT_IB_BASE_OBJ('PRESENT_DEPT_ORG_ID', row_IB_CONST_WK.PRESENT_DEPT_ORG_ID),               -- [4.1.]で取得したPRESENT_DEPT_ORG_ID
                                        NEW CONTACT_IB_BASE_OBJ('CTC_SALESREP_PERSON_ID', row_IB_CONST_WK.CTC_SALESREP_PERSON_ID),         -- [4.1.]で取得したCTC_SALESREP_PERSON_ID
                                        NEW CONTACT_IB_BASE_OBJ('MAINTE_BUS_DEPT_ORG_ID', row_IB_CONST_WK.MAINTE_BUS_DEPT_ORG_ID),         -- [4.1.]で取得したMAINTE_BUS_DEPT_ORG_ID
                                        NEW CONTACT_IB_BASE_OBJ('MAINTE_BUS_PERSON_ID', row_IB_CONST_WK.MAINTE_BUS_PERSON_ID),             -- [4.1.]で取得したMAINTE_BUS_PERSON_ID
                                        NEW CONTACT_IB_BASE_OBJ('OUT_WARRANTY_REGISTERED_FLAG', '3')                                       -- ’3’(出荷実績以外)を固定
                                        );
            --********************************************************************
            -- 5.4.設置機器共通情報の設定
            -- 対象データを設置機器共通情報に設定する。
            -- ※以下の内容は、設置機器・共通テーブル追加更新APIのパラメータ「設置機器共通情報」として、設定する。
            -- （NULL項目は追加・更新APIに渡す項目として、不要な項目とする。）
            --********************************************************************
            PRAM_PLACE_HOLDER   := '設置機器共通情報の設定';

              -- ※1　設置先顧客コードの取得　
              -- [4.1.]で取得した「INSTALL_LOCATION_CODE」が設定されている場合のみ、実施する。
                IF row_IB_CONST_WK.INSTALL_LOCATION_CODE IS NOT NULL THEN
                  BEGIN
                    SELECT CMIA.CUST_CD                                                            -- 顧客コード
                      INTO p_INSTALL_CUSTOMER_CODE_ICI
                      FROM CSG_M_IB_ADDRESS CMIA                                                   -- 設置先住所マスタ
                    where CMIA.INSTALL_LOCATION_CODE   = row_IB_CONST_WK.INSTALL_LOCATION_CODE    -- 設置先住所マスタ.設置先住所コード [4.1.]で取得した「INSTALL_LOCATION_CODE」
                   AND CMIA.ACTIVE_FLAG             = 'Y';                                     -- 設置先住所マスタ.有効フラグ "Y"：有効
                  EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                      NULL;
                  END;
                END IF;

            -- ※２　エンドユーザ会社名の取得　
            -- [4.1.]で取得した「ENDUSER_PARTY_CODE」が設定されている場合のみ、実施する。
              IF row_IB_CONST_WK.ENDUSER_PARTY_CODE IS NOT NULL THEN
                BEGIN
                  SELECT SMC.CUST_FRML_NM                                            -- 顧客正式名称
                    INTO p_ENDUSER_PARTY_CODE
                    FROM SNV_M_CUST SMC                                              -- 顧客マスタ
                   WHERE SMC.CUST_CD            = row_IB_CONST_WK.ENDUSER_PARTY_CODE -- 顧客マスタ.顧客コード [4.1.]で取得した「ENDUSER_PARTY_CODE」
                     and SMC.HDQRTRS_ID_FLG     = 'Y'                                -- 顧客マスタ.本社識別フラグ "Y"：本社
                     AND NVL(SMC.DEL_FLG, 'N') <> 'X';                               -- 顧客マスタ.削除フラグ "X"：削除　以外
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                     NULL;
                END;
              END IF;

              tIB_COMMON               := NEW ARRAY_IB_COMMON(
                                          NEW CONTACT_IB_COMMON_OBJ('CS_IN_CHARGE_CODE', row_IB_CONST_WK.CS_IN_CHARGE_CD),                        -- 担当CSコード
                                          NEW CONTACT_IB_COMMON_OBJ('INSTALL_CUSTOMER_CODE', p_INSTALL_CUSTOMER_CODE_ICI),                        -- 設置先顧客コード
                                          NEW CONTACT_IB_COMMON_OBJ('INSTALL_LOCATION_CODE', row_IB_CONST_WK.INSTALL_LOCATION_CODE),              -- 設置先顧客住所コード
                                          NEW CONTACT_IB_COMMON_OBJ('INSTALL_LOCATION_DEPT_NAME', row_IB_CONST_WK.INSTALL_LOCATION_DEPT_NAME),    -- 設置先顧客部署名
                                          NEW CONTACT_IB_COMMON_OBJ('INSTALL_LOCATION_PERSON_NAME', row_IB_CONST_WK.INSTALL_LOCATION_PERSON_NAME),-- 設置先顧客担当者名
                                          NEW CONTACT_IB_COMMON_OBJ('INSTALL_LOCATION_TEL', row_IB_CONST_WK.INSTALL_LOCATION_TEL),                -- 設置先TEL
                                          NEW CONTACT_IB_COMMON_OBJ('INSTALL_LOCATION_FAX', row_IB_CONST_WK.INSTALL_LOCATION_FAX),                                                -- 設置先FAX
                                          NEW CONTACT_IB_COMMON_OBJ('INCIDENT_SERVIRITY_NAME', row_IB_CONST_WK.INCIDENT_SAVERITY_NAME),                                             -- 重要度
                                          NEW CONTACT_IB_COMMON_OBJ('USE_CONDITION', row_IB_CONST_WK.USE_CONDITION),                                                       -- 利用形態
                                          NEW CONTACT_IB_COMMON_OBJ('USE_PERPOSE', row_IB_CONST_WK.USE_PERPOSE),                                                         -- 利用目的
                                          NEW CONTACT_IB_COMMON_OBJ('ENDUSER_PARTY_CODE', row_IB_CONST_WK.ENDUSER_PARTY_CODE),                      -- エンドユーザ会社コード
                                          NEW CONTACT_IB_COMMON_OBJ('ENDUSER_PARTY_NAME', p_ENDUSER_PARTY_CODE),                                  -- エンドユーザ会社名
                                          NEW CONTACT_IB_COMMON_OBJ('ENDUSER_LOCATION', row_IB_CONST_WK.ENDUSER_LOCATION),                        -- エンドユーザ住所
                                          NEW CONTACT_IB_COMMON_OBJ('ENDUSER_CHRG_DEPT_NAME', row_IB_CONST_WK.ENDUSER_CHRG_DEPT_NAME),            -- エンドユーザ部署名
                                          NEW CONTACT_IB_COMMON_OBJ('ENDUSER_CHRG_PERSON_NAME', row_IB_CONST_WK.ENDUSER_CHRG_PERSON_NAME),        -- エンドユーザ担当者名
                                          NEW CONTACT_IB_COMMON_OBJ('ENDUSER_TEL', row_IB_CONST_WK.ENDUSER_TEL),                                  -- エンドユーザTEL
                                          NEW CONTACT_IB_COMMON_OBJ('ENDUSER_FAX', ROW_IB_CONST_WK.ENDUSER_FAX),                                  -- エンドユーザFAX
                                          NEW CONTACT_IB_COMMON_OBJ('ENDUSER_MAIL_ADDRESS', row_IB_CONST_WK.ENDUSER_MAIL_ADDRESS)                -- エンドユーザメールアドレス
                                          );
            --********************************************************************
            -- 5.5.設置機器・共通テーブル追加更新APIのコール
            -- 設置機器・共通テーブル追加更新APIを呼び出す。
            --********************************************************************
            PRAM_PLACE_HOLDER   := '設置機器・設置機器共通情報更新';

              CSG02_IB_COMMON_PKG.CSG02_PROC_IB_TABLE_UPDATE(
                                                              0,
                                                              NULL,
                                                              NULL,
                                                              tIB_BASE,
                                                              tIB_COMMON,
                                                              'BAT-CSG02-0203',
                                                              INPUT_PROCESS_ID,
                                                              INPUT_USER_ID,
                                                              'N',
                                                              NULL,
                                                              OUT_RESULT_CD,
                                                              OUT_ERR_CONTENT,
                                                              p_INSTANCE_ID,
                                                              p_UPDATE_DATE_IBI
                                                            );
              CASE 
                WHEN OUT_RESULT_CD = 0  THEN --正常
                  NULL;--nop
                WHEN OUT_RESULT_CD = 21 THEN -- [マスタ存在チェックエラーの場合]
                  p_INVENTORY_ITEM_CODE := row_IB_CONST_WK.INVENTORY_ITEM_CODE; -- 品目コード
                  p_SERIAL_NO           := row_IB_CONST_WK.SERIAL_NO;           -- シリアル番号
                  v_Content             := OUT_ERR_CONTENT;                     -- 返却された「エラーメッセージ」

                  OUT_ERR_DETAIL  := '登録できなかったレコードが存在します。 品目コード： ' 
                                      || p_INVENTORY_ITEM_CODE || ' シリアル番号： ' 
                                      || p_SERIAL_NO || ' エラー内容: ' || v_Content;
                  DBMS_OUTPUT.PUT_LINE(OUT_ERR_DETAIL);

                  -- ・処理結果の警告件数としてカウントアップ（保持）する。
                  g_warnings_sel_cnt          := g_warnings_sel_cnt + 1;

                  -- ・中間ワークの紐付済フラグを「2:エラー」に更新し、次のレコードの処理に遷移する。（「5.9.中間ワーク更新」に遷移）
                  p_ASSIGN_FLAG               := '2';                    -- 紐付済フラグ "1" (紐付済)　／　"2"(エラー)

                ELSE    --その他エラー
                  RAISE P_EXCEPTION;
              END CASE;

            IF (row_IB_CONST_WK.MEMO_TYPE IS NOT NULL AND 
             row_IB_CONST_WK.TITLE IS NOT NULL AND 
             row_IB_CONST_WK.MEMO IS NOT NULL) 
            AND p_ASSIGN_FLAG = '1'  THEN --5.5.処理結果=正常

              --********************************************************************
              -- 5.6.設置機器メモ情報の設定
              -- 処理4.1で取得したデータの「メモ」に値が設定されている場合のみ、以下を実行する。
              -- 対象データを設置機器メモ情報に設定する。
              --********************************************************************
              PRAM_PLACE_HOLDER   := '設置機器メモ情報の設定';

                tIB_MEMO            := NEW ARRAY_IB_MEMO(
--                                     NEW CONTACT_IB_MEMO_OBJ('INSTANCE_ID', p_INSTANCE_ID),                         -- [5.5.]で取得したインスタンス番号
                                       NEW CONTACT_IB_MEMO_OBJ('MEMO_TYPE', row_IB_CONST_WK.MEMO_TYPE),               -- [4.1.]で取得したMEMO_TYPE
                                       NEW CONTACT_IB_MEMO_OBJ('TITLE', row_IB_CONST_WK.TITLE),                       -- [4.1.]で取得したTITLE
                                       NEW CONTACT_IB_MEMO_OBJ('MEMO', row_IB_CONST_WK.MEMO),                         -- [4.1.]で取得したMEMO
                                       NEW CONTACT_IB_MEMO_OBJ('SORT_NO', '10')                                      -- 10 (固定) 
                                     );
              --********************************************************************
              -- 5.7.設置機器メモ情報追加更新APIのコール
              -- 設置機器メモ情報追加更新APIを呼び出す。
              --********************************************************************
              PRAM_PLACE_HOLDER   := '設置機器メモ情報更新';

                CSG02_IB_COMMON_PKG.CSG02_PROC_IB_MEMO_INFO_UPDATE(
                                                                    0,
                                                                    p_INSTANCE_ID,
                                                                    NULL,
                                                                    tIB_MEMO,
                                                                    'BAT-CSG02-0203',
                                                                    INPUT_PROCESS_ID,
                                                                    INPUT_USER_ID,
                                                                    'N',
                                                                    NULL,
                                                                    OUT_RESULT_CD,
                                                                    OUT_ERR_CONTENT,
                                                                    p_INSTANCE_ID_CMIMI,
                                                                    p_MEMO_CMIMI,
                                                                    p_UPDATE_DATE_CMIMI
                                                                  );
                  CASE 
                    WHEN OUT_RESULT_CD = 0  THEN --正常
                      --********************************************************************
                      -- 5.8.正常件数のカウントアップ
                      -- 処理結果の正常件数をカウントアップ（保持）する。
                      --********************************************************************
                      g_normal_sel_cnt          := g_normal_sel_cnt + 1;
                      p_ASSIGN_FLAG             := '1';                        -- 紐付済フラグ "1" (紐付済)　／　"2"(エラー)
                    WHEN OUT_RESULT_CD = 21 THEN -- [マスタ存在チェックエラーの場合]
                      p_INVENTORY_ITEM_CODE := row_IB_CONST_WK.INVENTORY_ITEM_CODE; -- 品目コード
                      p_SERIAL_NO           := row_IB_CONST_WK.SERIAL_NO;           -- シリアル番号
                      v_Content             := OUT_ERR_CONTENT;                     -- 返却された「エラーメッセージ」
                      OUT_ERR_DETAIL  := '登録できなかったレコードが存在します。 品目コード： ' 
                                            || p_INVENTORY_ITEM_CODE || ' シリアル番号： ' 
                                            || p_SERIAL_NO || ' エラー内容: ' || v_Content;
                      DBMS_OUTPUT.PUT_LINE(OUT_ERR_DETAIL);

                      -- ・処理結果の警告件数としてカウントアップ（保持）する。
                      g_warnings_sel_cnt          := g_warnings_sel_cnt + 1;
                      -- ・中間ワークの紐付済フラグを「2:エラー」に更新し、次のレコードの処理に遷移する。（「5.9.中間ワーク更新」に遷移）
                      p_ASSIGN_FLAG               := '2';                    -- 紐付済フラグ "1" (紐付済)　／　"2"(エラー)

                  ELSE    --その他エラー
                    RAISE P_EXCEPTION;
                END CASE;

          END IF;

        END IF;
      --********************************************************************
      -- 5.9.中間ワーク更新
      -- 設置機器構成情報ワークの紐付済フラグを「1:紐付済」に更新する。
      --********************************************************************          
        UPDATE CSG_P_IB_CONST_WK                            -- 設置機器構成情報ワーク
           SET ASSIGN_FLAG    = p_ASSIGN_FLAG,              -- 紐付済フラグ "1" (紐付済)　／　"2"(エラー)
               UPDATE_USER_ID = INPUT_USER_ID,              -- 更新者 バッチ実行ユーザID
               UPDATE_DATE    = set_sysdate                     -- 更新日時 システム日時
         WHERE IB_CONST_ID    = row_IB_CONST_WK.IB_CONST_ID;-- 設置機器構成ID [4.1.]で取得したデータの設置機器構成ID

        COMMIT;

      END;
  --****************************************************************************
  -- 4.処理対象データの取得(最上位)
  -- 4.1.最上位インスタンスの取得
  --****************************************************************************
  <<END_LOOP>>
  NULL;
  END LOOP CUR_IB_CONST_WK_LOOP;

  --****************************************************************************
  -- 5.10.コミットの実行
  --****************************************************************************
  --COMMIT;

  --****************************************************************************
  -- 6.処理対象データの取得(第2階層、第3階層)
  -- 6.1.子インスタンスの取得
  -- 以下の条件に合致するデータを設置機器情報中間ワークより取得する。
  --****************************************************************************
  FOR l_cnt IN 1..2 LOOP
  
    <<CUR_IB_CONST_WK02_LOOP>>
    FOR row_IB_CONST_WK02 IN CUR_IB_CONST_WK02
      LOOP
        BEGIN
          p_ASSIGN_FLAG             := '1';                        -- 紐付済フラグ
          --**********************************************************************
          -- 7.2.重複チェック
          -- 処理7.1で取得した「設置機器情報テーブルのインスタンス番号」がNULLでない場合、以下のメッセージを出力する。
          -- エラーメッセージ                             プレースホルダ
          -- MSG-CSG-W-2029                             {0}：[6.1.]で取得した品目コード
          --                                            {1}：[6.1.]で取得したシリアル番号
          --                                            {2}：「既に登録されています」
          -- ・処理結果の警告件数としてカウントアップ（保持）する。
          -- ・中間ワークの紐付済フラグを「2:エラー」に更新し、次のレコードの処理に遷移する。（「7.9.中間ワーク更新」に遷移）
          --**********************************************************************
          IF row_IB_CONST_WK02.INSTANCE_ID IS NOT NULL THEN
              p_INVENTORY_ITEM_CODE := row_IB_CONST_WK02.INVENTORY_ITEM_CODE; -- 品目コード
              p_SERIAL_NO           := row_IB_CONST_WK02.SERIAL_NO;           -- シリアル番号
              v_Content             := '「既に登録されています」';
              OUT_ERR_DETAIL  := '登録できなかったレコードが存在します。 品目コード： ' 
                                  || p_INVENTORY_ITEM_CODE || ' シリアル番号： ' 
                                  || p_SERIAL_NO || ' エラー内容: ' || v_Content;
              DBMS_OUTPUT.PUT_LINE(OUT_ERR_DETAIL);
              g_warnings_sel_cnt          := g_warnings_sel_cnt + 1;
              p_ASSIGN_FLAG               := '2';                    -- 紐付済フラグ "1" (紐付済)　／　"2"(エラー)

          ELSE
            --********************************************************************
            -- 7.2.親インスタンスの検索
            -- 対象データの親情報を設置機器情報から取得する。
            --********************************************************************
            PRAM_PLACE_HOLDER   := '親情報を設置機器情報から取得する';
              BEGIN
                SELECT CIBI.INSTANCE_ID,                                                -- インスタンス番号
                       CIBI.PARENT_INSTANCE_ID,                                         -- 親インスタンス番号
                       CIBI.TOP_INSTANCE_ID,                                            -- 最上位インスタンス番号
                       CIBI.INVENTORY_ITEM_CODE,                                        -- 品目コード
                       CIBI.SERIAL_NO                                                   -- シリアル番号
                  INTO p_INSTANCE_ID_IBI,                                               --
                       p_PARENT_INSTANCE_ID_IBI,                                        --
                       p_TOP_INSTANCE_ID_IBI,                                           --
                       p_INVENTORY_ITEM_CODE_IBI,                                       --
                       p_SERIAL_NO_IBI                                                  --
                  FROM CSG_M_IB_INFO CIBI                                               -- 設置機器情報
                 WHERE CIBI.INVENTORY_ITEM_CODE = row_IB_CONST_WK02.PARENT_INVENTORY_ITEM_CODE -- 品目コード 対象データ（処理6.1）の親品目コード
                   AND CIBI.SERIAL_NO           = row_IB_CONST_WK02.PARENT_SRIAL_NO;          -- シリアル番号 対象データ（処理6.1）の親シリアル番号
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  CONTINUE;
              END;
            --********************************************************************
            -- 7.4.設置機器情報の設定
            -- 対象データを設置機器情報に設定する。
            -- ※以下の内容は、設置機器・共通テーブル追加更新APIのパラメータ「設置機器情報」として、設定する。
            -- ※上記以外の項目の更新内容とエラー処理に関しては、処理[5.3]と同様の内容となる為、割愛する。
            -- ＜注＞最上位インスタンスではない為、設置機器共通情報の登録は行わない。
            -- ※項目が設定されていても無視する。
            --********************************************************************
            PRAM_PLACE_HOLDER   := '設置機器情報の設定';
              tIB_BASE             := NEW ARRAY_IB_BASE(
                                      NEW CONTACT_IB_BASE_OBJ('PARENT_INSTANCE_ID', p_INSTANCE_ID_IBI),                                    -- 処理7.3で取得したインスタンス番号
                                      NEW CONTACT_IB_BASE_OBJ('TOP_INSTANCE_ID', p_TOP_INSTANCE_ID_IBI),                                   -- 処理7.3で取得した最上位インスタンス番号
                                      NEW CONTACT_IB_BASE_OBJ('INVENTORY_ITEM_CODE', row_IB_CONST_WK02.INVENTORY_ITEM_CODE),               -- [4.1.]で取得したINVENTORY_ITEM_CODE
                                      NEW CONTACT_IB_BASE_OBJ('ORG_ID', row_IB_CONST_WK02.ORG_ID),                                         -- [4.1.]で取得したORG_ID
                                      NEW CONTACT_IB_BASE_OBJ('INVENTORY_ITEM_NAME', row_IB_CONST_WK02.ITEM_REMARKS),                      -- [4.1.]で取得したITEM_REMARKS
                                      NEW CONTACT_IB_BASE_OBJ('SERIAL_NO', row_IB_CONST_WK02.SERIAL_NO),                                   -- [4.1.]で取得したSERIAL_NO
                                      NEW CONTACT_IB_BASE_OBJ('MAIN_OPTION_TYPE', '1'),                                                    -- TODO : CSVファイルに穂対オプション区分の項目が無い
                                      NEW CONTACT_IB_BASE_OBJ('IB_SYNC_STATUS', '10009'),                                                  -- Normalのコード「10009」を設定
                                      NEW CONTACT_IB_BASE_OBJ('QUANTITY', row_IB_CONST_WK02.QUANTITY),                                     -- [4.1.]で取得したQUANTITY
                                      NEW CONTACT_IB_BASE_OBJ('INSTALL_DATE', TO_DATE(row_IB_CONST_WK02.INSTALL_DATE, 'YYYY/MM/DD')),      -- [4.1.]で取得したINSTALL_DATE
                                      NEW CONTACT_IB_BASE_OBJ('SALES_DATE', TO_DATE(row_IB_CONST_WK02.SALES_DATE, 'YYYY/MM/DD')),          -- [4.1.]で取得したSALES_DATE
                                      NEW CONTACT_IB_BASE_OBJ('TRANSFER_FLAG', row_IB_CONST_WK02.TRANSFER_FLAG),                           -- [4.1.]で取得したTRANSFER_FLAG
                                      NEW CONTACT_IB_BASE_OBJ('TRANSFER_MAINTENANCE_FROM', row_IB_CONST_WK02.TRANSFER_MAINTENANCE_FROM),   -- [4.1.]で取得したTRANSFER_MAINTENANCE_FROM
                                      NEW CONTACT_IB_BASE_OBJ('TRANSFER_MAINTENANCE_DATE', TO_DATE(row_IB_CONST_WK02.TRANSFER_MAINTENANCE_DATE, 'YYYY/MM/DD')),   -- [4.1.]で取得したTRANSFER_MAINTENANCE_DATE
                                      NEW CONTACT_IB_BASE_OBJ('TRANSFER_MAINTNANCE_REASON', row_IB_CONST_WK02.TRANSFER_MAINTENANCE_REASON),-- [4.1.]で取得したTRANSFER_MAINTENANCE_REASON
                                      NEW CONTACT_IB_BASE_OBJ('SALES_OWNER_CODE', row_IB_CONST_WK02.SALES_OWNER_CODE),                     -- [4.1.]で取得したSALES_OWNER_CODE
                                      NEW CONTACT_IB_BASE_OBJ('MAINTENANCE_TYPE', row_IB_CONST_WK02.MAINTENANCE_TYPE),                     -- [4.1.]で取得したMAINTENANCE_TYPE
                                      NEW CONTACT_IB_BASE_OBJ('SERVICE_CONDITION', row_IB_CONST_WK02.SERVICE_CONDITION),                   -- [4.1.]で取得したSERVICE_CONDITION
                                      NEW CONTACT_IB_BASE_OBJ('OUT_SOURCING_FLAG', row_IB_CONST_WK02.OUT_SOURCING_FLAG),                   -- [4.1.]で取得したOUT_SOURCING_FLAG
                                      NEW CONTACT_IB_BASE_OBJ('HOST_NAME', row_IB_CONST_WK02.HOST_NAME),                                   -- [4.1.]で取得したHOST_NAME
                                      NEW CONTACT_IB_BASE_OBJ('SYSTEM_NAME', row_IB_CONST_WK02.SYSTEM_NAME),                               -- [4.1.]で取得したSYSTEM_NAME
                                      NEW CONTACT_IB_BASE_OBJ('SUPPORT_START_DATE', TO_DATE(row_IB_CONST_WK02.SUPPORT_START_DATE, 'YYYY/MM/DD')), -- [4.1.]で取得したSUPPORT_START_DATE
                                      NEW CONTACT_IB_BASE_OBJ('SUPPORT_END_DATE', TO_DATE(row_IB_CONST_WK02.SUPPORT_END_DATE, 'YYYY/MM/DD')), -- [4.1.]で取得したSUPPORT_END_DATE
                                      NEW CONTACT_IB_BASE_OBJ('SUPPORT_INSTRUCT_CODE', row_IB_CONST_WK02.SUPPORT_INSTRUCT_CODE),           -- [4.1.]で取得したSUPPORT_INSTRUCT_CODE
                                      NEW CONTACT_IB_BASE_OBJ('FIRST_COVERAGE', row_IB_CONST_WK02.FIRST_COVERAGE),                         -- [4.1.]で取得したFIRST_COVERAGE
                                      NEW CONTACT_IB_BASE_OBJ('FIRST_MONTHS', TO_NUMBER(row_IB_CONST_WK02.FIRST_MONTHS)),                  -- [4.1.]で取得したFIRST_MONTHS
                                      NEW CONTACT_IB_BASE_OBJ('FIRST_START_DATE', TO_DATE(row_IB_CONST_WK02.FIRST_START_DATE, 'YYYY/MM/DD')), -- [4.1.]で取得したFIRST_START_DATE
                                      NEW CONTACT_IB_BASE_OBJ('FIRST_END_DATE', p_FIRST_END_DATE_IBI),                                     -- ※１　参照
                                      NEW CONTACT_IB_BASE_OBJ('NEXT_COVERAGE', row_IB_CONST_WK02.NEXT_COVERAGE),                           -- [4.1.]で取得したNEXT_COVERAGE
                                      NEW CONTACT_IB_BASE_OBJ('NEXT_MONTHS', TO_NUMBER(row_IB_CONST_WK02.NEXT_MONTHS)),                    -- [4.1.]で取得したNEXT_MONTHS
                                      NEW CONTACT_IB_BASE_OBJ('NEXT_START_DATE', p_NEXT_START_DATE_IBI),                                   -- ※2　参照
                                      NEW CONTACT_IB_BASE_OBJ('NEXT_END_DATE', p_NEXT_END_DATE_IBI),                                       -- ※2　参照
                                      NEW CONTACT_IB_BASE_OBJ('AGENT_FLAG', row_IB_CONST_WK02.AGENT_FLAG),                                 -- [4.1.]で取得したAGENT_FLAG
                                      NEW CONTACT_IB_BASE_OBJ('BUNDLE_ITEM_CODE', row_IB_CONST_WK02.BUNDLE_ITEM_CODE),                     -- [4.1.]で取得したBUNDLE_ITEM_CODE
                                      NEW CONTACT_IB_BASE_OBJ('BUNDLE_ITEM_NAME', row_IB_CONST_WK02.BUNDLE_ITEM_NAME),                     -- [4.1.]で取得したBUNDLE_ITEM_NAME
                                      NEW CONTACT_IB_BASE_OBJ('BUNDLE_SERIAL_NO', row_IB_CONST_WK02.BUNDLE_SERAIL_NO),                     -- [4.1.]で取得したBUNDLE_SERAIL_NO
                                      NEW CONTACT_IB_BASE_OBJ('HOST_ID', row_IB_CONST_WK02.HOST_ID),                                       -- [4.1.]で取得したHOST_ID
                                      NEW CONTACT_IB_BASE_OBJ('KEEP_WATCH_SYSTEM_ID', row_IB_CONST_WK02.KEEP_WATCH_SYSTEM_ID),             -- [4.1.]で取得したKEEP_WATCH_SYSTEM_ID
                                      NEW CONTACT_IB_BASE_OBJ('OS_TYPE', row_IB_CONST_WK02.OS_TYPE),                                       -- [4.1.]で取得したOS_TYPE
                                      NEW CONTACT_IB_BASE_OBJ('OS_VERSION', row_IB_CONST_WK02.OS_VERSION),                                 -- [4.1.]で取得したOS_VERSION
                                      NEW CONTACT_IB_BASE_OBJ('REVISION', row_IB_CONST_WK02.REVISION),                                     -- [4.1.]で取得したREVISION
                                      NEW CONTACT_IB_BASE_OBJ('LICENSE_MANAGEMENT_NO', row_IB_CONST_WK02.LICENSE_MANAGEMENT_NO),           -- [4.1.]で取得したLICENSE_MANAGEMENT_NO
                                      NEW CONTACT_IB_BASE_OBJ('SUPERINTENDE_MANAGE_NO', row_IB_CONST_WK02.SUPERINTENDE_MANAGE_NO),         -- [4.1.]で取得したSUPERINTENDE_MANAGE_NO
                                      NEW CONTACT_IB_BASE_OBJ('LISENCE_START_DATE', TO_DATE(row_IB_CONST_WK02.LISENCE_START_DATE, 'YYYY/MM/DD')), -- [4.1.]で取得したLISENCE_START_DATE
                                      NEW CONTACT_IB_BASE_OBJ('LISENCE_END_DATE', TO_DATE(row_IB_CONST_WK02.LISENCE_END_DATE, 'YYYY/MM/DD')), -- [4.1.]で取得したLISENCE_END_DATE
                                      NEW CONTACT_IB_BASE_OBJ('REMOVE_ORDER_NO', row_IB_CONST_WK02.REMOVE_ORDER_NO),                       -- [4.1.]で取得したREMOVE_ORDER_NO
                                      NEW CONTACT_IB_BASE_OBJ('REMOVE_PO_NO', row_IB_CONST_WK02.REMOVE_PO_NO),                             -- [4.1.]で取得したREMOVE_PO_NO
                                      NEW CONTACT_IB_BASE_OBJ('REMOVE_DATE', TO_DATE(row_IB_CONST_WK02.REMOVE_DATE, 'YYYY/MM/DD')),        -- [4.1.]で取得したREMOVE_DATE
                                      NEW CONTACT_IB_BASE_OBJ('REMOVE_REASON', row_IB_CONST_WK02.REMOVE_REASON),                           -- [4.1.]で取得したREMOVE_REASON
                                      NEW CONTACT_IB_BASE_OBJ('SALES_DEPT_ORG_ID', row_IB_CONST_WK02.SALES_DEPT_ORG_ID),                   -- [4.1.]で取得したSALES_DEPT_ORG_ID
                                      NEW CONTACT_IB_BASE_OBJ('SALES_DEPT_PERSON_ID', row_IB_CONST_WK02.SALES_DEPT_PERSON_ID),             -- [4.1.]で取得したSALES_DEPT_PERSON_ID
                                      NEW CONTACT_IB_BASE_OBJ('PRESENT_DEPT_ORG_ID', row_IB_CONST_WK02.PRESENT_DEPT_ORG_ID),               -- [4.1.]で取得したPRESENT_DEPT_ORG_ID
                                      NEW CONTACT_IB_BASE_OBJ('CTC_SALESREP_PERSON_ID', row_IB_CONST_WK02.CTC_SALESREP_PERSON_ID),         -- [4.1.]で取得したCTC_SALESREP_PERSON_ID
                                      NEW CONTACT_IB_BASE_OBJ('MAINTE_BUS_DEPT_ORG_ID', row_IB_CONST_WK02.MAINTE_BUS_DEPT_ORG_ID),         -- [4.1.]で取得したMAINTE_BUS_DEPT_ORG_ID
                                      NEW CONTACT_IB_BASE_OBJ('MAINTE_BUS_PERSON_ID', row_IB_CONST_WK02.MAINTE_BUS_PERSON_ID),             -- [4.1.]で取得したMAINTE_BUS_PERSON_ID
                                      NEW CONTACT_IB_BASE_OBJ('OUT_WARRANTY_REGISTERED_FLAG', '3')                                         -- ’3’(出荷実績以外)を固定
                                      );
            --********************************************************************
            -- 7.5.設置機器・共通テーブル追加更新APIのコール
            -- 設置機器・共通テーブル追加更新APIを呼び出す。
            --********************************************************************
            PRAM_PLACE_HOLDER   := '設置機器・設置機器共通情報更新';

              CSG02_IB_COMMON_PKG.CSG02_PROC_IB_TABLE_UPDATE(
                                                              0,
                                                              NULL,
                                                              p_TOP_INSTANCE_ID_IBI,
                                                              tIB_BASE,
                                                              NULL,
                                                              'BAT-CSG02-0203',
                                                              INPUT_PROCESS_ID,
                                                              INPUT_USER_ID,
                                                              'N',
                                                              NULL,
                                                              OUT_RESULT_CD,
                                                              OUT_ERR_CONTENT,
                                                              p_INSTANCE_ID,
                                                              p_UPDATE_DATE_IBI
                                                            );
              CASE 
                WHEN OUT_RESULT_CD = 0  THEN --正常
                  NULL;--nop
                WHEN OUT_RESULT_CD = 21 THEN -- [マスタ存在チェックエラーの場合]
                  p_INVENTORY_ITEM_CODE := row_IB_CONST_WK02.INVENTORY_ITEM_CODE; -- 品目コード
                  p_SERIAL_NO           := row_IB_CONST_WK02.SERIAL_NO;           -- シリアル番号
                  v_Content             := OUT_ERR_CONTENT;                     -- 返却された「エラーメッセージ」

                  OUT_ERR_DETAIL  := '登録できなかったレコードが存在します。 品目コード： ' 
                                      || p_INVENTORY_ITEM_CODE || ' シリアル番号： ' 
                                      || p_SERIAL_NO || ' エラー内容: ' || v_Content;
                  DBMS_OUTPUT.PUT_LINE(OUT_ERR_DETAIL);

                  -- ・処理結果の警告件数としてカウントアップ（保持）する。
                  g_warnings_sel_cnt          := g_warnings_sel_cnt + 1;

                  -- ・中間ワークの紐付済フラグを「2:エラー」に更新し、次のレコードの処理に遷移する。（「7.9.中間ワーク更新」に遷移）
                  p_ASSIGN_FLAG               := '2';                    -- 紐付済フラグ "1" (紐付済)　／　"2"(エラー)

                ELSE    --その他エラー
                  RAISE P_EXCEPTION;
              END CASE;

              IF row_IB_CONST_WK02.MEMO_TYPE IS NOT NULL AND 
                row_IB_CONST_WK02.TITLE IS NOT NULL AND 
                row_IB_CONST_WK02.MEMO IS NOT NULL 
              AND p_ASSIGN_FLAG = '1'  THEN --7.5.処理結果=正常
              
                PRAM_PLACE_HOLDER   := '設置機器メモ情報の設定';
                
                  tIB_MEMO          := NEW ARRAY_IB_MEMO(
    --                                   NEW CONTACT_IB_MEMO_OBJ('INSTANCE_MEMO_ID', v_INSTANCE_MEMO_ID_CMIMI),       -- Oracleシーケンスで採番したメモID　※APIにて払い出し
    --                                   NEW CONTACT_IB_MEMO_OBJ('INSTANCE_ID', p_INSTANCE_ID),                       -- [7.5.]で取得したインスタンス番号
                                       NEW CONTACT_IB_MEMO_OBJ('MEMO_TYPE', row_IB_CONST_WK02.MEMO_TYPE),           -- [4.1.]で取得したMEMO_TYPE
                                       NEW CONTACT_IB_MEMO_OBJ('TITLE', row_IB_CONST_WK02.TITLE),                   -- [4.1.]で取得したTITLE
                                       NEW CONTACT_IB_MEMO_OBJ('MEMO', ROW_IB_CONST_WK02.MEMO),                     -- [4.1.]で取得したMEMO
                                       NEW CONTACT_IB_MEMO_OBJ('SORT_NO', '10')                                    -- 10 (固定) 
    --                                   NEW CONTACT_IB_MEMO_OBJ('PROGRAM_ID', 'BAT-CSG02-0203'),                     -- "BAT-CSG02-0203"
    --                                   NEW CONTACT_IB_MEMO_OBJ('PROCESS_ID', INPUT_PROCESS_ID),                     -- [0.3.]で取得した処理ID
    --                                   NEW CONTACT_IB_MEMO_OBJ('CREATION_USER_ID', INPUT_USER_ID),                  -- [0.2.]で取得したバッチ実行ユーザID
    --                                   NEW CONTACT_IB_MEMO_OBJ('CREATION_DATE', SYSDATE),                           -- [0.1.システム日時の取得]にて取得したシステム日時
    --                                   NEW CONTACT_IB_MEMO_OBJ('UPDATE_USER_ID', INPUT_USER_ID),                    -- [0.2.]で取得したバッチ実行ユーザID
    --                                   NEW CONTACT_IB_MEMO_OBJ('UPDATE_DATE', SYSDATE)                              -- [0.1.システム日時の取得]にて取得したシステム日時
                                      );
                --********************************************************************
                -- 7.7.設置機器メモ情報追加更新APIのコール
                -- 設置機器メモ情報追加更新APIを呼び出す。
                --********************************************************************
                PRAM_PLACE_HOLDER   := '設置機器メモ情報更新';

                  CSG02_IB_COMMON_PKG.CSG02_PROC_IB_MEMO_INFO_UPDATE(
                                                                      0,
                                                                      p_INSTANCE_ID,
                                                                      v_INSTANCE_MEMO_ID_CMIMI,  --NULL,
                                                                      tIB_MEMO,
                                                                      'BAT-CSG02-0203',
                                                                      INPUT_PROCESS_ID,
                                                                      INPUT_USER_ID,
                                                                      'N',
                                                                      NULL,
                                                                      OUT_RESULT_CD,
                                                                      OUT_ERR_CONTENT,
                                                                      p_INSTANCE_ID_CMIMI,
                                                                      p_MEMO_CMIMI,
                                                                      p_UPDATE_DATE_CMIMI
                                                                    );

                  CASE 
                    WHEN OUT_RESULT_CD = 0  THEN --正常
                      --********************************************************************
                      -- 7.8.正常件数のカウントアップ
                      -- 処理結果の正常件数をカウントアップ（保持）する。
                      --********************************************************************
                      g_normal_sel_cnt            := g_normal_sel_cnt + 1;
                      p_ASSIGN_FLAG               := '1';                    -- 紐付済フラグ "1" (紐付済)
                    WHEN OUT_RESULT_CD = 21 THEN -- [マスタ存在チェックエラーの場合]
                      p_INVENTORY_ITEM_CODE := row_IB_CONST_WK02.INVENTORY_ITEM_CODE; -- 品目コード
                      p_SERIAL_NO           := row_IB_CONST_WK02.SERIAL_NO;           -- シリアル番号
                      v_Content             := OUT_ERR_CONTENT;                     -- 返却された「エラーメッセージ」

                      OUT_ERR_DETAIL  := '登録できなかったレコードが存在します。 品目コード： ' 
                                      || p_INVENTORY_ITEM_CODE || ' シリアル番号： ' 
                                      || p_SERIAL_NO || ' エラー内容: ' || v_Content;
                      DBMS_OUTPUT.PUT_LINE(OUT_ERR_DETAIL);

                      -- ・処理結果の警告件数としてカウントアップ（保持）する。
                      g_warnings_sel_cnt          := g_warnings_sel_cnt + 1;

                      -- ・中間ワークの紐付済フラグを「2:エラー」に更新し、次のレコードの処理に遷移する。（「7.9.中間ワーク更新」に遷移）
                      p_ASSIGN_FLAG               := '2';                    -- 紐付済フラグ "1" (紐付済)　／　"2"(エラー)

                    ELSE    --その他エラー
                      RAISE P_EXCEPTION;
                  END CASE;

              END IF;
          END IF;

        --********************************************************************
        -- 7.9.中間ワーク更新
        -- 設置機器構成情報ワークの紐付済フラグを「1:紐付済」に更新する。
        --********************************************************************          
          UPDATE CSG_P_IB_CONST_WK                               -- 設置機器構成情報ワーク
           SET ASSIGN_FLAG    = p_ASSIGN_FLAG,                 -- 紐付済フラグ "1" (紐付済)　／　"2"(エラー)
               UPDATE_USER_ID = INPUT_USER_ID,                 -- 更新者 バッチ実行ユーザID
               UPDATE_DATE    = set_sysdate                        -- 更新日時 システム日時
         WHERE IB_CONST_ID    = row_IB_CONST_WK02.IB_CONST_ID; -- 設置機器構成ID [7.1.]で取得したデータの設置機器構成ID
        --****************************************************************************
        -- 7.10.コミットの実行
        --****************************************************************************
          COMMIT;
          
        END;
       <<END_LOOP>>
       NULL;
       END LOOP CUR_IB_CONST_WK02_LOOP;
      END LOOP;


  --**************************************************************************
  -- 8.残件データの取得
  -- 8.1.紐付きなしデータの取得
  -- 上記の処理で残ってしまったデータ（紐付かないレコード）はエラーとしてログに出力する。
  -- 以下の条件に合致するデータを設置機器構成情報ワークより取得する。
  --**************************************************************************
    OPEN CUR_IB_CONST_WK03;
      LOOP
        FETCH CUR_IB_CONST_WK03 INTO row_IB_CONST_WK03;
        --**********************************************************************
        -- [データ取得件数が0件の場合]
        -- 処理「9.終了処理」に遷移　（ステータス：正常終了）
        --**********************************************************************
        EXIT WHEN CUR_IB_CONST_WK03%NOTFOUND;
        --**********************************************************************
        -- [データ取得件数が1件以上存在する場合]
        -- 取得したレコード数分、以下のメッセージを出力する。
        --**********************************************************************
        p_INVENTORY_ITEM_CODE := row_IB_CONST_WK03.INVENTORY_ITEM_CODE; -- 品目コード
        p_SERIAL_NO           := row_IB_CONST_WK03.SERIAL_NO;           -- シリアル番号
        v_Content             := '紐づけるインスタンスが存在しません';
                              
        OUT_ERR_DETAIL  := '登録できなかったレコードが存在します。 品目コード： ' 
                              || p_INVENTORY_ITEM_CODE || ' シリアル番号： ' 
                              || p_SERIAL_NO || ' エラー内容: ' || v_Content;

        -- ・処理結果の警告件数としてカウントアップ（保持）する。
        g_warnings_sel_cnt          := g_warnings_sel_cnt + 1;

      END LOOP;
    CLOSE CUR_IB_CONST_WK03;
  --****************************************************************************
  -- 7.10.コミットの実行
  --****************************************************************************
    COMMIT;
    OUT_STATUS    := '1';
    OUT_RESULT_CD := '0';
    OUT_ERR_CONTENT := '処理結果　対象件数：' || g_target_sel_cnt || '　正常件数：' || g_normal_sel_cnt || '　警告件数：' || g_warnings_sel_cnt;
  EXCEPTION
    WHEN PRAM_EXCEPTION THEN
      -- データの取得に失敗した場合、異常終了としエラーメッセージをログ出力し後続の処理を中断する。
      DBMS_OUTPUT.PUT_LINE(PRAM_PLACE_HOLDER || 'に失敗しました。');
                          
      OUT_RESULT_CD   := '20';
      OUT_STATUS      := '3'; -- 3:エラー
      OUT_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
      OUT_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
      ROLLBACK;
      RETURN;
    WHEN P_EXCEPTION THEN
      DBMS_OUTPUT.PUT_LINE(PRAM_PLACE_HOLDER || 'に失敗しました。');
      OUT_RESULT_CD   := '20';
      OUT_STATUS      := '3';
      OUT_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
      OUT_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
      ROLLBACK;
      RETURN;
    -- その他未定義の例外の処理
    WHEN OTHERS THEN
      -- データの取得に失敗した場合、異常終了としエラーメッセージをログ出力し後続の処理を中断する。
      DBMS_OUTPUT.PUT_LINE(PRAM_PLACE_HOLDER || 'に失敗しました。');
      
      OUT_RESULT_CD   := '20';
      DBMS_OUTPUT.PUT_LINE('ORACLE ERR_CODE    := ' || SQLCODE);            -- ＤＢエラーコード
      DBMS_OUTPUT.PUT_LINE('ORACLE ERR_MESSAGE := ' || SQLERRM(SQLCODE));   -- ＤＢエラーメッセージ
      OUT_STATUS      := '3'; -- 3:エラー
      OUT_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
      OUT_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
      ROLLBACK;
      RETURN;
  END CSG02_PROC_INS_EQUI_SHELF_REG;

END CSG02_0203_PKG;

/
