CREATE OR REPLACE PACKAGE "CSG02_0301_PKG"
AS
/*******************************************************************************
* 設置機器情報中間ワーク移行                                                       *
*-------------------------------------------------------------------------------*
* <更新履歴>                                                                     *
* <Version>   <日付>      <更新概要>                             <更新者>         *
*   1.0     2016/04/01      新規                                FOCUS_LTBINH    *
********************************************************************************/
  /******************************************************************************
  * 設置機器登録（出荷実績）（PL/SQL）                                              *
  * CSG02_0301 (MAIN)                                                           *
  *******************************************************************************/
  PROCEDURE MAIN_CSG02_0301(
      INPUT_USER_ID    IN VARCHAR2 ,         --ユーザID
      INPUT_PROCESS_ID IN VARCHAR2 ,         --プロセスID
      RETURN_PROCESS_ID OUT VARCHAR2 ,       --処理ID
      RETURN_STATUS OUT VARCHAR2 ,           --ステータス
      RETURN_ERR_CONTENT OUT NVARCHAR2 ,     --エラー内容
      RETURN_ERR_DETAIL OUT NVARCHAR2 ,      --エラー詳細
      RETURN_RESULT_CD OUT VARCHAR2          --終了コード
    );

  /******************************************************************************
  * 設置機器登録（出荷実績）（PL/SQL）                                              *
  * CSG02-0301                                                                  *
  *******************************************************************************/
  PROCEDURE CSG02_PROC_INS_EQUIPMENT_REG(
      INPUT_USER_ID    IN VARCHAR2 ,         --ユーザID
      INPUT_PROCESS_ID IN VARCHAR2 ,         --プロセスID
      RETURN_PROCESS_ID OUT VARCHAR2 ,       --処理ID
      RETURN_STATUS OUT VARCHAR2 ,           --ステータス
      RETURN_ERR_CONTENT OUT NVARCHAR2 ,     --エラー内容
      RETURN_ERR_DETAIL OUT NVARCHAR2 ,      --エラー詳細
      RETURN_RESULT_CD OUT VARCHAR2          --終了コード
    );

END CSG02_0301_PKG;
/
