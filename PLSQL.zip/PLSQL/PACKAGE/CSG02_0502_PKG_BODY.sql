CREATE OR REPLACE PACKAGE BODY "CSG02_0502_PKG"
AS
/*******************************************************************************
* 設置先住所登録移行
*-------------------------------------------------------------------------------
* <更新履歴>
* <Version>   <日付>      <更新概要>                             <更新者>
*   1.0     2016/04/04      新規                                FOCUS_LTMINH
*   1.01    2016/05/19      修正                                FOCUS_AOKI
*******************************************************************************/
  /*****************************************************************************
  * 設置先住所登録（PL/SQL）
  * CSG02-0502 (MAIN)
  *****************************************************************************/
  g_shori_point                 VARCHAR2(250);    -- 処理ポイント

  PROCEDURE MAIN_CSG02_0502
  (
    RETURN_PROCESS_ID   OUT VARCHAR2 ,--処理ID
    RETURN_STATUS       OUT VARCHAR2 ,--ステータス
    RETURN_ERR_CONTENT  OUT VARCHAR2 ,--エラー内容
    RETURN_ERR_DETAIL   OUT VARCHAR2 ,--エラー詳細
    RETURN_RESULT_CD    OUT VARCHAR2  -- 終了コード (0  ：正常終了コード  ／  '20' ：異常終了コード)
  )
  AS
    BATCH_USER_ID         NVARCHAR2(250);
    P_EXCEPTION           EXCEPTION;
    BATCH_PROCESS_DATE    DATE;
  BEGIN
    g_shori_point := 'MAIN_CSG02_0502';
    -- *************************************************************************
    -- 0.1.システム日時の取得
    -- システム日時を取得する。
    -- *************************************************************************
    BATCH_PROCESS_DATE := sysdate;

    -- *************************************************************************
    -- 0.2.バッチ実行ユーザID 取得
    -- 汎用マスタより、バッチ実行ユーザIDを取得する。
    -- *************************************************************************
    SELECT SMGS.DTL_TXT_FRML_NM
      INTO BATCH_USER_ID
      FROM SNV_M_GNRC_SNV SMGS
      WHERE KEY_ITEM = 'CSG_GENERAL_PROP'  --(汎用プロパティ)
        AND CD_VAL = 'BATCH_USER';         --(バッチ実行ユーザID)

    -- *************************************************************************
    -- 0.3.処理IDの取得
    -- 開始時バックグラウンド処理を呼び出す。
    -- *************************************************************************
      CSG05_0101_PKG.CSG05_PROC_BG_PROCESS_START(
                                  'BAT-CSG02-0502-01',
                                  '-',
                                  TO_CHAR(BATCH_PROCESS_DATE),
                                  BATCH_USER_ID,
                                  RETURN_PROCESS_ID,
                                  RETURN_RESULT_CD
                                );
    -- *************************************************************************
    -- 処理結果 = "20"（異常終了）の場合
    -- エラーメッセージ[MSG-CSG-F-0003]をログ出力し、後続の処理を中断する。
    -- *************************************************************************
    IF RETURN_RESULT_CD = '20' THEN
        DBMS_OUTPUT.PUT_LINE('処理IDが取得できませんでした。システム管理者に問い合わせてください。');
        RAISE P_EXCEPTION;
    END IF;

    /***************************************************************************
    * 設置先住所登録（PL/SQL）
    * CSG02-0502
    ***************************************************************************/
      CSG02_PROC_INSTALL_ADDR_REGIST(
                                      BATCH_USER_ID,
                                      BATCH_PROCESS_DATE,
                                      RETURN_PROCESS_ID,
                                      RETURN_STATUS,
                                      RETURN_ERR_CONTENT,
                                      RETURN_ERR_DETAIL,
                                      RETURN_RESULT_CD
                                    );

  --****************************************************************************
  -- 3.終了処理
  -- 3.3.実行結果の登録
  -- 終了時バックグラウンド処理を呼び出す。
  --****************************************************************************
      CSG05_0101_PKG.CSG05_PROC_BG_PROCESS_UPD(
                                RETURN_PROCESS_ID,
                                RETURN_STATUS,
                                TO_CHAR(BATCH_PROCESS_DATE),
                                RETURN_ERR_CONTENT,
                                RETURN_ERR_DETAIL,
                                '-',
                                RETURN_RESULT_CD
                              );
    -- *************************************************************************
    -- 処理結果 ≠ 0（正常終了でない）の場合
    -- エラーメッセージ[MSG-CSG-W-0033]をログ出力し、呼び出し元に警告終了コードを返却する
    -- *************************************************************************
    IF RETURN_RESULT_CD <> '0' THEN
        DBMS_OUTPUT.PUT_LINE('処理結果の登録に失敗しました。ダウンロード、エラーログ参照ができない可能性がありますので、処理結果を確認してください。');
        RETURN_RESULT_CD   := '10';
        RETURN_STATUS      := '2';
    END IF;

    EXCEPTION
       WHEN P_EXCEPTION THEN
        RETURN_RESULT_CD   := '20';
        RETURN_STATUS      := '3';
        RETURN_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
        RETURN_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
        ROLLBACK;
        RETURN;
      -- その他未定義の例外の処理
      WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('ORACLE ERR_CODE    := ' || SQLCODE);          -- ＤＢエラーコード
        DBMS_OUTPUT.PUT_LINE('ORACLE ERR_MESSAGE := ' || SQLERRM(SQLCODE)); -- ＤＢエラーメッセージ
        DBMS_OUTPUT.PUT_LINE('PROC POINT         := ' || g_shori_point);    -- 処理ポイント
        RETURN_RESULT_CD   := '20';
        RETURN_STATUS      := '3'; -- 3:エラー
        RETURN_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
        RETURN_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
        ROLLBACK;
        RETURN;
  END MAIN_CSG02_0502;

  /*****************************************************************************
  * 設置先住所登録（PL/SQL）
  * CSG02-0502
  *****************************************************************************/
  PROCEDURE CSG02_PROC_INSTALL_ADDR_REGIST
  (
    INPUT_BATCH_USER_ID       IN VARCHAR2,            -- バッチユーザID
    INPUT_BATCH_PROCESS_DATE  IN DATE DEFAULT NULL,   -- バッチ処理日
    INPUT_PROCESS_ID          IN VARCHAR2,            -- プロセスID
    RETURN_STATUS             OUT VARCHAR2 ,          --ステータス
    RETURN_ERR_CONTENT        OUT VARCHAR2 ,          --エラー内容
    RETURN_ERR_DETAIL         OUT VARCHAR2 ,          --エラー詳細
    RETURN_RESULT_CD          OUT VARCHAR2            -- 終了コード
  )
  AS
  -- ***************************************************************************
  -- 処理パラメータ
  -- ***************************************************************************
  P_PLACE_HOLDER              VARCHAR2(100);     -- プレースホルダパラメータ
  P_PROCESS_DATE              CSG_T_BATCH_DATE.PROCESS_DATE%type; -- 処理日時
  P_BATCH_DATE                CSG_T_BATCH_DATE.PROCESS_DATE%type; -- 処理日時
  P_BATCH_PROCESS_DATE        DATE;
  P_CUST_CD                   SNV_M_CUST.CUST_CD%type;
  P_INSTALL_LOCATION          CSG_M_IB_ADDRESS.INSTALL_LOCATION%type;
  P_INSTALL_LOCATION_CODE     CSG_M_IB_ADDRESS.INSTALL_LOCATION_CODE%type;
  P_ROW_COUNT                 NUMBER;
  --****************************************************************************
  -- 1.1.出荷先住所取得
  -- 顧客マスタより出荷先の情報を取得する。
  --****************************************************************************
  CURSOR cur_SNV_M_CUST (PROCESS_DATE DATE) IS
     SELECT SNV_M_CUST.CUST_CD      -- 顧客コード
      , SNV_M_CUST.POST_NO          -- 郵便番号
      , SNV_M_CUST.PRFCTRS          -- 都道府県
      , SNV_M_CUST.ADDR             -- 市区町村
      , SNV_M_CUST.BLOK             -- 番地
      , SNV_M_CUST.BLDG_NM          -- 建物名
      , SNV_M_CUST.GRP_KEY          -- グループキー
    FROM SNV_M_CUST                 -- 顧客マスタ
    INNER JOIN SNV_M_GNRC_SNV GRS ON SNV_M_CUST.CUST_ACCT_GRP = GRS．CD_VAL
    WHERE SNV_M_CUST.BAT_UPDATE_DATE  > PROCESS_DATE  --0.4で取得した前回処理日時
      AND GRS.KEY_ITEM = 'ACCOUNT_GROUP'  -- キー項目が「勘定グループ」
      AND GRS.PARM3='Y'                   -- パラメータ３(代表出荷先使用可能)が’Y’
      AND NVL(GRS.DEL_FLG,'N') <> 'X';    -- 削除フラグが「削除」以外

    row_SNV_M_CUST cur_SNV_M_CUST%ROWTYPE;
  BEGIN
    g_shori_point           := 'CSG02_PROC_INSTALL_ADDR_REGIST';
    RETURN_STATUS           := 0;
    RETURN_ERR_CONTENT      := '';
    RETURN_ERR_DETAIL       := '';
    RETURN_RESULT_CD        := '0';
    P_CUST_CD               := '';
    P_INSTALL_LOCATION_CODE := 0;

    IF INPUT_BATCH_PROCESS_DATE IS NULL THEN
      P_BATCH_PROCESS_DATE := sysdate;
    ELSE
      P_BATCH_PROCESS_DATE := INPUT_BATCH_PROCESS_DATE;
    END IF;
    -- *************************************************************************
    -- 0.4.前回処理日時の取得
    -- 前回処理日時を取得する。
    -- *************************************************************************
    BEGIN
      SELECT PROCESS_DATE
        INTO P_BATCH_DATE
        FROM CSG_T_BATCH_DATE
       WHERE EXC_PROGRAM_ID = 'BAT-CSG02-0502-01';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        --RETURN_RESULT_CD   := '10';
        --RETURN_STATUS      := '2'; -- 2:警告終了
        RETURN_ERR_CONTENT := 'マスタに存在しない前回処理日時が設定されています。';
        RETURN_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
    END;
    -- *************************************************************************
    -- ※取得できなかった場合は、初回起動とみなし前回処理日時を1900/01/01として保持する
    -- *************************************************************************
    IF P_BATCH_DATE IS NULL THEN
      P_PROCESS_DATE := '1900/01/01';
    ELSE
      P_PROCESS_DATE := P_BATCH_DATE;
    END IF;

    OPEN CUR_SNV_M_CUST(P_PROCESS_DATE);
    LOOP
      FETCH cur_SNV_M_CUST INTO row_SNV_M_CUST;
      -- [1.1.]で取得したデータの件数が0件の場合、正常終了として後続の処理を中断する。
      EXIT WHEN cur_SNV_M_CUST%NOTFOUND;

      --************************************************************************
      -- 2.2.法人格の顧客コードを取得
      -- 顧客マスタより出荷先に紐づく法人格の顧客コードを取得する。
      --************************************************************************
      BEGIN
        SELECT CUST_CD                            -- 顧客コード
          INTO P_CUST_CD
          FROM SNV_M_CUST                           -- 顧客マスタ
         WHERE GRP_KEY = row_SNV_M_CUST.GRP_KEY    --  [1.1.]で取得したグループキー
           AND CUST_ACCT_GRP = 'Z001';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          --RETURN_RESULT_CD   := '10';
          --RETURN_STATUS      := '2'; -- 2:警告終了
          RETURN_ERR_CONTENT := 'マスタに存在しない顧客コードが設定されています。';
          RETURN_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
      END;
      --************************************************************************
      -- 2.3.設置先住所編集
      -- [1.1.]で取得した情報を設置先住所マスタに登録するためにデータの編集を行う。
      --************************************************************************
      -- 都道府県 + 市区町村 + 番地 + 建物名 = 住所
      P_INSTALL_LOCATION := row_SNV_M_CUST.PRFCTRS || row_SNV_M_CUST.ADDR ||
                                row_SNV_M_CUST.BLOK || row_SNV_M_CUST.BLDG_NM;

      -- 設置先住所コード
      SELECT CSG_M_INSTALL_LOCATION_ID_SEQ.NEXTVAL
        INTO P_INSTALL_LOCATION_CODE
        FROM DUAL;

      --************************************************************************
      -- 2.4.設置先住所マスタ存在チェック
      -- 対象の出荷先データが出荷先住所マスタに既に登録されているかチェックする。
      --************************************************************************
      --BEGIN
        SELECT COUNT(*)
          INTO P_ROW_COUNT
          FROM CSG_M_IB_ADDRESS
         WHERE SHIPMENT_LOCATION_CODE = row_SNV_M_CUST.CUST_CD; --[1.1.]で取得した「顧客コード」
      --EXCEPTION
      --  WHEN NO_DATA_FOUND THEN
      --    RETURN_RESULT_CD := '10';
      --    RETURN_STATUS      := '2'; -- 2:警告終了
      --    RETURN_ERR_CONTENT := 'マスタに存在しない顧客コードが設定されています。';
      --    RETURN_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
      --END;
      --************************************************************************
      -- 上記で取得したデータの件数が0件の場合、処理[2.5](追加処理)を実行する。
      -- 上記で取得したデータの件数が1件以上の場合、処理[2.6](更新処理)を実行する。
      --************************************************************************
      IF P_ROW_COUNT = 0 THEN
        --**********************************************************************
        -- 2.5.設置先住所マスタデータ追加
        -- 取得したデータを設置先住所マスタに追加する。
        --**********************************************************************
        INSERT INTO CSG_M_IB_ADDRESS
        (
          INSTALL_LOCATION_CODE
          , SHIPMENT_LOCATION_CODE
          , CUST_CD
          , POST_CODE
          , INSTALL_LOCATION
          , ACTIVE_FLAG
          , PROGRAM_ID
          , PROCESS_ID
          , CREATION_USER_ID
          , CREATION_DATE
          , UPDATE_USER_ID
          , UPDATE_DATE
        )
        VALUES
        (
          P_INSTALL_LOCATION_CODE
          , row_SNV_M_CUST.CUST_CD  -- [1.1.]で取得した「顧客コード」  (出荷先顧客のコード)
          , P_CUST_CD               -- [2.2.]で取得した「顧客コード」  (法人格顧客のコード)
          , row_SNV_M_CUST.POST_NO  -- [1.1.]で取得した「郵便番号」
          , P_INSTALL_LOCATION      -- [2.3.]で編集した「住所」
          , 'Y'                     -- "Y"(固定)を設定
          , 'BAT-CSG02-0502'
          , INPUT_PROCESS_ID           -- 0.3で取得した処理ID
          , INPUT_BATCH_USER_ID     -- 0.2.で取得したバッチ実行ユーザID
          , P_BATCH_PROCESS_DATE    -- 0.1.システム日時の取得にて取得したシステム日時
          , INPUT_BATCH_USER_ID     -- 0.2.で取得したバッチ実行ユーザID
          , P_BATCH_PROCESS_DATE    -- 0.1.システム日時の取得にて取得したシステム日時
        );

      ELSE
        --**********************************************************************
        -- 2.6.設置先住所マスタデータ更新
        -- 取得したデータを設置先住所マスタに更新する。
        --**********************************************************************
        UPDATE CSG_M_IB_ADDRESS
           SET POST_CODE  =   row_SNV_M_CUST.POST_NO   -- [1.1.]で取得した「郵便番号」
             , INSTALL_LOCATION = P_INSTALL_LOCATION   -- [2.3.]で編集した「住所」
             , PROGRAM_ID = 'BAT-CSG02-0502'
             , PROCESS_ID = INPUT_PROCESS_ID              -- 0.3で取得した処理ID
             , UPDATE_USER_ID = INPUT_BATCH_USER_ID    -- 0.2.で取得したバッチ実行ユーザID
             , UPDATE_DATE = P_BATCH_PROCESS_DATE      --0.1.システム日時の取得にて取得したシステム日時
         WHERE SHIPMENT_LOCATION_CODE = row_SNV_M_CUST.CUST_CD; --[1.1.]で取得した「顧客コード」
      END IF;
      --************************************************************************
      -- 3.終了処理
      -- 3.1.処理終了日時の設定
      -- バッチ処理日付に処理日時を設定する （条件：正常終了時のみ実施）
      -- 3.1.1.データ追加
      -- 0.3で前回処理日時が取得できなかった（NULL）場合はデータ追加を行う
      --************************************************************************
      IF P_BATCH_DATE IS NULL THEN
        INSERT INTO CSG_T_BATCH_DATE
        (
          EXC_PROGRAM_ID
          , PROCESS_DATE
          , PROGRAM_ID
          , PROCESS_ID
          , CREATION_USER_ID
          , CREATION_DATE
          , UPDATE_USER_ID
          , UPDATE_DATE
        )
        VALUES
        (
          'BAT-CSG02-0502-01'
          , P_BATCH_PROCESS_DATE  -- 0.1.システム日時の取得にて取得したシステム日時
          , 'BAT-CSG02-0502'
          , INPUT_PROCESS_ID         -- 0.3で取得した処理ID
          , INPUT_BATCH_USER_ID   -- 0.2.で取得したバッチ実行ユーザID
          , P_BATCH_PROCESS_DATE  -- 0.1.システム日時の取得にて取得したシステム日時
          , INPUT_BATCH_USER_ID   -- 0.2.で取得したバッチ実行ユーザID
          , P_BATCH_PROCESS_DATE  -- 0.1.システム日時の取得にて取得したシステム日時
        );

      ELSE
      --************************************************************************
      -- 0.3で前回処理日時が取得できた場合はデータ更新を行う。
      --************************************************************************
        UPDATE CSG_T_BATCH_DATE
        SET PROCESS_DATE = P_BATCH_PROCESS_DATE   -- 0.1.システム日時の取得にて取得したシステム日時
          , PROGRAM_ID = 'BAT-CSG02-0502'
          , PROCESS_ID = INPUT_PROCESS_ID            -- 0.3で取得した処理ID
          , UPDATE_USER_ID = INPUT_BATCH_USER_ID  -- 0.2.で取得したバッチ実行ユーザID
          , UPDATE_DATE = P_BATCH_PROCESS_DATE    -- 0.1.システム日時の取得にて取得したシステム日時
        WHERE EXC_PROGRAM_ID = 'BAT-CSG02-0502-01';
      END IF;
    END LOOP;
    CLOSE CUR_SNV_M_CUST;
    COMMIT;
    RETURN_RESULT_CD := '0'; -- 0 ：正常終了コード
    RETURN_STATUS := '1'; -- 3: エラー

  EXCEPTION
    WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('ORACLE ERR_CODE    := ' || SQLCODE);            -- ＤＢエラーコード
    DBMS_OUTPUT.PUT_LINE('ORACLE ERR_MESSAGE := ' || SQLERRM(SQLCODE));   -- ＤＢエラーメッセージ
    DBMS_OUTPUT.PUT_LINE('PROC POINT         := ' || g_shori_point);      -- 処理ポイント
    RETURN_RESULT_CD   := '20';
    RETURN_STATUS      := '3'; -- 3:エラー
    RETURN_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
    RETURN_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
    ROLLBACK;
    RETURN;
  END CSG02_PROC_INSTALL_ADDR_REGIST;

END CSG02_0502_PKG;
/
