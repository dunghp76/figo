CREATE OR REPLACE PACKAGE "CSG02_0602_PKG" AS
/*******************************************************************************
* CSテリトリー更新ツール
*-------------------------------------------------------------------------------
* <更新履歴>
* <Version>   <日付>      <更新概要>                             <更新者>
*   1.0     2016/04/04      新規                             FOCUS_NGUYENQUOCDAT
*******************************************************************************/
--******************************************************************************
--* CSG02-0602-CSテリトリー更新ツール   （PL/SQL）
--* CSG02-0602 (MAIN)
--******************************************************************************
  PROCEDURE MAIN_CSG02_0602
  (
      INPUT_USER_ID      IN VARCHAR2 ,   --ユーザID
      INPUT_PATH_FILE    IN VARCHAR2,
      OUT_PROCESS_END_DATE OUT VARCHAR2,
      OUT_ERR_CONTENT    OUT VARCHAR2,
      OUT_ERR_DETAIL     OUT VARCHAR2,
      OUT_DL_FILE        OUT VARCHAR2,
      OUT_RESULT_CD      OUT VARCHAR2    -- 終了コード (0  ：正常終了コード　／　'20' ：異常終了コード)
  );

--******************************************************************************
-- CSG02-0602-CSテリトリー更新ツール
--******************************************************************************
  PROCEDURE CSG02_PROC_CS_TERRITORY_UPDATE
(
        INPUT_USER_ID IN VARCHAR2         --ユーザID
      , INPUT_PROCESS_ID IN VARCHAR2      --プロセスID
      , INPUT_PATH_FILE IN VARCHAR2       --CSVファイルパス
      , OUT_PROCESS_ID OUT VARCHAR2       --処理ID
      , OUT_STATUS OUT VARCHAR2           --ステータス
      , OUT_PROCESS_END_DATE OUT VARCHAR2 --処理終了日時
      , OUT_ERR_CONTENT OUT VARCHAR2      --処理終了日時
      , OUT_ERR_DETAIL OUT VARCHAR2       --エラー内容
      , OUT_DL_FILE OUT VARCHAR2          --エラー詳細
      , OUT_RESULT_CD OUT VARCHAR2        --ダウンロードファイル
);

END CSG02_0602_PKG;
/
