CREATE OR REPLACE PACKAGE BODY "CSG02_0110_PKG" AS
/*******************************************************************************
* 担当ＣＳ設定移行                                                                *
*-------------------------------------------------------------------------------*
* <更新履歴>                                                                     *
* <Version>   <日付>      <更新概要>                             <更新者>         *
*   1.0     2016/04/01      新規                                FOCUS_LTBINH    *
********************************************************************************/
  g_shori_point                 VARCHAR2(250);    -- 処理ポイント
  set_sysdate                   DATE;             -- システム日時
  OUT_STATUS                    VARCHAR2(10);     -- ステータス
  OUT_ERR_CONTENT               VARCHAR2(250);    -- エラー内容
  OUT_ERR_DETAIL                VARCHAR2(250);    -- エラー詳細
  OUT_PROCESS_ID                VARCHAR2(15);     -- プロセスID
  /******************************************************************************
  * 担当CS設定（PL/SQL）                                                          *
  * CSG02-0110 (MAIN)                                                           *
  *******************************************************************************/
  PROCEDURE MAIN_CSG02_0110(
      INPUT_USER_ID               IN VARCHAR2 ,              --ユーザID
      INPUT_PROCESS_ID            IN VARCHAR2 DEFAULT NULL , --プロセスID
      INPUT_MODEL_CODE            IN VARCHAR2 DEFAULT NULL , -- 機種コード
      INPUT_ACCOUNT_NO            IN VARCHAR2 DEFAULT NULL , -- 顧客番号
      INPUT_F_SALES_DEP_CODE      IN VARCHAR2 DEFAULT NULL , -- Ｆ営業部課コード
      INPUT_INSTALL_LOCATION_CODE IN NUMBER DEFAULT NULL ,   -- 設置先住所ＩＤ
      OUT_RESULT_CD OUT VARCHAR2 ,                           -- 終了コード (0  ：正常終了コード　／　20 ：異常終了コード)
      OUT_RESULT_GET OUT VARCHAR2 ,                          -- 取得結果 (OK / NGを返却する)
      OUT_CONDITION_GET OUT VARCHAR2 ,                       -- 取得条件
      OUT_CS_IN_CHARGE_CODE OUT NUMBER )
  AS
  PRAM_EXCEPTION                EXCEPTION;
  BEGIN
  g_shori_point             := 'MAIN_CSG02_0110';
--******************************************************************************
-- 0.開始処理
-- 0.1.システム日時の取得
-- システム日時を取得する。
--******************************************************************************
  set_sysdate               := SYSDATE;
--******************************************************************************
-- 0.2.処理IDの取得
-- 開始時バックグラウンド処理を呼び出す。
--******************************************************************************
    CSG05_0101_PKG.CSG05_PROC_BG_PROCESS_START(
                                  'BAT-CSG02-0110-01',
                                  INPUT_MODEL_CODE || ',' || INPUT_ACCOUNT_NO || ',' || INPUT_F_SALES_DEP_CODE || ',' || INPUT_INSTALL_LOCATION_CODE,   -- 機種コード,顧客番号,部課コード,設置先住所ID
                                  set_sysdate,
                                  INPUT_USER_ID,
                                  OUT_PROCESS_ID,
                                  OUT_RESULT_CD
                               );
-- *****************************************************************************
-- [例外処理]
-- 処理結果 = 1（処理IDを取得できなかった）の場合
-- エラーメッセージ[MSG-CSG-F-0003]をログ出力し、後続の処理を中断する。
-- *****************************************************************************
    IF OUT_PROCESS_ID = 1 THEN
      DBMS_OUTPUT.PUT_LINE('処理IDが取得できませんでした。システム管理者に問い合わせてください。');
      RAISE PRAM_EXCEPTION;
    END IF;
--******************************************************************************
-- 担当ＣＳ設定移行
-- CSG02_PROC_CHARGE_OF_CS_SET
--******************************************************************************
    CSG02_PROC_CHARGE_OF_CS_SET(
                                  INPUT_MODEL_CODE,
                                  INPUT_ACCOUNT_NO,
                                  INPUT_F_SALES_DEP_CODE,
                                  INPUT_INSTALL_LOCATION_CODE,
                                  OUT_RESULT_CD,
                                  OUT_RESULT_GET,
                                  OUT_CONDITION_GET,
                                  OUT_CS_IN_CHARGE_CODE
                                );

--******************************************************************************
-- 4.終了処理
-- 4.1.実行結果の登録
-- 終了時バックグラウンド処理を呼び出す。
--******************************************************************************
    CSG05_0101_PKG.CSG05_PROC_BG_PROCESS_UPD(
                                OUT_PROCESS_ID,
                                OUT_STATUS,
                                set_sysdate,
                                OUT_ERR_CONTENT,
                                OUT_ERR_DETAIL,
                                '-',
                                OUT_RESULT_CD
                               );
  EXCEPTION
    WHEN PRAM_EXCEPTION THEN
        OUT_RESULT_CD   := '20';
        OUT_STATUS      := '3';
        OUT_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
        OUT_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
        ROLLBACK;
        RETURN;
    -- その他未定義の例外の処理
    WHEN OTHERS THEN
        OUT_RESULT_CD := '20';
        DBMS_OUTPUT.PUT_LINE('ORACLE ERR_CODE    := ' || SQLCODE);            -- ＤＢエラーコード
        DBMS_OUTPUT.PUT_LINE('ORACLE ERR_MESSAGE := ' || SQLERRM(SQLCODE));   -- ＤＢエラーメッセージ
        DBMS_OUTPUT.PUT_LINE('PROC POINT         := ' || g_shori_point);      -- 処理ポイント
      --************************************************************************
      -- 呼び出し元機能のステータス
      -- 0:処理中
      -- 1:正常終了
      -- 2:警告終了
      -- 3:エラー
      --************************************************************************
        OUT_STATUS      := '3';
        OUT_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
        OUT_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
        ROLLBACK;
        RETURN;
  END MAIN_CSG02_0110;

  /******************************************************************************
  * 担当CS設定（PL/SQL）                                                          *
  * CSG02-0110                                                                  *
  *******************************************************************************/
  PROCEDURE CSG02_PROC_CHARGE_OF_CS_SET(
      INPUT_MODEL_CODE            IN VARCHAR2 DEFAULT NULL , -- 機種コード
      INPUT_ACCOUNT_NO            IN VARCHAR2 DEFAULT NULL , -- 顧客番号
      INPUT_F_SALES_DEP_CODE      IN VARCHAR2 DEFAULT NULL , -- Ｆ営業部課コード
      INPUT_INSTALL_LOCATION_CODE IN NUMBER DEFAULT NULL ,   -- 設置先住所ＩＤ
      OUT_RESULT_CD OUT VARCHAR2 ,                           -- 終了コード (0  ：正常終了コード　／　20 ：異常終了コード)
      OUT_RESULT_GET OUT VARCHAR2 ,                          -- 取得結果 (OK / NGを返却する)
      OUT_CONDITION_GET OUT VARCHAR2 ,                       -- 取得条件
      OUT_CS_IN_CHARGE_CODE OUT NUMBER ) AS
-- ****************************************************************************
-- 処理パラメータ
-- ****************************************************************************
  PRAM_PLACE_HOLDER                   VARCHAR2(100);    -- プレースホルダパラメータ
--******************************************************************************
-- 郵便番号マスタ情報のパラメータ
--******************************************************************************
  p_POSTAL_CD                       CSG_M_POSTAL_CODE.POSTAL_CD%type ;                      -- 郵便番号
  p_POSTAL_CD_WITH_HYPHEN           CSG_M_POSTAL_CODE.POSTAL_CD_WITH_HYPHEN%type ;          -- 郵便番号（?）付き
  p_POSTAL_CD_3                     CSG_M_POSTAL_CODE.POSTAL_CD_3%type ;                    -- 郵便番号親３桁
  p_POSTAL_CD_4                     CSG_M_POSTAL_CODE.POSTAL_CD_4%type ;                    -- 郵便番号子４桁
  p_STATE_NAME                      CSG_M_POSTAL_CODE.STATE_NAME%type DEFAULT NULL;         -- 都道府県名
  p_STATE_NAME_KANA                 CSG_M_POSTAL_CODE.STATE_NAME_KANA%type DEFAULT NULL;    -- 都道府県名（カナ）
  p_CITY_NAME                       CSG_M_POSTAL_CODE.CITY_NAME%type DEFAULT NULL;          -- 市区町村名
  p_CITY_NAME_KANA                  CSG_M_POSTAL_CODE.CITY_NAME_KANA%type DEFAULT NULL;     -- 市区町村名（カナ）
  p_ADDRESS1_NAME                   CSG_M_POSTAL_CODE.ADDRESS1_NAME%type DEFAULT NULL;      -- 町域名
  p_ADDRESS1_NAME_KANA              CSG_M_POSTAL_CODE.ADDRESS1_NAME_KANA%type DEFAULT NULL; -- 町域名（カナ）
  p_ADDRESS2_NAME                   CSG_M_POSTAL_CODE.ADDRESS2_NAME%type DEFAULT NULL;      -- 小字名、丁目、番地等
  p_JIGYOSHO_NAME                   CSG_M_POSTAL_CODE.JIGYOSHO_NAME%type DEFAULT NULL;      -- 大口事業所等名
  p_KIGYO_FLAG                      CSG_M_POSTAL_CODE.KIGYO_FLAG%type ;                     -- 企業フラグ
  p_KOKYO_CD                        CSG_M_POSTAL_CODE.KOKYO_CD%type DEFAULT NULL;           -- 全国地方公共団体コード
  p_STATE_CD                        CSG_M_POSTAL_CODE.STATE_CD%type DEFAULT NULL;           -- 都道府県コード
  p_PROGRAM_ID                      CSG_M_POSTAL_CODE.PROGRAM_ID%type DEFAULT NULL;         -- 更新プログラムID
  p_PROCESS_ID                      CSG_M_POSTAL_CODE.PROCESS_ID%type DEFAULT NULL;         -- 処理ID
  p_CREATION_USER_ID                CSG_M_POSTAL_CODE.CREATION_USER_ID%type ;               -- 作成者
  p_CREATION_DATE                   CSG_M_POSTAL_CODE.CREATION_DATE%type ;                  -- 作成日時
  p_UPDATE_USER_ID                  CSG_M_POSTAL_CODE.UPDATE_USER_ID%TYPE ;                 -- 更新者
  p_UPDATE_DATE                     CSG_M_POSTAL_CODE.UPDATE_DATE%TYPE ;                    -- 更新日時
--******************************************************************************
-- 設置先住所マスタ情報のパラメータ
--******************************************************************************
  p_INSTALL_LOCATION_CODE            CSG_M_IB_ADDRESS.INSTALL_LOCATION_CODE%type ;              -- 設置先住所コード
  p_SHIPMENT_LOCATION_CODE           CSG_M_IB_ADDRESS.SHIPMENT_LOCATION_CODE%type DEFAULT NULL; -- 出荷先コード
  p_CUST_CD                          CSG_M_IB_ADDRESS.CUST_CD%type ;                            -- 顧客コード
  p_POST_CODE                        CSG_M_IB_ADDRESS.POST_CODE%type DEFAULT NULL;              -- 郵便番号
  p_INSTALL_LOCATION                 CSG_M_IB_ADDRESS.INSTALL_LOCATION%type DEFAULT NULL;       -- 住所
  p_ACTIVE_FLAG                      CSG_M_IB_ADDRESS.ACTIVE_FLAG%type DEFAULT NULL;            -- 有効フラグ
  p_PROGRAM_ID                       CSG_M_IB_ADDRESS.PROGRAM_ID%type DEFAULT NULL;             -- 更新プログラムID
  p_PROCESS_ID                       CSG_M_IB_ADDRESS.PROCESS_ID%type DEFAULT NULL;             -- 処理ID
  p_CREATION_USER_ID                 CSG_M_IB_ADDRESS.CREATION_USER_ID%type ;                   -- 作成者
  p_CREATION_DATE                    CSG_M_IB_ADDRESS.CREATION_DATE%type ;                      -- 作成日時
  p_UPDATE_USER_ID                   CSG_M_IB_ADDRESS.UPDATE_USER_ID%TYPE ;                     -- 更新者
  p_UPDATE_DATE                      CSG_M_IB_ADDRESS.UPDATE_DATE%TYPE ;                        -- 更新日時
--******************************************************************************
-- CSテリトリー情報のパラメータ
--******************************************************************************
  p_CS_TERITORY_ID              CSG_M_CS_TERRITORY_INFO.CS_TERITORY_ID%type ;                -- CSテリトリー情報ID
  p_CS_IN_CHARGE_CODE           CSG_M_CS_TERRITORY_INFO.CS_IN_CHARGE_CODE%type DEFAULT NULL; -- 担当CSコード
  p_MODEL_CODE                  CSG_M_CS_TERRITORY_INFO.MODEL_CODE%type DEFAULT NULL;        -- 機種コード
  p_F_SALES_CODE                CSG_M_CS_TERRITORY_INFO.F_SALES_CODE%type DEFAULT NULL;      -- 部課コード
  p_ACCOUNT_NO                  CSG_M_CS_TERRITORY_INFO.ACCOUNT_NO%type DEFAULT NULL;        -- 顧客番号
  p_STATE_CODE                  CSG_M_CS_TERRITORY_INFO.STATE_CODE%type DEFAULT NULL;        -- 都道府県コード
  p_LOCAL_GOV_CODE              CSG_M_CS_TERRITORY_INFO.LOCAL_GOV_CODE%type DEFAULT NULL;    -- 市区町村コード
  p_POSTAL_CODE                 CSG_M_CS_TERRITORY_INFO.POSTAL_CODE%type DEFAULT NULL;       -- 郵便番号
  p_PROGRAM_ID                  CSG_M_CS_TERRITORY_INFO.PROGRAM_ID%type DEFAULT NULL;        -- 更新プログラムID
  p_PROCESS_ID                  CSG_M_CS_TERRITORY_INFO.PROCESS_ID%type DEFAULT NULL;        -- 処理ID
  p_CREATION_USER_ID            CSG_M_CS_TERRITORY_INFO.CREATION_USER_ID%type ;              -- 作成者
  p_CREATION_DATE               CSG_M_CS_TERRITORY_INFO.CREATION_DATE%type ;                 -- 作成日時
  P_UPDATE_USER_ID              CSG_M_CS_TERRITORY_INFO.UPDATE_USER_ID%type ;                -- 更新者
  p_UPDATE_DATE                 CSG_M_CS_TERRITORY_INFO.UPDATE_DATE%TYPE ;                   -- 更新日時
  BEGIN
  --****************************************************************************
  -- 1.郵便番号の特定
  -- 1.1.郵便番号の特定
  -- パラメータで受け取った設置先住所IDをもとに設置先住所マスタより郵便番号を取得する。
  --****************************************************************************
    PRAM_PLACE_HOLDER         := '郵便番号の特定';
  --****************************************************************************
  -- 1.1.パラメータ必須チェック
  --****************************************************************************
    IF FUNC_REQUIRED_CHK(INPUT_INSTALL_LOCATION_CODE) = 1 THEN
      OUT_RESULT_CD              := '20';
      OUT_RESULT_GET             := 'NG';
      OUT_CONDITION_GET          := 'NULL';
      OUT_CS_IN_CHARGE_CODE      := 'NULL';
      --************************************************************************
      -- 呼び出し元機能のステータス
      -- 0:処理中
      -- 1:正常終了
      -- 2:警告終了
      -- 3:エラー
      --************************************************************************
      OUT_STATUS      := '3';
      OUT_ERR_CONTENT := '設置先住所コードを入力してください。';
      OUT_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
      RETURN;
    END IF;

    IF INPUT_INSTALL_LOCATION_CODE IS NOT NULL THEN
      BEGIN
        SELECT CMIA.POST_CODE                                              -- 郵便番号
          INTO p_POST_CODE
          FROM CSG_M_IB_ADDRESS CMIA                                       -- 設置先住所マスタ
         WHERE CMIA.INSTALL_LOCATION_CODE = INPUT_INSTALL_LOCATION_CODE    -- パラメータ.設置先住所コード
           AND CMIA.ACTIVE_FLAG = 'Y';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          OUT_STATUS            := '2';           -- ステータス 0:処理中 1:正常終了 2:警告終了 3:エラー
      END;
    END IF;
  --****************************************************************************
  -- 1.2.取得件数チェック
  -- [1.1.]の処理でデータが取得できなかった場合、出力パラメータに以下を設定して処理を終了する。
  -- ・	エラーメッセージ=NULL
  -- ・	取得結果='OK'
  -- ・	取得条件='0,0'
  -- ・	担当CSコード='担当G未設定'のコード値
  --****************************************************************************
    IF p_POST_CODE IS NULL THEN
      OUT_RESULT_CD         := '0';           -- 終了コード 0：正常終了コード／20：異常終了コード
      OUT_RESULT_GET        := 'OK';          -- 取得結果='OK'
      OUT_CONDITION_GET     := '0,0';         -- 取得条件='0,0'
      OUT_CS_IN_CHARGE_CODE := '100000300';   -- 担当CSコード='100000300'(担当G未設定)のコード値
      OUT_STATUS            := '1';           -- ステータス 0:処理中 1:正常終了 2:警告終了 3:エラー
      RETURN;
    ELSE
    --**************************************************************************
    -- 2.都道府県コード / 市区町村コードの取得
    -- 2.1.都道府県コード / 市区町村コードの取得
    -- [1.]にて取得した郵便番号をもとに郵便番号マスタより都道府県コード、市区町村コードを取得する。
    --**************************************************************************
      PRAM_PLACE_HOLDER         := '都道府県コード / 市区町村コードの取得';

      BEGIN
        SELECT CMPC.STATE_CD,                    -- 都道府県コード
               CMPC.KOKYO_CD                     -- 市区町村コード
          INTO p_STATE_CD,
               p_KOKYO_CD
          FROM CSG_M_POSTAL_CODE CMPC            -- 郵便番号マスタ
         WHERE CMPC.POSTAL_CD = p_POST_CODE;     -- 郵便番号
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          OUT_STATUS            := '2';           -- ステータス 0:処理中 1:正常終了 2:警告終了 3:エラー
      END;
    --**************************************************************************
    -- 2.2.取得件数チェック
    -- [2.1.]の処理でデータが取得できなかった場合、出力パラメータに以下を設定して処理を終了する。
    -- ・	取得結果='OK'
    -- ・	取得条件='0,0'
    -- ・	担当CSコード='担当G未設定'のコード値
    --**************************************************************************
      IF P_STATE_CD IS NULL AND P_KOKYO_CD IS NULL THEN
        OUT_RESULT_CD         := '0';          -- 終了コード 0：正常終了コード／20：異常終了コード
        OUT_RESULT_GET        := 'OK';         -- 取得結果='OK'
        OUT_CONDITION_GET     := '0,0';        -- 取得条件='0,0'
        OUT_CS_IN_CHARGE_CODE := '100000300';  -- 担当CSコード='100000300'(担当G未設定)のコード値
        OUT_STATUS            := '1';          -- ステータス 0:処理中 1:正常終了 2:警告終了 3:エラー
        RETURN;
      ELSE
      --************************************************************************
      -- 3.担当CS情報の取得
      -- 3.1.担当CS情報の取得
      -- パラメータの「機種コード」「顧客番号」「Ｆ営業部課コード」と前処理で取得した「郵便番号」「都道府県コード」「市区町村コード」をもとに
      -- CSテリトリー情報より「CSテリトリー情報ID」「担当CSコード」を取得する。
      --************************************************************************
      --************************************************************************
      -- 3.1.1. 「機種コード」≠ NULL かつ「顧客番号」≠NULLかつ「Ｆ営業部課コード」≠NULLの場合 ※優先順位
      --************************************************************************
        PRAM_PLACE_HOLDER         := 'CSテリトリー情報';

        IF INPUT_MODEL_CODE IS NOT NULL AND
           INPUT_F_SALES_DEP_CODE IS NOT NULL AND
           INPUT_ACCOUNT_NO IS NOT NULL THEN
           --*******************************************************************
           -- 3.1.1.1.　郵便番号からの抽出
           --*******************************************************************
           IF p_POST_CODE IS NOT NULL AND p_CS_IN_CHARGE_CODE IS NULL THEN
            BEGIN
              SELECT CMCTI.CS_TERITORY_ID,                            -- CSテリトリー情報ID
                     CMCTI.CS_IN_CHARGE_CODE                          -- 担当CSコード
                INTO p_CS_TERITORY_ID,
                     p_CS_IN_CHARGE_CODE
                FROM CSG_M_CS_TERRITORY_INFO CMCTI                    -- CSテリトリー情報
               WHERE CMCTI.MODEL_CODE     = INPUT_MODEL_CODE          -- 機種コード
                 AND CMCTI.F_SALES_CODE   = INPUT_F_SALES_DEP_CODE    -- 部課コード
                 AND CMCTI.ACCOUNT_NO     = INPUT_ACCOUNT_NO          -- 顧客番号
                 AND CMCTI.POSTAL_CODE    = p_POST_CODE;              -- 郵便番号

              OUT_RESULT_GET             := 'OK';                     -- 取得結果
              OUT_CONDITION_GET          := '1.1';                    -- 取得条件
              OUT_CS_IN_CHARGE_CODE      := P_CS_IN_CHARGE_CODE;      -- 担当CSコード
              OUT_RESULT_CD              := '0';
              --****************************************************************
              -- 呼び出し元機能のステータス
              -- 0:処理中
              -- 1:正常終了
              -- 2:警告終了
              -- 3:エラー
              --****************************************************************
              OUT_STATUS                 := '1';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_STATUS            := '2';           -- ステータス 0:処理中 1:正常終了 2:警告終了 3:エラー
            END;
           END IF;
           --*******************************************************************
           -- 3.1.1.2.　市区町村コードからの抽出
           --*******************************************************************
           IF p_KOKYO_CD IS NOT NULL AND p_CS_IN_CHARGE_CODE IS NULL THEN
            BEGIN
              SELECT CMCTI.CS_TERITORY_ID,                            -- CSテリトリー情報ID
                     CMCTI.CS_IN_CHARGE_CODE                          -- 担当CSコード
                INTO p_CS_TERITORY_ID,
                     p_CS_IN_CHARGE_CODE
                FROM CSG_M_CS_TERRITORY_INFO CMCTI                    -- CSテリトリー情報
               WHERE CMCTI.MODEL_CODE     = INPUT_MODEL_CODE          -- 機種コード
                 AND CMCTI.F_SALES_CODE   = INPUT_F_SALES_DEP_CODE    -- 部課コード
                 AND CMCTI.ACCOUNT_NO     = INPUT_ACCOUNT_NO          -- 顧客番号
                 AND CMCTI.POSTAL_CODE    IS NULL                     -- 郵便番号
                 AND CMCTI.LOCAL_GOV_CODE = p_KOKYO_CD;               -- 市区町村コード

              OUT_RESULT_GET             := 'OK';                     -- 取得結果
              OUT_CONDITION_GET          := '1.2';                    -- 取得条件
              OUT_CS_IN_CHARGE_CODE      := p_CS_IN_CHARGE_CODE;      -- 担当CSコード
              OUT_RESULT_CD              := '0';
              --****************************************************************
              -- 呼び出し元機能のステータス
              -- 0:処理中
              -- 1:正常終了
              -- 2:警告終了
              -- 3:エラー
              --****************************************************************
              OUT_STATUS                 := '1';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_STATUS            := '2';           -- ステータス 0:処理中 1:正常終了 2:警告終了 3:エラー
            END;
           END IF;
           --*******************************************************************
           -- 3.1.1.3.　都道府県コードからの抽出
           --*******************************************************************
           IF p_STATE_CD IS NOT NULL AND p_CS_IN_CHARGE_CODE IS NULL THEN
            BEGIN
              SELECT CMCTI.CS_TERITORY_ID,                            -- CSテリトリー情報ID
                     CMCTI.CS_IN_CHARGE_CODE                          -- 担当CSコード
                INTO p_CS_TERITORY_ID,
                     p_CS_IN_CHARGE_CODE
                FROM CSG_M_CS_TERRITORY_INFO CMCTI                    -- CSテリトリー情報
               WHERE CMCTI.MODEL_CODE     = INPUT_MODEL_CODE          -- 機種コード
                 AND CMCTI.F_SALES_CODE   = INPUT_F_SALES_DEP_CODE    -- 部課コード
                 AND CMCTI.ACCOUNT_NO     = INPUT_ACCOUNT_NO          -- 顧客番号
                 AND CMCTI.POSTAL_CODE    IS NULL                     -- 郵便番号
                 AND CMCTI.STATE_CODE     = p_STATE_CD                -- 都道府県コード
                 AND CMCTI.LOCAL_GOV_CODE IS NULL;                    -- 市区町村コード

              OUT_RESULT_GET             := 'OK';                     -- 取得結果
              OUT_CONDITION_GET          := '1.3';                    -- 取得条件
              OUT_CS_IN_CHARGE_CODE      := p_CS_IN_CHARGE_CODE;      -- 担当CSコード
              OUT_RESULT_CD              := '0';
              --****************************************************************
              -- 呼び出し元機能のステータス
              -- 0:処理中
              -- 1:正常終了
              -- 2:警告終了
              -- 3:エラー
              --****************************************************************
              OUT_STATUS                 := '1';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_STATUS            := '2';           -- ステータス 0:処理中 1:正常終了 2:警告終了 3:エラー
            END;
           END IF;
           --*******************************************************************
           -- 3.1.1.4.　パラメータ項目のみの抽出
           --*******************************************************************
           IF p_CS_IN_CHARGE_CODE IS NULL THEN
            BEGIN
              SELECT CMCTI.CS_TERITORY_ID,                            -- CSテリトリー情報ID
                     CMCTI.CS_IN_CHARGE_CODE                          -- 担当CSコード
                INTO p_CS_TERITORY_ID,
                     p_CS_IN_CHARGE_CODE
                FROM CSG_M_CS_TERRITORY_INFO CMCTI                    -- CSテリトリー情報
               WHERE CMCTI.MODEL_CODE     = INPUT_MODEL_CODE          -- 機種コード
                 AND CMCTI.F_SALES_CODE   = INPUT_F_SALES_DEP_CODE    -- 部課コード
                 AND CMCTI.ACCOUNT_NO     = INPUT_ACCOUNT_NO          -- 顧客番号
                 AND CMCTI.POSTAL_CODE    IS NULL                     -- 郵便番号
                 AND CMCTI.STATE_CODE     IS NULL                     -- 都道府県コード
                 AND CMCTI.LOCAL_GOV_CODE IS NULL;                    -- 市区町村コード

              OUT_RESULT_GET             := 'OK';                     -- 取得結果
              OUT_CONDITION_GET          := '1.4';                    -- 取得条件
              OUT_CS_IN_CHARGE_CODE      := p_CS_IN_CHARGE_CODE;      -- 担当CSコード
              OUT_RESULT_CD              := '0';
              --****************************************************************
              -- 呼び出し元機能のステータス
              -- 0:処理中
              -- 1:正常終了
              -- 2:警告終了
              -- 3:エラー
              --****************************************************************
              OUT_STATUS                 := '1';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_RESULT_CD              := '10';
                OUT_RESULT_GET             := 'OK';           -- 取得結果='OK'
                OUT_CONDITION_GET          := 'NULL';         -- 取得条件=NULL
                OUT_CS_IN_CHARGE_CODE      := '100000300';           -- 担当CSコード='100000300'(担当G未設定)のコード値
                --************************************************************************
                -- 呼び出し元機能のステータス
                -- 0:処理中
                -- 1:正常終了
                -- 2:警告終了
                -- 3:エラー
                --************************************************************************
                OUT_STATUS      := '2';
                OUT_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
                OUT_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
            END;
           END IF;
        END IF;
      --************************************************************************
      -- 3.1.2. 「機種コード」≠ NULL かつ「顧客番号」≠NULL の場合 　(部課コードをNULLで判定) ※優先順位
      --************************************************************************
        IF INPUT_MODEL_CODE IS NOT NULL AND
              INPUT_ACCOUNT_NO IS NOT NULL THEN
           --*******************************************************************
           -- 3.1.2.1.　郵便番号からの抽出
           --*******************************************************************
           IF p_POST_CODE IS NOT NULL AND p_CS_IN_CHARGE_CODE IS NULL THEN
            BEGIN
              SELECT CMCTI.CS_TERITORY_ID,                            -- CSテリトリー情報ID
                     CMCTI.CS_IN_CHARGE_CODE                          -- 担当CSコード
                INTO p_CS_TERITORY_ID,
                     p_CS_IN_CHARGE_CODE
                FROM CSG_M_CS_TERRITORY_INFO CMCTI                    -- CSテリトリー情報
               WHERE CMCTI.MODEL_CODE     = INPUT_MODEL_CODE          -- 機種コード
                 AND CMCTI.F_SALES_CODE   IS NULL                     -- 部課コード
                 AND CMCTI.ACCOUNT_NO     = INPUT_ACCOUNT_NO          -- 顧客番号
                 AND CMCTI.POSTAL_CODE    = p_POST_CODE;              -- 郵便番号

              OUT_RESULT_GET             := 'OK';                     -- 取得結果
              OUT_CONDITION_GET          := '2.1';                    -- 取得条件
              OUT_CS_IN_CHARGE_CODE      := p_CS_IN_CHARGE_CODE;      -- 担当CSコード
              OUT_RESULT_CD              := '0';
              --****************************************************************
              -- 呼び出し元機能のステータス
              -- 0:処理中
              -- 1:正常終了
              -- 2:警告終了
              -- 3:エラー
              --****************************************************************
              OUT_STATUS                 := '1';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_STATUS            := '2';           -- ステータス 0:処理中 1:正常終了 2:警告終了 3:エラー
            END;
           END IF;
           --*******************************************************************
           -- 3.1.2.2.　市区町村コードからの抽出
           --*******************************************************************
           IF p_KOKYO_CD IS NOT NULL AND p_CS_IN_CHARGE_CODE IS NULL THEN
            BEGIN
              SELECT CMCTI.CS_TERITORY_ID,                            -- CSテリトリー情報ID
                     CMCTI.CS_IN_CHARGE_CODE                          -- 担当CSコード
                INTO p_CS_TERITORY_ID,
                     p_CS_IN_CHARGE_CODE
                FROM CSG_M_CS_TERRITORY_INFO CMCTI                    -- CSテリトリー情報
               WHERE CMCTI.MODEL_CODE     = INPUT_MODEL_CODE          -- 機種コード
                 AND CMCTI.F_SALES_CODE   IS NULL                     -- 部課コード
                 AND CMCTI.ACCOUNT_NO     = INPUT_ACCOUNT_NO          -- 顧客番号
                 AND CMCTI.POSTAL_CODE    IS NULL                     -- 郵便番号
                 AND CMCTI.LOCAL_GOV_CODE = p_KOKYO_CD;               -- 市区町村コード

              OUT_RESULT_GET             := 'OK';                     -- 取得結果
              OUT_CONDITION_GET          := '2.2';                    -- 取得条件
              OUT_CS_IN_CHARGE_CODE      := p_CS_IN_CHARGE_CODE;      -- 担当CSコード
              OUT_RESULT_CD              := '0';
              --****************************************************************
              -- 呼び出し元機能のステータス
              -- 0:処理中
              -- 1:正常終了
              -- 2:警告終了
              -- 3:エラー
              --****************************************************************
              OUT_STATUS                 := '1';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_STATUS            := '2';           -- ステータス 0:処理中 1:正常終了 2:警告終了 3:エラー
            END;
           END IF;
           --*******************************************************************
           -- 3.1.2.3.　都道府県コードからの抽出
           --*******************************************************************
           IF p_STATE_CD IS NOT NULL AND p_CS_IN_CHARGE_CODE IS NULL THEN
            BEGIN
              SELECT CMCTI.CS_TERITORY_ID,                            -- CSテリトリー情報ID
                     CMCTI.CS_IN_CHARGE_CODE                          -- 担当CSコード
                INTO p_CS_TERITORY_ID,
                     p_CS_IN_CHARGE_CODE
                FROM CSG_M_CS_TERRITORY_INFO CMCTI                    -- CSテリトリー情報
               WHERE CMCTI.MODEL_CODE     = INPUT_MODEL_CODE          -- 機種コード
                 AND CMCTI.F_SALES_CODE   IS NULL                     -- 部課コード
                 AND CMCTI.ACCOUNT_NO     = INPUT_ACCOUNT_NO          -- 顧客番号
                 AND CMCTI.POSTAL_CODE    IS NULL                     -- 郵便番号
                 AND CMCTI.LOCAL_GOV_CODE IS NULL                     -- 市区町村コード
                 AND CMCTI.STATE_CODE     = p_STATE_CD;               -- 都道府県コード

              OUT_RESULT_GET             := 'OK';                     -- 取得結果
              OUT_CONDITION_GET          := '2.3';                    -- 取得条件
              OUT_CS_IN_CHARGE_CODE      := p_CS_IN_CHARGE_CODE;      -- 担当CSコード
              OUT_RESULT_CD              := '0';
              --****************************************************************
              -- 呼び出し元機能のステータス
              -- 0:処理中
              -- 1:正常終了
              -- 2:警告終了
              -- 3:エラー
              --****************************************************************
              OUT_STATUS                 := '1';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_STATUS            := '2';           -- ステータス 0:処理中 1:正常終了 2:警告終了 3:エラー
            END;
           END IF;
           --*******************************************************************
           -- 3.1.2.4.　パラメータ項目のみの抽出
           --*******************************************************************
           IF p_CS_IN_CHARGE_CODE IS NULL THEN
            BEGIN
              SELECT CMCTI.CS_TERITORY_ID,                            -- CSテリトリー情報ID
                     CMCTI.CS_IN_CHARGE_CODE                          -- 担当CSコード
                INTO p_CS_TERITORY_ID,
                     p_CS_IN_CHARGE_CODE
                FROM CSG_M_CS_TERRITORY_INFO CMCTI                    -- CSテリトリー情報
               WHERE CMCTI.MODEL_CODE     = INPUT_MODEL_CODE          -- 機種コード
                 AND CMCTI.F_SALES_CODE   IS NULL                     -- 部課コード
                 AND CMCTI.ACCOUNT_NO     = INPUT_ACCOUNT_NO          -- 顧客番号
                 AND CMCTI.POSTAL_CODE    IS NULL                     -- 郵便番号
                 AND CMCTI.STATE_CODE     IS NULL                     -- 都道府県コード
                 AND CMCTI.LOCAL_GOV_CODE IS NULL;                    -- 市区町村コード

              OUT_RESULT_GET             := 'OK';                     -- 取得結果
              OUT_CONDITION_GET          := '2.4';                    -- 取得条件
              OUT_CS_IN_CHARGE_CODE      := p_CS_IN_CHARGE_CODE;      -- 担当CSコード
              OUT_RESULT_CD              := '0';
              --****************************************************************
              -- 呼び出し元機能のステータス
              -- 0:処理中
              -- 1:正常終了
              -- 2:警告終了
              -- 3:エラー
              --****************************************************************
              OUT_STATUS                 := '1';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_RESULT_CD              := '10';
                OUT_RESULT_GET             := 'OK';           -- 取得結果='OK'
                OUT_CONDITION_GET          := 'NULL';         -- 取得条件=NULL
                OUT_CS_IN_CHARGE_CODE      := '100000300';           -- 担当CSコード='100000300'(担当G未設定)のコード値
                --************************************************************************
                -- 呼び出し元機能のステータス
                -- 0:処理中
                -- 1:正常終了
                -- 2:警告終了
                -- 3:エラー
                --************************************************************************
                OUT_STATUS      := '2';
                OUT_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
                OUT_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
            END;
           END IF;
        END IF;
      --************************************************************************
      -- 3.1.3. 「機種コード」≠ NULL かつ「Ｆ営業部課コード」≠NULLの場合 　(顧客番号をNULLで判定) ※優先順位
      --************************************************************************
        IF INPUT_MODEL_CODE IS NOT NULL AND
              INPUT_F_SALES_DEP_CODE IS NOT NULL THEN
           --*******************************************************************
           -- 3.1.3.1.　郵便番号からの抽出
           --*******************************************************************
           IF p_POST_CODE IS NOT NULL AND p_CS_IN_CHARGE_CODE IS NULL THEN
            BEGIN
              SELECT CMCTI.CS_TERITORY_ID,                            -- CSテリトリー情報ID
                     CMCTI.CS_IN_CHARGE_CODE                          -- 担当CSコード
                INTO p_CS_TERITORY_ID,
                     p_CS_IN_CHARGE_CODE
                FROM CSG_M_CS_TERRITORY_INFO CMCTI                    -- CSテリトリー情報
               WHERE CMCTI.MODEL_CODE     = INPUT_MODEL_CODE          -- 機種コード
                 AND CMCTI.F_SALES_CODE   = INPUT_F_SALES_DEP_CODE    -- 部課コード
                 AND CMCTI.ACCOUNT_NO     IS NULL                     -- 顧客番号
                 AND CMCTI.POSTAL_CODE    = p_POST_CODE;              -- 郵便番号

              OUT_RESULT_GET             := 'OK';                     -- 取得結果
              OUT_CONDITION_GET          := '3.1';                    -- 取得条件
              OUT_CS_IN_CHARGE_CODE      := p_CS_IN_CHARGE_CODE;      -- 担当CSコード
              OUT_RESULT_CD              := '0';
              --****************************************************************
              -- 呼び出し元機能のステータス
              -- 0:処理中
              -- 1:正常終了
              -- 2:警告終了
              -- 3:エラー
              --****************************************************************
              OUT_STATUS                 := '1';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_STATUS            := '2';           -- ステータス 0:処理中 1:正常終了 2:警告終了 3:エラー
            END;
           END IF;
           --*******************************************************************
           -- 3.1.3.2.　市区町村コードからの抽出
           --*******************************************************************
           IF p_KOKYO_CD IS NOT NULL AND p_CS_IN_CHARGE_CODE IS NULL THEN
            BEGIN
              SELECT CMCTI.CS_TERITORY_ID,                            -- CSテリトリー情報ID
                     CMCTI.CS_IN_CHARGE_CODE                          -- 担当CSコード
                INTO p_CS_TERITORY_ID,
                     p_CS_IN_CHARGE_CODE
                FROM CSG_M_CS_TERRITORY_INFO CMCTI                    -- CSテリトリー情報
               WHERE CMCTI.MODEL_CODE     = INPUT_MODEL_CODE          -- 機種コード
                 AND CMCTI.F_SALES_CODE   = INPUT_F_SALES_DEP_CODE    -- 部課コード
                 AND CMCTI.ACCOUNT_NO     IS NULL                     -- 顧客番号
                 AND CMCTI.POSTAL_CODE    IS NULL                     -- 郵便番号
                 AND CMCTI.LOCAL_GOV_CODE = p_KOKYO_CD;               -- 市区町村コード

              OUT_RESULT_GET             := 'OK';                     -- 取得結果
              OUT_CONDITION_GET          := '3.2';                    -- 取得条件
              OUT_CS_IN_CHARGE_CODE      := p_CS_IN_CHARGE_CODE;      -- 担当CSコード
              OUT_RESULT_CD              := '0';
              --****************************************************************
              -- 呼び出し元機能のステータス
              -- 0:処理中
              -- 1:正常終了
              -- 2:警告終了
              -- 3:エラー
              --****************************************************************
              OUT_STATUS                 := '1';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_STATUS            := '2';           -- ステータス 0:処理中 1:正常終了 2:警告終了 3:エラー
            END;
           END IF;
           --*******************************************************************
           -- 3.1.3.3.　都道府県コードからの抽出
           --*******************************************************************
           IF p_STATE_CD IS NOT NULL AND p_CS_IN_CHARGE_CODE IS NULL THEN
            BEGIN
              SELECT CMCTI.CS_TERITORY_ID,                            -- CSテリトリー情報ID
                     CMCTI.CS_IN_CHARGE_CODE                          -- 担当CSコード
                INTO p_CS_TERITORY_ID,
                     p_CS_IN_CHARGE_CODE
                FROM CSG_M_CS_TERRITORY_INFO CMCTI                    -- CSテリトリー情報
               WHERE CMCTI.MODEL_CODE     = INPUT_MODEL_CODE          -- 機種コード
                 AND CMCTI.F_SALES_CODE   = INPUT_F_SALES_DEP_CODE    -- 部課コード
                 AND CMCTI.ACCOUNT_NO     IS NULL                     -- 顧客番号
                 AND CMCTI.POSTAL_CODE    IS NULL                     -- 郵便番号
                 AND CMCTI.LOCAL_GOV_CODE IS NULL                     -- 市区町村コード
                 AND CMCTI.STATE_CODE     = p_STATE_CD;               -- 都道府県コード

              OUT_RESULT_GET             := 'OK';                     -- 取得結果
              OUT_CONDITION_GET          := '3.3';                    -- 取得条件
              OUT_CS_IN_CHARGE_CODE      := p_CS_IN_CHARGE_CODE;      -- 担当CSコード
              OUT_RESULT_CD              := '0';
              --****************************************************************
              -- 呼び出し元機能のステータス
              -- 0:処理中
              -- 1:正常終了
              -- 2:警告終了
              -- 3:エラー
              --****************************************************************
              OUT_STATUS                 := '1';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_STATUS            := '2';           -- ステータス 0:処理中 1:正常終了 2:警告終了 3:エラー
            END;
           END IF;
           --*******************************************************************
           -- 3.1.3.4.　パラメータ項目のみの抽出
           --*******************************************************************
           IF p_CS_IN_CHARGE_CODE IS NULL THEN
            BEGIN
              SELECT CMCTI.CS_TERITORY_ID,                            -- CSテリトリー情報ID
                     CMCTI.CS_IN_CHARGE_CODE                          -- 担当CSコード
                INTO p_CS_TERITORY_ID,
                     p_CS_IN_CHARGE_CODE
                FROM CSG_M_CS_TERRITORY_INFO CMCTI                    -- CSテリトリー情報
               WHERE CMCTI.MODEL_CODE     = INPUT_MODEL_CODE          -- 機種コード
                 AND CMCTI.F_SALES_CODE   = INPUT_F_SALES_DEP_CODE    -- 部課コード
                 AND CMCTI.ACCOUNT_NO     IS NULL                     -- 顧客番号
                 AND CMCTI.POSTAL_CODE    IS NULL                     -- 郵便番号
                 AND CMCTI.STATE_CODE     IS NULL                     -- 都道府県コード
                 AND CMCTI.LOCAL_GOV_CODE IS NULL;                    -- 市区町村コード

              OUT_RESULT_GET             := 'OK';                     -- 取得結果
              OUT_CONDITION_GET          := '3.4';                    -- 取得条件
              OUT_CS_IN_CHARGE_CODE      := p_CS_IN_CHARGE_CODE;      -- 担当CSコード
              OUT_RESULT_CD              := '0';
              --****************************************************************
              -- 呼び出し元機能のステータス
              -- 0:処理中
              -- 1:正常終了
              -- 2:警告終了
              -- 3:エラー
              --****************************************************************
              OUT_STATUS                 := '1';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_RESULT_CD              := '10';
                OUT_RESULT_GET             := 'OK';           -- 取得結果='OK'
                OUT_CONDITION_GET          := 'NULL';         -- 取得条件=NULL
                OUT_CS_IN_CHARGE_CODE      := '100000300';           -- 担当CSコード='100000300'(担当G未設定)のコード値
                --************************************************************************
                -- 呼び出し元機能のステータス
                -- 0:処理中
                -- 1:正常終了
                -- 2:警告終了
                -- 3:エラー
                --************************************************************************
                OUT_STATUS      := '2';
                OUT_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
                OUT_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
            END;
           END IF;
        END IF;
      --************************************************************************
      -- 3.1.4. 「機種コード」≠ NULL の場合 　(Ｆ営業部課コードと顧客番号をNULLで判定) ※優先順位
      --************************************************************************
        IF INPUT_MODEL_CODE IS NOT NULL THEN
           --*******************************************************************
           -- 3.1.4.1.　郵便番号からの抽出
           --*******************************************************************
           IF p_POST_CODE IS NOT NULL AND p_CS_IN_CHARGE_CODE IS NULL THEN
            BEGIN
              SELECT CMCTI.CS_TERITORY_ID,                            -- CSテリトリー情報ID
                     CMCTI.CS_IN_CHARGE_CODE                          -- 担当CSコード
                INTO p_CS_TERITORY_ID,
                     p_CS_IN_CHARGE_CODE
                FROM CSG_M_CS_TERRITORY_INFO CMCTI                    -- CSテリトリー情報
               WHERE CMCTI.MODEL_CODE     = INPUT_MODEL_CODE          -- 機種コード
                 AND CMCTI.F_SALES_CODE   IS NULL                     -- 部課コード
                 AND CMCTI.ACCOUNT_NO     IS NULL                     -- 顧客番号
                 AND CMCTI.POSTAL_CODE    = p_POST_CODE;              -- 郵便番号

              OUT_RESULT_GET             := 'OK';                     -- 取得結果
              OUT_CONDITION_GET          := '4.1';                    -- 取得条件
              OUT_CS_IN_CHARGE_CODE      := p_CS_IN_CHARGE_CODE;      -- 担当CSコード
              OUT_RESULT_CD              := '0';
              --****************************************************************
              -- 呼び出し元機能のステータス
              -- 0:処理中
              -- 1:正常終了
              -- 2:警告終了
              -- 3:エラー
              --****************************************************************
              OUT_STATUS                 := '1';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_STATUS            := '2';           -- ステータス 0:処理中 1:正常終了 2:警告終了 3:エラー
            END;
           END IF;
           --*******************************************************************
           -- 3.1.4.2.　市区町村コードからの抽出
           --*******************************************************************
           IF p_KOKYO_CD IS NOT NULL AND p_CS_IN_CHARGE_CODE IS NULL THEN
            BEGIN
              SELECT CMCTI.CS_TERITORY_ID,                            -- CSテリトリー情報ID
                     CMCTI.CS_IN_CHARGE_CODE                          -- 担当CSコード
                INTO p_CS_TERITORY_ID,
                     p_CS_IN_CHARGE_CODE
                FROM CSG_M_CS_TERRITORY_INFO CMCTI                    -- CSテリトリー情報
               WHERE CMCTI.MODEL_CODE     = INPUT_MODEL_CODE          -- 機種コード
                 AND CMCTI.F_SALES_CODE   IS NULL                     -- 部課コード
                 AND CMCTI.ACCOUNT_NO     IS NULL                     -- 顧客番号
                 AND CMCTI.POSTAL_CODE    IS NULL                     -- 郵便番号
                 AND CMCTI.LOCAL_GOV_CODE = p_KOKYO_CD;               -- 市区町村コード

              OUT_RESULT_GET             := 'OK';                     -- 取得結果
              OUT_CONDITION_GET          := '4.2';                    -- 取得条件
              OUT_CS_IN_CHARGE_CODE      := p_CS_IN_CHARGE_CODE;      -- 担当CSコード
              OUT_RESULT_CD              := '0';
              --****************************************************************
              -- 呼び出し元機能のステータス
              -- 0:処理中
              -- 1:正常終了
              -- 2:警告終了
              -- 3:エラー
              --****************************************************************
              OUT_STATUS                 := '1';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_STATUS            := '2';           -- ステータス 0:処理中 1:正常終了 2:警告終了 3:エラー
            END;
           END IF;
           --*******************************************************************
           -- 3.1.4.3.　都道府県コードからの抽出
           --*******************************************************************
           IF p_STATE_CD IS NOT NULL AND p_CS_IN_CHARGE_CODE IS NULL THEN
            BEGIN
              SELECT CMCTI.CS_TERITORY_ID,                            -- CSテリトリー情報ID
                     CMCTI.CS_IN_CHARGE_CODE                          -- 担当CSコード
                INTO p_CS_TERITORY_ID,
                     p_CS_IN_CHARGE_CODE
                FROM CSG_M_CS_TERRITORY_INFO CMCTI                    -- CSテリトリー情報
               WHERE CMCTI.MODEL_CODE     = INPUT_MODEL_CODE          -- 機種コード
                 AND CMCTI.F_SALES_CODE   IS NULL                     -- 部課コード
                 AND CMCTI.ACCOUNT_NO     IS NULL                     -- 顧客番号
                 AND CMCTI.POSTAL_CODE    IS NULL                     -- 郵便番号
                 AND CMCTI.LOCAL_GOV_CODE IS NULL                     -- 市区町村コード
                 AND CMCTI.STATE_CODE     = p_STATE_CD;               -- 都道府県コード

              OUT_RESULT_GET             := 'OK';                     -- 取得結果
              OUT_CONDITION_GET          := '4.3';                    -- 取得条件
              OUT_CS_IN_CHARGE_CODE      := p_CS_IN_CHARGE_CODE;      -- 担当CSコード
              OUT_RESULT_CD              := '0';
              --****************************************************************
              -- 呼び出し元機能のステータス
              -- 0:処理中
              -- 1:正常終了
              -- 2:警告終了
              -- 3:エラー
              --****************************************************************
              OUT_STATUS                 := '1';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_STATUS            := '2';           -- ステータス 0:処理中 1:正常終了 2:警告終了 3:エラー
            END;
           END IF;
           --*******************************************************************
           -- 3.1.4.4.　パラメータ項目のみの抽出
           --*******************************************************************
           IF p_CS_IN_CHARGE_CODE IS NULL THEN
            BEGIN
              SELECT CMCTI.CS_TERITORY_ID,                            -- CSテリトリー情報ID
                     CMCTI.CS_IN_CHARGE_CODE                          -- 担当CSコード
                INTO p_CS_TERITORY_ID,
                     p_CS_IN_CHARGE_CODE
                FROM CSG_M_CS_TERRITORY_INFO CMCTI                    -- CSテリトリー情報
               WHERE CMCTI.MODEL_CODE     = INPUT_MODEL_CODE          -- 機種コード
                 AND CMCTI.F_SALES_CODE   IS NULL                     -- 部課コード
                 AND CMCTI.ACCOUNT_NO     IS NULL                     -- 顧客番号
                 AND CMCTI.POSTAL_CODE    IS NULL                     -- 郵便番号
                 AND CMCTI.LOCAL_GOV_CODE IS NULL                     -- 市区町村コード
                 AND CMCTI.STATE_CODE     IS NULL;                    -- 都道府県コード

              OUT_RESULT_GET             := 'OK';                     -- 取得結果
              OUT_CONDITION_GET          := '4.4';                    -- 取得条件
              OUT_CS_IN_CHARGE_CODE      := p_CS_IN_CHARGE_CODE;      -- 担当CSコード
              OUT_RESULT_CD              := '0';
              --****************************************************************
              -- 呼び出し元機能のステータス
              -- 0:処理中
              -- 1:正常終了
              -- 2:警告終了
              -- 3:エラー
              --****************************************************************
              OUT_STATUS                 := '1';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_RESULT_CD              := '10';
                OUT_RESULT_GET             := 'OK';           -- 取得結果='OK'
                OUT_CONDITION_GET          := 'NULL';         -- 取得条件=NULL
                OUT_CS_IN_CHARGE_CODE      := '100000300';           -- 担当CSコード='100000300'(担当G未設定)のコード値
                --************************************************************************
                -- 呼び出し元機能のステータス
                -- 0:処理中
                -- 1:正常終了
                -- 2:警告終了
                -- 3:エラー
                --************************************************************************
                OUT_STATUS      := '2';
                OUT_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
                OUT_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
            END;
           END IF;
        END IF;
      --************************************************************************
      -- 3.1.5. 「顧客番号」≠NULLかつ「Ｆ営業部課コード」≠NULLの場合 　(機種コードをNULLで判定) ※優先順位
      --************************************************************************
        IF INPUT_F_SALES_DEP_CODE IS NOT NULL AND
           INPUT_ACCOUNT_NO IS NOT NULL THEN
           --*******************************************************************
           -- 3.1.5.1.　郵便番号からの抽出
           --*******************************************************************
           IF p_POST_CODE IS NOT NULL AND p_CS_IN_CHARGE_CODE IS NULL THEN
            BEGIN
              SELECT CMCTI.CS_TERITORY_ID,                            -- CSテリトリー情報ID
                     CMCTI.CS_IN_CHARGE_CODE                          -- 担当CSコード
                INTO p_CS_TERITORY_ID,
                     p_CS_IN_CHARGE_CODE
                FROM CSG_M_CS_TERRITORY_INFO CMCTI                    -- CSテリトリー情報
               WHERE CMCTI.MODEL_CODE     IS NULL                     -- 機種コード
                 AND CMCTI.F_SALES_CODE   = INPUT_F_SALES_DEP_CODE    -- 部課コード
                 AND CMCTI.ACCOUNT_NO     = INPUT_ACCOUNT_NO          -- 顧客番号
                 AND CMCTI.POSTAL_CODE    = p_POST_CODE;              -- 郵便番号

              OUT_RESULT_GET             := 'OK';                     -- 取得結果
              OUT_CONDITION_GET          := '5.1';                    -- 取得条件
              OUT_CS_IN_CHARGE_CODE      := p_CS_IN_CHARGE_CODE;      -- 担当CSコード
              OUT_RESULT_CD              := '0';
              --****************************************************************
              -- 呼び出し元機能のステータス
              -- 0:処理中
              -- 1:正常終了
              -- 2:警告終了
              -- 3:エラー
              --****************************************************************
              OUT_STATUS                 := '1';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_STATUS            := '2';           -- ステータス 0:処理中 1:正常終了 2:警告終了 3:エラー
            END;
           END IF;
           --*******************************************************************
           -- 3.1.5.2.　市区町村コードからの抽出
           --*******************************************************************
           IF p_KOKYO_CD IS NOT NULL AND p_CS_IN_CHARGE_CODE IS NULL THEN
            BEGIN
              SELECT CMCTI.CS_TERITORY_ID,                            -- CSテリトリー情報ID
                     CMCTI.CS_IN_CHARGE_CODE                          -- 担当CSコード
                INTO p_CS_TERITORY_ID,
                     p_CS_IN_CHARGE_CODE
                FROM CSG_M_CS_TERRITORY_INFO CMCTI                    -- CSテリトリー情報
               WHERE CMCTI.MODEL_CODE     IS NULL                     -- 機種コード
                 AND CMCTI.F_SALES_CODE   = INPUT_F_SALES_DEP_CODE    -- 部課コード
                 AND CMCTI.ACCOUNT_NO     = INPUT_ACCOUNT_NO          -- 顧客番号
                 AND CMCTI.POSTAL_CODE    IS NULL                     -- 郵便番号
                 AND CMCTI.LOCAL_GOV_CODE = p_KOKYO_CD;               -- 市区町村コード

              OUT_RESULT_GET             := 'OK';                     -- 取得結果
              OUT_CONDITION_GET          := '5.2';                    -- 取得条件
              OUT_CS_IN_CHARGE_CODE      := p_CS_IN_CHARGE_CODE;      -- 担当CSコード
              OUT_RESULT_CD              := '0';
              --****************************************************************
              -- 呼び出し元機能のステータス
              -- 0:処理中
              -- 1:正常終了
              -- 2:警告終了
              -- 3:エラー
              --****************************************************************
              OUT_STATUS                 := '1';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_STATUS            := '2';           -- ステータス 0:処理中 1:正常終了 2:警告終了 3:エラー
            END;
           END IF;
           --*******************************************************************
           -- 3.1.5.3.　都道府県コードからの抽出
           --*******************************************************************
           IF p_STATE_CD IS NOT NULL AND p_CS_IN_CHARGE_CODE IS NULL THEN
            BEGIN
              SELECT CMCTI.CS_TERITORY_ID,                            -- CSテリトリー情報ID
                     CMCTI.CS_IN_CHARGE_CODE                          -- 担当CSコード
                INTO p_CS_TERITORY_ID,
                     p_CS_IN_CHARGE_CODE
                FROM CSG_M_CS_TERRITORY_INFO CMCTI                    -- CSテリトリー情報
               WHERE CMCTI.MODEL_CODE     IS NULL                     -- 機種コード
                 AND CMCTI.F_SALES_CODE   = INPUT_F_SALES_DEP_CODE    -- 部課コード
                 AND CMCTI.ACCOUNT_NO     = INPUT_ACCOUNT_NO          -- 顧客番号
                 AND CMCTI.POSTAL_CODE    IS NULL                     -- 郵便番号
                 AND CMCTI.LOCAL_GOV_CODE IS NULL                     -- 市区町村コード
                 AND CMCTI.STATE_CODE     = p_STATE_CD;               -- 都道府県コード

              OUT_RESULT_GET             := 'OK';                     -- 取得結果
              OUT_CONDITION_GET          := '5.3';                    -- 取得条件
              OUT_CS_IN_CHARGE_CODE      := p_CS_IN_CHARGE_CODE;      -- 担当CSコード
              OUT_RESULT_CD              := '0';
              --****************************************************************
              -- 呼び出し元機能のステータス
              -- 0:処理中
              -- 1:正常終了
              -- 2:警告終了
              -- 3:エラー
              --****************************************************************
              OUT_STATUS                 := '1';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_STATUS            := '2';           -- ステータス 0:処理中 1:正常終了 2:警告終了 3:エラー
            END;
           END IF;
           --*******************************************************************
           -- 3.1.5.4.　パラメータ項目のみの抽出
           --*******************************************************************
           IF p_CS_IN_CHARGE_CODE IS NULL THEN
            BEGIN
              SELECT CMCTI.CS_TERITORY_ID,                            -- CSテリトリー情報ID
                     CMCTI.CS_IN_CHARGE_CODE                          -- 担当CSコード
                INTO p_CS_TERITORY_ID,
                     p_CS_IN_CHARGE_CODE
                FROM CSG_M_CS_TERRITORY_INFO CMCTI                    -- CSテリトリー情報
               WHERE CMCTI.MODEL_CODE     IS NULL                     -- 機種コード
                 AND CMCTI.F_SALES_CODE   = INPUT_F_SALES_DEP_CODE    -- 部課コード
                 AND CMCTI.ACCOUNT_NO     = INPUT_ACCOUNT_NO          -- 顧客番号
                 AND CMCTI.POSTAL_CODE    IS NULL                     -- 郵便番号
                 AND CMCTI.STATE_CODE     IS NULL                     -- 都道府県コード
                 AND CMCTI.LOCAL_GOV_CODE IS NULL;                    -- 市区町村コード

              OUT_RESULT_GET             := 'OK';                     -- 取得結果
              OUT_CONDITION_GET          := '5.4';                    -- 取得条件
              OUT_CS_IN_CHARGE_CODE      := p_CS_IN_CHARGE_CODE;      -- 担当CSコード
              OUT_RESULT_CD              := '0';
              --****************************************************************
              -- 呼び出し元機能のステータス
              -- 0:処理中
              -- 1:正常終了
              -- 2:警告終了
              -- 3:エラー
              --****************************************************************
              OUT_STATUS                 := '1';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_RESULT_CD              := '10';
                OUT_RESULT_GET             := 'OK';           -- 取得結果='OK'
                OUT_CONDITION_GET          := 'NULL';         -- 取得条件=NULL
                OUT_CS_IN_CHARGE_CODE      := '100000300';           -- 担当CSコード='100000300'(担当G未設定)のコード値
                --************************************************************************
                -- 呼び出し元機能のステータス
                -- 0:処理中
                -- 1:正常終了
                -- 2:警告終了
                -- 3:エラー
                --************************************************************************
                OUT_STATUS      := '2';
                OUT_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
                OUT_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
            END;
           END IF;
        END IF;
      --************************************************************************
      -- 3.1.6. 「顧客番号」≠NULLの場合 　(機種コード、Ｆ営業部課コードをNULLで判定) ※優先順位
      --************************************************************************
        IF INPUT_ACCOUNT_NO IS NOT NULL THEN
           --*******************************************************************
           -- 3.1.6.1.　郵便番号からの抽出
           --*******************************************************************
           IF p_POST_CODE IS NOT NULL AND p_CS_IN_CHARGE_CODE IS NULL THEN
            BEGIN
              SELECT CMCTI.CS_TERITORY_ID,                            -- CSテリトリー情報ID
                     CMCTI.CS_IN_CHARGE_CODE                          -- 担当CSコード
                INTO p_CS_TERITORY_ID,
                     p_CS_IN_CHARGE_CODE
                FROM CSG_M_CS_TERRITORY_INFO CMCTI                    -- CSテリトリー情報
               WHERE CMCTI.MODEL_CODE     IS NULL                     -- 機種コード
                 AND CMCTI.F_SALES_CODE   IS NULL                     -- 部課コード
                 AND CMCTI.ACCOUNT_NO     = INPUT_ACCOUNT_NO          -- 顧客番号
                 AND CMCTI.POSTAL_CODE    = p_POST_CODE;              -- 郵便番号

              OUT_RESULT_GET             := 'OK';                     -- 取得結果
              OUT_CONDITION_GET          := '6.1';                    -- 取得条件
              OUT_CS_IN_CHARGE_CODE      := p_CS_IN_CHARGE_CODE;      -- 担当CSコード
              OUT_RESULT_CD              := '0';
              --****************************************************************
              -- 呼び出し元機能のステータス
              -- 0:処理中
              -- 1:正常終了
              -- 2:警告終了
              -- 3:エラー
              --****************************************************************
              OUT_STATUS                 := '1';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_STATUS            := '2';           -- ステータス 0:処理中 1:正常終了 2:警告終了 3:エラー
            END;
           END IF;
           --*******************************************************************
           -- 3.1.6.2.　市区町村コードからの抽出
           --*******************************************************************
           IF p_KOKYO_CD IS NOT NULL AND p_CS_IN_CHARGE_CODE IS NULL THEN
            BEGIN
              SELECT CMCTI.CS_TERITORY_ID,                            -- CSテリトリー情報ID
                     CMCTI.CS_IN_CHARGE_CODE                          -- 担当CSコード
                INTO p_CS_TERITORY_ID,
                     p_CS_IN_CHARGE_CODE
                FROM CSG_M_CS_TERRITORY_INFO CMCTI                    -- CSテリトリー情報
               WHERE CMCTI.MODEL_CODE     IS NULL                     -- 機種コード
                 AND CMCTI.F_SALES_CODE   IS NULL                     -- 部課コード
                 AND CMCTI.ACCOUNT_NO     = INPUT_ACCOUNT_NO          -- 顧客番号
                 AND CMCTI.POSTAL_CODE    IS NULL                     -- 郵便番号
                 AND CMCTI.LOCAL_GOV_CODE = p_KOKYO_CD;               -- 市区町村コード

              OUT_RESULT_GET             := 'OK';                     -- 取得結果
              OUT_CONDITION_GET          := '6.2';                    -- 取得条件
              OUT_CS_IN_CHARGE_CODE      := p_CS_IN_CHARGE_CODE;      -- 担当CSコード
              OUT_RESULT_CD              := '0';
              --****************************************************************
              -- 呼び出し元機能のステータス
              -- 0:処理中
              -- 1:正常終了
              -- 2:警告終了
              -- 3:エラー
              --****************************************************************
              OUT_STATUS                 := '1';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_STATUS            := '2';           -- ステータス 0:処理中 1:正常終了 2:警告終了 3:エラー
            END;
           END IF;
           --*******************************************************************
           -- 3.1.6.3.　都道府県コードからの抽出
           --*******************************************************************
           IF p_STATE_CD IS NOT NULL AND p_CS_IN_CHARGE_CODE IS NULL THEN
            BEGIN
              SELECT CMCTI.CS_TERITORY_ID,                            -- CSテリトリー情報ID
                     CMCTI.CS_IN_CHARGE_CODE                          -- 担当CSコード
                INTO p_CS_TERITORY_ID,
                     p_CS_IN_CHARGE_CODE
                FROM CSG_M_CS_TERRITORY_INFO CMCTI                    -- CSテリトリー情報
               WHERE CMCTI.MODEL_CODE     IS NULL                     -- 機種コード
                 AND CMCTI.F_SALES_CODE   IS NULL                     -- 部課コード
                 AND CMCTI.ACCOUNT_NO     = INPUT_ACCOUNT_NO          -- 顧客番号
                 AND CMCTI.POSTAL_CODE    IS NULL                     -- 郵便番号
                 AND CMCTI.LOCAL_GOV_CODE IS NULL                     -- 市区町村コード
                 AND CMCTI.STATE_CODE     = p_STATE_CD;               -- 都道府県コード


              OUT_RESULT_GET             := 'OK';                     -- 取得結果
              OUT_CONDITION_GET          := '6.3';                    -- 取得条件
              OUT_CS_IN_CHARGE_CODE      := p_CS_IN_CHARGE_CODE;      -- 担当CSコード
              OUT_RESULT_CD              := '0';
              --****************************************************************
              -- 呼び出し元機能のステータス
              -- 0:処理中
              -- 1:正常終了
              -- 2:警告終了
              -- 3:エラー
              --****************************************************************
              OUT_STATUS                 := '1';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_STATUS            := '2';           -- ステータス 0:処理中 1:正常終了 2:警告終了 3:エラー
            END;
           END IF;
           --*******************************************************************
           -- 3.1.6.4.　パラメータ項目のみの抽出
           --*******************************************************************
           IF p_CS_IN_CHARGE_CODE IS NULL THEN
            BEGIN
              SELECT CMCTI.CS_TERITORY_ID,                            -- CSテリトリー情報ID
                     CMCTI.CS_IN_CHARGE_CODE                          -- 担当CSコード
                INTO p_CS_TERITORY_ID,
                     p_CS_IN_CHARGE_CODE
                FROM CSG_M_CS_TERRITORY_INFO CMCTI                    -- CSテリトリー情報
               WHERE CMCTI.MODEL_CODE     IS NULL                     -- 機種コード
                 AND CMCTI.F_SALES_CODE   IS NULL                     -- 部課コード
                 AND CMCTI.ACCOUNT_NO     = INPUT_ACCOUNT_NO          -- 顧客番号
                 AND CMCTI.POSTAL_CODE    IS NULL                     -- 郵便番号
                 AND CMCTI.LOCAL_GOV_CODE IS NULL                     -- 市区町村コード
                 AND CMCTI.STATE_CODE     IS NULL;                    -- 都道府県コード

              OUT_RESULT_GET             := 'OK';                     -- 取得結果
              OUT_CONDITION_GET          := '6.4';                    -- 取得条件
              OUT_CS_IN_CHARGE_CODE      := p_CS_IN_CHARGE_CODE;      -- 担当CSコード
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_RESULT_CD              := '10';
                OUT_RESULT_GET             := 'OK';           -- 取得結果='OK'
                OUT_CONDITION_GET          := 'NULL';         -- 取得条件=NULL
                OUT_CS_IN_CHARGE_CODE      := '100000300';           -- 担当CSコード='100000300'(担当G未設定)のコード値
                --************************************************************************
                -- 呼び出し元機能のステータス
                -- 0:処理中
                -- 1:正常終了
                -- 2:警告終了
                -- 3:エラー
                --************************************************************************
                OUT_STATUS      := '2';
                OUT_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
                OUT_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
            END;
           END IF;
        END IF;
      --************************************************************************
      -- 3.2.7. 「Ｆ営業部課コード」≠NULLの場合 　(機種コード、顧客コードをNULLで判定) ※優先順位
      --************************************************************************
        IF INPUT_F_SALES_DEP_CODE IS NOT NULL THEN
           --*******************************************************************
           -- 3.2.7.1.　郵便番号からの抽出
           --*******************************************************************
           IF p_POST_CODE IS NOT NULL AND p_CS_IN_CHARGE_CODE IS NULL THEN
            BEGIN
              SELECT CMCTI.CS_TERITORY_ID,                            -- CSテリトリー情報ID
                     CMCTI.CS_IN_CHARGE_CODE                          -- 担当CSコード
                INTO p_CS_TERITORY_ID,
                     p_CS_IN_CHARGE_CODE
                FROM CSG_M_CS_TERRITORY_INFO CMCTI                    -- CSテリトリー情報
               WHERE CMCTI.MODEL_CODE     IS NULL                     -- 機種コード
                 AND CMCTI.F_SALES_CODE   = INPUT_F_SALES_DEP_CODE    -- 部課コード
                 AND CMCTI.ACCOUNT_NO     IS NULL                     -- 顧客番号
                 AND CMCTI.POSTAL_CODE    = p_POST_CODE;              -- 郵便番号

              OUT_RESULT_GET             := 'OK';                     -- 取得結果
              OUT_CONDITION_GET          := '7.1';                    -- 取得条件
              OUT_CS_IN_CHARGE_CODE      := p_CS_IN_CHARGE_CODE;      -- 担当CSコード
              OUT_RESULT_CD              := '0';
              --****************************************************************
              -- 呼び出し元機能のステータス
              -- 0:処理中
              -- 1:正常終了
              -- 2:警告終了
              -- 3:エラー
              --****************************************************************
              OUT_STATUS                 := '1';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_STATUS            := '2';           -- ステータス 0:処理中 1:正常終了 2:警告終了 3:エラー
            END;
           END IF;
           --*******************************************************************
           -- 3.2.7.2.　市区町村コードからの抽出
           --*******************************************************************
           IF p_KOKYO_CD IS NOT NULL AND p_CS_IN_CHARGE_CODE IS NULL THEN
            BEGIN
              SELECT CMCTI.CS_TERITORY_ID,                            -- CSテリトリー情報ID
                     CMCTI.CS_IN_CHARGE_CODE                          -- 担当CSコード
                INTO p_CS_TERITORY_ID,
                     p_CS_IN_CHARGE_CODE
                FROM CSG_M_CS_TERRITORY_INFO CMCTI                    -- CSテリトリー情報
               WHERE CMCTI.MODEL_CODE     IS NULL                     -- 機種コード
                 AND CMCTI.F_SALES_CODE   = INPUT_F_SALES_DEP_CODE    -- 部課コード
                 AND CMCTI.ACCOUNT_NO     IS NULL                     -- 顧客番号
                 AND CMCTI.POSTAL_CODE    IS NULL                     -- 郵便番号
                 AND CMCTI.LOCAL_GOV_CODE = p_KOKYO_CD;               -- 市区町村コード

              OUT_RESULT_GET             := 'OK';                     -- 取得結果
              OUT_CONDITION_GET          := '7.2';                    -- 取得条件
              OUT_CS_IN_CHARGE_CODE      := P_CS_IN_CHARGE_CODE;      -- 担当CSコード
              OUT_RESULT_CD              := '0';
              --****************************************************************
              -- 呼び出し元機能のステータス
              -- 0:処理中
              -- 1:正常終了
              -- 2:警告終了
              -- 3:エラー
              --****************************************************************
              OUT_STATUS                 := '1';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_STATUS            := '2';           -- ステータス 0:処理中 1:正常終了 2:警告終了 3:エラー
            END;
           END IF;
           --*******************************************************************
           -- 3.2.7.3.　都道府県コードからの抽出
           --*******************************************************************
           IF p_STATE_CD IS NOT NULL AND p_CS_IN_CHARGE_CODE IS NULL THEN
            BEGIN
              SELECT CMCTI.CS_TERITORY_ID,                            -- CSテリトリー情報ID
                     CMCTI.CS_IN_CHARGE_CODE                          -- 担当CSコード
                INTO p_CS_TERITORY_ID,
                     p_CS_IN_CHARGE_CODE
                FROM CSG_M_CS_TERRITORY_INFO CMCTI                    -- CSテリトリー情報
               WHERE CMCTI.MODEL_CODE     IS NULL                     -- 機種コード
                 AND CMCTI.F_SALES_CODE   = INPUT_F_SALES_DEP_CODE    -- 部課コード
                 AND CMCTI.ACCOUNT_NO     IS NULL                     -- 顧客番号
                 AND CMCTI.POSTAL_CODE    IS NULL                     -- 郵便番号
                 AND CMCTI.LOCAL_GOV_CODE IS NULL                     -- 市区町村コード
                 AND CMCTI.STATE_CODE     = p_STATE_CD;               -- 都道府県コード

              OUT_RESULT_GET             := 'OK';                     -- 取得結果
              OUT_CONDITION_GET          := '7.3';                    -- 取得条件
              OUT_CS_IN_CHARGE_CODE      := p_CS_IN_CHARGE_CODE;      -- 担当CSコード
              OUT_RESULT_CD              := '0';
              --****************************************************************
              -- 呼び出し元機能のステータス
              -- 0:処理中
              -- 1:正常終了
              -- 2:警告終了
              -- 3:エラー
              --****************************************************************
              OUT_STATUS                 := '1';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_STATUS            := '2';           -- ステータス 0:処理中 1:正常終了 2:警告終了 3:エラー
            END;
           END IF;
           --*******************************************************************
           -- 3.2.7.4.　パラメータ項目のみの抽出
           --*******************************************************************
           IF p_CS_IN_CHARGE_CODE IS NULL THEN
            BEGIN
              SELECT CMCTI.CS_TERITORY_ID,                            -- CSテリトリー情報ID
                     CMCTI.CS_IN_CHARGE_CODE                          -- 担当CSコード
                INTO p_CS_TERITORY_ID,
                     p_CS_IN_CHARGE_CODE
                FROM CSG_M_CS_TERRITORY_INFO CMCTI                    -- CSテリトリー情報
               WHERE CMCTI.MODEL_CODE     IS NULL                     -- 機種コード
                 AND CMCTI.F_SALES_CODE   = INPUT_F_SALES_DEP_CODE    -- 部課コード
                 AND CMCTI.ACCOUNT_NO     IS NULL                     -- 顧客番号
                 AND CMCTI.POSTAL_CODE    IS NULL                     -- 郵便番号
                 AND CMCTI.LOCAL_GOV_CODE IS NULL                     -- 市区町村コード
                 AND CMCTI.STATE_CODE     IS NULL;                    -- 都道府県コード

              OUT_RESULT_GET             := 'OK';                     -- 取得結果
              OUT_CONDITION_GET          := '7.4';                    -- 取得条件
              OUT_CS_IN_CHARGE_CODE      := P_CS_IN_CHARGE_CODE;      -- 担当CSコード
              OUT_RESULT_CD              := '0';
              --****************************************************************
              -- 呼び出し元機能のステータス
              -- 0:処理中
              -- 1:正常終了
              -- 2:警告終了
              -- 3:エラー
              --****************************************************************
              OUT_STATUS                 := '1';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_RESULT_CD              := '10';
                OUT_RESULT_GET             := 'OK';           -- 取得結果='OK'
                OUT_CONDITION_GET          := 'NULL';         -- 取得条件=NULL
                OUT_CS_IN_CHARGE_CODE      := '100000300';           -- 担当CSコード='100000300'(担当G未設定)のコード値
                --************************************************************************
                -- 呼び出し元機能のステータス
                -- 0:処理中
                -- 1:正常終了
                -- 2:警告終了
                -- 3:エラー
                --************************************************************************
                OUT_STATUS      := '2';
                OUT_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
                OUT_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
            END;
           END IF;
        END IF;
      --************************************************************************
      -- 3.2.8. パラメータ項目NULL判定 　(機種コード、顧客コード、Ｆ営業部課コードをNULLで判定) ※優先順位
      --************************************************************************
        IF INPUT_MODEL_CODE IS NULL AND
           INPUT_F_SALES_DEP_CODE IS NULL AND
           INPUT_ACCOUNT_NO IS NULL THEN
           --*******************************************************************
           -- 3.2.8.1.　郵便番号からの抽出
           --*******************************************************************
           IF p_POST_CODE IS NOT NULL AND p_CS_IN_CHARGE_CODE IS NULL THEN
            BEGIN
              SELECT CMCTI.CS_TERITORY_ID,                            -- CSテリトリー情報ID
                     CMCTI.CS_IN_CHARGE_CODE                          -- 担当CSコード
                INTO p_CS_TERITORY_ID,
                     p_CS_IN_CHARGE_CODE
                FROM CSG_M_CS_TERRITORY_INFO CMCTI                    -- CSテリトリー情報
               WHERE CMCTI.MODEL_CODE     IS NULL                     -- 機種コード
                 AND CMCTI.F_SALES_CODE   IS NULL                     -- 部課コード
                 AND CMCTI.ACCOUNT_NO     IS NULL                     -- 顧客番号
                 AND CMCTI.POSTAL_CODE    = p_POST_CODE;              -- 郵便番号

              OUT_RESULT_GET             := 'OK';                     -- 取得結果
              OUT_CONDITION_GET          := '8.1';                    -- 取得条件
              OUT_CS_IN_CHARGE_CODE      := p_CS_IN_CHARGE_CODE;      -- 担当CSコード
              OUT_RESULT_CD              := '0';
              --****************************************************************
              -- 呼び出し元機能のステータス
              -- 0:処理中
              -- 1:正常終了
              -- 2:警告終了
              -- 3:エラー
              --****************************************************************
              OUT_STATUS                 := '1';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_STATUS            := '2';           -- ステータス 0:処理中 1:正常終了 2:警告終了 3:エラー
            END;
           END IF;
           --*******************************************************************
           -- 3.2.8.2.　市区町村コードからの抽出
           --*******************************************************************
           IF p_KOKYO_CD IS NOT NULL AND p_CS_IN_CHARGE_CODE IS NULL THEN
            BEGIN
              SELECT CMCTI.CS_TERITORY_ID,                            -- CSテリトリー情報ID
                     CMCTI.CS_IN_CHARGE_CODE                          -- 担当CSコード
                INTO p_CS_TERITORY_ID,
                     p_CS_IN_CHARGE_CODE
                FROM CSG_M_CS_TERRITORY_INFO CMCTI                    -- CSテリトリー情報
               WHERE CMCTI.MODEL_CODE     IS NULL                     -- 機種コード
                 AND CMCTI.F_SALES_CODE   IS NULL                     -- 部課コード
                 AND CMCTI.ACCOUNT_NO     IS NULL                     -- 顧客番号
                 AND CMCTI.POSTAL_CODE    IS NULL                     -- 郵便番号
                 AND CMCTI.LOCAL_GOV_CODE = p_KOKYO_CD;               -- 市区町村コード

              OUT_RESULT_GET             := 'OK';                     -- 取得結果
              OUT_CONDITION_GET          := '8.2';                    -- 取得条件
              OUT_CS_IN_CHARGE_CODE      := p_CS_IN_CHARGE_CODE;      -- 担当CSコード
              OUT_RESULT_CD              := '0';
              --****************************************************************
              -- 呼び出し元機能のステータス
              -- 0:処理中
              -- 1:正常終了
              -- 2:警告終了
              -- 3:エラー
              --****************************************************************
              OUT_STATUS                 := '1';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_STATUS            := '2';           -- ステータス 0:処理中 1:正常終了 2:警告終了 3:エラー
            END;
           END IF;
           --*******************************************************************
           -- 3.2.8.3.　都道府県コードからの抽出
           --*******************************************************************
           IF p_STATE_CD IS NOT NULL AND p_CS_IN_CHARGE_CODE IS NULL THEN
            BEGIN
              SELECT CMCTI.CS_TERITORY_ID,                            -- CSテリトリー情報ID
                     CMCTI.CS_IN_CHARGE_CODE                          -- 担当CSコード
                INTO p_CS_TERITORY_ID,
                     p_CS_IN_CHARGE_CODE
                FROM CSG_M_CS_TERRITORY_INFO CMCTI                    -- CSテリトリー情報
               WHERE CMCTI.MODEL_CODE     IS NULL                     -- 機種コード
                 AND CMCTI.F_SALES_CODE   IS NULL                     -- 部課コード
                 AND CMCTI.ACCOUNT_NO     IS NULL                     -- 顧客番号
                 AND CMCTI.POSTAL_CODE    IS NULL                     -- 郵便番号
                 AND CMCTI.LOCAL_GOV_CODE IS NULL                     -- 市区町村コード
                 AND CMCTI.STATE_CODE     = p_STATE_CD;               -- 都道府県コード

              OUT_RESULT_GET             := 'OK';                     -- 取得結果
              OUT_CONDITION_GET          := '8.3';                    -- 取得条件
              OUT_CS_IN_CHARGE_CODE      := P_CS_IN_CHARGE_CODE;      -- 担当CSコード
              OUT_RESULT_CD              := '0';
              --****************************************************************
              -- 呼び出し元機能のステータス
              -- 0:処理中
              -- 1:正常終了
              -- 2:警告終了
              -- 3:エラー
              --****************************************************************
              OUT_STATUS                 := '1';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_RESULT_CD              := '10';
                OUT_RESULT_GET             := 'OK';           -- 取得結果='OK'
                OUT_CONDITION_GET          := 'NULL';         -- 取得条件=NULL
                OUT_CS_IN_CHARGE_CODE      := '100000300';           -- 担当CSコード='100000300'(担当G未設定)のコード値
                --************************************************************************
                -- 呼び出し元機能のステータス
                -- 0:処理中
                -- 1:正常終了
                -- 2:警告終了
                -- 3:エラー
                --************************************************************************
                OUT_STATUS      := '2';
                OUT_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
                OUT_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
            END;
           END IF;
        END IF;
      END IF;
    END IF;
  EXCEPTION
    -- その他未定義の例外の処理
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE(PRAM_PLACE_HOLDER || 'に失敗しました。');
      OUT_RESULT_CD              := '20';
      OUT_RESULT_GET             := 'NG';
      OUT_CONDITION_GET          := 'NULL';
      OUT_CS_IN_CHARGE_CODE      := 'NULL';
      --************************************************************************
      -- 呼び出し元機能のステータス
      -- 0:処理中
      -- 1:正常終了
      -- 2:警告終了
      -- 3:エラー
      --************************************************************************
      OUT_STATUS      := '3';
      OUT_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
      OUT_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
      DBMS_OUTPUT.PUT_LINE('ORACLE ERR_CODE    := ' || sqlcode);            -- ＤＢエラーコード
      DBMS_OUTPUT.PUT_LINE('ORACLE ERR_MESSAGE := ' || sqlerrm(sqlcode));   -- ＤＢエラーメッセージ
      ROLLBACK;
      RETURN;
  END CSG02_PROC_CHARGE_OF_CS_SET;

END CSG02_0110_PKG;
/
