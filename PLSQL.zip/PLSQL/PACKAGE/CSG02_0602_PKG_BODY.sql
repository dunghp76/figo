CREATE OR REPLACE PACKAGE BODY "CSG02_0602_PKG" AS
/*******************************************************************************
* CSテリトリー更新ツール                                                                     
*-------------------------------------------------------------------------------
* <更新履歴>                                                                     
* <Version>   <日付>      <更新概要>                             <更新者>         
*   1.0     2016/04/04      新規                             FOCUS_NGUYENQUOCDAT
*   1.0     2016/06/08      更新                             FOCUS_LETHANHMINH
*******************************************************************************/
  g_shori_point                 VARCHAR2(250);    -- 処理ポイント
  set_sysdate                   DATE;             -- システム日時
  OUT_STATUS                    VARCHAR2(10);     -- ステータス
  OUT_PROCESS_ID                VARCHAR2(15);     -- プロセスID 
/*******************************************************************************/
  PROCEDURE MAIN_CSG02_0602
  (  
      INPUT_USER_ID        IN VARCHAR2 ,    -- ユーザID
      INPUT_PATH_FILE      IN VARCHAR2,     -- CSVファイルパス
      OUT_PROCESS_END_DATE OUT VARCHAR2,    -- エラー内容
      OUT_ERR_CONTENT      OUT VARCHAR2,    -- エラー詳細
      OUT_ERR_DETAIL       OUT VARCHAR2,    -- ダウンロードファイル
      OUT_DL_FILE          OUT VARCHAR2,
      OUT_RESULT_CD        OUT VARCHAR2     -- 終了コード (0  ：正常終了コード　／　'20' ：異常終了コード)       
  ) AS
  PRAM_EXCEPTION            EXCEPTION;
  v_DTL_TXT_FRML_NM         SNV_M_GNRC_SNV.DTL_TXT_FRML_NM%TYPE; -- 汎用マスタ.明細テキスト(正式名)（バッチ実行ユーザID）
  BEGIN
  g_shori_point :='PROCESS_MAIN';
-- *****************************************************************************
-- 0.1.システム日時の取得	
-- システム日時を取得する。
-- *****************************************************************************
  set_sysdate := SYSDATE;
-- *****************************************************************************
-- 0.2.	バッチ実行ユーザID 取得											
-- 汎用マスタより、バッチ実行ユーザIDを取得する。											
-- *****************************************************************************
  SELECT SNV_M_GNRC_SNV.DTL_TXT_FRML_NM               --明細テキスト(正式名)（バッチ実行ユーザID）									
    INTO v_DTL_TXT_FRML_NM
    FROM SNV_M_GNRC_SNV                               --汎用マスタ
   WHERE SNV_M_GNRC_SNV.KEY_ITEM = 'CSG_GENERAL_PROP' --コード区分(汎用プロパティ)
     AND SNV_M_GNRC_SNV.CD_VAL   = 'BATCH_USER';      --コード値(バッチ実行ユーザID)
-- *****************************************************************************
-- 0.3.処理IDの取得
-- 開始時バックグラウンド処理を呼び出す。
-- *****************************************************************************
  CSG05_0101_PKG.CSG05_PROC_BG_PROCESS_START (
                                'BAT-CSG02-0602-01',
                                INPUT_PATH_FILE,
                                set_sysdate,
                                v_DTL_TXT_FRML_NM,
                                OUT_PROCESS_ID,
                                OUT_RESULT_CD
                              );
-- *****************************************************************************
-- 処理結果 = 1（処理IDを取得できなかった）の場合
-- エラーメッセージ[MSG-CSG-F-0003]をログ出力し、後続の処理を中断する。
-- *****************************************************************************
  IF OUT_PROCESS_ID = '1' THEN
    DBMS_OUTPUT.PUT_LINE('処理IDが取得できませんでした。システム管理者に問い合わせてください。');
    RAISE PRAM_EXCEPTION;
  END IF; 
--******************************************************************************
-- CSテリトリー更新ツール（PL/SQL）                                                       
-- CSG02-0110                                                                  
--******************************************************************************
  CSG02_PROC_CS_TERRITORY_UPDATE ( 
                                  INPUT_USER_ID                                -- ユーザID
                                , OUT_PROCESS_ID                               -- プロセスID
                                , INPUT_PATH_FILE                              -- CSVファイルパス
                                , OUT_PROCESS_ID                               -- 処理ID
                                , OUT_STATUS                                   -- ステータス
                                , OUT_PROCESS_END_DATE                         -- 処理終了日時
                                , OUT_ERR_CONTENT                              -- エラー内容
                                , OUT_ERR_DETAIL                               -- エラー詳細
                                , OUT_DL_FILE                                  -- ダウンロードファイル
                                , OUT_RESULT_CD                                -- 終了コード
                                );
--****************************************************************************
-- 3.終了処理
-- 3.3.実行結果の登録
-- 終了時バックグラウンド処理を呼び出す。
--*****************************************************************************       
  CSG05_0101_PKG.CSG05_PROC_BG_PROCESS_UPD (
                              OUT_PROCESS_ID,
                              OUT_STATUS,
                              set_sysdate,
                              OUT_ERR_CONTENT,
                              OUT_ERR_DETAIL,
                              '-',
                              OUT_RESULT_CD
                            );
  EXCEPTION
    WHEN PRAM_EXCEPTION THEN
      OUT_RESULT_CD    := '20';
      --************************************************************************
      -- 呼び出し元機能のステータス
      -- 0:処理中
      -- 1:正常終了
      -- 2:警告終了
      -- 3:エラー
      --************************************************************************
      OUT_STATUS      := '3';
      OUT_ERR_CONTENT := g_shori_point || ' ' || to_char(sqlcode);
      OUT_ERR_DETAIL  := g_shori_point || ' ' || to_char(sqlcode) || ' ' || sqlerrm(sqlcode);
      ROLLBACK;
      RETURN;
    -- その他未定義の例外の処理
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('ORACLE ERR_CODE    := ' || SQLCODE);          -- ＤＢエラーコード
      DBMS_OUTPUT.PUT_LINE('ORACLE ERR_MESSAGE := ' || SQLERRM(SQLCODE)); -- ＤＢエラーメッセージ
      DBMS_OUTPUT.PUT_LINE('PROC POINT         := ' || g_shori_point);    -- 処理ポイント
      OUT_RESULT_CD   := '20';
      --************************************************************************
      -- 呼び出し元機能のステータス
      -- 0:処理中
      -- 1:正常終了
      -- 2:警告終了
      -- 3:エラー
      --************************************************************************
      OUT_STATUS      := '3';
      OUT_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
      OUT_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
      ROLLBACK;
      RETURN;        
END MAIN_CSG02_0602;

/******************************************************************************
  * * CSG02-0602-CSテリトリー更新ツール                                                            
******************************************************************************/ 
  PROCEDURE CSG02_PROC_CS_TERRITORY_UPDATE(
      INPUT_USER_ID    IN VARCHAR2,      -- ユーザID
      INPUT_PROCESS_ID IN VARCHAR2,      -- プロセスID
      INPUT_PATH_FILE  IN VARCHAR2,      -- CSVファイルパス
      OUT_PROCESS_ID OUT VARCHAR2,       -- 処理ID
      OUT_STATUS OUT VARCHAR2,           -- ステータス
      OUT_PROCESS_END_DATE OUT VARCHAR2, -- 処理終了日時
      OUT_ERR_CONTENT OUT VARCHAR2,      -- エラー内容
      OUT_ERR_DETAIL OUT VARCHAR2,       -- エラー詳細
      OUT_DL_FILE OUT VARCHAR2,          -- ダウンロードファイル
      OUT_RESULT_CD OUT VARCHAR2         -- 終了コード
  ) AS 
  F UTL_FILE.FILE_TYPE;
  V_LINE                    VARCHAR2 (32760);
  N_CNT                     NUMBER;
  PRAM_PLACE_HOLDER         VARCHAR2(100);    -- プレースホルダパラメータ
  PRAM_EXCEPTION            EXCEPTION;
  NO_CHECK_DATA             EXCEPTION;
  GET_COUNT                 NUMBER;
  str_value                 VARCHAR2(2000);
  v_DirPath                 VARCHAR2(250);
  v_FileName                VARCHAR2(250);
--******************************************************************************
-- CSテリトリー情報のパラメータ
--******************************************************************************
  v_CsInChargeCode     CSG_M_CS_TERRITORY_INFO.CS_IN_CHARGE_CODE%type DEFAULT NULL; -- 担当CSコード
  v_ModelCode          CSG_M_CS_TERRITORY_INFO.MODEL_CODE%type DEFAULT NULL;        -- 機種コード
  v_FSalesCode         CSG_M_CS_TERRITORY_INFO.F_SALES_CODE%type DEFAULT NULL;      -- 部課コード
  v_AccountNo          CSG_M_CS_TERRITORY_INFO.ACCOUNT_NO%type DEFAULT NULL;        -- 顧客番号
  v_StateCode          CSG_M_CS_TERRITORY_INFO.STATE_CODE%type DEFAULT NULL;        -- 都道府県コード
  v_LocalGovCode       CSG_M_CS_TERRITORY_INFO.LOCAL_GOV_CODE%type DEFAULT NULL;    -- 市区町村コード
  v_PostalCode         CSG_M_CS_TERRITORY_INFO.POSTAL_CODE%type DEFAULT NULL;       -- 郵便番号
  BEGIN
    N_CNT             := 0;               -- 入力定義（1.1.CSVファイル取込）の読込件数
    g_shori_point     := 'PROCESS_MAIN';
    str_value         := '';
    OUT_RESULT_CD     := '0';
    OUT_STATUS        := '1';
    OUT_PROCESS_ID    := INPUT_PROCESS_ID;
    -- *************************************************************************
    --1.CSVファイルの読み込み												
    --	1.1.CSVファイルの読み込み(FOPEN)											
    --		パラメータで指定されたCSVファイルを読み込む										
    --**************************************************************************
    IF INPUT_PATH_FILE IS NULL OR INPUT_PATH_FILE = '' THEN
      RAISE PRAM_EXCEPTION;
    ELSE
      v_DirPath :=  GET_DIR_PATH(INPUT_PATH_FILE);
      v_FileName := GET_FILE_NAME(INPUT_PATH_FILE, v_DirPath);
    END IF;
    -- *************************************************************************
    -- 2.CSテリトリー情報テーブルの全行削除
    --   2.1.CSテリトリー情報テーブルの全行削除
    -- *************************************************************************
    DELETE FROM CSG_M_CS_TERRITORY_INFO;
    --**************************************************************************
    F := UTL_FILE.FOPEN ('TMP', v_FileName, 'R', 32760);
    IF UTL_FILE.IS_OPEN(F) THEN
      LOOP
        BEGIN
          UTL_FILE.GET_LINE(F, V_LINE, 32760);
          IF V_LINE IS NULL THEN
            DBMS_OUTPUT.PUT_LINE('読み込み時にエラーが発生した。');
            EXIT;
          END IF;
          --条件は、ヘッダー行を削除します。
          IF N_CNT > 0 THEN
            str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 1);
            v_CsInChargeCode            := REGEXP_SUBSTR(str_value, '[^"]+', 1);
            str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 2);
            str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 3);
            v_ModelCode                 := REGEXP_SUBSTR(str_value, '[^"]+', 1);
            str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 4);
            str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 5);
            v_AccountNo                 := REGEXP_SUBSTR(str_value, '[^"]+', 1);
            str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 6);
            str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 7);
            v_FSalesCode                := REGEXP_SUBSTR(str_value, '[^"]+', 1);
            str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 8);
            str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 9);
            v_StateCode                 := REGEXP_SUBSTR(str_value, '[^"]+', 1);
            str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 10);
            str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 11);
            v_LocalGovCode              := REGEXP_SUBSTR(str_value, '[^"]+', 1);
            str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 12);
            str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 13);
            v_PostalCode                := REGEXP_SUBSTR(str_value, '[^"]+', 1);
            str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 14);
          -- *******************************************************************
          --3.チェック処理
          --	3.1.妥当性チェック
          --		取り込みを行ったデータの妥当性チェックを行う。
          --		詳細は「仕様補足説明(CSテリトリー更新ツール)」シート_No.3を参照
          --  3.1.0 必須項目チェック
          --    CSVデータの以下の項目について、必須項目チェックを行う。
          --    ※	CSVデータの「機種コード」「F営業部課コード」「顧客番号」全てが未設定の場合、「都道府県コード」は必須項目
          --    ※	CSVデータの「市区町村コード」が設定されている場合、「都道府県コード」は必須項目
          --    ※	CSVデータの「郵便番号」が設定されている場合「都道府県コード」「市区町村コード」は必須項目
          -- *******************************************************************
          IF v_ModelCode IS NULL AND v_FSalesCode IS NULL AND v_AccountNo IS NULL THEN
            IF v_StateCode IS NULL THEN
              OUT_ERR_CONTENT := '都道府県コードを入力してください。';
              RAISE NO_CHECK_DATA;
            END IF;
          END IF;
          
          IF v_LocalGovCode IS NOT NULL THEN
            IF v_StateCode IS NULL THEN
              OUT_ERR_CONTENT := '都道府県コードを入力してください。';
              RAISE NO_CHECK_DATA;
            END IF;
          END IF;
          
          IF v_PostalCode IS NOT NULL THEN
            IF v_StateCode IS NULL AND v_LocalGovCode IS NULL THEN
              OUT_ERR_CONTENT := '都道府県コードと市区町村コードを入力してください。';
              RAISE NO_CHECK_DATA;
            END IF;
          END IF;
          -- *******************************************************************
          --3.1.1. 担当CSコードの妥当性チェック															
          --	担当CSコードがグループ管理テーブルに存在するかチェックする。														
          -- *******************************************************************
            IF v_CsInChargeCode IS NULL THEN   
               v_CsInChargeCode :='100000300';
            END IF;
            
            IF v_CsInChargeCode IS NOT NULL THEN
              BEGIN
               SELECT COUNT(*) 
                 INTO GET_COUNT
                 FROM CSG_M_GROUP_MANAGEMENT                       -- グループ管理
                WHERE GROUP_ID = v_CsInChargeCode                  -- グループID
                  AND set_sysdate BETWEEN START_DATE AND NVL(END_DATE,SYSDATE); -- 有効開始日	有効終了日
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  DBMS_OUTPUT.PUT_LINE(g_shori_point || ' ' || TO_CHAR(SQLCODE));
              END;
               
              IF GET_COUNT = 0 THEN
                OUT_ERR_CONTENT := 'マスタに存在しない担当CSコードが設定されています。';
                RAISE NO_CHECK_DATA;
              END IF;
            END IF;
          -- *******************************************************************
          --3.1.2. 機種コードの妥当性チェック													
          --	機種コードが汎用マスタに存在するかチェックする。																							
          -- *******************************************************************
            IF v_ModelCode IS NOT NULL THEN
              BEGIN
               SELECT COUNT(*) 
                 INTO GET_COUNT
                 FROM SNV_M_GNRC_SNV                                    -- 汎用マスタ
                WHERE CLSFCTN = 'M'                                    -- 分類	
                  AND KEY_ITEM = 'CSG_MODEL_CODE'                       -- キー項目	
                  AND set_sysdate BETWEEN VALD_STRT_DT AND NVL(VALD_END_DT,SYSDATE)  -- 有効開始日	有効終了日	
                  AND NVL(DEL_FLG,'N') <>'X'                            -- 削除フラグ	
                  AND CD_VAL = v_ModelCode;                             -- コード値	
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  DBMS_OUTPUT.PUT_LINE(g_shori_point || ' ' || TO_CHAR(SQLCODE));
              END;
              
              IF GET_COUNT = 0 THEN
                OUT_ERR_CONTENT := 'マスタに存在しない機種コードが設定されています。';
                RAISE NO_CHECK_DATA;
              END IF;
            END IF;
          -- *******************************************************************
          -- 3.1.3. 部課コードの妥当性チェック		
          --	部課コードが組織マスタに存在するかチェックする。	
          -- *******************************************************************
            IF v_FSalesCode IS NOT NULL THEN
              BEGIN
               SELECT COUNT(*) 
                 INTO GET_COUNT
                 FROM SNV_M_DPT                                         -- 組織マスタ
                WHERE EXP_DPT_CD = v_FSalesCode                         -- 組織コード(経費負担部課)
                  AND set_sysdate BETWEEN VALD_STRT_DT AND NVL(VALD_END_DT,SYSDATE)  -- 有効開始日	有効終了日	
                  AND DEL_FLG   <> 'X';                                 -- 削除フラグ
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  DBMS_OUTPUT.PUT_LINE(g_shori_point || ' ' || TO_CHAR(SQLCODE));
              END;
              
              IF GET_COUNT = 0 THEN
                OUT_ERR_CONTENT := 'マスタに存在しない部課コードが設定されています。';
                RAISE NO_CHECK_DATA;
              END IF;
            END IF;
          -- *******************************************************************
          --3.1.4. 顧客番号の妥当性チェック	
          --	顧客番号が顧客マスタに存在するかチェックする。
          -- *******************************************************************
            IF v_AccountNo IS NOT NULL THEN
              BEGIN
               SELECT COUNT(*) 
                 INTO GET_COUNT
                 FROM SNV_M_CUST                                   -- 顧客マスタ
                WHERE CUST_CD       = v_AccountNo                  -- 顧客コード
                  AND CUST_ACCT_GRP = 'Z001'                       -- 顧客勘定グループ
                  AND DEL_FLG       <>'X';                         -- 削除フラグ
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  DBMS_OUTPUT.PUT_LINE(g_shori_point || ' ' || TO_CHAR(SQLCODE));
              END;
              
              IF GET_COUNT = 0 THEN
                OUT_ERR_CONTENT := 'マスタに存在しない顧客番号が設定されています。';
                RAISE NO_CHECK_DATA;
              END IF;
            END IF;
          -- *******************************************************************
          --3.1.5. 都道府県コードの妥当性チェック	
          --	都道府県コードが郵便番号マスタに存在するかチェックする。
          -- *******************************************************************
          IF v_StateCode IS NOT NULL THEN
              BEGIN
               SELECT COUNT(*) 
                 INTO GET_COUNT
                 FROM CSG_M_POSTAL_CODE                           -- 郵便番号マスタ
                WHERE STATE_CD = v_StateCode;                    -- 都道府県コード
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  DBMS_OUTPUT.PUT_LINE(g_shori_point || ' ' || TO_CHAR(SQLCODE));
              END;
              
              IF GET_COUNT = 0 THEN
                OUT_ERR_CONTENT := 'マスタに存在しない都道府県コードが設定されています。';
                RAISE NO_CHECK_DATA;
              END IF;
            END IF;
          -- *******************************************************************
          --3.1.6. 市区町村コードの妥当性チェック	
          --	市区町村コードが郵便番号マスタに存在するかチェックする。
          -- *******************************************************************
            IF v_LocalGovCode IS NOT NULL THEN
              BEGIN
               SELECT COUNT(*) 
                 INTO GET_COUNT
                 FROM CSG_M_POSTAL_CODE                           -- 郵便番号マスタ
                WHERE KOKYO_CD = v_LocalGovCode;                 -- 全国地方公共団体コード
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  DBMS_OUTPUT.PUT_LINE(g_shori_point || ' ' || TO_CHAR(SQLCODE));
              END;
              
              IF GET_COUNT = 0 THEN
                OUT_ERR_CONTENT := 'マスタに存在しない市区町村コードが設定されています。';
                RAISE NO_CHECK_DATA;
              END IF;
            END IF;
          -- *******************************************************************
          --3.1.7. 郵便番号の妥当性チェック	
          --	郵便番号が郵便番号マスタに存在するかチェックする。
          -- *******************************************************************
            IF v_PostalCode IS NOT NULL THEN
              BEGIN
               SELECT COUNT(*) 
                 INTO GET_COUNT
                 FROM CSG_M_POSTAL_CODE                          -- 郵便番号マスタ
                WHERE POSTAL_CD = v_PostalCode;                  -- 郵便番号
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  DBMS_OUTPUT.PUT_LINE(g_shori_point || ' ' || TO_CHAR(SQLCODE));
              END;
              
              IF GET_COUNT = 0 THEN
                OUT_ERR_CONTENT := 'マスタに存在しない郵便番号が設定されています。';
                RAISE NO_CHECK_DATA;
              END IF;
            END IF;
          -- *******************************************************************
          -- 4.CSテリトリーデータの登録   
          -- 4.1.トランザクション開始    						
          -- 4.2.CSテリトリーデータの登録   
          -- *******************************************************************
            PRAM_PLACE_HOLDER := 'CSテリトリー情報テーブルの登録';
          -- *******************************************************************
          -- 4.2.1.レコード追加
          -- *******************************************************************
            INSERT
            INTO
              CSG_M_CS_TERRITORY_INFO
              (
                CS_TERITORY_ID,    --CSテリトリー情報ID
                CS_IN_CHARGE_CODE, --担当CSコード
                MODEL_CODE,        --機種コード
                F_SALES_CODE,      --部課コード
                ACCOUNT_NO,        --顧客番号
                STATE_CODE,        --都道府県コード
                LOCAL_GOV_CODE,    --市区町村コード
                POSTAL_CODE,       --郵便番号
                PROGRAM_ID,        --更新プログラムID
                PROCESS_ID,        --処理ID
                CREATION_USER_ID,  --作成者
                CREATION_DATE,     --作成日時
                UPDATE_USER_ID,    --更新者
                UPDATE_DATE        --更新日時
              )
              VALUES
              (
                CSG_M_CS_TERITORY_ID_SEQ.NEXTVAL,--Oracleシーケンスにより新規払い出し
                v_CsInChargeCode,                --[1.1.]でCSVファイルより取り込んだ担当CSコード
                v_ModelCode,                     --[1.1.]でCSVファイルより取り込んだ機種コード
                v_FSalesCode,                    --[1.1.]でCSVファイルより取り込んだ部課コード
                v_AccountNo,                     --[1.1.]でCSVファイルより取り込んだ顧客番号
                v_StateCode,                     --[1.1.]でCSVファイルより取り込んだ都道府県コード
                v_LocalGovCode,                  --[1.1.]でCSVファイルより取り込んだ市区町村コード
                v_PostalCode,                    --[1.1.]でCSVファイルより取り込んだ郵便番号
                'BAT-CSG02-0602-01',             --"BAT-CSG02-0602-01"
                INPUT_PROCESS_ID,                --[0.3.]で取得した処理ID
                INPUT_USER_ID,                   --バッチ実行ユーザ
                set_sysdate,                     --[0.1.]で取得したシステム日時
                INPUT_USER_ID,                   --バッチ実行ユーザ
                set_sysdate                      --[0.1.]で取得したシステム日時
              );
          END IF;
          N_CNT := N_CNT + 1;
          EXCEPTION
            WHEN NO_CHECK_DATA THEN
              OUT_RESULT_CD   := '10';
              --************************************************************************
              -- 呼び出し元機能のステータス
              -- 0:処理中
              -- 1:正常終了
              -- 2:警告終了
              -- 3:エラー
              --************************************************************************
              OUT_STATUS      := '2';
              OUT_DL_FILE     := INPUT_PATH_FILE;
              OUT_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
            WHEN NO_DATA_FOUND THEN
              EXIT;
            WHEN OTHERS THEN
              OUT_RESULT_CD   := '20';
              --************************************************************************
              -- 呼び出し元機能のステータス
              -- 0:処理中
              -- 1:正常終了
              -- 2:警告終了
              -- 3:エラー
              --************************************************************************
              OUT_STATUS      := '3';
              OUT_DL_FILE     := INPUT_PATH_FILE;
              OUT_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
              OUT_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
              ROLLBACK;
              RETURN;
          END;
      END LOOP;
    END IF;
    UTL_FILE.FCLOSE(F);
    --**************************************************************************
    -- 4.3.COMMIT
    COMMIT;
    --**************************************************************************
  EXCEPTION
      WHEN PRAM_EXCEPTION THEN
        OUT_RESULT_CD   := '20';
        OUT_STATUS      := '3';
        OUT_PROCESS_ID  := INPUT_PROCESS_ID;
        OUT_ERR_CONTENT := g_shori_point || ' ' || to_char(sqlcode);
        OUT_ERR_DETAIL  := g_shori_point || ' ' || to_char(sqlcode) || ' ' || sqlerrm(sqlcode);
        ROLLBACK;
        return;
      -- その他未定義の例外の処理
      WHEN OTHERS THEN
        OUT_RESULT_CD   := '20';
        DBMS_OUTPUT.PUT_LINE('ORACLE ERR_CODE    := ' || sqlcode);            -- ＤＢエラーコード
        DBMS_OUTPUT.PUT_LINE('ORACLE ERR_MESSAGE := ' || sqlerrm(sqlcode));   -- ＤＢエラーメッセージ
          
        OUT_STATUS      := '3';
        OUT_PROCESS_ID  := INPUT_PROCESS_ID;
        OUT_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
        OUT_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
        OUT_DL_FILE     := v_FileName;
        ROLLBACK;
        RETURN;
  
  END CSG02_PROC_CS_TERRITORY_UPDATE;

END CSG02_0602_PKG;

/
