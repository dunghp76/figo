CREATE OR REPLACE PACKAGE "CSG02_0502_PKG"
AS
/*******************************************************************************
* 設置先住所登録移行
*-------------------------------------------------------------------------------
* <更新履歴>
* <Version>   <日付>      <更新概要>                             <更新者>
*   1.0     2016/04/04      新規                                FOCUS_LTMINH
*******************************************************************************/
  /*****************************************************************************
  * 設置先住所登録（PL/SQL）
  * CSG02-0502 (MAIN)
  *****************************************************************************/
  PROCEDURE MAIN_CSG02_0502
  (
    RETURN_PROCESS_ID   OUT VARCHAR2 ,--処理ID
    RETURN_STATUS       OUT VARCHAR2 ,--ステータス
    RETURN_ERR_CONTENT  OUT VARCHAR2 ,--エラー内容
    RETURN_ERR_DETAIL   OUT VARCHAR2 ,--エラー詳細
    RETURN_RESULT_CD    OUT VARCHAR2  -- 終了コード (0  ：正常終了コード　／　'20' ：異常終了コード)
  );

   /*****************************************************************************
  * 設置先住所登録（PL/SQL）
  * CSG02-0502
  *****************************************************************************/
  PROCEDURE CSG02_PROC_INSTALL_ADDR_REGIST
  (
    INPUT_BATCH_USER_ID       IN VARCHAR2,            -- バッチユーザID
    INPUT_BATCH_PROCESS_DATE  IN DATE DEFAULT NULL,   -- バッチ処理日
    INPUT_PROCESS_ID          IN VARCHAR2,            -- プロセスID
    RETURN_STATUS             OUT VARCHAR2 ,          --ステータス
    RETURN_ERR_CONTENT        OUT VARCHAR2 ,          --エラー内容
    RETURN_ERR_DETAIL         OUT VARCHAR2 ,          --エラー詳細
    RETURN_RESULT_CD          OUT VARCHAR2            -- 終了コード
  );


END CSG02_0502_PKG;
/
