CREATE OR REPLACE PACKAGE "CSG02_0205_PKG"
AS
/*******************************************************************************
* 設置機器一括変更の移行                                                       *
*------------------------------------------------------------------------------*
* <更新履歴>                                                                   *
* <Version>   <日付>      <更新概要>                             <更新者>      *
*   1.0     2016/04/01      新規                                FOCUS_LTBINH   *
*   1.01    2016/05/20      修正                                FOCUS_AOKI     *
********************************************************************************/
  /******************************************************************************
  * 設置機器一括変更（PL/SQL）                                                  *
  * CSG02-0205 (MAIN)                                                           *
  *******************************************************************************/
  PROCEDURE MAIN_CSG02_0205(
      INPUT_USER_ID    IN VARCHAR2,                   --ユーザID
      INPUT_PATH_FILE  IN VARCHAR2,                   --CSVファイルパス
      OUT_PROCESS_ID OUT VARCHAR2,                    --処理ID
      OUT_STATUS OUT VARCHAR2,                        --ステータス
      OUT_ERR_CONTENT OUT NVARCHAR2,                  --エラー内容
      OUT_ERR_DETAIL OUT NVARCHAR2,                   --エラー詳細
      OUT_RESULT_CD OUT VARCHAR2                      --終了コード
    );
  /******************************************************************************
  * 設置機器一括変更（PL/SQL）                                                     *
  * CSG02-0205                                                                  *
  *******************************************************************************/
  PROCEDURE CSG02_PROC_CHANGE_INS_EQUI_COL(
      INPUT_USER_ID    IN VARCHAR2,                   --ユーザID
      INPUT_PROCESS_ID IN VARCHAR2 DEFAULT NULL,      --プロセスID
      INPUT_PATH_FILE  IN VARCHAR2,                   --CSVファイルパス
      OUT_STATUS OUT VARCHAR2,                        --ステータス
      OUT_ERR_CONTENT OUT NVARCHAR2,                  --エラー内容
      OUT_ERR_DETAIL OUT NVARCHAR2,                   --エラー詳細
      OUT_RESULT_CD OUT VARCHAR2                      --終了コード
    );
END CSG02_0205_PKG;
/
