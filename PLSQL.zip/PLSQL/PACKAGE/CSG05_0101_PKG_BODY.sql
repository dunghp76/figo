CREATE OR REPLACE PACKAGE BODY "CSG05_0101_PKG"
AS 
--開始時バックグラウンド処理
   PROCEDURE "CSG05_PROC_BG_PROCESS_START" (
    --プログラムID
    INPUT_PROGRAM_ID IN VARCHAR2 ,
    --処理パラメータ
    INPUT_PROCESS_PARAM IN CLOB ,
    --処理開始日時
    INPUT_PROCESS_START_DATE IN VARCHAR2 ,
    --ユーザID
    INPUT_USER_ID IN VARCHAR2 ,
    --プロセスID
    PROCESS_ID OUT VARCHAR2 ,
    --終了コード
    RESULT_CD OUT VARCHAR2 )
AS
  vCNT                 NUMBER(2) DEFAULT 0;
  vPROCESS_ID          NUMBER(15);
  NO_SEARCH_PROGRAM_ID EXCEPTION;
  PRAM_EXCEPTION       EXCEPTION;
  vDATE                DATE := sysdate;
  vPROCESS_PARAM       VARCHAR2(2000);
BEGIN
  --開始メッセージ
  dbms_output.put_line('開始時バックグラウンド処理を開始します。'); 
  --入力チェック
  IF FUNC_REQUIRED_CHK(INPUT_PROGRAM_ID) = 1 THEN
    dbms_output.put_line('プログラムIDは必須入力です。');
    RAISE PRAM_EXCEPTION;
  ELSIF FUNC_LENGTH_CHK(INPUT_PROGRAM_ID,30) = 1 THEN
    dbms_output.put_line('プログラムIDが30文字を超えています。');
    RAISE PRAM_EXCEPTION;
  ELSIF FUNC_ENCHAR_CHK(INPUT_PROGRAM_ID) = 1 THEN
    dbms_output.put_line('プログラムIDはに半角以外が含まれています。');
    RAISE PRAM_EXCEPTION;
  END IF;
  IF FUNC_REQUIRED_CHK(INPUT_PROCESS_PARAM) = 1 THEN
    dbms_output.put_line('処理パラメータは必須入力です。');
    RAISE PRAM_EXCEPTION;
  ELSIF FUNC_ENCHAR_CHK(INPUT_PROCESS_PARAM) = 1 THEN
    dbms_output.put_line('処理パラメータに半角以外が含まれています。');
    RAISE PRAM_EXCEPTION;
  END IF;
  IF FUNC_LENGTH_CHK(INPUT_PROCESS_PARAM,2000) = 1 THEN
    vPROCESS_PARAM := dbms_lob.substr(INPUT_PROCESS_PARAM,2000,1);
  ELSE
    vPROCESS_PARAM := TO_CHAR(INPUT_PROCESS_PARAM);
  END IF;
  IF FUNC_REQUIRED_CHK(INPUT_PROCESS_START_DATE) = 1 THEN
    dbms_output.put_line('処理開始日時は必須入力です。');
    RAISE PRAM_EXCEPTION;
  ELSIF FUNC_DATE_CHK(INPUT_PROCESS_START_DATE) = 1 THEN
    dbms_output.put_line('処理開始日時に日付以外が含まれています。');
    RAISE PRAM_EXCEPTION;
  END IF;
  IF FUNC_REQUIRED_CHK(INPUT_USER_ID) = 1 THEN
    dbms_output.put_line('ユーザIDは必須入力です。');
    RAISE PRAM_EXCEPTION;
  ELSIF FUNC_LENGTH_CHK(INPUT_USER_ID,12) = 1 THEN
    dbms_output.put_line('ユーザIDが12文字を超えています。');
    RAISE PRAM_EXCEPTION;
  ELSIF FUNC_ENCHAR_CHK(INPUT_USER_ID) = 1 THEN
    dbms_output.put_line('ユーザIDに半角以外が含まれています。');
    RAISE PRAM_EXCEPTION;
  END IF;
  --プログラムID存在チェック
  SELECT COUNT(*)
  INTO vCNT
  FROM SNV_M_GNRC_SNV
  WHERE CLSFCTN = 'M' 
  AND GRP_KEY = 'CSG'
  AND KEY_ITEM = 'CSG_PROGRAM_ID'
  AND LNG = 'JA'
  AND CD_VAL  = INPUT_PROGRAM_ID
  AND vDATE between VALD_STRT_DT and NVL(VALD_END_DT,vDATE)
  AND nvl(DEL_FLG,'N') != 'X';
  --プログラムIDが存在しない場合
  IF vCNT = 0 THEN
    dbms_output.put_line('存在しないプログラムIDが指定されています。');
    RAISE NO_SEARCH_PROGRAM_ID;
  END IF;
  --処理IDの取得
  SELECT CSG_M_PROCESS_ID_SEQ.nextval INTO vPROCESS_ID FROM DUAL ;
  --バックグラウンド登録処理
  INSERT
  INTO CSG_M_BACK_GROUND
    (
      PROCESS_ID ,
      EXC_PROGRAM_ID ,
      PROCESS_PARAMERTER ,
      PROCESS_STATUS ,
      PROCESS_START_DATE ,
      PROCESS_END_DATE ,
      USER_ID ,
      ERROR_LOG_ID ,
      DOWNLOAD_FILE ,
      PROGRAM_ID ,
      CREATION_USER_ID ,
      CREATION_DATE ,
      UPDATE_USER_ID ,
      UPDATE_DATE
    )
    VALUES
    (
      vPROCESS_ID ,
      INPUT_PROGRAM_ID ,
      vPROCESS_PARAM ,
      '0' ,
      TO_DATE(INPUT_PROCESS_START_DATE,'YYYY-MM-DD HH24:MI:SS') ,
      NULL ,
      INPUT_USER_ID ,
      NULL ,
      NULL ,
      'BAT-CSG05-0101-01' ,
      INPUT_USER_ID ,
      sysdate ,
      INPUT_USER_ID ,
      sysdate
    );
  
  COMMIT;
  RESULT_CD :='0';
  PROCESS_ID:=vPROCESS_ID;
  --終了メッセージ
  dbms_output.put_line('開始時バックグラウンド処理が正常終了しました。'); 
  EXCEPTION
  WHEN NO_SEARCH_PROGRAM_ID THEN
    RESULT_CD :='20';
  WHEN PRAM_EXCEPTION THEN
    RESULT_CD :='20';
  WHEN OTHERS THEN
    dbms_output.put_line('予期せぬエラーが発生しました。');
    RESULT_CD :='20';
    dbms_output.put_line('ErrCode: ' || SQLCODE) ;
    dbms_output.put_line('ErrMsg : ' || sqlerrm) ;
  END CSG05_PROC_BG_PROCESS_START;    

--更新時バックグラウンド処理
  PROCEDURE "CSG05_PROC_BG_PROCESS_UPD" (
    --処理ID
    INPUT_PROCESS_ID IN VARCHAR2 ,
    --ステータス
    INPUT_STATUS IN VARCHAR2 ,
    --処理終了日時
    INPUT_PROCESS_END_DATE IN VARCHAR2 ,
    --エラー内容
    INPUT_ERR_CONTENT IN VARCHAR2 ,
    --エラー詳細
    INPUT_ERR_DETAIL IN CLOB ,
    --ダウンロードファイル
    INPUT_DL_FILE IN VARCHAR2 ,
    --終了コード
    RESULT_CD OUT VARCHAR2 )
  AS
  vUSER_ID       VARCHAR2(15);
  vERROR_LOG_ID_CNT  NUMBER(1);
  vERROR_LOG_ID  NUMBER(15);
  PRAM_EXCEPTION EXCEPTION;
  BEGIN
  --開始時メッセージ
  dbms_output.put_line('更新時バックグラウンド処理を開始します。'); 
  --入力チェック
  IF FUNC_REQUIRED_CHK(INPUT_PROCESS_ID) = 1 THEN
    dbms_output.put_line('処理IDは必須入力です。');
    RAISE PRAM_EXCEPTION;
  ELSIF FUNC_LENGTH_CHK(INPUT_PROCESS_ID,15) = 1 THEN
    dbms_output.put_line('処理IDが15文字を超えています。');
    RAISE PRAM_EXCEPTION;
  ELSIF FUNC_NUMBER_CHK(INPUT_PROCESS_ID) = 1 THEN
    dbms_output.put_line('処理IDに数値以外が含まれています。');
    RAISE PRAM_EXCEPTION;
  END IF;
  IF FUNC_REQUIRED_CHK(INPUT_STATUS) = 1 THEN
    dbms_output.put_line('ステータスは必須入力です。');
    RAISE PRAM_EXCEPTION;
  ELSIF FUNC_LENGTH_CHK(INPUT_STATUS,1) = 1 THEN
    dbms_output.put_line('ステータスが1文字を超えています。');
    RAISE PRAM_EXCEPTION;
  ELSIF FUNC_NUMBER_CHK(INPUT_STATUS) = 1 THEN
    dbms_output.put_line('ステータスに数値以外が含まれています。');
    RAISE PRAM_EXCEPTION;
  ELSIF INPUT_STATUS = 0 THEN
    dbms_output.put_line('0は入力不可です。');
    RAISE PRAM_EXCEPTION;
  END IF;
  IF FUNC_REQUIRED_CHK(INPUT_PROCESS_END_DATE) = 1 THEN
    dbms_output.put_line('処理終了日時は必須入力です。');
    RAISE PRAM_EXCEPTION;
  ELSIF FUNC_DATE_CHK(INPUT_PROCESS_END_DATE) = 1 THEN
    dbms_output.put_line('処理終了日時に日付以外が含まれています。');
    RAISE PRAM_EXCEPTION;
  END IF;
  IF FUNC_NVAR_LENGTH_CHK(INPUT_ERR_CONTENT,64) = 1 THEN
    dbms_output.put_line('エラー内容が64文字を超えています。');
    RAISE PRAM_EXCEPTION;
  END IF;
  IF FUNC_NVAR_LENGTH_CHK(INPUT_DL_FILE,1000) = 1 THEN
    dbms_output.put_line('ダウンロードファイルが1000文字を超えています。');
    RAISE PRAM_EXCEPTION;
  END IF;
  --ユーザIDの取得
  SELECT USER_ID
  INTO vUSER_ID
  FROM CSG_M_BACK_GROUND
  WHERE PROCESS_ID=INPUT_PROCESS_ID;
  
  --ユーザIDがnullの場合
  IF vUSER_ID is NULL THEN
    dbms_output.put_line('ユーザIDがありません。');
    RAISE PRAM_EXCEPTION;
  END IF;
  
    --エラーログIDの取得
  SELECT COUNT(ERROR_LOG_ID)
  INTO vERROR_LOG_ID_CNT
  FROM CSG_M_ERROR_LOG
  WHERE PROCESS_ID=INPUT_PROCESS_ID;
  
  --エラーログの登録
  IF INPUT_ERR_CONTENT is not NULL OR INPUT_ERR_DETAIL is not null THEN
    IF vERROR_LOG_ID_CNT = 0 THEN
      SELECT CSG_M_ERROR_LOG_ID_SEQ.nextval INTO vERROR_LOG_ID FROM DUAL;
      INSERT
      INTO CSG_M_ERROR_LOG
        (
          ERROR_LOG_ID ,
          PROCESS_ID ,
          USER_ID ,
          ERROR_CONTENT ,
          ERROR_DETAIL ,
          PROGRAM_ID ,
          CREATION_USER_ID ,
          CREATION_DATE ,
          UPDATE_USER_ID ,
          UPDATE_DATE
        )
        VALUES
        (
          vERROR_LOG_ID ,
          INPUT_PROCESS_ID ,
          vUSER_ID ,
          INPUT_ERR_CONTENT ,
          INPUT_ERR_DETAIL ,
          'BAT-CSG05-0101-02' ,
          vUSER_ID ,
          sysdate ,
          vUSER_ID ,
          sysdate
        );
    ELSE
      UPDATE CSG_M_ERROR_LOG
      SET ERROR_CONTENT   =INPUT_ERR_CONTENT ,
          ERROR_DETAIL    =INPUT_ERR_DETAIL ,
          UPDATE_DATE     =sysdate
      WHERE PROCESS_ID=INPUT_PROCESS_ID;
    END IF;
  END IF;
  --バックグラウンド更新処理
  UPDATE CSG_M_BACK_GROUND
  SET PROCESS_STATUS=INPUT_STATUS ,
    PROCESS_END_DATE=TO_DATE(INPUT_PROCESS_END_DATE,'YYYY-MM-DD HH24:MI:SS') ,
    ERROR_LOG_ID    =vERROR_LOG_ID ,
    DOWNLOAD_FILE   =INPUT_DL_FILE ,
    PROGRAM_ID      ='BAT-CSG05-0101-02' ,
    UPDATE_DATE     =sysdate
  WHERE PROCESS_ID  = INPUT_PROCESS_ID;
  COMMIT;
  RESULT_CD :='0';
  --終了時メッセージ
  dbms_output.put_line('更新時バックグラウンド処理が正常終了しました。'); 
  EXCEPTION
  WHEN NO_DATA_FOUND  THEN
    RESULT_CD :='20';
  WHEN PRAM_EXCEPTION THEN
    RESULT_CD :='20';
  WHEN OTHERS THEN
    dbms_output.put_line('予期せぬエラーが発生しました。');
    RESULT_CD :='20';
    RAISE;
  END CSG05_PROC_BG_PROCESS_UPD;

END CSG05_0101_PKG;

/
