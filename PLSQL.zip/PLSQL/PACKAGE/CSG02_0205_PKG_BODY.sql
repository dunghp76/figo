CREATE OR REPLACE PACKAGE BODY "CSG02_0205_PKG" AS
/*******************************************************************************
* 設置機器一括変更の移行                                                       *
*------------------------------------------------------------------------------*
* <更新履歴>                                                                   *
* <Version>   <日付>      <更新概要>                             <更新者>      *
*   1.0     2016/04/01      新規                                FOCUS_LTBINH   *
*   1.01    2016/05/19      修正                                FOCUS_AOKI     *
********************************************************************************/
  g_shori_point                 VARCHAR2(250);    -- 処理ポイント
  set_sysdate                   DATE;             -- システム日時
  g_target_sel_cnt              NUMBER;           -- 入力定義（設置機器構成情報ワークの単独機器）の読込件数
  g_normal_sel_cnt              NUMBER;           -- 入力定義（設置機器構成情報ワークの単独機器）の読込件数
  g_warnings_sel_cnt            NUMBER;           -- 入力定義（設置機器構成情報ワークの単独機器）の読込件数
  /******************************************************************************
  * 設置機器一括変更（PL/SQL）                                                  *
  * CSG02-0205 (MAIN)                                                           *
  *******************************************************************************/
  PROCEDURE MAIN_CSG02_0205(
      INPUT_USER_ID    IN VARCHAR2,                   --ユーザID
      --INPUT_ROLE_CLASS    IN VARCHAR2,                --ロール
      INPUT_PATH_FILE  IN VARCHAR2,                   --CSVファイルパス
      OUT_PROCESS_ID OUT VARCHAR2,                    --処理ID
      OUT_STATUS OUT VARCHAR2,                        --ステータス
      OUT_ERR_CONTENT OUT NVARCHAR2,                  --エラー内容
      OUT_ERR_DETAIL OUT NVARCHAR2,                   --エラー詳細
      OUT_RESULT_CD OUT VARCHAR2                      --終了コード
    ) AS
  v_DTL_TXT_FRML_NM             SNV_M_GNRC_SNV.DTL_TXT_FRML_NM%TYPE; -- 汎用マスタ.明細テキスト(正式名)（バッチ実行ユーザID）
  PRAM_EXCEPTION                EXCEPTION;
  BEGIN
    g_shori_point             := 'MAIN_CSG02_0205';
    g_target_sel_cnt          := 0; -- 対象データは単独機器(第1階層)がない。
    g_normal_sel_cnt          := 0; -- 対象データは単独機器(第1階層)がない。
    g_warnings_sel_cnt        := 0; -- 対象データは単独機器(第1階層)がない。
  --******************************************************************************
  -- 0.開始処理
  -- 0.1.システム日時の取得
  -- システム日時を取得する。
  --******************************************************************************
    set_sysdate               := SYSDATE;
  ----******************************************************************************
  ---- 0.2.バッチ実行ユーザID 取得
  ---- 汎用マスタより、バッチ実行ユーザIDを取得する。
  ----******************************************************************************
  --    SELECT SMGS.DTL_TXT_FRML_NM                  -- 汎用マスタ.明細テキスト(正式名)（バッチ実行ユーザID）
  --      INTO v_DTL_TXT_FRML_NM
  --      FROM SNV_M_GNRC_SNV SMGS                   -- 汎用マスタ
  --     where smgs.key_item   = 'CSG_GENERAL_PROP'  -- 汎用マスタ.コード区分
  --       AND SMGS.CD_VAL     = 'BATCH_USER';       -- 汎用マスタ.コード値

  --******************************************************************************
  -- 0.2.処理IDの取得
  -- 開始時バックグラウンド処理を呼び出す。
  --******************************************************************************
    CSG05_0101_PKG.CSG05_PROC_BG_PROCESS_START(
                                'BAT-CSG02-0205-01',
                                INPUT_PATH_FILE,
                                set_sysdate,
                                INPUT_USER_ID, --v_DTL_TXT_FRML_NM,
                                OUT_PROCESS_ID,
                                OUT_RESULT_CD
                             );
  -- *****************************************************************************
  -- [例外処理]
  -- 処理結果 = "20"（異常終了）の場合
  -- エラーメッセージ[MSG-CSG-F-0003]をログ出力し、後続の処理を中断する。
  -- *****************************************************************************
    IF OUT_RESULT_CD = '20' THEN
        DBMS_OUTPUT.PUT_LINE('処理IDが取得できませんでした。システム管理者に問い合わせてください。');
        RAISE PRAM_EXCEPTION;
    END IF;

  --******************************************************************************
  -- 設置機器一括変更
  -- CSG02_PROC_CHANGE_INS_EQUI_COL
  --******************************************************************************
    CSG02_PROC_CHANGE_INS_EQUI_COL(
                                 INPUT_USER_ID,--v_DTL_TXT_FRML_NM,
                                 OUT_PROCESS_ID,
                                 INPUT_PATH_FILE,
                                 OUT_STATUS,
                                 OUT_ERR_CONTENT,
                                 OUT_ERR_DETAIL,
                                 OUT_RESULT_CD
                               );

  /***************************************************************************
  * 14_バッチ設計_1408050_終了時バックグラウンド処理（PL/SQL）
  * BAT-CSG05-0101-02
  ***************************************************************************/
    CSG05_0101_PKG.CSG05_PROC_BG_PROCESS_UPD(
                              OUT_PROCESS_ID,
                              OUT_STATUS,
                              SYSDATE,
                              OUT_ERR_CONTENT,
                              OUT_ERR_DETAIL,
                              '-',
                              OUT_RESULT_CD
                             );
  -- *************************************************************************
  -- 処理結果 ≠ 0（正常終了でない）の場合
  -- エラーメッセージ[MSG-CSG-W-0033]をログ出力し、呼び出し元に警告終了コードを返却する
  -- *************************************************************************
    IF OUT_RESULT_CD <> '0' THEN
        DBMS_OUTPUT.PUT_LINE('処理結果の登録に失敗しました。ダウンロード、エラーログ参照ができない可能性がありますので、処理結果を確認してください。');
        OUT_RESULT_CD   := '10';
        OUT_STATUS      := '2';
    END IF;

  EXCEPTION
    WHEN PRAM_EXCEPTION THEN
        OUT_RESULT_CD   := '20';
        OUT_STATUS      := '3';
        OUT_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
        OUT_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
        ROLLBACK;
        RETURN;
    -- その他未定義の例外の処理
    WHEN OTHERS THEN
        OUT_RESULT_CD := '20';
        DBMS_OUTPUT.PUT_LINE('ORACLE ERR_CODE    := ' || SQLCODE);            -- ＤＢエラーコード
        DBMS_OUTPUT.PUT_LINE('ORACLE ERR_MESSAGE := ' || SQLERRM(SQLCODE));   -- ＤＢエラーメッセージ
        DBMS_OUTPUT.PUT_LINE('PROC POINT         := ' || g_shori_point);      -- 処理ポイント
        OUT_STATUS      := '3'; -- 3:エラー
        OUT_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
        OUT_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
        ROLLBACK;
        RETURN;
  END MAIN_CSG02_0205;

  /******************************************************************************
  * 設置機器一括変更（PL/SQL）                                                  *
  * CSG02-0205                                                                  *
  *******************************************************************************/
  PROCEDURE CSG02_PROC_CHANGE_INS_EQUI_COL(
      INPUT_USER_ID    IN VARCHAR2,                   --ユーザID
      INPUT_PROCESS_ID IN VARCHAR2 DEFAULT NULL,      --プロセスID
      INPUT_PATH_FILE  IN VARCHAR2,                   --CSVファイルパス
      OUT_STATUS OUT VARCHAR2,                        --ステータス
      OUT_ERR_CONTENT OUT NVARCHAR2,                  --エラー内容
      OUT_ERR_DETAIL OUT NVARCHAR2,                   --エラー詳細
      OUT_RESULT_CD OUT VARCHAR2                      --終了コード
    ) AS
    F UTL_FILE.FILE_TYPE;
    V_LINE               VARCHAR2 (32767);
    v_Content            VARCHAR2 (1000);           -- 内容
    v_DirPath            VARCHAR2 (1000);           -- フォルダパス
    v_FileName           VARCHAR2 (200);            -- ファイル名
    stmt_str             VARCHAR2(2000);
    str_value            VARCHAR2(2000);
    N_NULL_CNT           NUMBER;
    GET_COUNT            NUMBER;
    PRAM_PLACE_HOLDER    VARCHAR2(100);             -- プレースホルダパラメータ
    NO_CHECK_DATA        EXCEPTION;
    PRAM_EXCEPTION       EXCEPTION;
    P_EXCEPTION          EXCEPTION;
  
    tIB_BASE                      ARRAY_IB_BASE;
    tIB_COMMON                    ARRAY_IB_COMMON;
  --******************************************************************************
  -- 設置機器構成情報ワークのパラメータ
  --******************************************************************************
--    v_IbConstId                      CSG_P_IB_CONST_WK.IB_CONST_ID%type ;                  -- {1} 設置機器構成ID DEFAULT NOT NULL
    v_InstanceId                     CSG_P_IB_CONST_WK.INSTANCE_ID%type ;                  -- {2} インスタンス番号 ⇒一括変更
    v_MainOptionType                 CSG_P_IB_CONST_WK.MAIN_OPTION_TYPE%type ;             -- {3} 本体オプション区分 ⇒一括変更
    --v_InventoryItemCode              CSG_P_IB_CONST_WK.INVENTORY_ITEM_CODE%type ;          -- {4} 品目コード ⇒一括登録
    --v_OrgId                          CSG_P_IB_CONST_WK.ORG_ID%type ;                       -- {5} プラント ⇒一括登録
    --v_ItemMachineCd                  CSG_P_IB_CONST_WK.ITEM_MACHINE_CD%type ;              -- {6} 品目.機種コード ⇒一括登録
    --v_ItemMakerNo                    CSG_P_IB_CONST_WK.ITEM_MAKER_NO%type ;                -- {7} 品目.メーカー型番 ⇒一括登録
    --v_ItemBranchNo                   CSG_P_IB_CONST_WK.ITEM_BRANCH_NO%type ;               -- {8} 品目.枝番 ⇒一括登録
    v_SerialNo                       CSG_P_IB_CONST_WK.SERIAL_NO%type ;                    -- {9} シリアル番号 ⇒一括登録⇒一括変更
    v_SnChangeReason                 CSG_P_IB_CONST_WK.SN_CHANGE_REASON%type ;             -- {10} シリアル番号変更理由 ⇒一括変更
    v_ItemRemarks                    CSG_P_IB_CONST_WK.ITEM_REMARKS%type ;                 -- {11} 品目摘要 ⇒一括変更
    --v_ParentInventoryItemCode        CSG_P_IB_CONST_WK.PARENT_INVENTORY_ITEM_CODE%type ;   -- {12} 親品目コード
    --v_ParentMachineCd                CSG_P_IB_CONST_WK.PARENT_MACHINE_CD%type ;            -- {13} 親品目.機種コード ⇒一括登録
    --v_ParentMakerNo                  CSG_P_IB_CONST_WK.PARENT_MAKER_NO%type ;              -- {14} 親品目.メーカー型番 ⇒一括登録
    --v_ParentBranchNo                 CSG_P_IB_CONST_WK.PARENT_BRANCH_NO%type ;             -- {15} 親品目.枝番 ⇒一括登録
    --v_ParentSrialNo                  CSG_P_IB_CONST_WK.PARENT_SRIAL_NO%type ;              -- {16} 親シリアル番号 ⇒一括登録
    v_Quantity                       CSG_P_IB_CONST_WK.QUANTITY%type ;                     -- {17} 数量 ⇒一括登録⇒一括変更
    v_TransferFlag                   CSG_P_IB_CONST_WK.TRANSFER_FLAG%type ;                -- {18} 移管品フラグ ⇒一括登録⇒一括変更
    v_TransferMaintenanceFrom        CSG_P_IB_CONST_WK.TRANSFER_MAINTENANCE_FROM%type ;    -- {19} 保守移管元 ⇒一括登録⇒一括変更
    v_TransferMaintenanceTo          CSG_P_IB_CONST_WK.TRANSFER_MAINTENANCE_TO%type ;      -- {20} 保守移管先 ⇒一括変更
    v_TransferMaintenanceDate        CSG_P_IB_CONST_WK.TRANSFER_MAINTENANCE_DATE%type ;    -- {21} 保守移管日 ⇒一括登録⇒一括変更
    v_TransferMaintenanceReason      CSG_P_IB_CONST_WK.TRANSFER_MAINTENANCE_REASON%type ;  -- {22} 保守移管理由 ⇒一括登録⇒一括変更
    v_CsInChargeCd                   CSG_P_IB_CONST_WK.CS_IN_CHARGE_CD%type ;              -- {23} 担当CSコード ⇒一括登録⇒一括変更
    v_IncidentSaverityName           CSG_P_IB_CONST_WK.INCIDENT_SAVERITY_NAME%type ;       -- {24} 重要度 ⇒一括登録⇒一括変更
    v_SecondaryInventoryName         CSG_P_IB_CONST_WK.SECONDARY_INVENTORY_NAME%type ;     -- {25} 委託先コード ⇒一括登録⇒一括変更
    v_InstallLocationCode            CSG_P_IB_CONST_WK.INSTALL_LOCATION_CODE%type ;        -- {26} 設置先住所ID ⇒一括登録⇒一括変更
    v_InstallLocationDeptName        CSG_P_IB_CONST_WK.INSTALL_LOCATION_DEPT_NAME%type ;   -- {27} 設置先部署名 ⇒一括登録⇒一括変更
    v_InstallLocationPersonName      CSG_P_IB_CONST_WK.INSTALL_LOCATION_PERSON_NAME%type ; -- {28} 設置先担当者名 ⇒一括登録⇒一括変更
    v_InstallLocationTel             CSG_P_IB_CONST_WK.INSTALL_LOCATION_TEL%type ;         -- {29} 設置先TEL ⇒一括登録⇒一括変更
    v_InstallLocationFax             CSG_P_IB_CONST_WK.INSTALL_LOCATION_FAX%type ;         -- {30} 設置先FAX ⇒一括登録⇒一括変更
    v_InstallDate                    CSG_P_IB_CONST_WK.INSTALL_DATE%type ;                 -- {31} 納入日 ⇒一括登録⇒一括変更
    v_SalesDate                      CSG_P_IB_CONST_WK.SALES_DATE%type ;                   -- {32} 売上日 ⇒一括登録⇒一括変更
    v_SalesOwnerCode                 CSG_P_IB_CONST_WK.SALES_OWNER_CODE%type ;             -- {33} 販売元 ⇒一括登録⇒一括変更
    v_OrderNo                        CSG_P_IB_CONST_WK.ORDER_NO%type ;                     -- {34} 受注番号 ⇒一括変更
    v_CustomerOrderNo                CSG_P_IB_CONST_WK.CUSTOMER_ORDER_NO%type ;            -- {35} 客先注文番号 ⇒一括変更
    --v_MakerOrderNo                   CSG_P_IB_CONST_WK.MAKER_ORDER_NO%type ;               -- {36} メーカー発注番号 ⇒一括変更
    v_ServiceCondition               CSG_P_IB_CONST_WK.SERVICE_CONDITION%type ;            -- {37} サービス形態 ⇒一括登録⇒一括変更
    v_OutSourcingFlag                CSG_P_IB_CONST_WK.OUT_SOURCING_FLAG%type ;            -- {38} 外注フラグ ⇒一括登録⇒一括変更
    v_ShippingInspectionFlag         CSG_P_IB_CONST_WK.SHIPPING_INSPECTION_FLAG%type ;     -- {39} 出荷検査実施フラグ ⇒一括登録⇒一括変更
    --v_BundleItemCode                 CSG_P_IB_CONST_WK.BUNDLE_ITEM_CODE%type ;             -- {40} バンドル品目コード ⇒一括登録⇒一括変更
    --v_BundleItemName                 CSG_P_IB_CONST_WK.BUNDLE_ITEM_NAME%type ;             -- {41} バンドル品目名 ⇒一括登録⇒一括変更
    v_BundleMachineCd                CSG_P_IB_CONST_WK.BUNDLE_MACHINE_CD%type ;            -- {42} バンドル品.機種コード ⇒一括登録⇒一括変更
    v_BundleMakerNo                  CSG_P_IB_CONST_WK.BUNDLE_MAKER_NO%type ;              -- {43} バンドル品.メーカー型番 ⇒一括登録⇒一括変更
    v_BundleBranchNo                 CSG_P_IB_CONST_WK.BUNDLE_BRANCH_NO%type ;             -- {44} バンドル品.枝番 ⇒一括登録⇒一括変更
    v_BundleSerailNo                 CSG_P_IB_CONST_WK.BUNDLE_SERAIL_NO%type ;             -- {45} バンドルシリアル番号 ⇒一括登録⇒一括変更
    v_FirstCoverage                  CSG_P_IB_CONST_WK.FIRST_COVERAGE%type ;               -- {46} 初回ワランティ条件 ⇒一括登録⇒一括変更
    v_FirstMonths                    CSG_P_IB_CONST_WK.FIRST_MONTHS%type ;                 -- {47} 初回ワランティ月数 ⇒一括登録⇒一括変更
    v_FirstStartDate                 CSG_P_IB_CONST_WK.FIRST_START_DATE%type ;             -- {48} 初回ワランティ期間(自) ⇒一括登録⇒一括変更
    v_NextCoverage                   CSG_P_IB_CONST_WK.NEXT_COVERAGE%type ;                -- {49} 次回ワランティ条件 ⇒一括登録⇒一括変更
    v_NextMonths                     CSG_P_IB_CONST_WK.NEXT_MONTHS%type ;                  -- {50} 次回ワランティ月数 ⇒一括登録⇒一括変更
    v_HostId                         CSG_P_IB_CONST_WK.HOST_ID%type ;                      -- {51} ホストID ⇒一括登録⇒一括変更
    v_HostName                       CSG_P_IB_CONST_WK.HOST_NAME%type ;                    -- {52} ホスト名 ⇒一括登録⇒一括変更
    v_KeepWatchSystemId              CSG_P_IB_CONST_WK.KEEP_WATCH_SYSTEM_ID%type ;         -- {53} 監視システムID ⇒一括登録⇒一括変更
    v_OsType                         CSG_P_IB_CONST_WK.OS_TYPE%type ;                      -- {54} OS種別 ⇒一括登録⇒一括変更
    v_OsVersion                      CSG_P_IB_CONST_WK.OS_VERSION%type ;                   -- {55} OSバージョン ⇒一括登録⇒一括変更
    v_SystemName                     CSG_P_IB_CONST_WK.SYSTEM_NAME%type ;                  -- {56} システム名 ⇒一括登録⇒一括変更
    v_FirmwareVersion                CSG_P_IB_CONST_WK.FIRMWARE_VERSION%type ;             -- {57} ファームウェアVer ⇒一括変更
    v_Revision                       CSG_P_IB_CONST_WK.REVISION%type ;                     -- {58} リビジョン ⇒一括登録⇒一括変更
    v_UseCondition                   CSG_P_IB_CONST_WK.USE_CONDITION%type ;                -- {59} 利用形態 ⇒一括登録⇒一括変更
    v_CpuRomRevision                 CSG_P_IB_CONST_WK.CPU_ROM_REVISION%type ;             -- {60} CPU ROMリビジョン ⇒一括変更
    v_DiskCapacity                   CSG_P_IB_CONST_WK.DISK_CAPACITY%type ;                -- {61} ディスク容量 ⇒一括変更
    v_UsePerpose                     CSG_P_IB_CONST_WK.USE_PERPOSE%type ;                  -- {62} 利用目的 ⇒一括登録⇒一括変更
    v_PowerSupplyType                CSG_P_IB_CONST_WK.POWER_SUPPLY_TYPE%type ;            -- {63} 電源設備種類 ⇒一括変更
    v_PowerSupplyCapacity            CSG_P_IB_CONST_WK.POWER_SUPPLY_CAPACITY%type ;        -- {64} 電源容量 ⇒一括変更
    v_PpContAkNo                     CSG_P_IB_CONST_WK.PP_CONT_AK_NO%type ;                -- {65} PP契約AK番号 ⇒一括変更
    v_UsePowerFrequency              CSG_P_IB_CONST_WK.USE_POWER_FREQUENCY%type ;          -- {66} 使用電源周波数 ⇒一括変更
    v_UsePowerVoltage                CSG_P_IB_CONST_WK.USE_POWER_VOLTAGE%type ;            -- {67} 使用電源電圧 ⇒一括変更
    v_PpContStartDate                CSG_P_IB_CONST_WK.PP_CONT_START_DATE%type ;           -- {68} 契約期間(自) ⇒一括変更
    v_PpContEndDate                  CSG_P_IB_CONST_WK.PP_CONT_END_DATE%type ;             -- {69} 契約期間(至) ⇒一括変更
    v_MacAddress                     CSG_P_IB_CONST_WK.MAC_ADDRESS%type ;                  -- {70} MACアドレス ⇒一括変更
    v_IpAddress                      CSG_P_IB_CONST_WK.IP_ADDRESS%type ;                   -- {71} IPアドレス ⇒一括変更
    v_HpConfigCode                   CSG_P_IB_CONST_WK.HP_CONFIG_CODE%type ;               -- {72} HPコンフィグコード ⇒一括変更
    v_HavingEarthFlag                CSG_P_IB_CONST_WK.HAVING_EARTH_FLAG%type ;            -- {73} アース有無フラグ ⇒一括変更
    v_SupportInstructCode            CSG_P_IB_CONST_WK.SUPPORT_INSTRUCT_CODE%type ;        -- {74} 要サポートフラグ ⇒一括登録⇒一括変更
    v_SupportStartDate               CSG_P_IB_CONST_WK.SUPPORT_START_DATE%type ;           -- {75} 要サポート開始日 ⇒一括登録⇒一括変更
    v_SupportEndDate                 CSG_P_IB_CONST_WK.SUPPORT_END_DATE%type ;             -- {76} 要サポート終了日 ⇒一括登録⇒一括変更
    v_SalesDeptOrgId                 CSG_P_IB_CONST_WK.SALES_DEPT_ORG_ID%type ;            -- {77} F営業販売部署(部課コード) ⇒一括登録⇒一括変更
    v_SalesDeptPersonId              CSG_P_IB_CONST_WK.SALES_DEPT_PERSON_ID%type ;         -- {78} F営業販売担当者(Zなし社員番号) ⇒一括登録⇒一括変更
    v_PresentDeptOrgId               CSG_P_IB_CONST_WK.PRESENT_DEPT_ORG_ID%type ;          -- {79} F営業現在部署(部課コード) ⇒一括登録⇒一括変更
    v_CtcSalesrepPersonId            CSG_P_IB_CONST_WK.CTC_SALESREP_PERSON_ID%type ;       -- {80} F営業現在担当者(Zなし社員番号) ⇒一括登録⇒一括変更
    v_MainteBusDeptOrgId             CSG_P_IB_CONST_WK.MAINTE_BUS_DEPT_ORG_ID%type ;       -- {81} 保守営業担当部署(部課コード) ⇒一括登録⇒一括変更
    v_MainteBusPersonId              CSG_P_IB_CONST_WK.MAINTE_BUS_PERSON_ID%type ;         -- {82} 保守営業担当者(Zなし社員番号) ⇒一括登録⇒一括変更
    v_CeCode                         CSG_P_IB_CONST_WK.CE_CODE%type ;                      -- {83} 保守担当CE ⇒一括変更
    v_MaintenanceType                CSG_P_IB_CONST_WK.MAINTENANCE_TYPE%type ;             -- {84} 保守種別 ⇒一括登録⇒一括変更
    v_ImportantItemFlag              CSG_P_IB_CONST_WK.IMPORTANT_ITEM_FLAG%type ;          -- {85} 重要案件 ⇒一括変更
    v_AgentFlag                      CSG_P_IB_CONST_WK.AGENT_FLAG%type ;                   -- {86} 販社フラグ ⇒一括登録⇒一括変更
    v_FirstSaleDeptName              CSG_P_IB_CONST_WK.FIRST_SALE_DEPT_NAME%type ;         -- {87} 初期販売部署名 ⇒一括変更
    v_FirstSalePersonName            CSG_P_IB_CONST_WK.FIRST_SALE_PERSON_NAME%type ;       -- {88} 初期販売担当者名 ⇒一括変更
    v_FirstSalePartyLocation         CSG_P_IB_CONST_WK.FIRST_SALE_PARTY_LOCATION%type ;    -- {89} 初期販売住所コード ⇒一括変更
    v_FirstSaleTel                   CSG_P_IB_CONST_WK.FIRST_SALE_TEL%type ;               -- {90} 初期販売TEL ⇒一括変更
    v_FirstSaleFax                   CSG_P_IB_CONST_WK.FIRST_SALE_FAX%type ;               -- {91} 初期販売FAX ⇒一括変更
    v_FirstSaleMailAddress           CSG_P_IB_CONST_WK.FIRST_SALE_MAIL_ADDRESS%type ;      -- {92} 初期販売メールアドレス ⇒一括変更
    v_EnduserPartyCode               CSG_P_IB_CONST_WK.ENDUSER_PARTY_CODE%type ;           -- {93} エンドユーザ会社コード ⇒一括登録⇒一括変更
    v_EnduserLocation                CSG_P_IB_CONST_WK.ENDUSER_LOCATION%type ;             -- {94} エンドユーザ住所 ⇒一括登録⇒一括変更
    v_EnduserChrgDeptName            CSG_P_IB_CONST_WK.ENDUSER_CHRG_DEPT_NAME%type ;       -- {95} エンドユーザ部署 ⇒一括登録⇒一括変更
    v_EnduserTel                     CSG_P_IB_CONST_WK.ENDUSER_TEL%type ;                  -- {96} エンドユーザTEL ⇒一括登録⇒一括変更
    v_EnduserFax                     CSG_P_IB_CONST_WK.ENDUSER_FAX%type ;                  -- {97} エンドユーザFAX ⇒一括登録⇒一括変更
    v_EnduserChrgPersonName          CSG_P_IB_CONST_WK.ENDUSER_CHRG_PERSON_NAME%type ;     -- {98} エンドユーザ担当者 ⇒一括登録⇒一括変更
    v_EnduserMailAddress             CSG_P_IB_CONST_WK.ENDUSER_MAIL_ADDRESS%type ;         -- {99} エンドユーザメールアドレス ⇒一括変更
    v_LicenseManagementNo            CSG_P_IB_CONST_WK.LICENSE_MANAGEMENT_NO%type ;        -- {100} ライセンス管理番号 ⇒一括登録⇒一括変更
    v_LisenceStartDate               CSG_P_IB_CONST_WK.LISENCE_START_DATE%type ;           -- {101} ライセンス開始日 ⇒一括登録⇒一括変更
    v_LisenceEndDate                 CSG_P_IB_CONST_WK.LISENCE_END_DATE%type ;             -- {102} ライセンス終了日 ⇒一括登録⇒一括変更
    v_SuperintendeManageNo           CSG_P_IB_CONST_WK.SUPERINTENDE_MANAGE_NO%type ;       -- {103} 主管部管理番号 ⇒一括登録⇒一括変更
    v_RemoveDate                     CSG_P_IB_CONST_WK.REMOVE_DATE%type ;                  -- {104} ソフトウェア移設日 ⇒一括登録⇒一括変更
    v_RemoveOrderNo                  CSG_P_IB_CONST_WK.REMOVE_ORDER_NO%type ;              -- {105} ソフトウェア移設受注番号 ⇒一括登録⇒一括変更
    v_RemovePoNo                     CSG_P_IB_CONST_WK.REMOVE_PO_NO%type ;                 -- {106} ソフトウェア移設先発注番号 ⇒一括登録⇒一括変更
    v_RemoveReason                   CSG_P_IB_CONST_WK.REMOVE_REASON%type ;                -- {107} ソフトウェア移設理由 ⇒一括登録⇒一括変更
    --v_MemoType                       CSG_P_IB_CONST_WK.MEMO_TYPE%type ;                    -- {108} メモタイプ ⇒一括登録
    --v_Title                          CSG_P_IB_CONST_WK.TITLE%type ;                        -- {109} タイトル ⇒一括登録
    --v_Memo                           CSG_P_IB_CONST_WK.MEMO%type ;                         -- {110} メモ ⇒一括登録
  --******************************************************************************
    --p_IB_CONST_ID                       CSG_P_IB_CONST_WK.IB_CONST_ID%type ;                  --  設置機器構成ID
    p_INSTANCE_ID                       CSG_P_IB_CONST_WK.INSTANCE_ID%type ;                  --  インスタンス番号
    --p_MAIN_OPTION_TYPE                  CSG_P_IB_CONST_WK.MAIN_OPTION_TYPE%type ;             --  本体オプション区分
    --p_INVENTORY_ITEM_CODE               CSG_P_IB_CONST_WK.INVENTORY_ITEM_CODE%type ;          --  品目コード
    --p_ORG_ID                            CSG_P_IB_CONST_WK.ORG_ID%type ;                       --  プラント
    --p_ITEM_MACHINE_CD                   CSG_P_IB_CONST_WK.ITEM_MACHINE_CD%type ;              --  品目.機種コード
    --p_ITEM_MAKER_NO                     CSG_P_IB_CONST_WK.ITEM_MAKER_NO%type ;                --  品目.メーカー型番
    --p_ITEM_BRANCH_NO                    CSG_P_IB_CONST_WK.ITEM_BRANCH_NO%type ;               --  品目.枝番
    --p_SERIAL_NO                         CSG_P_IB_CONST_WK.SERIAL_NO%type ;                    --  シリアル番号
    --p_SN_CHANGE_REASON                  CSG_P_IB_CONST_WK.SN_CHANGE_REASON%type ;             --  シリアル番号変更理由
    --p_ITEM_REMARKS                      CSG_P_IB_CONST_WK.ITEM_REMARKS%type ;                 --  品目摘要
    --p_PARENT_INVENTORY_ITEM_CODE        CSG_P_IB_CONST_WK.PARENT_INVENTORY_ITEM_CODE%type ;   --  親品目コード
    --p_PARENT_MACHINE_CD                 CSG_P_IB_CONST_WK.PARENT_MACHINE_CD%type ;            --  親品目.機種コード
    --p_PARENT_MAKER_NO                   CSG_P_IB_CONST_WK.PARENT_MAKER_NO%type ;              --  親品目.メーカー型番
    --p_PARENT_BRANCH_NO                  CSG_P_IB_CONST_WK.PARENT_BRANCH_NO%type ;             --  親品目.枝番
    --p_PARENT_SRIAL_NO                   CSG_P_IB_CONST_WK.PARENT_SRIAL_NO%type ;              --  親シリアル番号
    --p_QUANTITY                          CSG_P_IB_CONST_WK.QUANTITY%type ;                     --  数量
    --p_TRANSFER_FLAG                     CSG_P_IB_CONST_WK.TRANSFER_FLAG%type ;                --  移管品フラグ
    --p_TRANSFER_MAINTENANCE_FROM         CSG_P_IB_CONST_WK.TRANSFER_MAINTENANCE_FROM%type ;    --  保守移管元
    --p_TRANSFER_MAINTENANCE_TO           CSG_P_IB_CONST_WK.TRANSFER_MAINTENANCE_TO%type ;      --  保守移管先
    p_TRANSFER_MAINTENANCE_DATE         CSG_P_IB_CONST_WK.TRANSFER_MAINTENANCE_DATE%type ;    --  保守移管日
    --p_TRANSFER_MAINTENANCE_REASON       CSG_P_IB_CONST_WK.TRANSFER_MAINTENANCE_REASON%type ;  --  保守移管理由
    --p_CS_IN_CHARGE_CD                   CSG_P_IB_CONST_WK.CS_IN_CHARGE_CD%type ;              --  担当CSコード
    --p_INCIDENT_SAVERITY_NAME            CSG_P_IB_CONST_WK.INCIDENT_SAVERITY_NAME%type ;       --  重要度
    --p_SECONDARY_INVENTORY_NAME          CSG_P_IB_CONST_WK.SECONDARY_INVENTORY_NAME%type ;     --  委託先コード
    --p_INSTALL_LOCATION_CODE             CSG_P_IB_CONST_WK.INSTALL_LOCATION_CODE%type ;        --  設置先住所ID
    --p_INSTALL_LOCATION_DEPT_NAME        CSG_P_IB_CONST_WK.INSTALL_LOCATION_DEPT_NAME%type ;   --  設置先部署名
    --p_INSTALL_LOCATION_PERSON_NAME      CSG_P_IB_CONST_WK.INSTALL_LOCATION_PERSON_NAME%type ; --  設置先担当者名
    --p_INSTALL_LOCATION_TEL              CSG_P_IB_CONST_WK.INSTALL_LOCATION_TEL%type ;         --  設置先TEL
    --p_INSTALL_LOCATION_FAX              CSG_P_IB_CONST_WK.INSTALL_LOCATION_FAX%type ;         --  設置先FAX
    p_INSTALL_DATE                      CSG_P_IB_CONST_WK.INSTALL_DATE%type ;                 --  納入日
    p_SALES_DATE                        CSG_P_IB_CONST_WK.SALES_DATE%type ;                   --  売上日
    --p_SALES_OWNER_CODE                  CSG_P_IB_CONST_WK.SALES_OWNER_CODE%type ;             --  販売元
    --p_ORDER_NO                          CSG_P_IB_CONST_WK.ORDER_NO%type ;                     --  受注番号
    --p_CUSTOMER_ORDER_NO                 CSG_P_IB_CONST_WK.CUSTOMER_ORDER_NO%type ;            --  客先注文番号
    --p_MAKER_ORDER_NO                    CSG_P_IB_CONST_WK.MAKER_ORDER_NO%type ;               --  メーカー発注番号
    p_SERVICE_CONDITION                 CSG_P_IB_CONST_WK.SERVICE_CONDITION%type ;            --  サービス形態
    --p_OUT_SOURCING_FLAG                 CSG_P_IB_CONST_WK.OUT_SOURCING_FLAG%type ;            --  外注フラグ
    --p_SHIPPING_INSPECTION_FLAG          CSG_P_IB_CONST_WK.SHIPPING_INSPECTION_FLAG%type ;     --  出荷検査実施フラグ
    p_BUNDLE_ITEM_CODE                  CSG_P_IB_CONST_WK.BUNDLE_ITEM_CODE%type ;             --  バンドル品目コード
    p_BUNDLE_ITEM_NAME                  CSG_P_IB_CONST_WK.BUNDLE_ITEM_NAME%type ;             --  バンドル品目名
    --p_BUNDLE_MACHINE_CD                 CSG_P_IB_CONST_WK.BUNDLE_MACHINE_CD%type ;            --  バンドル品.機種コード
    --p_BUNDLE_MAKER_NO                   CSG_P_IB_CONST_WK.BUNDLE_MAKER_NO%type ;              --  バンドル品.メーカー型番
    --p_BUNDLE_BRANCH_NO                  CSG_P_IB_CONST_WK.BUNDLE_BRANCH_NO%type ;             --  バンドル品.枝番
    --p_BUNDLE_SERAIL_NO                  CSG_P_IB_CONST_WK.BUNDLE_SERAIL_NO%type ;             --  バンドルシリアル番号
    --p_FIRST_COVERAGE                    CSG_P_IB_CONST_WK.FIRST_COVERAGE%type ;               --  初回ワランティ条件
    --p_FIRST_MONTHS                      CSG_P_IB_CONST_WK.FIRST_MONTHS%type ;                 --  初回ワランティ月数
    p_FIRST_START_DATE                  CSG_P_IB_CONST_WK.FIRST_START_DATE%type ;             --  初回ワランティ期間(自)
    --p_NEXT_COVERAGE                     CSG_P_IB_CONST_WK.NEXT_COVERAGE%type ;                --  次回ワランティ条件
    --p_NEXT_MONTHS                       CSG_P_IB_CONST_WK.NEXT_MONTHS%type ;                  --  次回ワランティ月数
    --p_HOST_ID                           CSG_P_IB_CONST_WK.HOST_ID%type ;                      --  ホストID
    --p_HOST_NAME                         CSG_P_IB_CONST_WK.HOST_NAME%type ;                    --  ホスト名
    --p_KEEP_WATCH_SYSTEM_ID              CSG_P_IB_CONST_WK.KEEP_WATCH_SYSTEM_ID%type ;         --  監視システムID
    --p_OS_TYPE                           CSG_P_IB_CONST_WK.OS_TYPE%type ;                      --  OS種別
    --p_OS_VERSION                        CSG_P_IB_CONST_WK.OS_VERSION%type ;                   --  OSバージョン
    --p_SYSTEM_NAME                       CSG_P_IB_CONST_WK.SYSTEM_NAME%type ;                  --  システム名
    --p_FIRMWARE_VERSION                  CSG_P_IB_CONST_WK.FIRMWARE_VERSION%type ;             --  ファームウェアVer
    --p_REVISION                          CSG_P_IB_CONST_WK.REVISION%type ;                     --  リビジョン
    --p_USE_CONDITION                     CSG_P_IB_CONST_WK.USE_CONDITION%type ;                --  利用形態
    --p_CPU_ROM_REVISION                  CSG_P_IB_CONST_WK.CPU_ROM_REVISION%type ;             --  CPU ROMリビジョン
    --p_DISK_CAPACITY                     CSG_P_IB_CONST_WK.DISK_CAPACITY%type ;                --  ディスク容量
    --p_USE_PERPOSE                       CSG_P_IB_CONST_WK.USE_PERPOSE%type ;                  --  利用目的
    --p_POWER_SUPPLY_TYPE                 CSG_P_IB_CONST_WK.POWER_SUPPLY_TYPE%type ;            --  電源設備種類
    --p_POWER_SUPPLY_CAPACITY             CSG_P_IB_CONST_WK.POWER_SUPPLY_CAPACITY%type ;        --  電源容量
    --p_PP_CONT_AK_NO                     CSG_P_IB_CONST_WK.PP_CONT_AK_NO%type ;                --  PP契約AK番号
    --p_USE_POWER_FREQUENCY               CSG_P_IB_CONST_WK.USE_POWER_FREQUENCY%type ;          --  使用電源周波数
    --p_USE_POWER_VOLTAGE                 CSG_P_IB_CONST_WK.USE_POWER_VOLTAGE%type ;            --  使用電源電圧
    --p_PP_CONT_START_DATE                CSG_P_IB_CONST_WK.PP_CONT_START_DATE%type ;           --  契約期間(自)
    --p_PP_CONT_END_DATE                  CSG_P_IB_CONST_WK.PP_CONT_END_DATE%type ;             --  契約期間(至)
    --p_MAC_ADDRESS                       CSG_P_IB_CONST_WK.MAC_ADDRESS%type ;                  --  MACアドレス
    --p_IP_ADDRESS                        CSG_P_IB_CONST_WK.IP_ADDRESS%type ;                   --  IPアドレス
    --p_HP_CONFIG_CODE                    CSG_P_IB_CONST_WK.HP_CONFIG_CODE%type ;               --  HPコンフィグコード
    --p_HAVING_EARTH_FLAG                 CSG_P_IB_CONST_WK.HAVING_EARTH_FLAG%type ;            --  アース有無フラグ
    --p_SUPPORT_INSTRUCT_CODE             CSG_P_IB_CONST_WK.SUPPORT_INSTRUCT_CODE%type ;        --  要サポートフラグ
    --p_SUPPORT_START_DATE                CSG_P_IB_CONST_WK.SUPPORT_START_DATE%type ;           --  要サポート開始日
    --p_SUPPORT_END_DATE                  CSG_P_IB_CONST_WK.SUPPORT_END_DATE%type ;             --  要サポート終了日
    --p_SALES_DEPT_ORG_ID                 CSG_P_IB_CONST_WK.SALES_DEPT_ORG_ID%type ;            --  F営業販売部署(部課コード)
    --p_SALES_DEPT_PERSON_ID              CSG_P_IB_CONST_WK.SALES_DEPT_PERSON_ID%type ;         --  F営業販売担当者(Zなし社員番号)
    --p_PRESENT_DEPT_ORG_ID               CSG_P_IB_CONST_WK.PRESENT_DEPT_ORG_ID%type ;          --  F営業現在部署(部課コード)
    --p_CTC_SALESREP_PERSON_ID            CSG_P_IB_CONST_WK.CTC_SALESREP_PERSON_ID%type ;       --  F営業現在担当者(Zなし社員番号)
    --p_MAINTE_BUS_DEPT_ORG_ID            CSG_P_IB_CONST_WK.MAINTE_BUS_DEPT_ORG_ID%type ;       --  保守営業担当部署(部課コード)
    --p_MAINTE_BUS_PERSON_ID              CSG_P_IB_CONST_WK.MAINTE_BUS_PERSON_ID%type ;         --  保守営業担当者(Zなし社員番号)
    --p_CE_CODE                           CSG_P_IB_CONST_WK.CE_CODE%type ;                      --  保守担当CE
    --p_MAINTENANCE_TYPE                  CSG_P_IB_CONST_WK.MAINTENANCE_TYPE%type ;             --  保守種別
    --p_IMPORTANT_ITEM_FLAG               CSG_P_IB_CONST_WK.IMPORTANT_ITEM_FLAG%type ;          --  重要案件
    --p_AGENT_FLAG                        CSG_P_IB_CONST_WK.AGENT_FLAG%type ;                   --  販社フラグ
    --p_FIRST_SALE_DEPT_NAME              CSG_P_IB_CONST_WK.FIRST_SALE_DEPT_NAME%type ;         --  初期販売部署名
    --p_FIRST_SALE_PERSON_NAME            CSG_P_IB_CONST_WK.FIRST_SALE_PERSON_NAME%type ;       --  初期販売担当者名
    --p_FIRST_SALE_PARTY_LOCATION         CSG_P_IB_CONST_WK.FIRST_SALE_PARTY_LOCATION%type ;    --  初期販売住所コード
    --p_FIRST_SALE_TEL                    CSG_P_IB_CONST_WK.FIRST_SALE_TEL%type ;               --  初期販売TEL
    --p_FIRST_SALE_FAX                    CSG_P_IB_CONST_WK.FIRST_SALE_FAX%type ;               --  初期販売FAX
    --p_FIRST_SALE_MAIL_ADDRESS           CSG_P_IB_CONST_WK.FIRST_SALE_MAIL_ADDRESS%type ;      --  初期販売メールアドレス
    p_ENDUSER_PARTY_CODE                CSG_P_IB_CONST_WK.ENDUSER_PARTY_CODE%type ;           --  エンドユーザ会社コード
    --p_ENDUSER_LOCATION                  CSG_P_IB_CONST_WK.ENDUSER_LOCATION%type ;             --  エンドユーザ住所
    --p_ENDUSER_CHRG_DEPT_NAME            CSG_P_IB_CONST_WK.ENDUSER_CHRG_DEPT_NAME%type ;       --  エンドユーザ部署
    --p_ENDUSER_TEL                       CSG_P_IB_CONST_WK.ENDUSER_TEL%type ;                  --  エンドユーザTEL
    --p_ENDUSER_FAX                       CSG_P_IB_CONST_WK.ENDUSER_FAX%type ;                  --  エンドユーザFAX
    --p_ENDUSER_CHRG_PERSON_NAME          CSG_P_IB_CONST_WK.ENDUSER_CHRG_PERSON_NAME%type ;     --  エンドユーザ担当者
    --p_ENDUSER_MAIL_ADDRESS              CSG_P_IB_CONST_WK.ENDUSER_MAIL_ADDRESS%type ;         --  エンドユーザメールアドレス
    --p_LICENSE_MANAGEMENT_NO             CSG_P_IB_CONST_WK.LICENSE_MANAGEMENT_NO%type ;        --  ライセンス管理番号
    --p_LISENCE_START_DATE                CSG_P_IB_CONST_WK.LISENCE_START_DATE%type ;           --  ライセンス開始日
    --p_LISENCE_END_DATE                  CSG_P_IB_CONST_WK.LISENCE_END_DATE%type ;             --  ライセンス終了日
    --p_SUPERINTENDE_MANAGE_NO            CSG_P_IB_CONST_WK.SUPERINTENDE_MANAGE_NO%type ;       --  主管部管理番号
    --p_REMOVE_DATE                       CSG_P_IB_CONST_WK.REMOVE_DATE%type ;                  --  ソフトウェア移設日
    --p_REMOVE_ORDER_NO                   CSG_P_IB_CONST_WK.REMOVE_ORDER_NO%type ;              --  ソフトウェア移設受注番号
    --p_REMOVE_PO_NO                      CSG_P_IB_CONST_WK.REMOVE_PO_NO%type ;                 --  ソフトウェア移設先発注番号
    --p_REMOVE_REASON                     CSG_P_IB_CONST_WK.REMOVE_REASON%type ;                --  ソフトウェア移設理由
    --p_MEMO_TYPE                         CSG_P_IB_CONST_WK.MEMO_TYPE%type ;                    --  メモタイプ
    --p_TITLE                             CSG_P_IB_CONST_WK.TITLE%type ;                        --  タイトル
    --p_MEMO                              CSG_P_IB_CONST_WK.MEMO%type ;                         --  メモ
    p_ASSIGN_FLAG                       CSG_P_IB_CONST_WK.ASSIGN_FLAG%type ;                  --  紐付済フラグ
  --******************************************************************************
  -- 設置機器情報のパラメータ
  --******************************************************************************
    p_INSTANCE_ID_IBI                       CSG_M_IB_INFO.INSTANCE_ID%type ;                  -- インスタンス番号
    --p_PARENT_INSTANCE_ID_IBI                CSG_M_IB_INFO.PARENT_INSTANCE_ID%type ;           -- 親インスタンス番号
    --p_TOP_INSTANCE_ID_IBI                   CSG_M_IB_INFO.TOP_INSTANCE_ID%type ;              -- 最上位インスタンス番号
    p_INVENTORY_ITEM_CODE_IBI               CSG_M_IB_INFO.INVENTORY_ITEM_CODE%type ;          -- 品目コード
    p_ORG_ID_IBI                            CSG_M_IB_INFO.ORG_ID%type ;                       -- プラント
    --p_INVENTORY_ITEM_NAME_IBI               CSG_M_IB_INFO.INVENTORY_ITEM_NAME%type ;          -- 品目名
    --p_SERIAL_NO_IBI                         CSG_M_IB_INFO.SERIAL_NO%type ;                    -- シリアル番号
    --p_MAIN_OPTION_TYPE_IBI                  CSG_M_IB_INFO.MAIN_OPTION_TYPE%type ;             -- 本体オプション区分
    --p_IB_SYNC_STATUS_IBI                    CSG_M_IB_INFO.IB_SYNC_STATUS%type ;               -- IBステータス
    --p_QUANTITY_IBI                          CSG_M_IB_INFO.QUANTITY%type ;                     -- 数量
    --p_INSTALL_DATE_IBI                      CSG_M_IB_INFO.INSTALL_DATE%type ;                 -- 納入日
    --p_SALES_DATE_IBI                        CSG_M_IB_INFO.SALES_DATE%type ;                   -- 売上日
    --p_CUSTOMER_ORDER_NO_IBI                 CSG_M_IB_INFO.CUSTOMER_ORDER_NO%type ;            -- 客先注文番号
    --p_MAKER_ORDER_NO_IBI                    CSG_M_IB_INFO.MAKER_ORDER_NO%type ;               -- メーカー発注番号
    --p_ORDER_NO_IBI                          CSG_M_IB_INFO.ORDER_NO%type ;                     -- 受注番号
    --p_TRANSFER_FLAG_IBI                     CSG_M_IB_INFO.TRANSFER_FLAG%TYPE ;                -- 移管品フラグ
    --p_TRANSFER_MAINTENANCE_FROM             CSG_M_IB_INFO.TRANSFER_MAINTENANCE_FROM%type ;    -- 保守移管元
    --p_TRANSFER_MAINTENANCE_TO_IBI           CSG_M_IB_INFO.TRANSFER_MAINTENANCE_TO%type ;      -- 保守移管先
    --p_TRANSFER_MAINTENANCE_DATE_IB          CSG_M_IB_INFO.TRANSFER_MAINTENANCE_DATE%type ;    -- 保守移管日
    --p_TRANSFER_MAINTNANCE_REASON            CSG_M_IB_INFO.TRANSFER_MAINTNANCE_REASON%type ;   -- 保守移管理由
    --p_SALES_OWNER_CODE_IBI                  CSG_M_IB_INFO.SALES_OWNER_CODE%type ;             -- 販売元
    --p_MAINTENANCE_TYPE_IBI                  CSG_M_IB_INFO.MAINTENANCE_TYPE%type ;             -- 保守種別
    --p_IMPORTANT_ITEM_FLAG_IBI               CSG_M_IB_INFO.IMPORTANT_ITEM_FLAG%type ;          -- 重要案件
    --p_SERVICE_CONDITION_IBI                 CSG_M_IB_INFO.SERVICE_CONDITION%type ;            -- サービス形態
    --p_OUT_SOURCING_FLAG_IBI                 CSG_M_IB_INFO.OUT_SOURCING_FLAG%type ;            -- 外注フラグ
    --p_SHIPPING_INSPECTION_FLAG_IBI          CSG_M_IB_INFO.SHIPPING_INSPECTION_FLAG%type ;     -- 出荷検査実施フラグ
    --p_HOST_NAME_IBI                         CSG_M_IB_INFO.HOST_NAME%type ;                    -- ホスト名
    --p_SYSTEM_NAME_IBI                       CSG_M_IB_INFO.SYSTEM_NAME%type ;                  -- システム名
    p_SUPPORT_START_DATE_IBI                CSG_M_IB_INFO.SUPPORT_START_DATE%type ;           -- 要サポート開始日
    p_SUPPORT_END_DATE_IBI                  CSG_M_IB_INFO.SUPPORT_END_DATE%type ;             -- 要サポート終了日
    --p_SUPPORT_INSTRUCT_CODE_IBI             CSG_M_IB_INFO.SUPPORT_INSTRUCT_CODE%type ;        -- 要サポートフラグ
    --p_FIRST_SALE_PARTY_CODE_IBI             CSG_M_IB_INFO.FIRST_SALE_PARTY_CODE%type ;        -- 初期販売会社コード
    --p_FIRST_SALE_PARTY_LOCATION             CSG_M_IB_INFO.FIRST_SALE_PARTY_LOCATION%type ;    -- 初期販売会社住所
    --p_FIRST_SALE_DEPT_NAME_IBI              CSG_M_IB_INFO.FIRST_SALE_DEPT_NAME%type ;         -- 初期販売部署名
    --p_FIRST_SALE_TEL_IBI                    CSG_M_IB_INFO.FIRST_SALE_TEL%type ;               -- 初期販売会社TEL
    --p_FIRST_SALE_FAX_IBI                    CSG_M_IB_INFO.FIRST_SALE_FAX%type ;               -- 初期販売会社FAX
    --p_FIRST_SALE_PERSON_NAME_IBI            CSG_M_IB_INFO.FIRST_SALE_PERSON_NAME%type ;       -- 初期販売担当者名
    --p_FIRST_SALE_MAIL_ADDRESS_IBI           CSG_M_IB_INFO.FIRST_SALE_MAIL_ADDRESS%type ;      -- 初期販売メールアドレス
    --p_FIRST_COVERAGE_IBI                    CSG_M_IB_INFO.FIRST_COVERAGE%type ;               -- 初回ワランティ条件
    --p_FIRST_MONTHS_IBI                      CSG_M_IB_INFO.FIRST_MONTHS%type ;                 -- 初回ワランティ月数
    --p_FIRST_START_DATE_IBI                  CSG_M_IB_INFO.FIRST_START_DATE%type ;             -- 初回期間(自)
    p_FIRST_END_DATE_IBI                    CSG_M_IB_INFO.FIRST_END_DATE%type ;               -- 初回期間(至)
    --p_NEXT_COVERAGE_IBI                     CSG_M_IB_INFO.NEXT_COVERAGE%type ;                -- 次回ワランティ条件
    --p_NEXT_MONTHS_IBI                       CSG_M_IB_INFO.NEXT_MONTHS%type ;                  -- 次回ワランティ月数
    p_NEXT_START_DATE_IBI                   CSG_M_IB_INFO.NEXT_START_DATE%type ;              -- 次回期間(自)
    p_NEXT_END_DATE_IBI                     CSG_M_IB_INFO.NEXT_END_DATE%type ;                -- 次回期間(至)
    --p_AGENT_FLAG_IBI                        CSG_M_IB_INFO.AGENT_FLAG%type ;                   -- 販社フラグ
    --p_SECONDARY_INVENTORY_CODE_IBI          CSG_M_IB_INFO.SECONDARY_INVENTORY_CODE%type ;     -- 委託先コード
    --p_BUNDLE_ITEM_CODE_IBI                  CSG_M_IB_INFO.BUNDLE_ITEM_CODE%type ;             -- バンドル品目コード
    --p_BUNDLE_ITEM_NAME_IBI                  CSG_M_IB_INFO.BUNDLE_ITEM_NAME%type ;             -- バンドル品目名
    --p_BUNDLE_SERIAL_NO_IBI                  CSG_M_IB_INFO.BUNDLE_SERIAL_NO%type ;             -- バンドルシリアル
    --p_HOST_ID_IBI                           CSG_M_IB_INFO.HOST_ID%type ;                      -- ホストID
    --p_KEEP_WATCH_SYSTEM_ID_IBI              CSG_M_IB_INFO.KEEP_WATCH_SYSTEM_ID%type ;         -- 監視システムID
    --p_HP_CONFIG_CODE_IBI                    CSG_M_IB_INFO.HP_CONFIG_CODE%type ;               -- HPコンフィグコード
    --p_OS_TYPE_IBI                           CSG_M_IB_INFO.OS_TYPE%type ;                      -- OS種別
    --p_OS_VERSION_IBI                        CSG_M_IB_INFO.OS_VERSION%type ;                   -- OSバージョン
    --p_FIRMWARE_VERSION_IBI                  CSG_M_IB_INFO.FIRMWARE_VERSION%type ;             -- Firmware Version
    --p_REVISION_IBI                          CSG_M_IB_INFO.REVISION%type ;                     -- リビジョン
    --p_CPU_ROM_REVISION_IBI                  CSG_M_IB_INFO.CPU_ROM_REVISION%type ;             -- CPU　ROMリビジョン
    --p_DISK_CAPACITY_IBI                     CSG_M_IB_INFO.DISK_CAPACITY%type ;                -- ディスク容量
    --p_POWER_SUPPLY_TYPE_IBI                 CSG_M_IB_INFO.POWER_SUPPLY_TYPE%type ;            -- 電源設備種類
    --p_POWER_SUPPLY_CAPACITY_IBI             CSG_M_IB_INFO.POWER_SUPPLY_CAPACITY%type ;        -- 電源容量
    --p_USE_POWER_FREQUENCY_IBI               CSG_M_IB_INFO.USE_POWER_FREQUENCY%type ;          -- 使用電源周波数
    --p_USE_POWER_VOLTAGE_IBI                 CSG_M_IB_INFO.USE_POWER_VOLTAGE%type ;            -- 使用電源電圧
    --p_HAVING_EARTH_FLAG_IBI                 CSG_M_IB_INFO.HAVING_EARTH_FLAG%type ;            -- アース有無フラグ
    --p_MAC_ADDRESS_IBI                       CSG_M_IB_INFO.MAC_ADDRESS%type ;                  -- MACアドレス
    --p_IP_ADDRESS_IBI                        CSG_M_IB_INFO.IP_ADDRESS%type ;                   -- IPアドレス
    --p_LICENSE_MANAGEMENT_NO_IBI             CSG_M_IB_INFO.LICENSE_MANAGEMENT_NO%type ;        -- ライセンス管理番号
    --p_SUPERINTENDE_MANAGE_NO_IBI            CSG_M_IB_INFO.SUPERINTENDE_MANAGE_NO%type ;       -- 主管部管理番号
    p_LISENCE_START_DATE_IBI                CSG_M_IB_INFO.LISENCE_START_DATE%type ;           -- ライセンス開始日
    p_LISENCE_END_DATE_IBI                  CSG_M_IB_INFO.LISENCE_END_DATE%type ;             -- ライセンス終了日
    --p_REMOVE_ORDER_NO_IBI                   CSG_M_IB_INFO.REMOVE_ORDER_NO%type ;              -- 移設受注番号
    --p_REMOVE_PO_NO_IBI                      CSG_M_IB_INFO.REMOVE_PO_NO%type ;                 -- 移設先発注番号
    p_REMOVE_DATE_IBI                       CSG_M_IB_INFO.REMOVE_DATE%type ;                  -- 移設日
    --p_REMOVE_REASON_IBI                     CSG_M_IB_INFO.REMOVE_REASON%type ;                -- 移設理由
    --p_SALES_DEPT_ORG_ID_IBI                 CSG_M_IB_INFO.SALES_DEPT_ORG_ID%type ;            -- F営業販売部署コード
    --p_SALES_DEPT_PERSON_ID_IBI              CSG_M_IB_INFO.SALES_DEPT_PERSON_ID%type ;         -- F営業販売担当者コード
    --p_PRESENT_DEPT_ORG_ID_IBI               CSG_M_IB_INFO.PRESENT_DEPT_ORG_ID%type ;          -- F営業現在担当部署コード
    --p_CTC_SALESREP_PERSON_ID_IBI            CSG_M_IB_INFO.CTC_SALESREP_PERSON_ID%type ;       -- F営業現在担当者コード
    --p_MAINTE_BUS_DEPT_ORG_ID_IBI            CSG_M_IB_INFO.MAINTE_BUS_DEPT_ORG_ID%type ;       -- 保守営業担当部署コード
    --p_MAINTE_BUS_PERSON_ID_IBI              CSG_M_IB_INFO.MAINTE_BUS_PERSON_ID%type ;         -- 保守営業担当者コード
    --p_PP_CONT_AK_NO_IBI                     CSG_M_IB_INFO.PP_CONT_AK_NO%type ;                -- PP契約AK番号
    p_PP_CONT_START_DATE_IBI                CSG_M_IB_INFO.PP_CONT_START_DATE%type ;           -- 契約期間(自)
    p_PP_CONT_END_DATE_IBI                  CSG_M_IB_INFO.PP_CONT_END_DATE%type ;             -- 契約期間(至)
    --p_SN_CHANGE_REASON_IBI                  CSG_M_IB_INFO.SN_CHANGE_REASON%type ;             -- シリアル番号変更理由
    --p_X_DEPLOY_FLAG_IBI                     CSG_M_IB_INFO.X_DEPLOY_FLAG%type ;                -- X配備対象フラグ
    --p_ACCEPTANCE_DATE_IBI                   CSG_M_IB_INFO.ACCEPTANCE_DATE%type ;              -- 受入日
    --p_OUT_WARRANTY_REGISTERED_FLAG          CSG_M_IB_INFO.OUT_WARRANTY_REGISTERED_FLAG%type ; -- 外注契約ワランティ登録済フラグ
    p_UPDATE_DATE_IBI                       CSG_M_IB_INFO.UPDATE_DATE%TYPE ;                  -- 更新日時
  
--  v_INSTANCE_ID_SEQ                       CSG_M_IB_INFO.INSTANCE_ID%type ;                  -- インスタンス番号
  --******************************************************************************
  -- 設置機器共通情報のパラメータ
  --******************************************************************************
    --p_TOP_INSTANCE_ID_ICI                   CSG_M_IB_COMMON_INFO.TOP_INSTANCE_ID%type ;                          -- 最上位インスタンス番号
    --p_CS_IN_CHARGE_CODE_ICI                 CSG_M_IB_COMMON_INFO.CS_IN_CHARGE_CODE%type ;                        -- 担当CSコード
    --p_CE_CODE_ICI                           CSG_M_IB_COMMON_INFO.CE_CODE%type DEFAULT NULL;                      -- 担当CEコード
    p_INSTALL_CUSTOMER_CODE_ICI             CSG_M_IB_COMMON_INFO.INSTALL_CUSTOMER_CODE%type ;                    -- 設置先顧客コード
    --p_INSTALL_LOCATION_CODE_ICI             CSG_M_IB_COMMON_INFO.INSTALL_LOCATION_CODE%type ;                    -- 設置先顧客住所コード
    --p_INSTALL_LOCATION_DEPT_NAME            CSG_M_IB_COMMON_INFO.INSTALL_LOCATION_DEPT_NAME%type DEFAULT NULL;   -- 設置先顧客部署名
    --p_INSTALL_LOCATION_PERSON_NAME          CSG_M_IB_COMMON_INFO.INSTALL_LOCATION_PERSON_NAME%type DEFAULT NULL; -- 設置先顧客担当者名
    --p_INSTALL_LOCATION_TEL_ICI              CSG_M_IB_COMMON_INFO.INSTALL_LOCATION_TEL%type DEFAULT NULL;         -- 設置先TEL
    --p_INSTALL_LOCATION_FAX_ICI              CSG_M_IB_COMMON_INFO.INSTALL_LOCATION_FAX%type DEFAULT NULL;         -- 設置先FAX
    --p_INCIDENT_SERVIRITY_NAME_ICI           CSG_M_IB_COMMON_INFO.INCIDENT_SERVIRITY_NAME%type ;                  -- 重要度
    --p_USE_CONDITION_ICI                     CSG_M_IB_COMMON_INFO.USE_CONDITION%type DEFAULT NULL;                -- 利用形態
    --p_USE_PERPOSE_ICI                       CSG_M_IB_COMMON_INFO.USE_PERPOSE%type DEFAULT NULL;                  -- 利用目的
    --p_ENDUSER_PARTY_CODE_ICI                CSG_M_IB_COMMON_INFO.ENDUSER_PARTY_CODE%type DEFAULT NULL;           -- エンドユーザ会社コード
    p_ENDUSER_PARTY_NAME_ICI                CSG_M_IB_COMMON_INFO.ENDUSER_PARTY_NAME%type DEFAULT NULL;           -- エンドユーザ会社名
    --p_ENDUSER_LOCATION_ICI                  CSG_M_IB_COMMON_INFO.ENDUSER_LOCATION%type DEFAULT NULL;             -- エンドユーザ住所
    --p_ENDUSER_CHRG_DEPT_NAME_ICI            CSG_M_IB_COMMON_INFO.ENDUSER_CHRG_DEPT_NAME%type DEFAULT NULL;       -- エンドユーザ部署名
    --p_ENDUSER_CHRG_PERSON_NAME_ICI          CSG_M_IB_COMMON_INFO.ENDUSER_CHRG_PERSON_NAME%type DEFAULT NULL;     -- エンドユーザ担当者名
    --p_ENDUSER_TEL_ICI                       CSG_M_IB_COMMON_INFO.ENDUSER_TEL%type DEFAULT NULL;                  -- エンドユーザTEL
    --p_ENDUSER_FAX_ICI                       CSG_M_IB_COMMON_INFO.ENDUSER_FAX%type DEFAULT NULL;                  -- エンドユーザFAX
    --p_ENDUSER_MAIL_ADDRESS_ICI              CSG_M_IB_COMMON_INFO.ENDUSER_MAIL_ADDRESS%type DEFAULT NULL;         -- エンドユーザメールアドレス
  --******************************************************************************
    v_ItemCd01                       SNV_M_ITEM.ITEM_CD%type ;                             -- 品目コード

    v_ItemRemarks01                  SNV_M_ITEM.REMARKS%type ;                             -- 摘要

    v_IsParent NUMBER;--構成最上位設置機器か否か

    v_RoleClass SNV_M_GNRC_SNV.PARM1%type;

  --******************************************************************************
  -- 4.処理対象データの取得
  -- 4.1.更新情報の取得
  -- 以下の条件に合致するデータを設置機器構成情報ワークより取得する。
  --******************************************************************************
    CURSOR CUR_IB_CONST_WK
    IS
      SELECT 
        IBI.INSTANCE_ID AS INSTANCE_ID_IBI,                       -- 設置機器情報テーブルのインスタンス番号（登録済み判定用）
        IBI.PARENT_INSTANCE_ID,                                   -- 設置機器情報テーブルの親インスタンス番号（親子判定用）
        IBI.TOP_INSTANCE_ID,                                      -- 設置機器情報テーブルの最上位インスタンス番号（親子判定用）
        IBCW.IB_CONST_ID,                                         -- 設置機器構成ID
        IBCW.INSTANCE_ID,                  -- インスタンス番号
        IBCW.MAIN_OPTION_TYPE,             -- 本体オプション区分
        IBCW.SERIAL_NO,                    -- シリアル番号
        IBCW.SN_CHANGE_REASON,             -- シリアル番号変更理由
        IBCW.ITEM_REMARKS,                 -- 品目摘要
        IBCW.QUANTITY,                                            -- 数量
        IBCW.TRANSFER_FLAG,                -- 移管品フラグ
        IBCW.TRANSFER_MAINTENANCE_FROM,    -- 保守移管元
        IBCW.TRANSFER_MAINTENANCE_TO,      -- 保守移管先
        IBCW.TRANSFER_MAINTENANCE_DATE,    -- 保守移管日
        IBCW.TRANSFER_MAINTENANCE_REASON,  -- 保守移管理由
        IBCW.CS_IN_CHARGE_CD,              -- 担当CSコード
        IBCW.INCIDENT_SAVERITY_NAME,       -- 重要度
        IBCW.SECONDARY_INVENTORY_NAME,     -- 委託先コード
        IBCW.INSTALL_LOCATION_CODE,        -- 設置先住所ID
        IBCW.INSTALL_LOCATION_DEPT_NAME,   -- 設置先部署名
        IBCW.INSTALL_LOCATION_PERSON_NAME, -- 設置先担当者名
        IBCW.INSTALL_LOCATION_TEL,         -- 設置先TEL
        IBCW.INSTALL_LOCATION_FAX,         -- 設置先FAX
        IBCW.INSTALL_DATE,                 -- 納入日
        IBCW.SALES_DATE,                   -- 売上日
        IBCW.SALES_OWNER_CODE,             -- 販売元
        IBCW.ORDER_NO,                     -- 受注番号
        IBCW.CUSTOMER_ORDER_NO,            -- 客先注文番号
        IBCW.SERVICE_CONDITION,            -- サービス形態
        IBCW.OUT_SOURCING_FLAG,            -- 外注フラグ
        IBCW.SHIPPING_INSPECTION_FLAG,     -- 出荷検査実施フラグ
        IBCW.BUNDLE_ITEM_CODE,             -- バンドル品目コード（品目マスタから取得 ※1参照）
        IBCW.BUNDLE_ITEM_NAME,             -- バンドル品目名（品目マスタから取得 ※1参照）
        IBCW.BUNDLE_MACHINE_CD,            -- バンドル品.機種コード
        IBCW.BUNDLE_MAKER_NO,              -- バンドル品.メーカー型番
        IBCW.BUNDLE_BRANCH_NO,             -- バンドル品.枝番
        IBCW.BUNDLE_SERAIL_NO,             -- バンドルシリアル番号
        IBCW.FIRST_COVERAGE,               -- 初回ワランティ条件
        IBCW.FIRST_MONTHS,                                        -- 初回ワランティ月数
        IBCW.FIRST_START_DATE,             -- 初回ワランティ期間(自)
        IBCW.NEXT_COVERAGE,                -- 次回ワランティ条件
        IBCW.NEXT_MONTHS,                                         -- 次回ワランティ月数
        IBCW.HOST_ID,                      -- ホストID
        IBCW.HOST_NAME,                    -- ホスト名
        IBCW.KEEP_WATCH_SYSTEM_ID,         -- 監視システムID
        IBCW.OS_TYPE,                      -- OS種別
        IBCW.OS_VERSION,                   -- OSバージョン
        IBCW.SYSTEM_NAME,                  -- システム名
        IBCW.FIRMWARE_VERSION,             -- ファームウェアVer
        IBCW.REVISION,                     -- リビジョン
        IBCW.USE_CONDITION,                -- 利用形態
        IBCW.CPU_ROM_REVISION,             -- CPU ROMリビジョン
        IBCW.DISK_CAPACITY,                -- ディスク容量
        IBCW.USE_PERPOSE,                  -- 利用目的
        IBCW.POWER_SUPPLY_TYPE,            -- 電源設備種類
        IBCW.POWER_SUPPLY_CAPACITY,        -- 電源容量
        IBCW.PP_CONT_AK_NO,                -- PP契約AK番号
        IBCW.USE_POWER_FREQUENCY,          -- 使用電源周波数
        IBCW.USE_POWER_VOLTAGE,            -- 使用電源電圧
        IBCW.PP_CONT_START_DATE,           -- 契約期間(自)
        IBCW.PP_CONT_END_DATE,             -- 契約期間(至)
        IBCW.MAC_ADDRESS,                  -- MACアドレス
        IBCW.IP_ADDRESS,                   -- IPアドレス
        IBCW.HP_CONFIG_CODE,               -- HPコンフィグコード
        IBCW.HAVING_EARTH_FLAG,            -- アース有無フラグ
        IBCW.SUPPORT_INSTRUCT_CODE,        -- 要サポートフラグ
        IBCW.SUPPORT_START_DATE,           -- 要サポート開始日
        IBCW.SUPPORT_END_DATE,             -- 要サポート終了日
        IBCW.SALES_DEPT_ORG_ID,            -- F営業販売部署(部課コード)
        IBCW.SALES_DEPT_PERSON_ID,         -- F営業販売担当者(Zなし社員番号)
        IBCW.PRESENT_DEPT_ORG_ID,          -- F営業現在部署(部課コード)
        IBCW.CTC_SALESREP_PERSON_ID,       -- F営業現在担当者(Zなし社員番号)
        IBCW.MAINTE_BUS_DEPT_ORG_ID,       -- 保守営業担当部署(部課コード)
        IBCW.MAINTE_BUS_PERSON_ID,         -- 保守営業担当者(Zなし社員番号)
        IBCW.CE_CODE,                      -- 保守担当CE
        IBCW.MAINTENANCE_TYPE,             -- 保守種別
        IBCW.IMPORTANT_ITEM_FLAG,          -- 重要案件
        IBCW.AGENT_FLAG,                   -- 販社フラグ
        IBCW.FIRST_SALE_DEPT_NAME,         -- 初期販売部署名
        IBCW.FIRST_SALE_PERSON_NAME,       -- 初期販売担当者名
        IBCW.FIRST_SALE_PARTY_LOCATION,    -- 初期販売住所コード
        IBCW.FIRST_SALE_TEL,               -- 初期販売TEL
        IBCW.FIRST_SALE_FAX,               -- 初期販売FAX
        IBCW.FIRST_SALE_MAIL_ADDRESS,      -- 初期販売メールアドレス
        IBCW.ENDUSER_PARTY_CODE,           -- エンドユーザ会社コード
        IBCW.ENDUSER_LOCATION,             -- エンドユーザ住所
        IBCW.ENDUSER_CHRG_DEPT_NAME,       -- エンドユーザ部署
        IBCW.ENDUSER_TEL,                  -- エンドユーザTEL
        IBCW.ENDUSER_FAX,                  -- エンドユーザFAX
        IBCW.ENDUSER_CHRG_PERSON_NAME,     -- エンドユーザ担当者
        IBCW.ENDUSER_MAIL_ADDRESS,         -- エンドユーザメールアドレス
        IBCW.LICENSE_MANAGEMENT_NO,        -- ライセンス管理番号
        IBCW.LISENCE_START_DATE,           -- ライセンス開始日
        IBCW.LISENCE_END_DATE,             -- ライセンス終了日
        IBCW.SUPERINTENDE_MANAGE_NO,       -- 主管部管理番号
        IBCW.REMOVE_DATE,                  -- ソフトウェア移設日
        IBCW.REMOVE_ORDER_NO,              -- ソフトウェア移設受注番号
        IBCW.REMOVE_PO_NO,                 -- ソフトウェア移設先発注番号
        IBCW.REMOVE_REASON                 -- ソフトウェア移設理由
      FROM CSG_P_IB_CONST_WK IBCW                          -- 設置機器構成情報ワーク
      LEFT OUTER JOIN CSG_M_IB_INFO IBI                    -- 設置機器情報
      ON IBCW.INSTANCE_ID= IBI.INSTANCE_ID -- ワーク.インスタンス番号＝設置.インスタンス番号
      WHERE IBCW．ASSIGN_FLAG     = '0';                   -- ワーク.紐付済フラグ
  BEGIN
    GET_COUNT                 := 0;
    g_shori_point             := 'PROCESS_MAIN';
    str_value                 := '';
    PRAM_PLACE_HOLDER         := 'データの取得';
    g_target_sel_cnt          := 0; -- 対象データは単独機器(第1階層)がない。
    g_normal_sel_cnt          := 0; -- 対象データは単独機器(第1階層)がない。
    g_warnings_sel_cnt        := 0; -- 対象データは単独機器(第1階層)がない。

    IF INPUT_PATH_FILE IS NULL OR INPUT_PATH_FILE = '' THEN
        RAISE PRAM_EXCEPTION;
    ELSE
        v_DirPath :=  GET_DIR_PATH(INPUT_PATH_FILE);
        v_FileName := GET_FILE_NAME(INPUT_PATH_FILE, v_DirPath);
    END IF;
  --******************************************************************************
    PRAM_PLACE_HOLDER := '設置機器構成情報の削除';

  --******************************************************************************
  -- 1.1.　設置機器構成情報ワークのレコード全件削除
  -- 設置機器構成情報ワークに存在するレコード（前回実行分のデータ）を全件削除する。（TRUNCATE TABLE）
  --******************************************************************************
    stmt_str          := 'TRUNCATE TABLE CSG_P_IB_CONST_WK';
    EXECUTE IMMEDIATE stmt_str;
  --******************************************************************************
  -- 1.　CSVファイル取込
  -- 1.1.　CSVファイル取込
  -- 設置機器一括変更CSVファイルを読み込む。
  --******************************************************************************

    set_sysdate               := SYSDATE;

    PRAM_PLACE_HOLDER := 'ファイル読み込み';
    F := UTL_FILE.FOPEN (v_DirPath, v_FileName, 'R', 32760);
    IF UTL_FILE.IS_OPEN(F) THEN
      LOOP
        BEGIN
          UTL_FILE.GET_LINE(F, V_LINE, 32760);
          IF V_LINE IS NULL THEN
              RAISE PRAM_EXCEPTION;
          END IF;
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 1);
          v_InstanceId                := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 2);
          v_MainOptionType            := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 3);
          v_SerialNo                  := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 4);
          v_SnChangeReason            := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 5);
          v_ItemRemarks               := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 6);
          v_Quantity                  := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 7);
          v_TransferFlag              := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 8);
          v_TransferMaintenanceFrom   := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 9);
          v_TransferMaintenanceTo     := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 10);
          v_TransferMaintenanceDate   := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 11);
          v_TransferMaintenanceReason := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 12);
          v_CsInChargeCd              := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 13);
          v_IncidentSaverityName      := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 14);
          v_SecondaryInventoryName    := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 15);
          v_InstallLocationCode       := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 16);
          v_InstallLocationDeptName   := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 17);
          v_InstallLocationPersonName := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 18);
          v_InstallLocationTel        := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 19);
          v_InstallLocationFax        := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 20);
          v_InstallDate               := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 21);
          v_SalesDate                 := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 22);
          v_SalesOwnerCode            := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 23);
          v_OrderNo                   := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 24);
          v_CustomerOrderNo           := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 25);
          v_ServiceCondition          := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 26);
          v_OutSourcingFlag           := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 27);
          v_ShippingInspectionFlag    := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 28);
          --IF REGEXP_SUBSTR(str_value, '[^"]+', 1) IS NOT NULL THEN
          --    IF INSTR(REGEXP_SUBSTR(str_value, '[^"]+', 1),'.') > 0 THEN
          --        v_BundleMachineCd   := REGEXP_SUBSTR(REGEXP_SUBSTR(str_value, '[^"]+', 1), '[^.]+', 1, 1);
          --        v_BundleMakerNo     := REGEXP_SUBSTR(REGEXP_SUBSTR(str_value, '[^"]+', 1), '[^.]+', 1, 2);
          --        v_BundleBranchNo    := REGEXP_SUBSTR(REGEXP_SUBSTR(str_value, '[^"]+', 1), '[^.]+', 1, 3);
          --    ELSE
          --        v_BundleMachineCd   := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          --    END IF;
          --END IF;
          v_BundleMachineCd           := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 29);
          v_BundleMakerNo             := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 30);
          v_BundleBranchNo            := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 31);
          v_BundleSerailNo            := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 32);
          v_FirstCoverage             := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 33);
          v_FirstMonths               := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 34);
          v_FirstStartDate            := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 35);
          v_NextCoverage              := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 36);
          v_NextMonths                := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 37);
          v_HostId                    := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 38);
          v_HostName                  := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 39);
          v_KeepWatchSystemId         := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 40);
          v_OsType                    := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 41);
          v_OsVersion                 := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 42);
          v_SystemName                := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 43);
          v_FirmwareVersion           := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 44);
          v_Revision                  := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 45);
          v_UseCondition              := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 46);
          v_CpuRomRevision            := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 47);
          v_DiskCapacity              := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 48);
          v_UsePerpose                := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 49);
          v_PowerSupplyType           := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 50);
          v_PowerSupplyCapacity       := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 51);
          v_PpContAkNo                := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 52);
          v_UsePowerFrequency         := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 53);
          v_UsePowerVoltage           := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 54);
          v_PpContStartDate           := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 55);
          v_PpContEndDate             := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 56);
          v_MacAddress                := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 57);
          v_IpAddress                 := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 58);
          v_HpConfigCode              := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 59);
          v_HavingEarthFlag           := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 60);
          v_SupportInstructCode       := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 61);
          v_SupportStartDate          := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 62);
          v_SupportEndDate            := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 63);
          v_SalesDeptOrgId            := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 64);
          v_SalesDeptPersonId         := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 65);
          v_PresentDeptOrgId          := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 66);
          v_CtcSalesrepPersonId       := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 67);
          v_MainteBusDeptOrgId        := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 68);
          v_MainteBusPersonId         := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 69);
          v_CeCode                    := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 70);
          v_MaintenanceType           := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 71);
          v_ImportantItemFlag         := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 72);
          v_AgentFlag                 := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 73);
          v_FirstSaleDeptName         := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 74);
          v_FirstSalePersonName       := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 75);
          v_FirstSalePartyLocation    := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 76);
          v_FirstSaleTel              := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 77);
          v_FirstSaleFax              := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 78);
          v_FirstSaleMailAddress      := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 79);
          v_EnduserPartyCode          := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 80);
          v_EnduserLocation           := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 81);
          v_EnduserChrgDeptName       := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 82);
          v_EnduserTel                := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 83);
          v_EnduserFax                := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 84);
          v_EnduserChrgPersonName     := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 85);
          v_EnduserMailAddress        := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 86);
          v_LicenseManagementNo       := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 87);
          v_LisenceStartDate          := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 88);
          v_LisenceEndDate            := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 89);
          v_SuperintendeManageNo      := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 90);
          v_RemoveDate                := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 91);
          v_RemoveOrderNo             := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 92);
          v_RemovePoNo                := REGEXP_SUBSTR(str_value, '[^"]+', 1);
          str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, 93);
          v_RemoveReason              := REGEXP_SUBSTR(str_value, '[^"]+', 1);

        --********************************************************************
        -- レコードの読込み件数カウンター
        --********************************************************************
          g_target_sel_cnt          := g_target_sel_cnt + 1;

        --********************************************************************
        -- 2.　チェック処理
        -- 2.1.　対象データをチェックする。（単項目）
        --********************************************************************
        PRAM_PLACE_HOLDER         := 'チェック処理';
          -- インスタンス番号
          ---- 必須チェック 
          IF FUNC_REQUIRED_CHK(v_InstanceId) = 1 THEN
              OUT_ERR_CONTENT := 'インスタンス番号を入力してください。';
              RAISE NO_CHECK_DATA;
          END IF;
          p_INSTANCE_ID := v_InstanceId;

          ---- 存在チェック
          BEGIN
            SELECT INSTANCE_ID, INVENTORY_ITEM_CODE, ORG_ID
             INTO p_INSTANCE_ID_IBI, p_INVENTORY_ITEM_CODE_IBI, p_ORG_ID_IBI 
             FROM CSG_M_IB_INFO 
            where INSTANCE_ID = p_INSTANCE_ID;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              OUT_ERR_CONTENT := 'インスタンス番号がIB情報に存在しません。';
              RAISE NO_CHECK_DATA;
          END;
          ----(最上位判断)
          --IF ((v_InventoryItemCode = v_ParentInventoryItemCode AND v_SerialNo = v_ParentSrialNo) OR (v_ParentInventoryItemCode IS NULL AND v_ParentSrialNo IS NULL)) THEN
          SELECT COUNT(*)                       -- 件数
            INTO GET_COUNT
          FROM CSG_M_IB_INFO
          WHERE INSTANCE_ID = p_INSTANCE_ID
            AND PARENT_INSTANCE_ID = p_INSTANCE_ID
            AND TOP_INSTANCE_ID = p_INSTANCE_ID;

          IF GET_COUNT > 0 THEN
              v_IsParent := 1;
          ELSE
              v_IsParent := 0;
          END IF;

          -- シリアル番号
          ---- XXXX(空白)チェック 
          IF TRIM(v_SerialNo) = 'XXXX' THEN
              OUT_ERR_CONTENT := 'シリアル番号を空白に更新することはできません。';
              RAISE NO_CHECK_DATA;
          END IF;

          -- 品目摘要
          ---- XXXX(空白)チェック 
          IF TRIM(v_ItemRemarks) = 'XXXX' THEN
            OUT_ERR_CONTENT := '品目摘要を空白に更新することはできません。';
            RAISE NO_CHECK_DATA;
          END IF;

          -- 数量
          ---- 妥当性チェック 
          --IF FUNC_NUMBER_CHK(v_Quantity) = 1 THEN
          IF (v_Quantity < 1 or v_Quantity > 9999) THEN
              OUT_ERR_CONTENT := '数量は1-9999の数字を入力してください。';
              RAISE NO_CHECK_DATA;
          END IF;

          -- 担当CS
          ---- XXXX(空白)チェック 
          IF TRIM(v_CsInChargeCd) = 'XXXX' THEN
            OUT_ERR_CONTENT := '担当CSを空白に更新することはできません。';
            RAISE NO_CHECK_DATA;
          END IF;
          ---- 存在チェック 
          IF v_CsInChargeCd IS NOT NULL THEN
              IF FUNC_CSG_M_GROUP_MANA_CHK(v_CsInChargeCd) = 1 THEN
                  OUT_ERR_CONTENT := '担当CSがリソースグループに存在しません。';
                  RAISE NO_CHECK_DATA;
              END IF;
          END IF;

          -- 重要度
          ---- XXXX(空白)チェック
          IF TRIM(v_IncidentSaverityName) = 'XXXX' THEN
              OUT_ERR_CONTENT := '重要度を空白に更新することはできません。';
              RAISE NO_CHECK_DATA;
          END IF;
          ---- 存在チェック(指定値) 
          IF v_IncidentSaverityName IS NOT NULL THEN
              IF FUNC_SNV_M_GNRC_SNV_CHK('CSG_IMPORTANCE_LEVEL', v_IncidentSaverityName) = 1 THEN
                  OUT_ERR_CONTENT := '重要度を正しく設定してください。';
                  RAISE NO_CHECK_DATA;
              END IF;
          END IF;
          ---- 構成親チェック
          IF v_IncidentSaverityName IS NOT NULL AND v_IsParent = 0 THEN
              OUT_ERR_CONTENT := '重要度は構成最上位設置機器の重要度を変更した場合のみ反映されます';
              RAISE NO_CHECK_DATA;
          END IF;

          -- 区分
          ---- XXXX(空白)チェック
          IF TRIM(v_MainOptionType) = 'XXXX' THEN
              OUT_ERR_CONTENT := '区分を空白に更新することはできません。';
              RAISE NO_CHECK_DATA;
          END IF;
          ---- 存在チェック(指定値) 
          IF v_MainOptionType IS NOT NULL THEN
              IF FUNC_SNV_M_GNRC_SNV_CHK('CSG_CONFIG_TYPE',v_MainOptionType) = 1 THEN
                  OUT_ERR_CONTENT := '区分を正しく設定してください。';
                  RAISE NO_CHECK_DATA;
              END IF;
          END IF;

          -- 移管品
          ---- 存在チェック(指定値) 
          --IF TRIM(v_TransferFlag) <> 'Y' OR TRIM(v_TransferFlag) <> 'N' THEN
          IF TRIM(v_TransferFlag) <> 'XXXX' AND INSTR('YN', v_TransferFlag) = 0 THEN
              OUT_ERR_CONTENT := '移管品は「Y」か「N」を入力してください。';
              RAISE NO_CHECK_DATA;
          END IF;

          -- 委託先コード
          ---- 存在チェック
          IF v_SecondaryInventoryName IS NOT NULL AND TRIM(v_SecondaryInventoryName) <> 'XXXX' THEN
              IF FUNC_CSL_M_DEPO_CHK(v_SecondaryInventoryName) = 1 THEN
                  OUT_ERR_CONTENT := '委託先が委託先マスタに存在しません。';
                  RAISE NO_CHECK_DATA;
              END IF;
          END IF;

          -- 設置先部署
          ---- 構成親チェック
          IF v_InstallLocationDeptName IS NOT NULL AND v_IsParent = 0 THEN
              OUT_ERR_CONTENT := '設置先情報.部署は構成最上位設置機器の設置先情報.部署を変更した場合のみ反映されます';
              RAISE NO_CHECK_DATA;
          END IF;

          -- 設置先担当者
          ---- 構成親チェック
          IF v_InstallLocationPersonName IS NOT NULL AND v_IsParent = 0 THEN
              OUT_ERR_CONTENT := '設置先情報.担当者は構成最上位設置機器の設置先情報.担当者を変更した場合のみ反映されます';
              RAISE NO_CHECK_DATA;
          END IF;

          -- 設置先住所
          ---- XXXX(空白)チェック 
          IF TRIM(v_InstallLocationCode) = 'XXXX' THEN
              OUT_ERR_CONTENT := '住所(設置先情報)を空白に更新することはできません。';
              RAISE NO_CHECK_DATA;
          END IF;
          ---- 存在チェック(顧客サイトマスタ)
          IF v_InstallLocationCode IS NOT NULL THEN
              IF FUNC_CSG_M_IB_ADDRESS_CHK(v_InstallLocationCode) = 1 THEN
                  OUT_ERR_CONTENT := '委託先住所がパーティサイトマスタに存在しません。';
                  RAISE NO_CHECK_DATA;
              END IF; 
          END IF; 
          ---- 構成親チェック
          IF v_InstallLocationCode IS NOT NULL AND v_IsParent = 0 THEN
              OUT_ERR_CONTENT := '設置先情報.住所は構成最上位設置機器の設置先情報.住所を変更した場合のみ反映されます';
              RAISE NO_CHECK_DATA;
          END IF;

          -- 設置先TEL
          ---- 構成親チェック
          IF v_InstallLocationTel IS NOT NULL AND v_IsParent = 0 THEN
              OUT_ERR_CONTENT := '設置先情報.TELは構成最上位設置機器の設置先情報.TELを変更した場合のみ反映されます';
              RAISE NO_CHECK_DATA;
          END IF;

          -- 設置先FAX
          ---- 構成親チェック
          IF v_InstallLocationFax IS NOT NULL AND v_IsParent = 0 THEN
              OUT_ERR_CONTENT := '設置先情報.FAXは構成最上位設置機器の設置先情報.FAXを変更した場合のみ反映されます';
              RAISE NO_CHECK_DATA;
          END IF;

          -- 納入日
          ---- XXXX(空白)チェック
          IF TRIM(v_InstallDate) = 'XXXX' THEN
              OUT_ERR_CONTENT := '納入日を空白に更新することはできません。';
              RAISE NO_CHECK_DATA;
          END IF;
          ---- 日付型チェック
          IF v_InstallDate IS NOT NULL AND TRIM(v_InstallDate) <> 'XXXX' THEN
            BEGIN
              SELECT TO_DATE(v_InstallDate, 'YYYY/MM/DD') INTO p_INSTALL_DATE FROM DUAL;
            EXCEPTION
              WHEN OTHERS THEN
                OUT_ERR_CONTENT := '納入日を入力してください(yyyy/mm/dd)。';
                RAISE NO_CHECK_DATA;
            END;
          END IF;
          ---- 日付最小最大チェック
          IF TRIM(v_InstallDate) <> 'XXXX' AND (v_InstallDate < '1900/01/01' OR v_InstallDate > '9999/12/31') THEN
              OUT_ERR_CONTENT := '納入日は1900/01/01から9999/12/31の間で入力してください。';
              RAISE NO_CHECK_DATA;
          END IF;

          -- 売上日
          ---- 日付型チェック 
          IF v_SalesDate IS NOT NULL AND TRIM(v_SalesDate) <> 'XXXX' THEN
            BEGIN
              SELECT TO_DATE(v_SalesDate, 'YYYY/MM/DD') INTO p_SALES_DATE FROM DUAL;
            EXCEPTION
              WHEN OTHERS THEN
                OUT_ERR_CONTENT := '売上日を入力してください(yyyy/mm/dd)。';
                RAISE NO_CHECK_DATA;
            END;
          END IF;
          ---- 日付最小最大チェック
          --IF FUNC_DATE_CHK(v_SalesDate) = 1 THEN
          IF TRIM(v_SalesDate) <> 'XXXX' AND (v_SalesDate < '1900/01/01' OR v_SalesDate > '9999/12/31') THEN
              OUT_ERR_CONTENT := '売上日は1900/01/01から9999/12/31の間で入力してください。';
              RAISE NO_CHECK_DATA;
          END IF;

          -- 出荷検査実施フラグ
          ---- 存在チェック(指定値)
          --IF v_ShippingInspectionFlag = 'Y' OR v_ShippingInspectionFlag = 'N' THEN
          IF TRIM(v_ShippingInspectionFlag) <> 'XXXX' AND INSTR('YN', v_ShippingInspectionFlag) = 0 THEN
              OUT_ERR_CONTENT := '出荷検査実施フラグは「Y」か「N」を入力してください。';
              RAISE NO_CHECK_DATA;
          END IF;

          -- 販売元
          ---- XXXX(空白)チェック
          IF TRIM(v_SalesOwnerCode) = 'XXXX' THEN
              OUT_ERR_CONTENT := '販売元を空白に更新することはできません。';
              RAISE NO_CHECK_DATA;
          END IF;
          ---- 存在チェック(指定値)
          IF v_SalesOwnerCode IS NOT NULL AND TRIM(v_SalesOwnerCode) <> 'XXXX' THEN
              IF FUNC_SNV_M_GNRC_SNV_CHK('CSG_INSTANCE_USE_COMPANY',v_SalesOwnerCode, 2) = 1 THEN
                  OUT_ERR_CONTENT := '販売元を正しく設定してください。';
                  RAISE NO_CHECK_DATA;
              END IF;
          END IF;

          -- 外注フラグ
          ---- 存在チェック(指定値)
          IF v_OutSourcingFlag IS NOT NULL AND TRIM(v_OutSourcingFlag) <> 'XXXX' THEN
              IF FUNC_SNV_M_GNRC_SNV_CHK('SBCN_FLAG',v_OutSourcingFlag) = 1 THEN
                  OUT_ERR_CONTENT := '外注フラグを正しく設定してください。';
                  RAISE NO_CHECK_DATA;
              END IF;
          END IF;

          -- バンドル品コード
          ---- 存在チェック 
          --IF FUNC_SNV_M_ITEM_CHK(v_BundleItemCode, v_OrgId) = 1 THEN
          IF v_SalesOwnerCode IS NOT NULL AND (v_BundleMachineCd IS NOT NULL AND TRIM(v_BundleMachineCd) <> 'XXXX') AND (v_BundleMakerNo IS NOT NULL AND TRIM(v_BundleMakerNo) <> 'XXXX') THEN
            BEGIN
              SELECT SMI.ITEM_CD,                              -- 品目コード
                     SMI.REMARKS                               -- 摘要（品目名）
                INTO p_BUNDLE_ITEM_CODE,
                     p_BUNDLE_ITEM_NAME
                FROM SNV_M_ITEM SMI                            -- 品目マスタ
               WHERE SMI.PLT               = (
                                              SELECT SVN.PARM4                                  -- パラメータ4 (プラント)
                                                FROM SNV_M_GNRC_SNV SVN                         -- 汎用マスタ(SNV)
                                               WHERE SVN.KEY_ITEM          ='CSG_ROLE_CLASS'    -- (設置機器使用会社) 汎用マスタ(SNV).キー項目
                                                 AND SVN.VALD_STRT_DT     <= TRUNC(set_sysdate) -- 汎用マスタ(SNV).有効開始日
                                                 AND NVL(SVN.VALD_END_DT,TRUNC(set_sysdate)) >= TRUNC(set_sysdate) -- 汎用マスタ(SNV).有効終了日
                                                 AND NVL(SVN.DEL_FLG,'N') <> 'X'                -- 汎用マスタ(SNV).削除フラグ
                                                 AND SVN.CD_VAL            = v_SalesOwnerCode   -- 汎用マスタ(SNV).コード値 CSVファイルの販売元「SALES_OWNER_CODE」
                                              )                -- 品目マスタ.プラント 
                 AND SMI.PROD_CD           = v_BundleMachineCd -- 品目マスタ.機種コード CSVファイルのバンドル品.機種コード「BUNDLE_MACHINE_CD」
                 AND SMI.MAKR_MDL_NO       = v_BundleMakerNo   -- 品目マスタ.メーカ型番 CSVファイルのバンドル品.メーカー型番「BUNDLE_MAKER_NO」
                 and SMI.BR_NO             = v_BundleBranchNo  -- 品目マスタ.枝番 CSVファイルのバンドル品.枝番「BUNDLE_BRANCH_NO」
                 AND NVL(SMI.DEL_FLG,'N') <> 'X';              -- 品目マスタ.削除フラグ
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_ERR_CONTENT := 'バンドル品が品目マスタに存在しません。またはバンドル区分がバンドル品ではありません。';
                RAISE NO_CHECK_DATA;
            END;
          END IF;

          -- 初回ワランティ条件
          ---- 存在チェック 
          --IF FUNC_SNV_M_ITEM_CHK('ZMMDEFIRST_WT_COND', v_FirstCoverage) = 1 THEN
          IF v_FirstCoverage IS NOT NULL AND TRIM(v_FirstCoverage) <> 'XXXX' THEN
              IF FUNC_SNV_M_GNRC_SNV_CHK('ZMMDEFIRST_WT_COND', v_FirstCoverage) = 1 THEN
                  OUT_ERR_CONTENT := '初回ワランティ条件を正しく設定してください。';
                  RAISE NO_CHECK_DATA;
              END IF;
          END IF;

          -- 初回ワランティ月数
          ---- 数値型チェック
          IF v_FirstMonths IS NOT NULL AND TRIM(v_FirstMonths) <> 'XXXX' THEN
            BEGIN
              SELECT TO_NUMBER(v_FirstMonths, '99') INTO v_FirstMonths FROM DUAL;
            EXCEPTION
              WHEN OTHERS THEN
                OUT_ERR_CONTENT := '初回ワランティ月数は1-99の数字を入力してください。';
                RAISE NO_CHECK_DATA;
            END;
          END IF;
          ---- 数値チェック
          IF TRIM(v_FirstMonths) <> 'XXXX' AND (TO_NUMBER(v_FirstMonths) < 1 or TO_NUMBER(v_FirstMonths) > 99) THEN
              OUT_ERR_CONTENT := '初回ワランティ月数は1-99の数字を入力してください。';
              RAISE NO_CHECK_DATA;
          END IF;

          -- 初回ワランティ期間(自)
          ---- 日付型チェック
          IF v_FirstStartDate IS NOT NULL AND TRIM(v_FirstStartDate) <> 'XXXX' THEN
            BEGIN
              SELECT TO_DATE(v_FirstStartDate, 'YYYY/MM/DD') INTO p_FIRST_START_DATE FROM DUAL;
            EXCEPTION
              WHEN OTHERS THEN
                OUT_ERR_CONTENT := '初回ワランティ期間(自)を入力してください(yyyy/mm/dd)。';
                RAISE NO_CHECK_DATA;
            END;
          END IF;
          ---- 日付最小最大チェック
          --IF FUNC_DATE_CHK(v_FirstStartDate) = 1 THEN
          IF TRIM(v_FirstStartDate) <> 'XXXX' AND (v_FirstStartDate < '1900/01/01' OR v_FirstStartDate > '9999/12/31') THEN
              OUT_ERR_CONTENT := '初回ワランティ期間(自)は1900/01/01から9999/12/31の間で入力してください。';
              RAISE NO_CHECK_DATA;
          END IF;

          -- 次回ワランティ条件
          ---- 存在チェック 
          --IF FUNC_SNV_M_ITEM_CHK('ZMMDENEXT_VW_COND', v_NextCoverage) = 1 THEN
          IF v_NextCoverage IS NOT NULL AND TRIM(v_NextCoverage) <> 'XXXX' THEN
              IF FUNC_SNV_M_GNRC_SNV_CHK('ZMMDENEXT_WT_COND', v_NextCoverage) = 1 THEN
                  OUT_ERR_CONTENT := '次回ワランティ条件を正しく設定してください。';
                  RAISE NO_CHECK_DATA;
              END IF;
          END IF;

          -- 次回ワランティ月数
          ---- 数値型チェック
          IF v_NextMonths IS NOT NULL AND TRIM(v_NextMonths) <> 'XXXX' THEN
            BEGIN
              SELECT TO_NUMBER(v_NextMonths, '99') INTO v_NextMonths FROM DUAL;
            EXCEPTION
              WHEN OTHERS THEN
                OUT_ERR_CONTENT := '次回ワランティ月数は1-99の数字を入力してください。';
                RAISE NO_CHECK_DATA;
            END;
          END IF;
          ---- 数値チェック
          --IF FUNC_NUMBER_CHK(v_NextMonths) = 1 THEN
          IF TRIM(v_NextMonths) <> 'XXXX' AND (v_NextMonths < 1 or v_NextMonths > 99) THEN
              OUT_ERR_CONTENT := '次回ワランティ月数は1-99の数字を入力してください。';
              RAISE NO_CHECK_DATA;
          END IF;

          -- サービス形態
          ---- 存在チェック(指定値)
          IF v_ServiceCondition IS NOT NULL AND TRIM(v_ServiceCondition) <> 'XXXX' THEN
              IF FUNC_SNV_M_GNRC_SNV_CHK('ZMMDESERVICE', v_ServiceCondition) = 1 THEN
                  OUT_ERR_CONTENT := 'サービス形態を正しく設定してください。';
                  RAISE NO_CHECK_DATA;
              END IF;
          END IF;

          -- 保守移管日
          ---- 日付型チェック 
          IF v_TransferMaintenanceDate IS NOT NULL AND TRIM(v_TransferMaintenanceDate) <> 'XXXX' THEN
            BEGIN
              SELECT TO_DATE(v_TransferMaintenanceDate, 'YYYY/MM/DD') INTO p_TRANSFER_MAINTENANCE_DATE FROM DUAL;
            EXCEPTION
              WHEN OTHERS THEN
                OUT_ERR_CONTENT := '保守移管日を入力してください(yyyy/mm/dd)。';
                RAISE NO_CHECK_DATA;
            END;
          END IF;
          ---- 日付最小最大チェック
          --IF FUNC_DATE_CHK(v_TransferMaintenanceDate) = 1 THEN
          IF TRIM(v_TransferMaintenanceDate) <> 'XXXX' AND (v_TransferMaintenanceDate < '1900/01/01' OR v_TransferMaintenanceDate > '9999/12/31') THEN
              OUT_ERR_CONTENT := '保守移管日は1900/01/01から9999/12/31の間で入力してください。';
              RAISE NO_CHECK_DATA;
          END IF;

          -- 要サポートフラグ
          ---- 存在チェック(指定値) 
          IF v_SupportInstructCode IS NOT NULL AND TRIM(v_SupportInstructCode) <> 'XXXX' THEN
              IF FUNC_SNV_M_GNRC_SNV_CHK('CSG_SUPPORT_INSTRUCT_CODE',v_SupportInstructCode) = 1 THEN
                  OUT_ERR_CONTENT := '要サポートフラグを正しく設定してください。';
                  RAISE NO_CHECK_DATA;
              END IF;
          END IF;

          -- 要サポート開始日
          ---- 日付型チェック 
          IF v_SupportStartDate IS NOT NULL AND TRIM(v_SupportStartDate) <> 'XXXX' THEN
            BEGIN
              SELECT TO_DATE(v_SupportStartDate, 'YYYY/MM/DD') INTO p_SUPPORT_START_DATE_IBI FROM DUAL;
            EXCEPTION
              WHEN OTHERS THEN
                OUT_ERR_CONTENT := '要サポート開始日を入力してください(yyyy/mm/dd)。';
                RAISE NO_CHECK_DATA;
            END;
          END IF;
          ---- 日付最小最大チェック
          --IF FUNC_DATE_CHK(v_SupportStartDate) = 1 THEN
          IF TRIM(v_SupportStartDate) <> 'XXXX' AND (v_SupportStartDate < '1900/01/01' OR v_SupportStartDate > '9999/12/31') THEN
              OUT_ERR_CONTENT := '要サポート開始日は1900/01/01から9999/12/31の間で入力してください。';
              RAISE NO_CHECK_DATA;
          END IF;

          -- 要サポート終了日
          ---- 日付型チェック
          IF v_SupportEndDate IS NOT NULL AND TRIM(v_SupportEndDate) <> 'XXXX' THEN
            BEGIN
              SELECT TO_DATE(v_SupportEndDate, 'YYYY/MM/DD') INTO p_SUPPORT_END_DATE_IBI FROM DUAL;
            EXCEPTION
              WHEN OTHERS THEN
                OUT_ERR_CONTENT := '要サポート終了日を入力してください(yyyy/mm/dd)。';
                RAISE NO_CHECK_DATA;
            END;
          END IF;
          ---- 日付最小最大チェック 
          --IF FUNC_DATE_CHK(v_SupportEndDate) = 1 THEN
          IF TRIM(v_SupportEndDate) <> 'XXXX' AND (v_SupportEndDate < '1900/01/01' OR v_SupportEndDate > '9999/12/31') THEN
              OUT_ERR_CONTENT := '要サポート終了日は1900/01/01から9999/12/31の間で入力してください。';
              RAISE NO_CHECK_DATA;
          END IF;

          -- F営業販売部署
          ---- 存在チェック
          IF v_SalesDeptOrgId IS NOT NULL AND TRIM(v_SalesDeptOrgId) <> 'XXXX' THEN
              IF FUNC_SNV_M_DPT_CHK(v_SalesDeptOrgId, 1) = 1 THEN
                  OUT_ERR_CONTENT := 'F営業販売部署が組織マスタに存在しません。';
                  RAISE NO_CHECK_DATA;
              END IF;
          END IF;

          -- F営業販売担当者
          ---- 存在チェック
          IF v_SalesDeptPersonId IS NOT NULL AND TRIM(v_SalesDeptPersonId) <> 'XXXX' THEN
              IF FUNC_SNV_M_EMP_CHK(v_SalesDeptPersonId, 1) = 1 THEN
                  OUT_ERR_CONTENT := 'F営業販売担当者が従業員マスタに存在しません。';
                  RAISE NO_CHECK_DATA;
              END IF;
          END IF;

          -- F営業現在部署
          ---- 存在チェック
          IF v_PresentDeptOrgId IS NOT NULL AND TRIM(v_PresentDeptOrgId) <> 'XXXX' THEN
              IF FUNC_SNV_M_DPT_CHK(v_PresentDeptOrgId, 2) = 1 THEN
                  OUT_ERR_CONTENT := 'F営業現在部署が組織マスタに存在しません。';
                  RAISE NO_CHECK_DATA;
              END IF;
          END IF;

          -- F営業現在担当者
          ---- 存在チェック
          IF v_CtcSalesrepPersonId IS NOT NULL AND TRIM(v_CtcSalesrepPersonId) <> 'XXXX' THEN
              IF FUNC_SNV_M_EMP_CHK(v_CtcSalesrepPersonId, 2) = 1 THEN
                  OUT_ERR_CONTENT := 'F営業現在担当者が従業員マスタに存在しません。';
                  RAISE NO_CHECK_DATA;
              END IF;
          END IF;

          -- 保守営業担当部署
          ---- 存在チェック 
          IF v_MainteBusDeptOrgId IS NOT NULL AND TRIM(v_MainteBusDeptOrgId) <> 'XXXX' THEN
              IF FUNC_SNV_M_DPT_CHK(v_MainteBusDeptOrgId, 2) = 1 THEN
                  OUT_ERR_CONTENT := '保守営業担当部署が組織マスタに存在しません。';
                  RAISE NO_CHECK_DATA;
              END IF;
          END IF;

          -- 保守営業担当者
          ---- 存在チェック 
          IF v_MainteBusPersonId IS NOT NULL AND TRIM(v_MainteBusPersonId) <> 'XXXX' THEN
              IF FUNC_SNV_M_EMP_CHK(v_MainteBusPersonId, 2) = 1 THEN
                  OUT_ERR_CONTENT := '保守営業担当者が従業員マスタに存在しません。';
                  RAISE NO_CHECK_DATA;
              END IF;
          END IF;

          -- 保守担当CE
          ---- 必須項目チェック 
          IF v_CeCode IS NOT NULL AND TRIM(v_CeCode) <> 'XXXX' THEN
              IF FUNC_SNV_M_EMP_CHK(v_CeCode, 3) = 1 THEN
                  OUT_ERR_CONTENT := '保守担当CEが従業員マスタに存在しません。';
                  RAISE NO_CHECK_DATA;
              END IF;
          END IF;
          ---- 構成親チェック
          IF v_CeCode IS NOT NULL AND v_IsParent = 0 THEN
              OUT_ERR_CONTENT := '保守担当CEは構成最上位設置機器の保守担当CEを変更した場合のみ反映されます';
              RAISE NO_CHECK_DATA;
          END IF;

          -- 保守種別
          ---- XXXX(空白)チェック
          IF TRIM(v_MaintenanceType) = 'XXXX' THEN
              OUT_ERR_CONTENT := '保守種別を空白に更新することはできません。';
              RAISE NO_CHECK_DATA;
          END IF;
          ---- 存在チェック 
          IF v_MaintenanceType IS NOT NULL THEN
              IF FUNC_SNV_M_GNRC_SNV_CHK('CSG_INSTANCE_USE_COMPANY',v_MaintenanceType, 1) = 1 THEN
                  OUT_ERR_CONTENT := '保守種別を正しく設定してください。';
                  RAISE NO_CHECK_DATA;
              END IF;
          END IF;

          -- 販社フラグ
          ---- XXXX(空白)チェック
          IF TRIM(v_AgentFlag) = 'XXXX' THEN
              OUT_ERR_CONTENT := '販社フラグを空白に更新することはできません。';
              RAISE NO_CHECK_DATA;
          END IF;
          ---- 存在チェック
          IF v_AgentFlag IS NOT NULL AND TRIM(v_AgentFlag) <> 'XXXX' THEN
              IF FUNC_SNV_M_GNRC_SNV_CHK('CSG_INSTANCE_USE_COMPANY',v_AgentFlag, 3) = 1 THEN
                  OUT_ERR_CONTENT := '販社フラグを正しく設定してください。';
                  RAISE NO_CHECK_DATA;
              END IF;
          END IF;

          -- 初期販売住所(サイト番号)
          ---- 存在チェック(設置先住所マスタ)
          IF v_FirstSalePartyLocation IS NOT NULL AND TRIM(v_FirstSalePartyLocation) <> 'XXXX' THEN
              IF FUNC_CSG_M_IB_ADDRESS_CHK(v_FirstSalePartyLocation) = 1 THEN
                  OUT_ERR_CONTENT := '初期販売住所が設置先住所マスタに存在しません。';
                  RAISE NO_CHECK_DATA;
              END IF;
          END IF;

          -- エンドユーザ会社番号
          ---- 存在チェック
          IF v_EnduserPartyCode IS NOT NULL AND TRIM(v_EnduserPartyCode) <> 'XXXX' THEN
              IF FUNC_SNV_M_CUST_CHK(v_EnduserPartyCode) = 1 THEN
                  OUT_ERR_CONTENT := 'エンドユーザ会社番号が顧客マスタに存在しません。';
                  RAISE NO_CHECK_DATA;
              END IF;
          END IF;
          ---- 構成親チェック
          IF v_EnduserPartyCode IS NOT NULL AND v_IsParent = 0 THEN
              OUT_ERR_CONTENT := 'エンドユーザ.会社番号は構成最上位設置機器のエンドユーザ.会社番号を変更した場合のみ反映されます';
              RAISE NO_CHECK_DATA;
          END IF;

          -- エンドユーザ部署
          ---- 構成親チェック
          IF v_EnduserChrgDeptName IS NOT NULL AND v_IsParent = 0 THEN
              OUT_ERR_CONTENT := 'エンドユーザ.部署は構成最上位設置機器のエンドユーザ.部署を変更した場合のみ反映されます';
              RAISE NO_CHECK_DATA;
          END IF;

          -- エンドユーザ担当者
          ---- 構成親チェック
          IF v_EnduserChrgPersonName IS NOT NULL AND v_IsParent = 0 THEN
              OUT_ERR_CONTENT := 'エンドユーザ.担当者は構成最上位設置機器のエンドユーザ.担当者を変更した場合のみ反映されます';
              RAISE NO_CHECK_DATA;
          END IF;

          -- エンドユーザ住所
          ---- 構成親チェック
          IF v_EnduserLocation IS NOT NULL AND v_IsParent = 0 THEN
              OUT_ERR_CONTENT := 'エンドユーザ.住所は構成最上位設置機器のエンドユーザ.住所を変更した場合のみ反映されます';
              RAISE NO_CHECK_DATA;
          END IF;

          -- エンドユーザTEL
          ---- 構成親チェック
          IF v_EnduserTel IS NOT NULL AND v_IsParent = 0 THEN
              OUT_ERR_CONTENT := 'エンドユーザ.TELは構成最上位設置機器のエンドユーザ.TELを変更した場合のみ反映されます';
              RAISE NO_CHECK_DATA;
          END IF;

          -- エンドユーザFAX
          ---- 構成親チェック
          IF v_EnduserFax IS NOT NULL AND v_IsParent = 0 THEN
              OUT_ERR_CONTENT := 'エンドユーザ.FAXは構成最上位設置機器のエンドユーザ.FAXを変更した場合のみ反映されます';
              RAISE NO_CHECK_DATA;
          END IF;

          -- エンドユーザメールアドレス
          ---- 構成親チェック
          IF v_EnduserMailAddress IS NOT NULL AND v_IsParent = 0 THEN
              OUT_ERR_CONTENT := 'エンドユーザ.メールアドレスは構成最上位設置機器のエンドユーザ.メールアドレスを変更した場合のみ反映されます';
              RAISE NO_CHECK_DATA;
          END IF;

          -- 監視システムID
          ---- 構成親チェック
          IF v_KeepWatchSystemId IS NOT NULL AND v_IsParent = 0 THEN
              OUT_ERR_CONTENT := '監視システムIDは構成最上位設置機器の監視システムIDを変更した場合のみ反映されます';
              RAISE NO_CHECK_DATA;
          END IF;

          -- OS種別
          ---- 存在チェック(指定値)
          IF v_OsType IS NOT NULL AND TRIM(v_OsType) <> 'XXXX' THEN
              IF FUNC_SNV_M_GNRC_SNV_CHK('CSG_OS_TYPE',v_OsType) = 1 THEN
                  OUT_ERR_CONTENT := 'OS種別を正しく設定してください。';
                  RAISE NO_CHECK_DATA;
              END IF;
          END IF;

          -- システム名
          ---- 構成親チェック
          IF v_SystemName IS NOT NULL AND v_IsParent = 0 THEN
              OUT_ERR_CONTENT := 'システム名は構成最上位設置機器のシステム名を変更した場合のみ反映されます';
              RAISE NO_CHECK_DATA;
          END IF;

          -- 利用形態
          ---- 構成親チェック
          IF v_UseCondition IS NOT NULL AND v_IsParent = 0 THEN
              OUT_ERR_CONTENT := '利用形態は構成最上位設置機器の利用形態を変更した場合のみ反映されます';
              RAISE NO_CHECK_DATA;
          END IF;

          -- 利用目的
          ---- 構成親チェック
          IF v_UsePerpose IS NOT NULL AND v_IsParent = 0 THEN
              OUT_ERR_CONTENT := '利用目的は構成最上位設置機器の利用目的を変更した場合のみ反映されます';
              RAISE NO_CHECK_DATA;
          END IF;

          -- 電源設備種類
          ---- 存在チェック(指定値)
          IF v_PowerSupplyType IS NOT NULL AND TRIM(v_PowerSupplyType) <> 'XXXX' THEN
              IF FUNC_SNV_M_GNRC_SNV_CHK('CSG_POWER_SUPPLY_TYPE',v_PowerSupplyType) = 1 THEN
                  OUT_ERR_CONTENT := '電源設備種類を正しく設定してください。';
                  RAISE NO_CHECK_DATA;
              END IF;
          END IF;

          -- 使用電源周波数
          ---- 存在チェック(指定値)
          IF v_UsePowerFrequency IS NOT NULL AND TRIM(v_UsePowerFrequency) <> 'XXXX' THEN
              IF FUNC_SNV_M_GNRC_SNV_CHK('CSG_USE_POWER_FREQUENCY',v_UsePowerFrequency) = 1 THEN
                  OUT_ERR_CONTENT := '使用電源周波数を正しく設定してください。';
                  RAISE NO_CHECK_DATA;
              END IF;
          END IF;

          -- 契約期間(自)
          ---- 日付型チェック 
          IF v_PpContStartDate IS NOT NULL AND TRIM(v_PpContStartDate) <> 'XXXX' THEN
            BEGIN
              SELECT TO_DATE(v_PpContStartDate, 'YYYY/MM/DD') INTO p_PP_CONT_START_DATE_IBI FROM DUAL;
            EXCEPTION
              WHEN OTHERS THEN
                OUT_ERR_CONTENT := '契約期間(自)を入力してください(yyyy/mm/dd)。';
                RAISE NO_CHECK_DATA;
            END;
          END IF;
          -- 日付最小最大チェック
          --IF FUNC_DATE_CHK(v_PpContStartDate) = 1 THEN
          IF TRIM(v_PpContStartDate) <> 'XXXX' AND (v_PpContStartDate < '1900/01/01' OR v_PpContStartDate > '9999/12/31') THEN
              OUT_ERR_CONTENT := '契約期間(自)は1900/01/01から9999/12/31の間で入力してください。';
              RAISE NO_CHECK_DATA;
          END IF;

          -- 契約期間(至)
          ---- 日付型チェック 
          IF v_PpContEndDate IS NOT NULL AND TRIM(v_PpContEndDate) <> 'XXXX' THEN
            BEGIN
              SELECT TO_DATE(v_PpContEndDate, 'YYYY/MM/DD') INTO p_PP_CONT_END_DATE_IBI FROM DUAL;
            EXCEPTION
              WHEN OTHERS THEN
                OUT_ERR_CONTENT := '契約期間(至)を入力してください(yyyy/mm/dd)。';
                RAISE NO_CHECK_DATA;
            END;
          END IF;
          ---- 日付最小最大チェック
          --IF FUNC_DATE_CHK(v_PpContEndDate) = 1 THEN
          IF TRIM(v_PpContEndDate) <> 'XXXX' AND (v_PpContEndDate < '1900/01/01' OR v_PpContEndDate > '9999/12/31') THEN
              OUT_ERR_CONTENT := '契約期間(至)は1900/01/01から9999/12/31の間で入力してください。';
              RAISE NO_CHECK_DATA;
          END IF;

          -- アース有無
          ---- 存在チェック(指定値) 
          --IF v_HavingEarthFlag = 'Y' OR v_HavingEarthFlag = 'N' THEN
          IF TRIM(v_HavingEarthFlag) <> 'XXXX' AND INSTR('YN', v_HavingEarthFlag) = 0 THEN
              OUT_ERR_CONTENT := 'アース有無は「Y」か「N」を入力してください。';
              RAISE NO_CHECK_DATA;
          END IF;

          -- ライセンス開始日
          ---- 日付型チェック
          IF v_LisenceStartDate IS NOT NULL AND TRIM(v_LisenceStartDate) <> 'XXXX' THEN
            BEGIN
              SELECT TO_DATE(v_LisenceStartDate, 'YYYY/MM/DD') INTO p_LISENCE_START_DATE_IBI FROM DUAL;
            EXCEPTION
              WHEN OTHERS THEN
                OUT_ERR_CONTENT := 'ライセンス開始日を入力してください(yyyy/mm/dd)。';
                RAISE NO_CHECK_DATA;
            END;
          END IF;
          ---- 日付最小最大チェック
          --IF FUNC_DATE_CHK(v_LisenceStartDate) = 1 THEN
          IF TRIM(v_LisenceStartDate) <> 'XXXX' AND (v_LisenceStartDate < '1900/01/01' OR v_LisenceStartDate > '9999/12/31') THEN
              OUT_ERR_CONTENT := 'ライセンス開始日は1900/01/01から9999/12/31の間で入力してください。';
              RAISE NO_CHECK_DATA;
          END IF;

          -- ライセンス終了日
          ---- 日付型チェック 
          IF v_LisenceEndDate IS NOT NULL AND TRIM(v_LisenceEndDate) <> 'XXXX' THEN
            BEGIN
              SELECT TO_DATE(v_LisenceEndDate, 'YYYY/MM/DD') INTO p_LISENCE_END_DATE_IBI FROM DUAL;
            EXCEPTION
              WHEN OTHERS THEN
                OUT_ERR_CONTENT := 'ライセンス終了日を入力してください(yyyy/mm/dd)。';
                RAISE NO_CHECK_DATA;
            END;
          END IF;
          ---- 日付最小最大チェック
          --IF FUNC_DATE_CHK(v_LisenceEndDate) = 1 THEN
          IF TRIM(v_LisenceEndDate) <> 'XXXX' AND (v_LisenceEndDate < '1900/01/01' OR v_LisenceEndDate > '9999/12/31') THEN
              OUT_ERR_CONTENT := 'ライセンス終了日は1900/01/01から9999/12/31の間で入力してください。';
              RAISE NO_CHECK_DATA;
          END IF;

          -- 移設日
          ---- 日付型チェック
          IF v_RemoveDate IS NOT NULL AND TRIM(v_RemoveDate) <> 'XXXX' THEN
            BEGIN
              SELECT TO_DATE(v_RemoveDate, 'YYYY/MM/DD') INTO p_REMOVE_DATE_IBI FROM DUAL;
            EXCEPTION
              WHEN OTHERS THEN
                OUT_ERR_CONTENT := '移設日を入力してください(yyyy/mm/dd)。';
                RAISE NO_CHECK_DATA;
            END;
          END IF;
          -- 日付最小最大チェック
          --IF FUNC_DATE_CHK(v_RemoveDate) = 1 THEN
          IF TRIM(v_RemoveDate) <> 'XXXX' AND (v_RemoveDate < '1900/01/01' OR v_RemoveDate > '9999/12/31') THEN
              OUT_ERR_CONTENT := '移設日は1900/01/01から9999/12/31の間で入力してください。';
              RAISE NO_CHECK_DATA;
          END IF;

        --********************************************************************
        -- 2.　チェック処理
        -- 2.2.　対象データをチェックする。（相関チェック）
        --********************************************************************
          -- インスタンス番号と他項目
          N_NULL_CNT := 0;
          IF p_INSTANCE_ID IS NOT NULL THEN
              FOR i IN 2..93
              LOOP
                  str_value                   := REGEXP_SUBSTR(V_LINE, '[^,]+', 1, i);
                  IF REGEXP_SUBSTR(str_value, '[^"]+', 1) IS NULL OR REGEXP_SUBSTR(str_value, '[^"]+', 1) = '' THEN
                      N_NULL_CNT    := N_NULL_CNT + 1;
                  END IF;
              END LOOP;

              IF N_NULL_CNT = 92 THEN
                  OUT_ERR_CONTENT := 'インスタンス番号以外の項目を入力してください。';
                  RAISE NO_CHECK_DATA;
              END IF;
          END IF;

          -- シリアル番号と品目
          --IF v_InventoryItemCode IS NOT NULL AND v_SerialNo IS NOT NULL THEN
          IF v_SerialNo IS NOT NULL THEN
              SELECT COUNT(*)
                INTO GET_COUNT
                FROM CSG_M_IB_INFO IB         -- 設置機器情報
               WHERE IB.INVENTORY_ITEM_CODE = p_INVENTORY_ITEM_CODE_IBI -- 品目コード
                 AND IB.SERIAL_NO           = v_SerialNo          -- シリアル番号
                 AND IB.INSTANCE_ID         <> p_INSTANCE_ID;          -- インスタンス番号

              IF GET_COUNT > 0 THEN
                  OUT_ERR_CONTENT := '対象の品目・シリアルの組み合わせが既に登録されています。';
                  RAISE NO_CHECK_DATA;
              END IF;
          END IF;

          -- 数量と品目
          --(品目がシリアル管理品(品目マスタ.シリアル区分≠0)の場合、数量の項目に入力があるとエラー)
          --IF v_InventoryItemCode IS NOT NULL AND v_OrgId IS NOT NULL THEN
          IF (p_INVENTORY_ITEM_CODE_IBI IS NOT NULL AND p_ORG_ID_IBI IS NOT NULL) AND v_Quantity IS NOT NULL THEN
              SELECT COUNT(*)
                INTO GET_COUNT
                FROM SNV_M_ITEM ITEM
               WHERE ITEM.ITEM_CD = p_INVENTORY_ITEM_CODE_IBI
                 AND ITEM.PLT     = p_ORG_ID_IBI
                 AND ITEM.SER_TP  = '0'; --数量管理

              IF GET_COUNT > 0 THEN
                OUT_ERR_CONTENT := '数量はシリアル管理品のため更新できません。';
                  RAISE NO_CHECK_DATA;
              END IF;
          END IF;

          -- ワランティ情報
          ---- 初回条件のみ,初回月数のみ,初回期間(自)のみ「XXXX」が入力されている
          IF (TRIM(v_FirstCoverage) = 'XXXX' AND TRIM(v_FirstMonths) <> 'XXXX' AND TRIM(v_FirstStartDate) <> 'XXXX') OR 
             (TRIM(v_FirstCoverage) <> 'XXXX' AND TRIM(v_FirstMonths) = 'XXXX' AND TRIM(v_FirstStartDate) <> 'XXXX') OR 
             (TRIM(v_FirstCoverage) <> 'XXXX' AND TRIM(v_FirstMonths) <> 'XXXX' AND TRIM(v_FirstStartDate) = 'XXXX') THEN
              OUT_ERR_CONTENT := '削除文字：XXXXはワランティ情報項目すべてがXXXXのときに設定可能です。';
              RAISE NO_CHECK_DATA;
          END IF;
          ---- 初回条件のみ設定しようとする場合
          IF TRIM(v_FirstCoverage) IS NOT NULL AND 
             TRIM(v_FirstMonths) IS NULL AND 
             TRIM(v_FirstStartDate) IS NULL THEN
              OUT_ERR_CONTENT := 'ワランティ情報.初回月数 及び ワランティ情報.初回期間(自)は必須入力です。';
              RAISE NO_CHECK_DATA;
          END IF;
          ---- 初回月数のみ設定しようとする場合
          IF TRIM(v_FirstCoverage) IS NULL AND 
             TRIM(v_FirstMonths) IS NOT NULL AND 
             TRIM(v_FirstStartDate) IS NULL THEN
              OUT_ERR_CONTENT := 'ワランティ情報.初回条件 及び ワランティ情報.初回期間(自)は必須入力です。';
              RAISE NO_CHECK_DATA;
          END IF;
          ---- 初回期間(自)のみ設定しようする場合
          IF TRIM(v_FirstCoverage) IS NULL AND 
             TRIM(v_FirstMonths) IS NULL AND 
             TRIM(v_FirstStartDate) IS NOT NULL THEN
              OUT_ERR_CONTENT := 'ワランティ情報.初回条件 及び ワランティ情報.初回月数は必須入力です。';
              RAISE NO_CHECK_DATA;
          END IF;
          ---- 次回条件のみ,次回月数のみ「XXXX」の場合
          IF (TRIM(v_NextCoverage) = 'XXXX' AND TRIM(v_NextMonths) <> 'XXXX') OR 
             (TRIM(v_NextCoverage) <> 'XXXX' AND TRIM(v_NextMonths) = 'XXXX') THEN
              OUT_ERR_CONTENT := '削除文字：XXXXはワランティ情報.次回項目全てがXXXXのときに設定可能です。';
              RAISE NO_CHECK_DATA;
          END IF;
          ---- 次回条件のみ設定しようとする場合
          IF TRIM(v_NextCoverage) IS NOT NULL AND 
             TRIM(v_NextMonths) IS NULL THEN
              OUT_ERR_CONTENT := '初回ワランティ情報またはワランティ情報.次回月数は必須入力です。';
              RAISE NO_CHECK_DATA;
          END IF;
          ---- 次回月数のみ設定しようとする場合
          IF TRIM(v_NextCoverage) IS NULL AND 
             TRIM(v_NextMonths) IS NOT NULL THEN
              OUT_ERR_CONTENT := '初回ワランティ情報またはワランティ情報.次回条件は必須入力です。';
              RAISE NO_CHECK_DATA;
          END IF;

          -- ワランティとサービス形態
          ----ワランティとサービス形態の組合わせ不正
          IF (v_FirstCoverage IS NOT NULL AND TRIM(v_FirstCoverage) <> 'XXXX')  AND (v_ServiceCondition IS NOT NULL AND TRIM(v_ServiceCondition) <> 'XXXX') THEN
            BEGIN
              SELECT PARM1
                INTO p_SERVICE_CONDITION
                FROM SNV_M_GNRC_ERP
               WHERE CLSFCTN          = 'V'
                 AND GRP_KEY          = 'MATERIAL' 
                 AND KEY_ITEM         = 'ZMMDEFIRST_WT_COND'
                 AND VALD_STRT_DT     <= TRUNC(set_sysdate)
                 AND NVL(VALD_END_DT,TRUNC(set_sysdate)) >= TRUNC(set_sysdate)
                 AND NVL(DEL_FLG,'N') <> 'X'
                 AND CD_VAL           = v_FirstCoverage;
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_ERR_CONTENT := '初回ワランティ情報とサービス形態の整合性を合わせてください。';
                RAISE NO_CHECK_DATA;
            END;
            IF v_ServiceCondition <> p_SERVICE_CONDITION THEN
                OUT_ERR_CONTENT := '初回ワランティ情報とサービス形態の整合性を合わせてください。';
                RAISE NO_CHECK_DATA;
            END IF;
          END IF;
          IF (v_NextCoverage IS NOT NULL AND TRIM(v_NextCoverage) <> 'XXXX') AND (v_ServiceCondition IS NOT NULL AND TRIM(v_ServiceCondition) <> 'XXXX') THEN
            BEGIN
              SELECT PARM1
                INTO p_SERVICE_CONDITION
                FROM SNV_M_GNRC_ERP
               WHERE CLSFCTN          = 'V'
                 AND GRP_KEY          = 'MATERIAL' 
                 AND KEY_ITEM         = 'ZMMDENEXT_WT_COND'
                 AND VALD_STRT_DT     <= TRUNC(set_sysdate)
                 AND NVL(VALD_END_DT,TRUNC(set_sysdate)) >= TRUNC(set_sysdate)
                 AND NVL(DEL_FLG,'N') <> 'X'
                 AND CD_VAL           =  v_NextCoverage;
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_ERR_CONTENT := '次回ワランティ情報とサービス形態の整合性を合わせてください。';
                RAISE NO_CHECK_DATA;
            END;
            IF v_ServiceCondition <> p_SERVICE_CONDITION THEN
                OUT_ERR_CONTENT := '次回ワランティ情報とサービス形態の整合性を合わせてください。';
                RAISE NO_CHECK_DATA;
            END IF;
          END IF;

          -- 要サポート項目
          ---- どちらか一方のみ入力されている場合
          IF (v_SupportStartDate IS NOT NULL AND v_SupportEndDate IS NULL) THEN
              OUT_ERR_CONTENT := '開始日のみ：終了日(要サポート)を入力してください。';
              RAISE NO_CHECK_DATA;
          END IF;
          IF (v_SupportStartDate IS NULL AND v_SupportEndDate IS NOT NULL) THEN
              OUT_ERR_CONTENT := '終了日のみ：開始日(要サポート)を入力してください。';
              RAISE NO_CHECK_DATA;
          END IF;
          IF (TRIM(v_SupportStartDate) <> 'XXXX' AND TRIM(v_SupportEndDate) <> 'XXXX') THEN
          ---- 要サポート開始日より要サポート終了日の方が過去の日付
              IF TO_DATE(v_SupportStartDate,'YYYY/MM/DD HH24:MI:SS') > TO_DATE(v_SupportEndDate,'YYYY/MM/DD HH24:MI:SS') THEN
                  OUT_ERR_CONTENT := '開始日(要サポート)には終了日(要サポート)より過去日を設定してください。';
                  RAISE NO_CHECK_DATA;
              END IF;
          ---- フラグが入力されていない状態で、開始日もしくは終了日が入力されている場合
              IF v_SupportInstructCode IS NULL AND NOT(v_SupportStartDate IS NULL AND v_SupportEndDate IS NULL) THEN
                  OUT_ERR_CONTENT := '要サポートフラグを入力してください。';
                  RAISE NO_CHECK_DATA;
              END IF;
          ---- 3ヶ月以上の場合
          --IF TO_DATE(ADD_MONTHS(v_SupportStartDate, 3),'YYYY/MM/DD HH24:MI:SS') < TO_DATE(v_SupportEndDate,'YYYY/MM/DD HH24:MI:SS') THEN
              IF MONTHS_BETWEEN(TO_DATE(v_SupportEndDate,'YYYY/MM/DD'), TO_DATE(v_SupportStartDate,'YYYY/MM/DD')) > 3 THEN
                  OUT_ERR_CONTENT := '開始日(要サポート)と終了日(要サポート)の期間は3ヶ月以内に設定してください。';
                  RAISE NO_CHECK_DATA;
              END IF;
          ---- 日付必須フラグが「Y」、日付指定なし
              IF v_SupportInstructCode IS NOT NULL AND (v_SupportStartDate IS NULL OR v_SupportEndDate IS NULL) THEN
                  OUT_ERR_CONTENT := '要サポートフラグが入力されている場合、日付は必須入力です。';
                  RAISE NO_CHECK_DATA;
              END IF;
          ---- 日付必須フラグが「Y」以外、日付指定あり
              IF v_SupportInstructCode IS NULL AND (v_SupportStartDate IS NOT NULL OR v_SupportEndDate IS NOT NULL) THEN
                  OUT_ERR_CONTENT := '要サポートフラグが未入力の場合、日付は入力できません。';
                  RAISE NO_CHECK_DATA;
              END IF;
          ---- ログイン職責がCTC
          ----(バッチ実行ユーザがCTCの場合、要サポート項目(要サポートフラグ、要サポート開始日、要サポート終了日）に入力があるとエラー)
              ----IF INPUT_USER_ID = 'CTC' AND (v_SupportInstructCode IS NOT NULL OR v_SupportStartDate IS NOT NULL OR v_SupportEndDate IS NOT NULL) THEN
              --IF (v_SupportInstructCode IS NOT NULL OR v_SupportStartDate IS NOT NULL OR v_SupportEndDate IS NOT NULL) THEN
              --    BEGIN
              --        SELECT PARM1
              --        INTO v_RoleClass
              --        FROM SNV_M_GNRC_SNV
              --       WHERE CLSFCTN          = 'M'
              --         AND GRP_KEY          = 'CSG' 
              --         AND KEY_ITEM         = 'CSG_ROLE_CLASS'
              --         AND VALD_STRT_DT     <= TRUNC(set_sysdate)
              --         AND VALD_END_DT      >= TRUNC(set_sysdate)
              --         AND NVL(DEL_FLG,'N') <> 'X'
              --         AND CD_VAL           = INPUT_ROLE_CLASS;
              --    EXCEPTION
              --      WHEN NO_DATA_FOUND THEN
              --        OUT_ERR_CONTENT := '該当の職責からは要サポートフラグが設定できません。';
              --        RAISE NO_CHECK_DATA;
              --    END;
              --    IF v_RoleClass <> 'CTC' THEN
              --        OUT_ERR_CONTENT := '該当の職責からは要サポートフラグが設定できません。';
              --        RAISE NO_CHECK_DATA;
              --    END IF;
              --END IF;
          END IF;

          -- 契約期間(自)と契約期間(至)
          ----契約期間(自)(至）どちらかのみ設定されるような更新方法はエラー
          IF (v_PpContStartDate IS NULL AND v_PpContEndDate IS NOT NULL) OR (v_PpContStartDate IS NOT NULL AND v_PpContEndDate IS NULL) THEN
              OUT_ERR_CONTENT := '契約期間(自)(至)はどちらか一方のみ空白に更新できません。';
              RAISE NO_CHECK_DATA;
          END IF;
          IF (TRIM(v_PpContStartDate) <> 'XXXX' AND TRIM(v_PpContEndDate) <> 'XXXX') THEN
              ---- 契約期間(自)より契約期間(至)の方が過去の日付だとエラー
              IF TO_DATE(v_PpContStartDate,'YYYY/MM/DD HH24:MI:SS') > TO_DATE(v_PpContEndDate,'YYYY/MM/DD HH24:MI:SS') THEN
                  OUT_ERR_CONTENT := '契約期間(自)には契約期間(至)より過去日を設定してください。';
                  RAISE NO_CHECK_DATA;
              END IF;
          END IF;

          -- ライセンス開始日とライセンス終了日
          ----ライセンス開始日よりライセンス終了日の方が過去の日付の場合はエラー
          IF (TRIM(v_LisenceStartDate) <> 'XXXX' AND TRIM(v_LisenceEndDate) <> 'XXXX') THEN
              IF TO_DATE(v_LisenceStartDate,'YYYY/MM/DD HH24:MI:SS') > TO_DATE(v_LisenceEndDate,'YYYY/MM/DD HH24:MI:SS') THEN
                  OUT_ERR_CONTENT := 'ライセンス開始日にはライセンス終了日より過去日を設定してください。';
                  RAISE NO_CHECK_DATA;
              END IF;
          END IF;

          -- シリアル番号とシリアル番号変更理由
          ----シリアル番号が入力された際にシリアル番号変更理由が空白の場合はエラー
          IF v_SerialNo IS NOT NULL AND v_SnChangeReason IS NULL THEN
              OUT_ERR_CONTENT := 'シリアル番号を更新する際にはシリアル番号変更理由を入力してください。';
              RAISE NO_CHECK_DATA;
          END IF;
          ----シリアル番号変更理由が入力された際にシリアル番号が空白の場合はエラー
          IF v_SerialNo IS NULL AND v_SnChangeReason IS NOT NULL THEN
              OUT_ERR_CONTENT := 'シリアル番号変更理由を更新する際にはシリアル番号を入力してください。';
              RAISE NO_CHECK_DATA;
          END IF;

          -- バンドルシリアル番号チェック
          ----バンドル品が入力され、バンドルシリアル番号が空白の場合はエラー
          IF p_BUNDLE_ITEM_CODE IS NOT NULL AND v_BundleSerailNo IS NULL THEN
             OUT_ERR_CONTENT := 'バンドル品がシリアル管理品の場合、バンドルシリアル番号は必須です。';
             RAISE NO_CHECK_DATA;
          END IF;

          --********************************************************************
          -- ※1　バンドル品目コード、バンドル品目名の取得
          -- [1.1.]で取得した「販売元」、「バンドル品.機種コード」、「バンドル品.メーカ型番」が設定されいる場合のみ、実施する。
          --********************************************************************
          IF (v_SalesOwnerCode IS NOT NULL AND TRIM(v_SalesOwnerCode) <> 'XXXX') AND (v_BundleMachineCd IS NOT NULL AND TRIM(v_BundleMachineCd) <> 'XXXX') AND (v_BundleMakerNo IS NOT NULL AND TRIM(v_BundleMakerNo) <> 'XXXX') THEN
            BEGIN
              SELECT SMI.ITEM_CD,                              -- 品目コード
                     SMI.REMARKS                               -- 摘要　（品目名）
                INTO v_ItemCd01,                               -- 品目コード
                     v_ItemRemarks01                           -- バンドル品目コード
                FROM SNV_M_ITEM SMI                            -- 品目マスタ
               WHERE SMI.PLT               = p_ORG_ID_IBI      -- 品目マスタ.プラント ※１で取得したプラント
                 AND SMI.PROD_CD           = v_BundleMachineCd -- 品目マスタ.機種コード CSVファイルのバンドル品.機種コード「BUNDLE_MACHINE_CD」
                 AND SMI.MAKR_MDL_NO       = v_BundleMakerNo   -- 品目マスタ.メーカ型番 CSVファイルのバンドル品.メーカー型番「BUNDLE_MAKER_NO」
                 AND SMI.BR_NO             = v_BundleBranchNo  -- 品目マスタ.枝番 CSVファイルのバンドル品.枝番「BUNDLE_BRANCH_NO」
                 AND NVL(SMI.DEL_FLG,'N') <> 'X';              -- 品目マスタ.削除フラグ
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                OUT_ERR_CONTENT := 'バンドル品目コード、バンドル品目名が取得できませんでした。';
                RAISE NO_CHECK_DATA;
            END;
          END IF;

        --********************************************************************
        PRAM_PLACE_HOLDER := '設置機器構成情報の登録';
        --********************************************************************
          -- 3. 登録処理
          -- 3.1. 設置機器構成情報の登録
          -- CSVから読み込んだ設置機器一括変更情報を設置機器構成情報ワークテーブルに挿入する。
          --********************************************************************
          INSERT
          INTO CSG_P_IB_CONST_WK
            (
              IB_CONST_ID,                  -- 設置機器構成ID
              INSTANCE_ID,                  -- インスタンス番号
              MAIN_OPTION_TYPE,             -- 本体オプション区分
              SERIAL_NO,                    -- シリアル番号
              SN_CHANGE_REASON,             -- シリアル番号変更理由
              ITEM_REMARKS,                 -- 品目摘要
              QUANTITY,                     -- 数量
              TRANSFER_FLAG,                -- 移管品フラグ
              TRANSFER_MAINTENANCE_FROM,    -- 保守移管元
              TRANSFER_MAINTENANCE_TO,      -- 保守移管先
              TRANSFER_MAINTENANCE_DATE,    -- 保守移管日
              TRANSFER_MAINTENANCE_REASON,  -- 保守移管理由
              CS_IN_CHARGE_CD,              -- 担当CSコード
              INCIDENT_SAVERITY_NAME,       -- 重要度
              SECONDARY_INVENTORY_NAME,     -- 委託先コード
              INSTALL_LOCATION_CODE,        -- 設置先住所ID
              INSTALL_LOCATION_DEPT_NAME,   -- 設置先部署名
              INSTALL_LOCATION_PERSON_NAME, -- 設置先担当者名
              INSTALL_LOCATION_TEL,         -- 設置先TEL
              INSTALL_LOCATION_FAX,         -- 設置先FAX
              INSTALL_DATE,                 -- 納入日
              SALES_DATE,                   -- 売上日
              SALES_OWNER_CODE,             -- 販売元
              ORDER_NO,                     -- 受注番号
              CUSTOMER_ORDER_NO,            -- 客先注文番号
              SERVICE_CONDITION,            -- サービス形態
              OUT_SOURCING_FLAG,            -- 外注フラグ
              SHIPPING_INSPECTION_FLAG,     -- 出荷検査実施フラグ
              BUNDLE_ITEM_CODE,             -- バンドル品目コード
              BUNDLE_ITEM_NAME,             -- バンドル品目名
              BUNDLE_MACHINE_CD,            -- バンドル品.機種コード
              BUNDLE_MAKER_NO,              -- バンドル品.メーカー型番
              BUNDLE_BRANCH_NO,             -- バンドル品.枝番
              BUNDLE_SERAIL_NO,             -- バンドルシリアル番号
              FIRST_COVERAGE,               -- 初回ワランティ条件
              FIRST_MONTHS,                 -- 初回ワランティ月数
              FIRST_START_DATE,             -- 初回ワランティ期間(自)
              NEXT_COVERAGE,                -- 次回ワランティ条件
              NEXT_MONTHS,                  -- 次回ワランティ月数
              HOST_ID,                      -- ホストID
              HOST_NAME,                    -- ホスト名
              KEEP_WATCH_SYSTEM_ID,         -- 監視システムID
              OS_TYPE,                      -- OS種別
              OS_VERSION,                   -- OSバージョン
              SYSTEM_NAME,                  -- システム名
              FIRMWARE_VERSION,             -- ファームウェアVer
              REVISION,                     -- リビジョン
              USE_CONDITION,                -- 利用形態
              CPU_ROM_REVISION,             -- CPU ROMリビジョン
              DISK_CAPACITY,                -- ディスク容量
              USE_PERPOSE,                  -- 利用目的
              POWER_SUPPLY_TYPE,            -- 電源設備種類
              POWER_SUPPLY_CAPACITY,        -- 電源容量
              PP_CONT_AK_NO,                -- PP契約AK番号
              USE_POWER_FREQUENCY,          -- 使用電源周波数
              USE_POWER_VOLTAGE,            -- 使用電源電圧
              PP_CONT_START_DATE,           -- 契約期間(自)
              PP_CONT_END_DATE,             -- 契約期間(至)
              MAC_ADDRESS,                  -- MACアドレス
              IP_ADDRESS,                   -- IPアドレス
              HP_CONFIG_CODE,               -- HPコンフィグコード
              HAVING_EARTH_FLAG,            -- アース有無フラグ
              SUPPORT_INSTRUCT_CODE,        -- 要サポートフラグ
              SUPPORT_START_DATE,           -- 要サポート開始日
              SUPPORT_END_DATE,             -- 要サポート終了日
              SALES_DEPT_ORG_ID,            -- F営業販売部署(部課コード)
              SALES_DEPT_PERSON_ID,         -- F営業販売担当者(Zなし社員番号)
              PRESENT_DEPT_ORG_ID,          -- F営業現在部署(部課コード)
              CTC_SALESREP_PERSON_ID,       -- F営業現在担当者(Zなし社員番号)
              MAINTE_BUS_DEPT_ORG_ID,       -- 保守営業担当部署(部課コード)
              MAINTE_BUS_PERSON_ID,         -- 保守営業担当者(Zなし社員番号)
              CE_CODE,                      -- 保守担当CE
              MAINTENANCE_TYPE,             -- 保守種別
              IMPORTANT_ITEM_FLAG,          -- 重要案件
              AGENT_FLAG,                   -- 販社フラグ
              FIRST_SALE_DEPT_NAME,         -- 初期販売部署名
              FIRST_SALE_PERSON_NAME,       -- 初期販売担当者名
              FIRST_SALE_PARTY_LOCATION,    -- 初期販売住所コード
              FIRST_SALE_TEL,               -- 初期販売TEL
              FIRST_SALE_FAX,               -- 初期販売FAX
              FIRST_SALE_MAIL_ADDRESS,      -- 初期販売メールアドレス
              ENDUSER_PARTY_CODE,           -- エンドユーザ会社コード
              ENDUSER_LOCATION,             -- エンドユーザ住所
              ENDUSER_CHRG_DEPT_NAME,       -- エンドユーザ部署
              ENDUSER_TEL,                  -- エンドユーザTEL
              ENDUSER_FAX,                  -- エンドユーザFAX
              ENDUSER_CHRG_PERSON_NAME,     -- エンドユーザ担当者
              ENDUSER_MAIL_ADDRESS,         -- エンドユーザメールアドレス
              LICENSE_MANAGEMENT_NO,        -- ライセンス管理番号
              LISENCE_START_DATE,           -- ライセンス開始日
              LISENCE_END_DATE,             -- ライセンス終了日
              SUPERINTENDE_MANAGE_NO,       -- 主管部管理番号
              REMOVE_DATE,                  -- ソフトウェア移設日
              REMOVE_ORDER_NO,              -- ソフトウェア移設受注番号
              REMOVE_PO_NO,                 -- ソフトウェア移設先発注番号
              REMOVE_REASON,                -- ソフトウェア移設理由
              ASSIGN_FLAG,                  -- 紐付済フラグ
              PROGRAM_ID,                   -- 更新プログラムID
              PROCESS_ID,                   -- 処理ID
              CREATION_USER_ID,             -- 作成者
              CREATION_DATE,                -- 作成日時
              UPDATE_USER_ID,               -- 更新者
              UPDATE_DATE                   -- 更新日時
            )
            VALUES
            (
              CSG_W_IB_CONST_ID_SEQ.NEXTVAL,     -- Oracleシーケンス（SEQUENCE）
              p_INSTANCE_ID,               -- インスタンス番号
              v_MainOptionType,            -- 本体オプション区分
              v_SerialNo,                  -- シリアル番号
              v_SnChangeReason,            -- シリアル番号変更理由
              v_ItemRemarks,               -- 品目摘要
              v_Quantity,                  -- 数量
              v_TransferFlag,              -- 移管品フラグ
              v_TransferMaintenanceFrom,   -- 保守移管元
              v_TransferMaintenanceTo,     -- 保守移管先
              v_TransferMaintenanceDate,   -- 保守移管日
              v_TransferMaintenanceReason, -- 保守移管理由
              v_CsInChargeCd,              -- 担当CSコード
              v_IncidentSaverityName,      -- 重要度
              v_SecondaryInventoryName,    -- 委託先コード
              v_InstallLocationCode,       -- 設置先住所ID
              v_InstallLocationDeptName,   -- 設置先部署名
              v_InstallLocationPersonName, -- 設置先担当者名
              v_InstallLocationTel,        -- 設置先TEL
              v_InstallLocationFax,        -- 設置先FAX
              v_InstallDate,               -- 納入日
              v_SalesDate,                 -- 売上日
              v_SalesOwnerCode,            -- 販売元
              v_OrderNo,                   -- 受注番号
              v_CustomerOrderNo,           -- 客先注文番号
              v_ServiceCondition,          -- サービス形態
              v_OutSourcingFlag,           -- 外注フラグ
              v_ShippingInspectionFlag,    -- 出荷検査実施フラグ
              v_ItemCd01,                  -- バンドル品目コード（品目マスタから取得 ※1参照）
              v_ItemRemarks01,             -- バンドル品目名（品目マスタから取得 ※1参照）
              v_BundleMachineCd,           -- バンドル品.機種コード
              v_BundleMakerNo,             -- バンドル品.メーカー型番
              v_BundleBranchNo,            -- バンドル品.枝番
              v_BundleSerailNo,            -- バンドルシリアル番号
              v_FirstCoverage,             -- 初回ワランティ条件
              v_FirstMonths,               -- 初回ワランティ月数
              v_FirstStartDate,            -- 初回ワランティ期間(自)
              v_NextCoverage,              -- 次回ワランティ条件
              v_NextMonths,                -- 次回ワランティ月数
              v_HostId,                    -- ホストID
              v_HostName,                  -- ホスト名
              v_KeepWatchSystemId,         -- 監視システムID
              v_OsType,                    -- OS種別
              v_OsVersion,                 -- OSバージョン
              v_SystemName,                -- システム名
              v_FirmwareVersion,           -- ファームウェアVer
              v_Revision,                  -- リビジョン
              v_UseCondition,              -- 利用形態
              v_CpuRomRevision,            -- CPU ROMリビジョン
              v_DiskCapacity,              -- ディスク容量
              v_UsePerpose,                -- 利用目的
              v_PowerSupplyType,           -- 電源設備種類
              v_PowerSupplyCapacity,       -- 電源容量
              v_PpContAkNo,                -- PP契約AK番号
              v_UsePowerFrequency,         -- 使用電源周波数
              v_UsePowerVoltage,           -- 使用電源電圧
              v_PpContStartDate,           -- 契約期間(自)
              v_PpContEndDate,             -- 契約期間(至)
              v_MacAddress,                -- MACアドレス
              v_IpAddress,                 -- IPアドレス
              v_HpConfigCode,              -- HPコンフィグコード
              v_HavingEarthFlag,           -- アース有無フラグ
              v_SupportInstructCode,       -- 要サポートフラグ
              v_SupportStartDate,          -- 要サポート開始日
              v_SupportEndDate,            -- 要サポート終了日
              v_SalesDeptOrgId,            -- F営業販売部署(部課コード)
              v_SalesDeptPersonId,         -- F営業販売担当者(Zなし社員番号)
              v_PresentDeptOrgId,          -- F営業現在部署(部課コード)
              v_CtcSalesrepPersonId,       -- F営業現在担当者(Zなし社員番号)
              v_MainteBusDeptOrgId,        -- 保守営業担当部署(部課コード)
              v_MainteBusPersonId,         -- 保守営業担当者(Zなし社員番号)
              v_CeCode,                    -- 保守担当CE
              v_MaintenanceType,           -- 保守種別
              v_ImportantItemFlag,         -- 重要案件
              v_AgentFlag,                 -- 販社フラグ
              v_FirstSaleDeptName,         -- 初期販売部署名
              v_FirstSalePersonName,       -- 初期販売担当者名
              v_FirstSalePartyLocation,    -- 初期販売住所コード
              v_FirstSaleTel,              -- 初期販売TEL
              v_FirstSaleFax,              -- 初期販売FAX
              v_FirstSaleMailAddress,      -- 初期販売メールアドレス
              v_EnduserPartyCode,          -- エンドユーザ会社コード
              v_EnduserLocation,           -- エンドユーザ住所
              v_EnduserChrgDeptName,       -- エンドユーザ部署
              v_EnduserTel,                -- エンドユーザTEL
              v_EnduserFax,                -- エンドユーザFAX
              v_EnduserChrgPersonName,     -- エンドユーザ担当者
              v_EnduserMailAddress,        -- エンドユーザメールアドレス
              v_LicenseManagementNo,       -- ライセンス管理番号
              v_LisenceStartDate,          -- ライセンス開始日
              v_LisenceEndDate,            -- ライセンス終了日
              v_SuperintendeManageNo,      -- 主管部管理番号
              v_RemoveDate,                -- ソフトウェア移設日
              v_RemoveOrderNo,             -- ソフトウェア移設受注番号
              v_RemovePoNo,                -- ソフトウェア移設先発注番号
              v_RemoveReason,              -- ソフトウェア移設理由
              '0',                         -- 紐付済フラグ：'０’（固定）
              'CSG02-0205',                -- CSG02-0015
              INPUT_PROCESS_ID,            -- 
              INPUT_USER_ID,               -- ログインユーザID
              set_sysdate,                 -- SYSDATE
              INPUT_USER_ID,               -- ログインユーザID
              set_sysdate                  -- SYSDATE
            );

          EXCEPTION
            WHEN NO_CHECK_DATA THEN
              OUT_RESULT_CD   := '10';
              OUT_STATUS      := '2'; -- 2:警告終了
              OUT_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(g_target_sel_cnt) || '行目： ' || OUT_ERR_CONTENT;--TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
              DBMS_OUTPUT.PUT_LINE(OUT_ERR_DETAIL);
              ROLLBACK;
              RETURN;
            WHEN NO_DATA_FOUND THEN
              EXIT;
            WHEN OTHERS THEN
              OUT_RESULT_CD   := '20';
              OUT_STATUS      := '3'; -- 3:エラー
              OUT_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
              OUT_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
              ROLLBACK;
              RETURN;
          END;
      END LOOP;
    END IF;
    UTL_FILE.FCLOSE(F);
  --****************************************************************************
  -- コミットの実行
  --****************************************************************************
    COMMIT;

  --****************************************************************************
  -- 4.処理対象データの取得
  -- 4.1.更新情報の取得
  -- 以下の条件に合致するデータを設置機器構成情報ワークより取得する。
  --****************************************************************************
    PRAM_PLACE_HOLDER   := 'データの取得';

  <<CUR_IB_CONST_WK_LOOP>>
    FOR row_IB_CONST_WK IN CUR_IB_CONST_WK
      LOOP
        BEGIN
          p_ASSIGN_FLAG             := '1';                        -- 紐付済フラグ

        --**********************************************************************
        -- 5.2.未存在チェック
        -- 処理4.1で取得した「設置機器情報テーブルのインスタンス番号」がNULLの場合
        -- ・処理結果の警告件数としてカウントアップ（保持）する。
        -- ・中間ワークの紐付済フラグを「2:エラー」に更新し、次のレコードの処理に遷移する。（「5.7.中間ワーク更新」に遷移）
        --**********************************************************************
          --IF row_IB_CONST_WK.INSTANCE_ID IS NULL THEN
          IF row_IB_CONST_WK.INSTANCE_ID_IBI IS NULL THEN
              p_INSTANCE_ID     := row_IB_CONST_WK.INSTANCE_ID;         -- インスタンス番号
              v_Content             := '「更新対象のインスタンスが存在しません」';
              OUT_ERR_DETAIL  := '更新できなかったレコードが存在します。 インスタンス番号：' 
                              || p_INSTANCE_ID || '  エラー内容:' ||  v_Content;
              DBMS_OUTPUT.PUT_LINE(OUT_ERR_DETAIL);
              g_warnings_sel_cnt          := g_warnings_sel_cnt + 1;
              p_ASSIGN_FLAG               := '2';                    -- 紐付済フラグ "1" (紐付済)　／　"2"(エラー)
          ELSE
          --********************************************************************
          -- 5.3.設置機器情報の設定
          -- 対象データを設置機器情報に設定する。
          -- ※以下の内容は、設置機器・共通テーブル追加更新APIのパラメータ「設置機器情報」として、設定する。
          -- （NULL項目は追加・更新APIに渡す項目として、不要な項目とする。）
          --********************************************************************
            PRAM_PLACE_HOLDER   := '設置機器情報の設定';

              -- ※１ 初回期間(至)
              -- 初回ワランティ期間(自)と初回ワランティ月数に値が設定されている場合
              -- ・初回期間(至)＝初回ワランティ期間(自)＋初回ワランティ月数を自動計算して設定
              IF REPLACE(row_IB_CONST_WK.FIRST_START_DATE, 'XXXX', NULL) IS NOT NULL AND 
                 REPLACE(row_IB_CONST_WK.FIRST_MONTHS, 'XXXX', NULL) IS NOT NULL THEN
                  p_FIRST_END_DATE_IBI := TO_DATE(ADD_MONTHS(TO_DATE(row_IB_CONST_WK.FIRST_START_DATE, 'YYYY/MM/DD'), TO_NUMBER(row_IB_CONST_WK.FIRST_MONTHS)), 'YYYY/MM/DD');
              END IF;

              -- ※2 次回期間(自)／次回期間(至)
              -- 初回ワランティ期間(至)と次回ワランティ月数に値が設定されている場合
              -- ・次回期間(自)＝初回ワランティ期間(至)＋1日を自動計算して設定
              -- ・次回期間(至)＝次回ワランティ期間(自)＋次回ワランティ月数を自動計算して設定
              IF REPLACE(row_IB_CONST_WK.FIRST_START_DATE, 'XXXX', NULL) IS NOT NULL AND 
                 REPLACE(row_IB_CONST_WK.NEXT_MONTHS, 'XXXX', NULL) IS NOT NULL THEN
                  p_NEXT_START_DATE_IBI := TO_DATE(row_IB_CONST_WK.FIRST_START_DATE, 'YYYY/MM/DD') + 1;
                  p_NEXT_END_DATE_IBI   := TO_DATE(ADD_MONTHS(p_NEXT_START_DATE_IBI, TO_NUMBER(row_IB_CONST_WK.NEXT_MONTHS)), 'YYYY/MM/DD');
              END IF;

              tIB_BASE := NEW ARRAY_IB_BASE( 
--                      NEW CONTACT_IB_BASE_OBJ('INSTANCE_ID', row_IB_CONST_WK.INSTANCE_ID),                                -- [4.1.]で取得したINSTANCE_ID
                          NEW CONTACT_IB_BASE_OBJ('PARENT_INSTANCE_ID', row_IB_CONST_WK.PARENT_INSTANCE_ID),                  -- [4.1.]で取得したPARENT_INSTANCE_ID
                          NEW CONTACT_IB_BASE_OBJ('TOP_INSTANCE_ID', row_IB_CONST_WK.TOP_INSTANCE_ID),                        -- [4.1.]で取得したTOP_INSTANCE_ID
--                      NEW CONTACT_IB_BASE_OBJ('INVENTORY_ITEM_CODE', NULL),                                               -- NULL
--                      NEW CONTACT_IB_BASE_OBJ('ORG_ID', NULL),                                                            -- NULL
                      NEW CONTACT_IB_BASE_OBJ('INVENTORY_ITEM_CODE', p_INVENTORY_ITEM_CODE_IBI),                                               -- (※渡さないと品目マスタチェックでエラーになる)
                      NEW CONTACT_IB_BASE_OBJ('ORG_ID', p_ORG_ID_IBI),                                                      -- (※渡さないと品目マスタチェックでエラーになる)
                          NEW CONTACT_IB_BASE_OBJ('IB_SYNC_STATUS', '10009'),                                                 -- Normalのコード「10009」を設定
--                      NEW CONTACT_IB_BASE_OBJ('MAKER_ORDER_NO', NULL),                                                    -- NULL
--                      NEW CONTACT_IB_BASE_OBJ('FIRST_SALE_PARTY_CODE', NULL),                                             -- NULL
--                      NEW CONTACT_IB_BASE_OBJ('X_DEPLOY_FLAG', NULL),                                                     -- NULL
--                      NEW CONTACT_IB_BASE_OBJ('ACCEPTANCE_DATE', NULL),                                                   -- NULL
                          NEW CONTACT_IB_BASE_OBJ('OUT_WARRANTY_REGISTERED_FLAG', '3')                                        -- ’3’(対象外)を固定
                      );

              ----[NotNull項目]
              -- [4.1.]で取得したITEM_REMARKS
              --NEW CONTACT_IB_BASE_OBJ('INVENTORY_ITEM_NAME', row_IB_CONST_WK.ITEM_REMARKS),
              IF row_IB_CONST_WK.ITEM_REMARKS IS NOT NULL THEN
                  tIB_BASE.EXTEND;
                  tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('INVENTORY_ITEM_NAME', row_IB_CONST_WK.ITEM_REMARKS); 
              END IF;
              -- [4.1.]で取得したMAIN_OPTION_TYPE
              --NEW CONTACT_IB_BASE_OBJ('MAIN_OPTION_TYPE', row_IB_CONST_WK.MAIN_OPTION_TYPE),
              IF row_IB_CONST_WK.MAIN_OPTION_TYPE IS NOT NULL THEN
                  tIB_BASE.EXTEND;
                  tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('MAIN_OPTION_TYPE', row_IB_CONST_WK.MAIN_OPTION_TYPE); 
              END IF;
              -- [4.1.]で取得したQUANTITY
              --NEW CONTACT_IB_BASE_OBJ('QUANTITY', row_IB_CONST_WK.QUANTITY),
              IF row_IB_CONST_WK.QUANTITY IS NOT NULL THEN
                  tIB_BASE.EXTEND;
                  tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('QUANTITY', row_IB_CONST_WK.QUANTITY); 
              END IF;
              -- [4.1.]で取得したINSTALL_DATE
              --NEW CONTACT_IB_BASE_OBJ('INSTALL_DATE', row_IB_CONST_WK.INSTALL_DATE),
              IF row_IB_CONST_WK.INSTALL_DATE IS NOT NULL THEN
                  tIB_BASE.EXTEND;
                  tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('INSTALL_DATE', row_IB_CONST_WK.INSTALL_DATE);
              END IF;
              -- [4.1.]で取得したSALES_OWNER_CODE
              --NEW CONTACT_IB_BASE_OBJ('SALES_OWNER_CODE', row_IB_CONST_WK.SALES_OWNER_CODE),
              IF row_IB_CONST_WK.SALES_OWNER_CODE IS NOT NULL THEN
                  tIB_BASE.EXTEND;
                  tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('SALES_OWNER_CODE', row_IB_CONST_WK.SALES_OWNER_CODE);
              END IF;
              -- [4.1.]で取得したMAINTENANCE_TYPE
              --NEW CONTACT_IB_BASE_OBJ('MAINTENANCE_TYPE', row_IB_CONST_WK.MAINTENANCE_TYPE),
              IF row_IB_CONST_WK.MAINTENANCE_TYPE IS NOT NULL THEN
                  tIB_BASE.EXTEND;
                  tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('MAINTENANCE_TYPE', row_IB_CONST_WK.MAINTENANCE_TYPE);
              END IF;
              -- [4.1.]で取得したAGENT_FLAG
              --NEW CONTACT_IB_BASE_OBJ('AGENT_FLAG', row_IB_CONST_WK.AGENT_FLAG),
              IF row_IB_CONST_WK.AGENT_FLAG IS NOT NULL THEN
                  tIB_BASE.EXTEND;
                  tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('AGENT_FLAG', row_IB_CONST_WK.AGENT_FLAG);
              END IF;

              -- ※１　参照
              --NEW CONTACT_IB_BASE_OBJ('FIRST_END_DATE', p_FIRST_END_DATE_IBI),
              IF REPLACE(row_IB_CONST_WK.FIRST_START_DATE, 'XXXX', NULL) IS NOT NULL AND 
                 REPLACE(row_IB_CONST_WK.FIRST_MONTHS, 'XXXX', NULL) IS NOT NULL THEN
                  tIB_BASE.EXTEND;
                  tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('FIRST_END_DATE', p_FIRST_END_DATE_IBI); 
              END IF;
              -- ※2　参照
              --NEW CONTACT_IB_BASE_OBJ('NEXT_START_DATE', p_NEXT_START_DATE_IBI),
              IF REPLACE(row_IB_CONST_WK.FIRST_START_DATE, 'XXXX', NULL) IS NOT NULL AND 
                 REPLACE(row_IB_CONST_WK.NEXT_MONTHS, 'XXXX', NULL) IS NOT NULL THEN
                  tIB_BASE.EXTEND;
                  tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('NEXT_START_DATE', p_NEXT_START_DATE_IBI); 
                  tIB_BASE.EXTEND;
                  tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('NEXT_END_DATE', p_NEXT_END_DATE_IBI); 
              END IF;

              -- [4.1.]で取得したSERIAL_NO
              --NEW CONTACT_IB_BASE_OBJ('SERIAL_NO', row_IB_CONST_WK.SERIAL_NO),
              IF row_IB_CONST_WK.SERIAL_NO IS NOT NULL THEN
                  IF row_IB_CONST_WK.SERIAL_NO = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('SERIAL_NO', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('SERIAL_NO', row_IB_CONST_WK.SERIAL_NO); 
                  END IF;
              END IF;

              -- [4.1.]で取得したSALES_DATE
              --NEW CONTACT_IB_BASE_OBJ('SALES_DATE', row_IB_CONST_WK.SALES_DATE),
              IF row_IB_CONST_WK.SALES_DATE IS NOT NULL THEN
                  IF row_IB_CONST_WK.SALES_DATE = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('SALES_DATE', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('SALES_DATE', row_IB_CONST_WK.SALES_DATE); 
                  END IF;
              END IF;
              -- [4.1.]で取得したCUSTOMER_ORDER_NO
              --NEW CONTACT_IB_BASE_OBJ('CUSTOMER_ORDER_NO', row_IB_CONST_WK.CUSTOMER_ORDER_NO),
              IF row_IB_CONST_WK.CUSTOMER_ORDER_NO IS NOT NULL THEN
                  IF row_IB_CONST_WK.CUSTOMER_ORDER_NO = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('CUSTOMER_ORDER_NO', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('CUSTOMER_ORDER_NO', row_IB_CONST_WK.CUSTOMER_ORDER_NO);
                  END IF;
              END IF;
              -- [4.1.]で取得したORDER_NO
              --NEW CONTACT_IB_BASE_OBJ('ORDER_NO', row_IB_CONST_WK.ORDER_NO),
              IF row_IB_CONST_WK.ORDER_NO IS NOT NULL THEN
                  IF row_IB_CONST_WK.ORDER_NO = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('ORDER_NO', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('ORDER_NO', row_IB_CONST_WK.ORDER_NO);
                  END IF;
              END IF;
              -- [4.1.]で取得したTRANSFER_FLAG
              --NEW CONTACT_IB_BASE_OBJ('TRANSFER_FLAG', row_IB_CONST_WK.TRANSFER_FLAG),
              IF row_IB_CONST_WK.TRANSFER_FLAG IS NOT NULL THEN
                  IF row_IB_CONST_WK.TRANSFER_FLAG = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('TRANSFER_FLAG', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('TRANSFER_FLAG', row_IB_CONST_WK.TRANSFER_FLAG);
                  END IF;
              END IF;
              -- [4.1.]で取得したTRANSFER_MAINTENANCE_FROM
              --NEW CONTACT_IB_BASE_OBJ('TRANSFER_MAINTENANCE_FROM', row_IB_CONST_WK.TRANSFER_MAINTENANCE_FROM),
              IF row_IB_CONST_WK.TRANSFER_MAINTENANCE_FROM IS NOT NULL THEN
                  IF row_IB_CONST_WK.TRANSFER_MAINTENANCE_FROM = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('TRANSFER_MAINTENANCE_FROM', NULL);
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('TRANSFER_MAINTENANCE_FROM', row_IB_CONST_WK.TRANSFER_MAINTENANCE_FROM);
                  END IF;
              END IF;
              -- [4.1.]で取得したTRANSFER_MAINTENANCE_TO
              --NEW CONTACT_IB_BASE_OBJ('TRANSFER_MAINTENANCE_TO', row_IB_CONST_WK.TRANSFER_MAINTENANCE_TO),
              IF row_IB_CONST_WK.TRANSFER_MAINTENANCE_TO IS NOT NULL THEN
                  IF row_IB_CONST_WK.TRANSFER_MAINTENANCE_TO = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('TRANSFER_MAINTENANCE_TO', NULL);
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('TRANSFER_MAINTENANCE_TO', row_IB_CONST_WK.TRANSFER_MAINTENANCE_TO);
                  END IF;
              END IF;
              -- [4.1.]で取得したTRANSFER_MAINTENANCE_DATE
              --NEW CONTACT_IB_BASE_OBJ('TRANSFER_MAINTENANCE_DATE', row_IB_CONST_WK.TRANSFER_MAINTENANCE_DATE),
              IF row_IB_CONST_WK.TRANSFER_MAINTENANCE_DATE IS NOT NULL THEN
                  IF row_IB_CONST_WK.TRANSFER_MAINTENANCE_DATE = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('TRANSFER_MAINTENANCE_DATE', NULL);
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('TRANSFER_MAINTENANCE_DATE', row_IB_CONST_WK.TRANSFER_MAINTENANCE_DATE);
                  END IF;
              END IF;
              -- [4.1.]で取得したTRANSFER_MAINTENANCE_REASON
              --NEW CONTACT_IB_BASE_OBJ('TRANSFER_MAINTNANCE_REASON', row_IB_CONST_WK.TRANSFER_MAINTENANCE_REASON),
              IF row_IB_CONST_WK.TRANSFER_MAINTENANCE_REASON IS NOT NULL THEN
                  IF row_IB_CONST_WK.TRANSFER_MAINTENANCE_REASON = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('TRANSFER_MAINTNANCE_REASON', NULL);
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('TRANSFER_MAINTNANCE_REASON', row_IB_CONST_WK.TRANSFER_MAINTENANCE_REASON);
                  END IF;
              END IF;
              -- [4.1.]で取得したIMPORTANT_ITEM_FLAG
              --NEW CONTACT_IB_BASE_OBJ('IMPORTANT_ITEM_FLAG', row_IB_CONST_WK.IMPORTANT_ITEM_FLAG),
              IF row_IB_CONST_WK.IMPORTANT_ITEM_FLAG IS NOT NULL THEN
                  IF row_IB_CONST_WK.IMPORTANT_ITEM_FLAG = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('IMPORTANT_ITEM_FLAG', NULL);
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('IMPORTANT_ITEM_FLAG', row_IB_CONST_WK.IMPORTANT_ITEM_FLAG);
                  END IF;
              END IF;
              -- [4.1.]で取得したSERVICE_CONDITION
              --NEW CONTACT_IB_BASE_OBJ('SERVICE_CONDITION', row_IB_CONST_WK.SERVICE_CONDITION),
              IF row_IB_CONST_WK.SERVICE_CONDITION IS NOT NULL THEN
                  IF row_IB_CONST_WK.SERVICE_CONDITION = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('SERVICE_CONDITION', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('SERVICE_CONDITION', row_IB_CONST_WK.SERVICE_CONDITION);
                  END IF;
              END IF;
              -- [4.1.]で取得したOUT_SOURCING_FLAG
              --NEW CONTACT_IB_BASE_OBJ('OUT_SOURCING_FLAG', row_IB_CONST_WK.OUT_SOURCING_FLAG),
              IF row_IB_CONST_WK.OUT_SOURCING_FLAG IS NOT NULL THEN
                  IF row_IB_CONST_WK.OUT_SOURCING_FLAG = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('OUT_SOURCING_FLAG', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('OUT_SOURCING_FLAG', row_IB_CONST_WK.OUT_SOURCING_FLAG);
                  END IF;
              END IF;
              -- [4.1.]で取得したSHIPPING_INSPECTION_FLAG
              --NEW CONTACT_IB_BASE_OBJ('SHIPPING_INSPECTION_FLAG', row_IB_CONST_WK.SHIPPING_INSPECTION_FLAG),
              IF row_IB_CONST_WK.SHIPPING_INSPECTION_FLAG IS NOT NULL THEN
                  IF row_IB_CONST_WK.SHIPPING_INSPECTION_FLAG = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('SHIPPING_INSPECTION_FLAG', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('SHIPPING_INSPECTION_FLAG', row_IB_CONST_WK.SHIPPING_INSPECTION_FLAG);
                  END IF;
              END IF;
              -- [4.1.]で取得したHOST_NAME
              --NEW CONTACT_IB_BASE_OBJ('HOST_NAME', row_IB_CONST_WK.HOST_NAME),
              IF row_IB_CONST_WK.HOST_NAME IS NOT NULL THEN
                  IF row_IB_CONST_WK.HOST_NAME = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('HOST_NAME', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('HOST_NAME', row_IB_CONST_WK.HOST_NAME);
                  END IF;
              END IF;
              -- [4.1.]で取得したSYSTEM_NAME
              --NEW CONTACT_IB_BASE_OBJ('SYSTEM_NAME', row_IB_CONST_WK.SYSTEM_NAME),
              IF row_IB_CONST_WK.SYSTEM_NAME IS NOT NULL THEN
                  IF row_IB_CONST_WK.SYSTEM_NAME = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('SYSTEM_NAME', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('SYSTEM_NAME', row_IB_CONST_WK.SYSTEM_NAME);
                  END IF;
              END IF;
              -- [4.1.]で取得したSUPPORT_START_DATE
              --NEW CONTACT_IB_BASE_OBJ('SUPPORT_START_DATE', row_IB_CONST_WK.SUPPORT_START_DATE),
              IF row_IB_CONST_WK.SUPPORT_START_DATE IS NOT NULL THEN
                  IF row_IB_CONST_WK.SUPPORT_START_DATE = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('SUPPORT_START_DATE', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('SUPPORT_START_DATE', row_IB_CONST_WK.SUPPORT_START_DATE);
                  END IF;
              END IF;
              -- [4.1.]で取得したSUPPORT_END_DATE
              --NEW CONTACT_IB_BASE_OBJ('SUPPORT_END_DATE', row_IB_CONST_WK.SUPPORT_END_DATE),
              IF row_IB_CONST_WK.SUPPORT_END_DATE IS NOT NULL THEN
                  IF row_IB_CONST_WK.SUPPORT_END_DATE = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('SUPPORT_END_DATE', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('SUPPORT_END_DATE', row_IB_CONST_WK.SUPPORT_END_DATE);
                  END IF;
              END IF;
              -- [4.1.]で取得したSUPPORT_INSTRUCT_CODE
              --NEW CONTACT_IB_BASE_OBJ('SUPPORT_INSTRUCT_CODE', row_IB_CONST_WK.SUPPORT_INSTRUCT_CODE),
              IF row_IB_CONST_WK.SUPPORT_INSTRUCT_CODE IS NOT NULL THEN
                  IF row_IB_CONST_WK.SUPPORT_INSTRUCT_CODE = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('SUPPORT_INSTRUCT_CODE', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('SUPPORT_INSTRUCT_CODE', row_IB_CONST_WK.SUPPORT_INSTRUCT_CODE);
                  END IF;
              END IF;
              -- [4.1.]で取得したFIRST_SALE_PARTY_LOCATION
              --NEW CONTACT_IB_BASE_OBJ('FIRST_SALE_PARTY_LOCATION', row_IB_CONST_WK.FIRST_SALE_PARTY_LOCATION),
              IF row_IB_CONST_WK.FIRST_SALE_PARTY_LOCATION IS NOT NULL THEN
                  IF row_IB_CONST_WK.FIRST_SALE_PARTY_LOCATION = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('FIRST_SALE_PARTY_LOCATION', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('FIRST_SALE_PARTY_LOCATION', row_IB_CONST_WK.FIRST_SALE_PARTY_LOCATION);
                  END IF;
              END IF;
              -- [4.1.]で取得したAGENT_FLAG
              --NEW CONTACT_IB_BASE_OBJ('AGENT_FLAG', row_IB_CONST_WK.AGENT_FLAG),
              --IF row_IB_CONST_WK.AGENT_FLAG IS NOT NULL THEN
              --    IF row_IB_CONST_WK.AGENT_FLAG = 'XXXX' THEN
              --        tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('AGENT_FLAG', NULL); 
              --    ELSE
              --        tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('AGENT_FLAG', row_IB_CONST_WK.AGENT_FLAG);
              --    END IF;
              --END IF;
              -- [4.1.]で取得したFIRST_SALE_DEPT_NAME
              --NEW CONTACT_IB_BASE_OBJ('FIRST_SALE_DEPT_NAME', row_IB_CONST_WK.FIRST_SALE_DEPT_NAME),
              IF row_IB_CONST_WK.FIRST_SALE_DEPT_NAME IS NOT NULL THEN
                  IF row_IB_CONST_WK.FIRST_SALE_DEPT_NAME = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('FIRST_SALE_DEPT_NAME', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('FIRST_SALE_DEPT_NAME', row_IB_CONST_WK.FIRST_SALE_DEPT_NAME);
                  END IF;
              END IF;
              -- [4.1.]で取得したFIRST_SALE_TEL
              --NEW CONTACT_IB_BASE_OBJ('FIRST_SALE_TEL', row_IB_CONST_WK.FIRST_SALE_TEL),
              IF row_IB_CONST_WK.FIRST_SALE_TEL IS NOT NULL THEN
                  IF row_IB_CONST_WK.FIRST_SALE_TEL = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('FIRST_SALE_TEL', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('FIRST_SALE_TEL', row_IB_CONST_WK.FIRST_SALE_TEL);
                  END IF;
              END IF;
              -- [4.1.]で取得したFIRST_SALE_FAX
              --NEW CONTACT_IB_BASE_OBJ('FIRST_SALE_FAX', row_IB_CONST_WK.FIRST_SALE_FAX),
              IF row_IB_CONST_WK.FIRST_SALE_FAX IS NOT NULL THEN
                  IF row_IB_CONST_WK.FIRST_SALE_FAX = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('FIRST_SALE_FAX', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('FIRST_SALE_FAX', row_IB_CONST_WK.FIRST_SALE_FAX);
                  END IF;
              END IF;
              -- [4.1.]で取得したFIRST_SALE_PERSON_NAME
              --NEW CONTACT_IB_BASE_OBJ('FIRST_SALE_PERSON_NAME', row_IB_CONST_WK.FIRST_SALE_PERSON_NAME),
              IF row_IB_CONST_WK.FIRST_SALE_PERSON_NAME IS NOT NULL THEN
                  IF row_IB_CONST_WK.FIRST_SALE_PERSON_NAME = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('FIRST_SALE_PERSON_NAME', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('FIRST_SALE_PERSON_NAME', row_IB_CONST_WK.FIRST_SALE_PERSON_NAME);
                  END IF;
              END IF;
              -- [4.1.]で取得したFIRST_SALE_MAIL_ADDRESS
              --NEW CONTACT_IB_BASE_OBJ('FIRST_SALE_MAIL_ADDRESS', row_IB_CONST_WK.FIRST_SALE_MAIL_ADDRESS),
              IF row_IB_CONST_WK.FIRST_SALE_MAIL_ADDRESS IS NOT NULL THEN
                  IF row_IB_CONST_WK.FIRST_SALE_MAIL_ADDRESS = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('FIRST_SALE_MAIL_ADDRESS', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('FIRST_SALE_MAIL_ADDRESS', row_IB_CONST_WK.FIRST_SALE_MAIL_ADDRESS);
                  END IF;
              END IF;
              -- [4.1.]で取得したFIRST_COVERAGE
              --NEW CONTACT_IB_BASE_OBJ('FIRST_COVERAGE', row_IB_CONST_WK.FIRST_COVERAGE),
              IF row_IB_CONST_WK.FIRST_COVERAGE IS NOT NULL THEN
                  IF row_IB_CONST_WK.FIRST_COVERAGE = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('FIRST_COVERAGE', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('FIRST_COVERAGE', row_IB_CONST_WK.FIRST_COVERAGE);
                  END IF;
              END IF;
              -- [4.1.]で取得したFIRST_MONTHS
              --NEW CONTACT_IB_BASE_OBJ('FIRST_MONTHS', row_IB_CONST_WK.FIRST_MONTHS),
              IF row_IB_CONST_WK.FIRST_MONTHS IS NOT NULL THEN
                  IF row_IB_CONST_WK.FIRST_MONTHS = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('FIRST_MONTHS', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('FIRST_MONTHS', row_IB_CONST_WK.FIRST_MONTHS);
                  END IF;
              END IF;
              -- [4.1.]で取得したFIRST_START_DATE
              --NEW CONTACT_IB_BASE_OBJ('FIRST_START_DATE', row_IB_CONST_WK.FIRST_START_DATE),
              IF row_IB_CONST_WK.FIRST_START_DATE IS NOT NULL THEN
                  IF row_IB_CONST_WK.FIRST_START_DATE = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('FIRST_START_DATE', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('FIRST_START_DATE', row_IB_CONST_WK.FIRST_START_DATE);
                  END IF;
              END IF;
              -- [4.1.]で取得したNEXT_COVERAGE
              --NEW CONTACT_IB_BASE_OBJ('NEXT_COVERAGE', row_IB_CONST_WK.NEXT_COVERAGE),
              IF row_IB_CONST_WK.NEXT_COVERAGE IS NOT NULL THEN
                  IF row_IB_CONST_WK.NEXT_COVERAGE = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('NEXT_COVERAGE', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('NEXT_COVERAGE', row_IB_CONST_WK.NEXT_COVERAGE);
                  END IF;
              END IF;
              -- [4.1.]で取得したNEXT_MONTHS
              --NEW CONTACT_IB_BASE_OBJ('NEXT_MONTHS', row_IB_CONST_WK.NEXT_MONTHS),
              IF row_IB_CONST_WK.NEXT_MONTHS IS NOT NULL THEN
                  IF row_IB_CONST_WK.NEXT_MONTHS = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('NEXT_MONTHS', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('NEXT_MONTHS', row_IB_CONST_WK.NEXT_MONTHS);
                  END IF;
              END IF;
              -- [4.1.]で取得したSECONDARY_INVENTORY_NAME
              --NEW CONTACT_IB_BASE_OBJ('SECONDARY_INVENTORY_CODE', row_IB_CONST_WK.SECONDARY_INVENTORY_NAME),
              IF row_IB_CONST_WK.SECONDARY_INVENTORY_NAME IS NOT NULL THEN
                  IF row_IB_CONST_WK.SECONDARY_INVENTORY_NAME = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('SECONDARY_INVENTORY_CODE', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('SECONDARY_INVENTORY_CODE', row_IB_CONST_WK.SECONDARY_INVENTORY_NAME);
                  END IF;
              END IF;
              -- [4.1.]で取得したBUNDLE_ITEM_CODE
              --NEW CONTACT_IB_BASE_OBJ('BUNDLE_ITEM_CODE', row_IB_CONST_WK.BUNDLE_ITEM_CODE),
              IF row_IB_CONST_WK.BUNDLE_ITEM_CODE IS NOT NULL THEN
                  IF row_IB_CONST_WK.BUNDLE_ITEM_CODE = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('BUNDLE_ITEM_CODE', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('BUNDLE_ITEM_CODE', row_IB_CONST_WK.BUNDLE_ITEM_CODE);
                  END IF;
              END IF;
              -- [4.1.]で取得したBUNDLE_ITEM_NAME
              --NEW CONTACT_IB_BASE_OBJ('BUNDLE_ITEM_NAME', row_IB_CONST_WK.BUNDLE_ITEM_NAME),
              IF row_IB_CONST_WK.BUNDLE_ITEM_NAME IS NOT NULL THEN
                  IF row_IB_CONST_WK.BUNDLE_ITEM_NAME = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('BUNDLE_ITEM_NAME', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('BUNDLE_ITEM_NAME', row_IB_CONST_WK.BUNDLE_ITEM_NAME);
                  END IF;
              END IF;
              -- [4.1.]で取得したBUNDLE_SERAIL_NO
              --NEW CONTACT_IB_BASE_OBJ('BUNDLE_SERIAL_NO', row_IB_CONST_WK.BUNDLE_SERAIL_NO), 
              IF row_IB_CONST_WK.BUNDLE_SERAIL_NO IS NOT NULL THEN
                  IF row_IB_CONST_WK.BUNDLE_SERAIL_NO = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('BUNDLE_SERIAL_NO', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('BUNDLE_SERIAL_NO', row_IB_CONST_WK.BUNDLE_SERAIL_NO);
                  END IF;
              END IF;
              -- [4.1.]で取得したHOST_ID
              --NEW CONTACT_IB_BASE_OBJ('HOST_ID', row_IB_CONST_WK.HOST_ID),
              IF row_IB_CONST_WK.HOST_ID IS NOT NULL THEN
                  IF row_IB_CONST_WK.HOST_ID = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('HOST_ID', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('HOST_ID', row_IB_CONST_WK.HOST_ID);
                  END IF;
              END IF;
              -- [4.1.]で取得したKEEP_WATCH_SYSTEM_ID
              --NEW CONTACT_IB_BASE_OBJ('KEEP_WATCH_SYSTEM_ID', row_IB_CONST_WK.KEEP_WATCH_SYSTEM_ID),
              IF row_IB_CONST_WK.KEEP_WATCH_SYSTEM_ID IS NOT NULL THEN
                  IF row_IB_CONST_WK.KEEP_WATCH_SYSTEM_ID = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('KEEP_WATCH_SYSTEM_ID', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('KEEP_WATCH_SYSTEM_ID', row_IB_CONST_WK.KEEP_WATCH_SYSTEM_ID);
                  END IF;
              END IF;
              -- [4.1.]で取得したHP_CONFIG_CODE
              --NEW CONTACT_IB_BASE_OBJ('HP_CONFIG_CODE', row_IB_CONST_WK.HP_CONFIG_CODE),
              IF row_IB_CONST_WK.HP_CONFIG_CODE IS NOT NULL THEN
                  IF row_IB_CONST_WK.HP_CONFIG_CODE = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('HP_CONFIG_CODE', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('HP_CONFIG_CODE', row_IB_CONST_WK.HP_CONFIG_CODE);
                  END IF;
              END IF;
              -- [4.1.]で取得したOS_TYPE
              --NEW CONTACT_IB_BASE_OBJ('OS_TYPE', row_IB_CONST_WK.OS_TYPE),
              IF row_IB_CONST_WK.OS_TYPE IS NOT NULL THEN
                  IF row_IB_CONST_WK.OS_TYPE = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('OS_TYPE', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('OS_TYPE', row_IB_CONST_WK.OS_TYPE);
                  END IF;
              END IF;
              -- [4.1.]で取得したOS_VERSION
              --NEW CONTACT_IB_BASE_OBJ('OS_VERSION', row_IB_CONST_WK.OS_VERSION),
              IF row_IB_CONST_WK.OS_VERSION IS NOT NULL THEN
                  IF row_IB_CONST_WK.OS_VERSION = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('OS_VERSION', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('OS_VERSION', row_IB_CONST_WK.OS_VERSION);
                  END IF;
              END IF;
              -- [4.1.]で取得したFIRMWARE_VERSION
              --NEW CONTACT_IB_BASE_OBJ('FIRMWARE_VERSION', row_IB_CONST_WK.FIRMWARE_VERSION), 
              IF row_IB_CONST_WK.FIRMWARE_VERSION IS NOT NULL THEN
                  IF row_IB_CONST_WK.FIRMWARE_VERSION = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('FIRMWARE_VERSION', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('FIRMWARE_VERSION', row_IB_CONST_WK.FIRMWARE_VERSION);
                  END IF;
              END IF;
              -- [4.1.]で取得したREVISION
              --NEW CONTACT_IB_BASE_OBJ('REVISION', row_IB_CONST_WK.REVISION),
              IF row_IB_CONST_WK.REVISION IS NOT NULL THEN
                  IF row_IB_CONST_WK.REVISION = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('REVISION', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('REVISION', row_IB_CONST_WK.REVISION);
                  END IF;
              END IF;
              -- [4.1.]で取得したCPU_ROM_REVISION
              --NEW CONTACT_IB_BASE_OBJ('CPU_ROM_REVISION', row_IB_CONST_WK.CPU_ROM_REVISION),
              IF row_IB_CONST_WK.CPU_ROM_REVISION IS NOT NULL THEN
                  IF row_IB_CONST_WK.CPU_ROM_REVISION = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('CPU_ROM_REVISION', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('CPU_ROM_REVISION', row_IB_CONST_WK.CPU_ROM_REVISION);
                  END IF;
              END IF;
              -- [4.1.]で取得したDISK_CAPACITY
              --NEW CONTACT_IB_BASE_OBJ('DISK_CAPACITY', row_IB_CONST_WK.DISK_CAPACITY),
              IF row_IB_CONST_WK.DISK_CAPACITY IS NOT NULL THEN
                  IF row_IB_CONST_WK.DISK_CAPACITY = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('DISK_CAPACITY', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('DISK_CAPACITY', row_IB_CONST_WK.DISK_CAPACITY);
                  END IF;
              END IF;
              -- [4.1.]で取得したPOWER_SUPPLY_TYPE
              --NEW CONTACT_IB_BASE_OBJ('POWER_SUPPLY_TYPE', row_IB_CONST_WK.POWER_SUPPLY_TYPE),
              IF row_IB_CONST_WK.POWER_SUPPLY_TYPE IS NOT NULL THEN
                  IF row_IB_CONST_WK.POWER_SUPPLY_TYPE = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('POWER_SUPPLY_TYPE', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('POWER_SUPPLY_TYPE', row_IB_CONST_WK.POWER_SUPPLY_TYPE);
                  END IF;
              END IF;
              -- [4.1.]で取得したPOWER_SUPPLY_CAPACITY
              --NEW CONTACT_IB_BASE_OBJ('POWER_SUPPLY_CAPACITY', row_IB_CONST_WK.POWER_SUPPLY_CAPACITY),
              IF row_IB_CONST_WK.POWER_SUPPLY_CAPACITY IS NOT NULL THEN
                  IF row_IB_CONST_WK.POWER_SUPPLY_CAPACITY = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('POWER_SUPPLY_CAPACITY', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('POWER_SUPPLY_CAPACITY', row_IB_CONST_WK.POWER_SUPPLY_CAPACITY);
                  END IF;
              END IF;
              -- [4.1.]で取得したUSE_POWER_FREQUENCY
              --NEW CONTACT_IB_BASE_OBJ('USE_POWER_FREQUENCY', row_IB_CONST_WK.USE_POWER_FREQUENCY),
              IF row_IB_CONST_WK.USE_POWER_FREQUENCY IS NOT NULL THEN
                  IF row_IB_CONST_WK.USE_POWER_FREQUENCY = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('USE_POWER_FREQUENCY', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('USE_POWER_FREQUENCY', row_IB_CONST_WK.USE_POWER_FREQUENCY);
                  END IF;
              END IF;
              -- [4.1.]で取得したUSE_POWER_VOLTAGE
              --NEW CONTACT_IB_BASE_OBJ('USE_POWER_VOLTAGE', row_IB_CONST_WK.USE_POWER_VOLTAGE),
              IF row_IB_CONST_WK.USE_POWER_VOLTAGE IS NOT NULL THEN
                  IF row_IB_CONST_WK.USE_POWER_VOLTAGE = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('USE_POWER_VOLTAGE', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('USE_POWER_VOLTAGE', row_IB_CONST_WK.USE_POWER_VOLTAGE);
                  END IF;
              END IF;
              -- [4.1.]で取得したHAVING_EARTH_FLAG
              --NEW CONTACT_IB_BASE_OBJ('HAVING_EARTH_FLAG', row_IB_CONST_WK.HAVING_EARTH_FLAG),
              IF row_IB_CONST_WK.HAVING_EARTH_FLAG IS NOT NULL THEN
                  IF row_IB_CONST_WK.HAVING_EARTH_FLAG = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('HAVING_EARTH_FLAG', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('HAVING_EARTH_FLAG', row_IB_CONST_WK.HAVING_EARTH_FLAG);
                  END IF;
              END IF;
              -- [4.1.]で取得したMAC_ADDRESS
              --NEW CONTACT_IB_BASE_OBJ('MAC_ADDRESS', row_IB_CONST_WK.MAC_ADDRESS),
              IF row_IB_CONST_WK.MAC_ADDRESS IS NOT NULL THEN
                  IF row_IB_CONST_WK.MAC_ADDRESS = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('MAC_ADDRESS', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('MAC_ADDRESS', row_IB_CONST_WK.MAC_ADDRESS);
                  END IF;
              END IF;
              -- [4.1.]で取得したIP_ADDRESS
              --NEW CONTACT_IB_BASE_OBJ('IP_ADDRESS', row_IB_CONST_WK.IP_ADDRESS),
              IF row_IB_CONST_WK.IP_ADDRESS IS NOT NULL THEN
                  IF row_IB_CONST_WK.IP_ADDRESS = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('IP_ADDRESS', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('IP_ADDRESS', row_IB_CONST_WK.IP_ADDRESS);
                  END IF;
              END IF;
              -- [4.1.]で取得したLICENSE_MANAGEMENT_NO
              --NEW CONTACT_IB_BASE_OBJ('LICENSE_MANAGEMENT_NO', row_IB_CONST_WK.LICENSE_MANAGEMENT_NO),
              IF row_IB_CONST_WK.LICENSE_MANAGEMENT_NO IS NOT NULL THEN
                  IF row_IB_CONST_WK.LICENSE_MANAGEMENT_NO = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('LICENSE_MANAGEMENT_NO', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('LICENSE_MANAGEMENT_NO', row_IB_CONST_WK.LICENSE_MANAGEMENT_NO);
                  END IF;
              END IF;
              -- [4.1.]で取得したSUPERINTENDE_MANAGE_NO
              --NEW CONTACT_IB_BASE_OBJ('SUPERINTENDE_MANAGE_NO', row_IB_CONST_WK.SUPERINTENDE_MANAGE_NO),
              IF row_IB_CONST_WK.SUPERINTENDE_MANAGE_NO IS NOT NULL THEN
                  IF row_IB_CONST_WK.SUPERINTENDE_MANAGE_NO = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('SUPERINTENDE_MANAGE_NO', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('SUPERINTENDE_MANAGE_NO', row_IB_CONST_WK.SUPERINTENDE_MANAGE_NO);
                  END IF;
              END IF;
              -- [4.1.]で取得したLISENCE_START_DATE
              --NEW CONTACT_IB_BASE_OBJ('LISENCE_START_DATE', row_IB_CONST_WK.LISENCE_START_DATE),
              IF row_IB_CONST_WK.LISENCE_START_DATE IS NOT NULL THEN
                  IF row_IB_CONST_WK.LISENCE_START_DATE = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('LISENCE_START_DATE', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('LISENCE_START_DATE', row_IB_CONST_WK.LISENCE_START_DATE);
                  END IF;
              END IF;
              -- [4.1.]で取得したLISENCE_END_DATE
              --NEW CONTACT_IB_BASE_OBJ('LISENCE_END_DATE', row_IB_CONST_WK.LISENCE_END_DATE),
              IF row_IB_CONST_WK.LISENCE_END_DATE IS NOT NULL THEN
                  IF row_IB_CONST_WK.LISENCE_END_DATE = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('LISENCE_END_DATE', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('LISENCE_END_DATE', row_IB_CONST_WK.LISENCE_END_DATE);
                  END IF;
              END IF;
              -- [4.1.]で取得したREMOVE_ORDER_NO
              --NEW CONTACT_IB_BASE_OBJ('REMOVE_ORDER_NO', row_IB_CONST_WK.REMOVE_ORDER_NO),
              IF row_IB_CONST_WK.REMOVE_ORDER_NO IS NOT NULL THEN
                  IF row_IB_CONST_WK.REMOVE_ORDER_NO = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('REMOVE_ORDER_NO', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('REMOVE_ORDER_NO', row_IB_CONST_WK.REMOVE_ORDER_NO);
                  END IF;
              END IF;
              -- [4.1.]で取得したREMOVE_PO_NO
              --NEW CONTACT_IB_BASE_OBJ('REMOVE_PO_NO', row_IB_CONST_WK.REMOVE_PO_NO),
              IF row_IB_CONST_WK.REMOVE_PO_NO IS NOT NULL THEN
                  IF row_IB_CONST_WK.REMOVE_PO_NO = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('REMOVE_PO_NO', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('REMOVE_PO_NO', row_IB_CONST_WK.REMOVE_PO_NO);
                  END IF;
              END IF;
              -- [4.1.]で取得したREMOVE_DATE
              --NEW CONTACT_IB_BASE_OBJ('REMOVE_DATE', row_IB_CONST_WK.REMOVE_DATE),
              IF row_IB_CONST_WK.REMOVE_DATE IS NOT NULL THEN
                  IF row_IB_CONST_WK.REMOVE_DATE = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('REMOVE_DATE', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('REMOVE_DATE', row_IB_CONST_WK.REMOVE_DATE);
                  END IF;
              END IF;
              -- [4.1.]で取得したREMOVE_REASON
              --NEW CONTACT_IB_BASE_OBJ('REMOVE_REASON', row_IB_CONST_WK.REMOVE_REASON),
              IF row_IB_CONST_WK.REMOVE_REASON IS NOT NULL THEN
                  IF row_IB_CONST_WK.REMOVE_REASON = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('REMOVE_REASON', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('REMOVE_REASON', row_IB_CONST_WK.REMOVE_REASON);
                  END IF;
              END IF;
              -- [4.1.]で取得したSALES_DEPT_ORG_ID
              --NEW CONTACT_IB_BASE_OBJ('SALES_DEPT_ORG_ID', row_IB_CONST_WK.SALES_DEPT_ORG_ID), 
              IF row_IB_CONST_WK.SALES_DEPT_ORG_ID IS NOT NULL THEN
                  IF row_IB_CONST_WK.SALES_DEPT_ORG_ID = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('SALES_DEPT_ORG_ID', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('SALES_DEPT_ORG_ID', row_IB_CONST_WK.SALES_DEPT_ORG_ID);
                  END IF;
              END IF;
              -- [4.1.]で取得したSALES_DEPT_PERSON_ID
              --NEW CONTACT_IB_BASE_OBJ('SALES_DEPT_PERSON_ID', row_IB_CONST_WK.SALES_DEPT_PERSON_ID),
              IF row_IB_CONST_WK.SALES_DEPT_PERSON_ID IS NOT NULL THEN
                  IF row_IB_CONST_WK.SALES_DEPT_PERSON_ID = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('SALES_DEPT_PERSON_ID', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('SALES_DEPT_PERSON_ID', row_IB_CONST_WK.SALES_DEPT_PERSON_ID);
                  END IF;
              END IF;
              -- [4.1.]で取得したPRESENT_DEPT_ORG_ID
              --NEW CONTACT_IB_BASE_OBJ('PRESENT_DEPT_ORG_ID', row_IB_CONST_WK.PRESENT_DEPT_ORG_ID),
              IF row_IB_CONST_WK.PRESENT_DEPT_ORG_ID IS NOT NULL THEN
                  IF row_IB_CONST_WK.PRESENT_DEPT_ORG_ID = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('PRESENT_DEPT_ORG_ID', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('PRESENT_DEPT_ORG_ID', row_IB_CONST_WK.PRESENT_DEPT_ORG_ID);
                  END IF;
              END IF;
              -- [4.1.]で取得したCTC_SALESREP_PERSON_ID
              --NEW CONTACT_IB_BASE_OBJ('CTC_SALESREP_PERSON_ID', row_IB_CONST_WK.CTC_SALESREP_PERSON_ID),
              IF row_IB_CONST_WK.CTC_SALESREP_PERSON_ID IS NOT NULL THEN
                  IF row_IB_CONST_WK.CTC_SALESREP_PERSON_ID = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('CTC_SALESREP_PERSON_ID', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('CTC_SALESREP_PERSON_ID', row_IB_CONST_WK.CTC_SALESREP_PERSON_ID);
                  END IF;
              END IF;
              -- [4.1.]で取得したMAINTE_BUS_DEPT_ORG_ID
              --NEW CONTACT_IB_BASE_OBJ('MAINTE_BUS_DEPT_ORG_ID', row_IB_CONST_WK.MAINTE_BUS_DEPT_ORG_ID),
              IF row_IB_CONST_WK.MAINTE_BUS_DEPT_ORG_ID IS NOT NULL THEN
                  IF row_IB_CONST_WK.MAINTE_BUS_DEPT_ORG_ID = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('MAINTE_BUS_DEPT_ORG_ID', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('MAINTE_BUS_DEPT_ORG_ID', row_IB_CONST_WK.MAINTE_BUS_DEPT_ORG_ID);
                  END IF;
              END IF;
              -- [4.1.]で取得したMAINTE_BUS_PERSON_ID
              --NEW CONTACT_IB_BASE_OBJ('MAINTE_BUS_PERSON_ID', row_IB_CONST_WK.MAINTE_BUS_PERSON_ID),
              IF row_IB_CONST_WK.MAINTE_BUS_PERSON_ID IS NOT NULL THEN
                  IF row_IB_CONST_WK.MAINTE_BUS_PERSON_ID = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('MAINTE_BUS_PERSON_ID', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('MAINTE_BUS_PERSON_ID', row_IB_CONST_WK.MAINTE_BUS_PERSON_ID);
                  END IF;
              END IF;
              -- [4.1.]で取得したPP_CONT_AK_NO
              --NEW CONTACT_IB_BASE_OBJ('PP_CONT_AK_NO', row_IB_CONST_WK.PP_CONT_AK_NO),
              IF row_IB_CONST_WK.PP_CONT_AK_NO IS NOT NULL THEN
                  IF row_IB_CONST_WK.PP_CONT_AK_NO = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('PP_CONT_AK_NO', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('PP_CONT_AK_NO', row_IB_CONST_WK.PP_CONT_AK_NO);
                  END IF;
              END IF;
              -- [4.1.]で取得したPP_CONT_START_DATE
              --NEW CONTACT_IB_BASE_OBJ('PP_CONT_START_DATE', row_IB_CONST_WK.PP_CONT_START_DATE),
              IF row_IB_CONST_WK.PP_CONT_START_DATE IS NOT NULL THEN
                  IF row_IB_CONST_WK.PP_CONT_START_DATE = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('PP_CONT_START_DATE', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('PP_CONT_START_DATE', row_IB_CONST_WK.PP_CONT_START_DATE);
                  END IF;
              END IF;
              -- [4.1.]で取得したPP_CONT_END_DATE
              --NEW CONTACT_IB_BASE_OBJ('PP_CONT_END_DATE', row_IB_CONST_WK.PP_CONT_END_DATE), 
              IF row_IB_CONST_WK.PP_CONT_END_DATE IS NOT NULL THEN
                  IF row_IB_CONST_WK.PP_CONT_END_DATE = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('PP_CONT_END_DATE', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('PP_CONT_END_DATE', row_IB_CONST_WK.PP_CONT_END_DATE);
                  END IF;
              END IF;
              -- [4.1.]で取得したSN_CHANGE_REASON
              --NEW CONTACT_IB_BASE_OBJ('SN_CHANGE_REASON', row_IB_CONST_WK.SN_CHANGE_REASON),
              IF row_IB_CONST_WK.SN_CHANGE_REASON IS NOT NULL THEN
                  IF row_IB_CONST_WK.SN_CHANGE_REASON = 'XXXX' THEN
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('SN_CHANGE_REASON', NULL); 
                  ELSE
                      tIB_BASE.EXTEND;
                      tIB_BASE(tIB_BASE.COUNT) := CONTACT_IB_BASE_OBJ('SN_CHANGE_REASON', row_IB_CONST_WK.SN_CHANGE_REASON);
                  END IF;
              END IF;

            --********************************************************************
            -- 5.4.設置機器共通情報の設定
            -- 対象データを設置機器共通情報に設定する。
            -- ※以下の内容は、設置機器・共通テーブル追加更新APIのパラメータ「設置機器共通情報」として、設定する。
            -- （NULL項目は追加・更新APIに渡す項目として、不要な項目とする。）
            --********************************************************************
            PRAM_PLACE_HOLDER   := '設置機器共通情報の設定';
            --********************************************************************

            -- ※1　設置先顧客コードの取得　
            -- [4.1.]で取得した「INSTALL_LOCATION_CODE」が設定されている場合のみ、実施する。
              IF row_IB_CONST_WK.INSTALL_LOCATION_CODE IS NOT NULL THEN
                BEGIN
                  SELECT CMIA.CUST_CD                                                            -- 顧客コード
                    INTO p_INSTALL_CUSTOMER_CODE_ICI
                    FROM CSG_M_IB_ADDRESS CMIA                                                   -- 設置先住所マスタ
                   WHERE CMIA.INSTALL_LOCATION_CODE   = row_IB_CONST_WK.INSTALL_LOCATION_CODE    -- 設置先住所マスタ.設置先住所コード [4.1.]で取得した「設置先住所コード」
                     AND CMIA.ACTIVE_FLAG              = 'Y';                                    -- 設置先住所マスタ.有効フラグ "Y"：有効
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                    --OUT_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
                    --OUT_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
                    NULL;
                END;
              END IF;

            -- ※２　エンドユーザ会社名の取得　
            -- [4.1.]で取得した「ENDUSER_PARTY_CODE」が設定されている場合のみ、実施する。
              IF REPLACE(row_IB_CONST_WK.ENDUSER_PARTY_CODE, 'XXXX', NULL) IS NOT NULL THEN
                BEGIN
                  SELECT SMC.CUST_FRML_NM                                            -- 顧客正式名称
                    INTO p_ENDUSER_PARTY_NAME_ICI
                    FROM SNV_M_CUST SMC                                              -- 顧客マスタ
                   WHERE SMC.CUST_CD            = row_IB_CONST_WK.ENDUSER_PARTY_CODE -- 顧客マスタ.顧客コード [4.1.]で取得した「エンドユーザ会社コード」
                     AND SMC.HDQRTRS_ID_FLG     = 'Y'                                -- 顧客マスタ.本社識別フラグ "Y"：本社
                     AND NVL(SMC.DEL_FLG, 'N') <> 'X';                               -- 顧客マスタ.削除フラグ "X"：削除　以外
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                    --OUT_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
                    --OUT_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
                    NULL;
                END;
              END IF;

              IF COALESCE(row_IB_CONST_WK.CS_IN_CHARGE_CD, 
                          row_IB_CONST_WK.INSTALL_LOCATION_CODE, 
                          row_IB_CONST_WK.INCIDENT_SAVERITY_NAME, 
                          p_ENDUSER_PARTY_CODE, 
                          p_INSTALL_CUSTOMER_CODE_ICI, 
                          row_IB_CONST_WK.INSTALL_LOCATION_DEPT_NAME, 
                          row_IB_CONST_WK.INSTALL_LOCATION_PERSON_NAME, 
                          row_IB_CONST_WK.INSTALL_LOCATION_TEL, 
                          row_IB_CONST_WK.INSTALL_LOCATION_FAX, 
                          row_IB_CONST_WK.USE_CONDITION, 
                          row_IB_CONST_WK.USE_PERPOSE, 
                          row_IB_CONST_WK.ENDUSER_PARTY_CODE, 
                          row_IB_CONST_WK.ENDUSER_LOCATION, 
                          row_IB_CONST_WK.ENDUSER_CHRG_DEPT_NAME, 
                          row_IB_CONST_WK.ENDUSER_CHRG_PERSON_NAME, 
                          row_IB_CONST_WK.ENDUSER_TEL, 
                          row_IB_CONST_WK.ENDUSER_FAX, 
                          row_IB_CONST_WK.ENDUSER_MAIL_ADDRESS) IS NOT NULL THEN
                  tIB_COMMON := NEW ARRAY_IB_COMMON();
--                        NEW CONTACT_IB_COMMON_OBJ('CE_CODE', NULL),                                                                           -- NULL
--                        NEW CONTACT_IB_COMMON_OBJ('PROGRAM_ID', 'BAT-CSG02-0203'),                                                            -- "BAT-CSG02-0203"
--                        NEW CONTACT_IB_COMMON_OBJ('PROCESS_ID', INPUT_PROCESS_ID),                                                            -- [0.3.]で取得した処理ID
--                        NEW CONTACT_IB_COMMON_OBJ('CREATION_USER_ID', INPUT_USER_ID),                                                         -- [0.2.]で取得したバッチ実行ユーザID
--                        NEW CONTACT_IB_COMMON_OBJ('CREATION_DATE', set_sysdate),                                                                  -- [0.1.システム日時の取得]にて取得したシステム日時
--                        NEW CONTACT_IB_COMMON_OBJ('UPDATE_USER_ID', INPUT_USER_ID),                                                           -- [0.2.]で取得したバッチ実行ユーザID
--                        NEW CONTACT_IB_COMMON_OBJ('UPDATE_DATE', set_sysdate)                                                                     -- [0.1.システム日時の取得]にて取得したシステム日時
--                        );
              END IF;

              ----[NotNull項目]
              -- [4.1.]で取得したCS_IN_CHARGE_CD
              --NEW CONTACT_IB_COMMON_OBJ('CS_IN_CHARGE_CODE', row_IB_CONST_WK.CS_IN_CHARGE_CD),
              IF row_IB_CONST_WK.CS_IN_CHARGE_CD IS NOT NULL THEN
                  tIB_COMMON.EXTEND;
                  tIB_COMMON(tIB_COMMON.COUNT) := CONTACT_IB_COMMON_OBJ('CS_IN_CHARGE_CODE', row_IB_CONST_WK.CS_IN_CHARGE_CD); 
              END IF;
              -- [4.1.]で取得したINSTALL_LOCATION_CODE
              --NEW CONTACT_IB_COMMON_OBJ('INSTALL_LOCATION_CODE', row_IB_CONST_WK.INSTALL_LOCATION_CODE),
              ----※1
              --NEW CONTACT_IB_COMMON_OBJ('INSTALL_CUSTOMER_CODE', p_INSTALL_CUSTOMER_CODE_ICI),                                      -- 設置先住所マスタから取得　※１
              IF row_IB_CONST_WK.INSTALL_LOCATION_CODE IS NOT NULL THEN
                  tIB_COMMON.EXTEND;
                  tIB_COMMON(tIB_COMMON.COUNT) := CONTACT_IB_COMMON_OBJ('INSTALL_LOCATION_CODE', row_IB_CONST_WK.INSTALL_LOCATION_CODE); 
                  tIB_COMMON.EXTEND;
                  tIB_COMMON(tIB_COMMON.COUNT) := CONTACT_IB_COMMON_OBJ('INSTALL_CUSTOMER_CODE', p_INSTALL_CUSTOMER_CODE_ICI); 
              END IF;
              -- [4.1.]で取得したINCIDENT_SAVERITY_NAME
              --NEW CONTACT_IB_COMMON_OBJ('INCIDENT_SERVIRITY_NAME', row_IB_CONST_WK.INCIDENT_SAVERITY_NAME),
              IF row_IB_CONST_WK.INCIDENT_SAVERITY_NAME IS NOT NULL THEN
                  tIB_COMMON.EXTEND;
                  tIB_COMMON(tIB_COMMON.COUNT) := CONTACT_IB_COMMON_OBJ('INCIDENT_SERVIRITY_NAME', row_IB_CONST_WK.INCIDENT_SAVERITY_NAME); 
              END IF;

              ----[NullOK項目]
              -- [4.1.]で取得したINSTALL_LOCATION_DEPT_NAME
              --NEW CONTACT_IB_COMMON_OBJ('INSTALL_LOCATION_DEPT_NAME', row_IB_CONST_WK.INSTALL_LOCATION_DEPT_NAME),
              IF row_IB_CONST_WK.INSTALL_LOCATION_DEPT_NAME IS NOT NULL THEN
                  IF row_IB_CONST_WK.INSTALL_LOCATION_DEPT_NAME = 'XXXX' THEN
                      tIB_COMMON.EXTEND;
                      tIB_COMMON(tIB_COMMON.COUNT) := CONTACT_IB_COMMON_OBJ('INSTALL_LOCATION_DEPT_NAME', NULL); 
                  ELSE
                      tIB_COMMON.EXTEND;
                      tIB_COMMON(tIB_COMMON.COUNT) := CONTACT_IB_COMMON_OBJ('INSTALL_LOCATION_DEPT_NAME', row_IB_CONST_WK.INSTALL_LOCATION_DEPT_NAME); 
                  END IF;
              END IF;
              -- [4.1.]で取得したINSTALL_LOCATION_PERSON_NAME
              --NEW CONTACT_IB_COMMON_OBJ('INSTALL_LOCATION_PERSON_NAME', row_IB_CONST_WK.INSTALL_LOCATION_PERSON_NAME),
              IF row_IB_CONST_WK.INSTALL_LOCATION_PERSON_NAME IS NOT NULL THEN
                  IF row_IB_CONST_WK.INSTALL_LOCATION_PERSON_NAME = 'XXXX' THEN
                      tIB_COMMON.EXTEND;
                      tIB_COMMON(tIB_COMMON.COUNT) := CONTACT_IB_COMMON_OBJ('INSTALL_LOCATION_PERSON_NAME', NULL); 
                  ELSE
                      tIB_COMMON.EXTEND;
                      tIB_COMMON(tIB_COMMON.COUNT) := CONTACT_IB_COMMON_OBJ('INSTALL_LOCATION_PERSON_NAME', row_IB_CONST_WK.INSTALL_LOCATION_PERSON_NAME); 
                  END IF;
              END IF;
              -- [4.1.]で取得したINSTALL_LOCATION_TEL
              --NEW CONTACT_IB_COMMON_OBJ('INSTALL_LOCATION_TEL', row_IB_CONST_WK.INSTALL_LOCATION_TEL),
              IF row_IB_CONST_WK.INSTALL_LOCATION_TEL IS NOT NULL THEN
                  IF row_IB_CONST_WK.INSTALL_LOCATION_TEL = 'XXXX' THEN
                      tIB_COMMON.EXTEND;
                      tIB_COMMON(tIB_COMMON.COUNT) := CONTACT_IB_COMMON_OBJ('INSTALL_LOCATION_TEL', NULL); 
                  ELSE
                      tIB_COMMON.EXTEND;
                      tIB_COMMON(tIB_COMMON.COUNT) := CONTACT_IB_COMMON_OBJ('INSTALL_LOCATION_TEL', row_IB_CONST_WK.INSTALL_LOCATION_TEL); 
                  END IF;
              END IF;
              -- [4.1.]で取得したINSTALL_LOCATION_FAX
              --NEW CONTACT_IB_COMMON_OBJ('INSTALL_LOCATION_FAX', row_IB_CONST_WK.INSTALL_LOCATION_FAX),
              IF row_IB_CONST_WK.INSTALL_LOCATION_FAX IS NOT NULL THEN
                  IF row_IB_CONST_WK.INSTALL_LOCATION_FAX = 'XXXX' THEN
                      tIB_COMMON.EXTEND;
                      tIB_COMMON(tIB_COMMON.COUNT) := CONTACT_IB_COMMON_OBJ('INSTALL_LOCATION_FAX', NULL); 
                  ELSE
                      tIB_COMMON.EXTEND;
                      tIB_COMMON(tIB_COMMON.COUNT) := CONTACT_IB_COMMON_OBJ('INSTALL_LOCATION_FAX', row_IB_CONST_WK.INSTALL_LOCATION_FAX); 
                  END IF;
              END IF;
              -- [4.1.]で取得したUSE_CONDITION
              --NEW CONTACT_IB_COMMON_OBJ('USE_CONDITION', row_IB_CONST_WK.USE_CONDITION),
              IF row_IB_CONST_WK.USE_CONDITION IS NOT NULL THEN
                  IF row_IB_CONST_WK.USE_CONDITION = 'XXXX' THEN
                      tIB_COMMON.EXTEND;
                      tIB_COMMON(tIB_COMMON.COUNT) := CONTACT_IB_COMMON_OBJ('USE_CONDITION', NULL); 
                  ELSE
                      tIB_COMMON.EXTEND;
                      tIB_COMMON(tIB_COMMON.COUNT) := CONTACT_IB_COMMON_OBJ('USE_CONDITION', row_IB_CONST_WK.USE_CONDITION); 
                  END IF;
              END IF;
              -- [4.1.]で取得したUSE_PERPOSE
              --NEW CONTACT_IB_COMMON_OBJ('USE_PERPOSE', row_IB_CONST_WK.USE_PERPOSE), 
              IF row_IB_CONST_WK.USE_PERPOSE IS NOT NULL THEN
                  IF row_IB_CONST_WK.USE_PERPOSE = 'XXXX' THEN
                      tIB_COMMON.EXTEND;
                      tIB_COMMON(tIB_COMMON.COUNT) := CONTACT_IB_COMMON_OBJ('USE_PERPOSE', NULL); 
                  ELSE
                      tIB_COMMON.EXTEND;
                      tIB_COMMON(tIB_COMMON.COUNT) := CONTACT_IB_COMMON_OBJ('USE_PERPOSE', row_IB_CONST_WK.USE_PERPOSE); 
                  END IF;
              END IF;
              -- [4.1.]で取得したENDUSER_PARTY_CODE
              --NEW CONTACT_IB_COMMON_OBJ('ENDUSER_PARTY_CODE', row_IB_CONST_WK.ENDUSER_PARTY_CODE), 
              IF row_IB_CONST_WK.ENDUSER_PARTY_CODE IS NOT NULL THEN
                  IF row_IB_CONST_WK.ENDUSER_PARTY_CODE = 'XXXX' THEN
                      tIB_COMMON.EXTEND;
                      tIB_COMMON(tIB_COMMON.COUNT) := CONTACT_IB_COMMON_OBJ('ENDUSER_PARTY_CODE', NULL); 
                      tIB_COMMON.EXTEND;
                      tIB_COMMON(tIB_COMMON.COUNT) := CONTACT_IB_COMMON_OBJ('ENDUSER_PARTY_NAME', NULL); --※２
                  ELSE
                      tIB_COMMON.EXTEND;
                      tIB_COMMON(tIB_COMMON.COUNT) := CONTACT_IB_COMMON_OBJ('ENDUSER_PARTY_CODE', row_IB_CONST_WK.ENDUSER_PARTY_CODE); 
                      tIB_COMMON.EXTEND;
                      tIB_COMMON(tIB_COMMON.COUNT) := CONTACT_IB_COMMON_OBJ('ENDUSER_PARTY_NAME', p_ENDUSER_PARTY_NAME_ICI); --※２
                  END IF;
              END IF;
              -- [4.1.]で取得したENDUSER_LOCATION
              --NEW CONTACT_IB_COMMON_OBJ('ENDUSER_LOCATION', row_IB_CONST_WK.ENDUSER_LOCATION), 
              IF row_IB_CONST_WK.ENDUSER_LOCATION IS NOT NULL THEN
                  IF row_IB_CONST_WK.ENDUSER_LOCATION = 'XXXX' THEN
                      tIB_COMMON.EXTEND;
                      tIB_COMMON(tIB_COMMON.COUNT) := CONTACT_IB_COMMON_OBJ('ENDUSER_LOCATION', NULL); 
                  ELSE
                      tIB_COMMON.EXTEND;
                      tIB_COMMON(tIB_COMMON.COUNT) := CONTACT_IB_COMMON_OBJ('ENDUSER_LOCATION', row_IB_CONST_WK.ENDUSER_LOCATION); 
                  END IF;
              END IF;
              -- [4.1.]で取得したENDUSER_CHRG_DEPT_NAME
              --NEW CONTACT_IB_COMMON_OBJ('ENDUSER_CHRG_DEPT_NAME', row_IB_CONST_WK.ENDUSER_CHRG_DEPT_NAME), 
              IF row_IB_CONST_WK.ENDUSER_CHRG_DEPT_NAME IS NOT NULL THEN
                  IF row_IB_CONST_WK.ENDUSER_CHRG_DEPT_NAME = 'XXXX' THEN
                      tIB_COMMON.EXTEND;
                      tIB_COMMON(tIB_COMMON.COUNT) := CONTACT_IB_COMMON_OBJ('ENDUSER_CHRG_DEPT_NAME', NULL); 
                  ELSE
                      tIB_COMMON.EXTEND;
                      tIB_COMMON(tIB_COMMON.COUNT) := CONTACT_IB_COMMON_OBJ('ENDUSER_CHRG_DEPT_NAME', row_IB_CONST_WK.ENDUSER_CHRG_DEPT_NAME); 
                  END IF;
              END IF;
              -- [4.1.]で取得したENDUSER_CHRG_PERSON_NAME
              --NEW CONTACT_IB_COMMON_OBJ('ENDUSER_CHRG_PERSON_NAME', row_IB_CONST_WK.ENDUSER_CHRG_PERSON_NAME),
              IF row_IB_CONST_WK.ENDUSER_CHRG_PERSON_NAME IS NOT NULL THEN
                  IF row_IB_CONST_WK.ENDUSER_CHRG_PERSON_NAME = 'XXXX' THEN
                      tIB_COMMON.EXTEND;
                      tIB_COMMON(tIB_COMMON.COUNT) := CONTACT_IB_COMMON_OBJ('ENDUSER_CHRG_PERSON_NAME', NULL); 
                  ELSE
                      tIB_COMMON.EXTEND;
                      tIB_COMMON(tIB_COMMON.COUNT) := CONTACT_IB_COMMON_OBJ('ENDUSER_CHRG_PERSON_NAME', row_IB_CONST_WK.ENDUSER_CHRG_PERSON_NAME); 
                  END IF;
              END IF;
              -- [4.1.]で取得したENDUSER_TEL
              --NEW CONTACT_IB_COMMON_OBJ('ENDUSER_TEL', row_IB_CONST_WK.ENDUSER_TEL),
              IF row_IB_CONST_WK.ENDUSER_TEL IS NOT NULL THEN
                  IF row_IB_CONST_WK.ENDUSER_TEL = 'XXXX' THEN
                      tIB_COMMON.EXTEND;
                      tIB_COMMON(tIB_COMMON.COUNT) := CONTACT_IB_COMMON_OBJ('ENDUSER_TEL', NULL); 
                  ELSE
                      tIB_COMMON.EXTEND;
                      tIB_COMMON(tIB_COMMON.COUNT) := CONTACT_IB_COMMON_OBJ('ENDUSER_TEL', row_IB_CONST_WK.ENDUSER_TEL); 
                  END IF;
              END IF;
              -- [4.1.]で取得したENDUSER_FAX
              --NEW CONTACT_IB_COMMON_OBJ('ENDUSER_FAX', row_IB_CONST_WK.ENDUSER_FAX),
              IF row_IB_CONST_WK.ENDUSER_FAX IS NOT NULL THEN
                  IF row_IB_CONST_WK.ENDUSER_FAX = 'XXXX' THEN
                      tIB_COMMON.EXTEND;
                      tIB_COMMON(tIB_COMMON.COUNT) := CONTACT_IB_COMMON_OBJ('ENDUSER_FAX', NULL); 
                  ELSE
                      tIB_COMMON.EXTEND;
                      tIB_COMMON(tIB_COMMON.COUNT) := CONTACT_IB_COMMON_OBJ('ENDUSER_FAX', row_IB_CONST_WK.ENDUSER_FAX); 
                  END IF;
              END IF;
              -- [4.1.]で取得したENDUSER_MAIL_ADDRESS
              --NEW CONTACT_IB_COMMON_OBJ('ENDUSER_MAIL_ADDRESS', row_IB_CONST_WK.ENDUSER_MAIL_ADDRESS)
              IF row_IB_CONST_WK.ENDUSER_MAIL_ADDRESS IS NOT NULL THEN
                  IF row_IB_CONST_WK.ENDUSER_MAIL_ADDRESS = 'XXXX' THEN
                      tIB_COMMON.EXTEND;
                      tIB_COMMON(tIB_COMMON.COUNT) := CONTACT_IB_COMMON_OBJ('ENDUSER_MAIL_ADDRESS', NULL); 
                  ELSE
                      tIB_COMMON.EXTEND;
                      tIB_COMMON(tIB_COMMON.COUNT) := CONTACT_IB_COMMON_OBJ('ENDUSER_MAIL_ADDRESS', row_IB_CONST_WK.ENDUSER_MAIL_ADDRESS); 
                  END IF;
              END IF;

          --********************************************************************
          -- 5.5.設置機器・共通テーブル追加更新APIのコール
          -- 設置機器・共通テーブル追加更新APIを呼び出す。
          --********************************************************************
            PRAM_PLACE_HOLDER   := '設置機器・設置機器共通情報更新';

              IF tIB_COMMON.COUNT > 0 THEN
                  CSG02_IB_COMMON_PKG.CSG02_PROC_IB_TABLE_UPDATE(
                                                                  10,
                                                                  row_IB_CONST_WK.INSTANCE_ID,
                                                                  row_IB_CONST_WK.TOP_INSTANCE_ID,
                                                                  tIB_BASE,
                                                                  tIB_COMMON,
                                                                  'BAT-CSG02-0205',
                                                                  INPUT_PROCESS_ID,
                                                                  INPUT_USER_ID,
                                                                  'N',
                                                                  NULL,
                                                                  OUT_RESULT_CD,
                                                                  OUT_ERR_CONTENT,
                                                                  p_INSTANCE_ID,
                                                                  p_UPDATE_DATE_IBI
                                                          );
              ELSE
                  CSG02_IB_COMMON_PKG.CSG02_PROC_IB_TABLE_UPDATE(
                                                                  10,
                                                                  row_IB_CONST_WK.INSTANCE_ID,
                                                                  row_IB_CONST_WK.TOP_INSTANCE_ID,
                                                                  tIB_BASE,
                                                                  NULL,
                                                                  'BAT-CSG02-0205',
                                                                  INPUT_PROCESS_ID,
                                                                  INPUT_USER_ID,
                                                                  'N',
                                                                  NULL,
                                                                  OUT_RESULT_CD,
                                                                  OUT_ERR_CONTENT,
                                                                  p_INSTANCE_ID,
                                                                  p_UPDATE_DATE_IBI
                                                          );
              END IF;
              CASE 
                WHEN OUT_RESULT_CD = 0  THEN --正常
                  --********************************************************************
                  -- 5.8.正常件数のカウントアップ
                  -- 処理結果の正常件数をカウントアップ（保持）する。
                  --********************************************************************
                  g_normal_sel_cnt          := g_normal_sel_cnt + 1;
                  p_ASSIGN_FLAG             := '1';                        -- 紐付済フラグ "1" (紐付済)　／　"2"(エラー)
                WHEN OUT_RESULT_CD = 21 THEN -- [マスタ存在チェックエラーの場合]
                  p_INSTANCE_ID         := row_IB_CONST_WK.INSTANCE_ID;         -- インスタンス番号
                  v_Content             := OUT_ERR_CONTENT;
                  OUT_ERR_DETAIL  := '更新できなかったレコードが存在します。 インスタンス番号：' 
                                  || p_INSTANCE_ID || '  エラー内容:' ||  v_Content;
                  DBMS_OUTPUT.PUT_LINE(OUT_ERR_DETAIL);

                  -- ・処理結果の警告件数としてカウントアップ（保持）する。
                  g_warnings_sel_cnt          := g_warnings_sel_cnt + 1;

                  -- ・中間ワークの紐付済フラグを「2:エラー」に更新し、次のレコードの処理に遷移する。（「5.9.中間ワーク更新」に遷移）
                  p_ASSIGN_FLAG               := '2';                    -- 紐付済フラグ "1" (紐付済)　／　"2"(エラー)

                ELSE    --その他エラー
                  RAISE P_EXCEPTION;
              END CASE;
          END IF;

        --********************************************************************
        -- 5.7.中間ワーク更新
        -- 設置機器構成情報ワークの紐付済フラグを「1:紐付済」に更新する。
        --********************************************************************
        PRAM_PLACE_HOLDER   := '設置機器構成情報ワーク更新';

          BEGIN
            UPDATE CSG_P_IB_CONST_WK                            -- 設置機器構成情報ワーク
               SET ASSIGN_FLAG    = p_ASSIGN_FLAG,              -- 紐付済フラグ "1" (紐付済)　／　"2"(エラー)
                   UPDATE_USER_ID = INPUT_USER_ID,              -- 更新者 バッチ実行ユーザID
                   UPDATE_DATE    = set_sysdate                 -- 更新日時 システム日時
            WHERE IB_CONST_ID    = row_IB_CONST_WK.IB_CONST_ID;-- 設置機器構成ID [4.1.]で取得したデータの設置機器構成ID
          EXCEPTION
            -- その他未定義の例外の処理
            WHEN OTHERS THEN
              DBMS_OUTPUT.PUT_LINE(PRAM_PLACE_HOLDER || 'に失敗しました。');
              DBMS_OUTPUT.PUT_LINE('ORACLE ERR_CODE    := ' || SQLCODE);            -- ＤＢエラーコード
              DBMS_OUTPUT.PUT_LINE('ORACLE ERR_MESSAGE := ' || SQLERRM(SQLCODE));   -- ＤＢエラーメッセージ
              OUT_RESULT_CD   := '20';
              OUT_STATUS      := '3'; -- 3:エラー
              OUT_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
              OUT_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
              ROLLBACK;
              RETURN;
          END;

        --****************************************************************************
        -- 5.10.コミットの実行
        --****************************************************************************
          COMMIT;

        END;

      END LOOP CUR_IB_CONST_WK_LOOP;

    OUT_RESULT_CD        := '0'; -- 0 ：正常コード
    OUT_STATUS           := '1'; -- 1:正常終了
    OUT_ERR_CONTENT := '処理結果　対象件数：' || g_target_sel_cnt || '　正常件数：' || g_normal_sel_cnt || '　警告件数：' || g_warnings_sel_cnt;
  EXCEPTION
    WHEN PRAM_EXCEPTION THEN
      -- データの取得に失敗した場合、異常終了としエラーメッセージをログ出力し後続の処理を中断する。
      OUT_ERR_DETAIL  := PRAM_PLACE_HOLDER || 'に失敗しました。';
      DBMS_OUTPUT.PUT_LINE(OUT_ERR_DETAIL);
      OUT_RESULT_CD   := '20';
      OUT_STATUS      := '3';  -- 3:エラー
      OUT_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
      ROLLBACK;
      RETURN;
    WHEN P_EXCEPTION THEN
      OUT_ERR_DETAIL  := PRAM_PLACE_HOLDER || 'に失敗しました。 エラー内容： ' || OUT_ERR_CONTENT;
      DBMS_OUTPUT.PUT_LINE(OUT_ERR_DETAIL);
      OUT_RESULT_CD   := '20';
      OUT_STATUS      := '3';
      OUT_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
      ROLLBACK;
      RETURN;
    -- その他未定義の例外の処理
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE(PRAM_PLACE_HOLDER || 'に失敗しました。');
      DBMS_OUTPUT.PUT_LINE('ORACLE ERR_CODE    := ' || SQLCODE);            -- ＤＢエラーコード
      DBMS_OUTPUT.PUT_LINE('ORACLE ERR_MESSAGE := ' || SQLERRM(SQLCODE));   -- ＤＢエラーメッセージ
      OUT_RESULT_CD   := '20';
      OUT_STATUS      := '3'; -- 3:エラー
      OUT_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
      OUT_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
      ROLLBACK;
      RETURN;
  END CSG02_PROC_CHANGE_INS_EQUI_COL;

END CSG02_0205_PKG;

/
