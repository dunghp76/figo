CREATE OR REPLACE PACKAGE "CSG02_0110_PKG"
AS
/*******************************************************************************
* 担当ＣＳ設定移行                                                                *
*-------------------------------------------------------------------------------*
* <更新履歴>                                                                     *
* <Version>   <日付>      <更新概要>                             <更新者>         *
*   1.0     2016/04/01      新規                                FOCUS_LTBINH    *
********************************************************************************/
  /******************************************************************************
  * 担当CS設定（PL/SQL）                                                          *
  * CSG02-0110 (MAIN)                                                           *
  *******************************************************************************/
  PROCEDURE MAIN_CSG02_0110(
      INPUT_USER_ID               IN VARCHAR2 ,              --ユーザID
      INPUT_PROCESS_ID            IN VARCHAR2 DEFAULT NULL , --プロセスID
      INPUT_MODEL_CODE            IN VARCHAR2 DEFAULT NULL , -- 機種コード
      INPUT_ACCOUNT_NO            IN VARCHAR2 DEFAULT NULL , -- 顧客番号
      INPUT_F_SALES_DEP_CODE      IN VARCHAR2 DEFAULT NULL , -- Ｆ営業部課コード
      INPUT_INSTALL_LOCATION_CODE IN NUMBER DEFAULT NULL ,   -- 設置先住所ＩＤ
      OUT_RESULT_CD OUT VARCHAR2 ,                           -- 終了コード (0  ：正常終了コード　／　20 ：異常終了コード)
      OUT_RESULT_GET OUT VARCHAR2 ,                          -- 取得結果 (OK / NGを返却する)
      OUT_CONDITION_GET OUT VARCHAR2 ,                       -- 取得条件
      OUT_CS_IN_CHARGE_CODE OUT NUMBER );

  /******************************************************************************
  * 担当CS設定（PL/SQL）                                                          *
  * CSG02-0110                                                                  *
  *******************************************************************************/
  PROCEDURE CSG02_PROC_CHARGE_OF_CS_SET(
      INPUT_MODEL_CODE            IN VARCHAR2 DEFAULT NULL , -- 機種コード
      INPUT_ACCOUNT_NO            IN VARCHAR2 DEFAULT NULL , -- 顧客番号
      INPUT_F_SALES_DEP_CODE      IN VARCHAR2 DEFAULT NULL , -- Ｆ営業部課コード
      INPUT_INSTALL_LOCATION_CODE IN NUMBER DEFAULT NULL ,   -- 設置先住所ＩＤ
      OUT_RESULT_CD OUT VARCHAR2 ,                           -- 終了コード (0  ：正常終了コード　／　20 ：異常終了コード)
      OUT_RESULT_GET OUT VARCHAR2 ,                          -- 取得結果 (OK / NGを返却する)
      OUT_CONDITION_GET OUT VARCHAR2 ,                       -- 取得条件
      OUT_CS_IN_CHARGE_CODE OUT NUMBER );                    -- 担当CSコード

END CSG02_0110_PKG;
/
