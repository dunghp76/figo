CREATE OR REPLACE PACKAGE BODY "CSG04_0601_PKG"
AS
  PROCEDURE "CSG04_PROC_ZIP_REGISTRATION" (
    --ユーザID
    INPUT_USERID         IN VARCHAR2 ,
    --プロセスID
    INPUT_PROCESS_ID     IN VARCHAR2 ,
    --終了コード
    RESULT_CD           OUT VARCHAR2 )
AS
  --  定数宣言
  vDATE                DATE := SYSDATE;
  vPROCESS_ID          NUMBER(7);
  vRESULT_CD           VARCHAR2(1);
  vIN_RESULT_CD        VARCHAR2(1);
  PRAM_EXCEPTION       EXCEPTION;
  vERROR               CLOB;
  vERRORCONTEXT        NVARCHAR2(64);
  vTABLE               VARCHAR2(100);
  vERRORFLAG           VARCHAR2(10);
  vERRORPOSTAL         NUMBER(7);

  vPOSTALCD            NUMBER(7);
  vPOSTALCD2           NUMBER(7);
  vPOSTALCDFULL        VARCHAR2(7);
  vPOSTALCD3           VARCHAR2(3);     --郵便番号親３桁
  vPOSTALCD4           VARCHAR2(4);     --郵便番号子４桁
  vPOSTALCD5           VARCHAR2(8);     --郵便番号（－）付き
  vKOKYOCD             VARCHAR2(5);     --全国地方公共団体コード
  vSTATECD             VARCHAR2(2);     --都道府県コード
  vSTATENAME           VARCHAR2(300);   --都道府県名
  vSTATENAME_KANA      VARCHAR2(300);   --都道府県名カナ
  vCITYNAME            VARCHAR2(300);   --市町村区名
  vCITYNAME_KANA       VARCHAR2(300);   --市町村区名カナ
  vADDRESSNAME         VARCHAR2(1500);  --町域名
  vADDRESSNAME_KANA    VARCHAR2(1500);  --町域名カナ
  vKIGYO_FLAG          VARCHAR2(1);     --企業フラグ

  vCOUNT               NUMBER(15);
  vCOUNT2              NUMBER(15);
  vCOUNT3              NUMBER(15);
  vCOUNT4              NUMBER(15);

  vPOSTALCDK           NUMBER(7);
  vPOSTALCDKFULL       VARCHAR2(7);
  vPOSTALCDK3          VARCHAR2(3);
  vPOSTALCDK4          VARCHAR2(4);
  vPOSTALCDK5          VARCHAR2(8);
  vJISCDK              VARCHAR2(5);     --全国地方公共団体コード(企業)
  vSTATECDK            VARCHAR2(2);     --都道府県コード(企業)
  vSTATENAMEK          VARCHAR2(300);   --都道府県名(企業)
  vCITYNAMEK           VARCHAR2(300);   --市町村区名(企業)
  vADDRESS1NAME        VARCHAR2(1500);
  vADDRESS2NAME        VARCHAR2(900);
  vJIGYOSHONAME        VARCHAR2(900);

  vCOUNTK              NUMBER(15);
  vCOUNTK2             NUMBER(15);
  vCOUNTK3             NUMBER(15);
  vCOUNTK4             NUMBER(15);
  vCOUNTK5             NUMBER(15);
  vCOUNTK6             NUMBER(15);

  --CD_VAL
  PROGRAM_ID           CONSTANT VARCHAR2(30) := 'BAT-CSG04-0601-01';   --郵便番号マスタ登録
  ERR_CONTEXT20        CONSTANT VARCHAR2(64) := 'エラーメッセージあり';   --エラー内容
  ERR_CONTEXT10        CONSTANT VARCHAR2(64) := '警告メッセージあり';     --エラー内容

BEGIN
  --開始メッセージ
  dbms_output.put_line('郵便番号マスタ登録を開始します。');

  --PLSQL用のログ出力DIRの取得
  --PLSQL用のログ出力ファイル名の取得

  --開始時バックグラウンド処理
  CSG05_0101_PKG.csg05_proc_bg_process_upd(INPUT_PROCESS_ID, '1',null,null,null,null,vRESULT_CD);
  IF vRESULT_CD = '20' THEN
    dbms_output.put_line('処理ステータスの更新に失敗しました。処理を中断します。');
    RAISE PRAM_EXCEPTION;
  END IF;

  --入力チェック
  IF FUNC_REQUIRED_CHK(INPUT_USERID) = 1 THEN
    DBMS_OUTPUT.PUT_LINE('ユーザIDは必須入力です。');
    RAISE PRAM_EXCEPTION;
  END IF;
  IF FUNC_REQUIRED_CHK(INPUT_PROCESS_ID) = 1 THEN
    dbms_output.put_line('処理IDは必須入力です。');
    RAISE PRAM_EXCEPTION;
  END IF;

  --トランザクション開始
  LOCK TABLE CSG_P_POSTAL_CODE_WORK IN EXCLUSIVE MODE NOWAIT;

  --重複レコード処理(郵便番号全国一般)
  EXECUTE IMMEDIATE 'TRUNCATE TABLE CSG_P_POSTAL_CODE_WORK';

    vPOSTALCD:= '0';
    vERROR:= '';
    vKIGYO_FLAG:= 'N';

    --一つの郵便番号で二以上の町域を表す場合の表示＝"1"の場合
    FOR REC IN (
    SELECT * FROM CSG_P_POSTAL_CODE_IPPAN WHERE FLAG4 = '1' ORDER BY POSTAL_CD
    ) LOOP

    IF vPOSTALCD <> REC.POSTAL_CD OR vPOSTALCD = '0' THEN
       vPOSTALCD:= REC.POSTAL_CD;
       vSTATENAME:= REC.STATE_NAME;
       vSTATENAME_KANA:= REC.STATE_NAME_KANA;
       vCITYNAME:= REC.CITY_NAME;
       vCITYNAME_KANA:= REC.CITY_NAME_KANA;
       vADDRESSNAME:= REC.ADDRESS_NAME;
       vADDRESSNAME_KANA:= REC.ADDRESS_NAME_KANA;
       vPOSTALCDFULL:= TO_CHAR(vPOSTALCD,'FM0000000');
       vPOSTALCD3:= SUBSTR(vPOSTALCDFULL,1,3);
       vPOSTALCD4:= SUBSTR(vPOSTALCDFULL,4,4);
       vPOSTALCD5:= vPOSTALCD3||'-'||vPOSTALCD4;
       vKOKYOCD:= TO_CHAR(REC.KOKYO_CD,'FM00000');
       vSTATECD:= SUBSTR(vKOKYOCD,1,2);

      SELECT COUNT(*) INTO VCOUNT FROM CSG_P_POSTAL_CODE_IPPAN WHERE FLAG4 = '1' AND POSTAL_CD = vPOSTALCD;
      SELECT COUNT(*) INTO VCOUNT2 FROM CSG_P_POSTAL_CODE_IPPAN WHERE FLAG4 = '1' AND POSTAL_CD = vPOSTALCD AND STATE_NAME = vSTATENAME;
      SELECT COUNT(*) INTO VCOUNT3 FROM CSG_P_POSTAL_CODE_IPPAN WHERE FLAG4 = '1' AND POSTAL_CD = vPOSTALCD AND STATE_NAME = vSTATENAME AND CITY_NAME = vCITYNAME;
      SELECT COUNT(*) INTO vCOUNT4 FROM CSG_P_POSTAL_CODE_IPPAN WHERE FLAG4 = '1' AND POSTAL_CD = vPOSTALCD AND STATE_NAME = vSTATENAME AND CITY_NAME = vCITYNAME AND ADDRESS_NAME = vADDRESSNAME;

      --都道府県名以降全てNull
      IF vCOUNT <> vCOUNT2 THEN
        vSTATENAME:= NULL;
        vSTATENAME_KANA:= NULL;
        vCITYNAME:= NULL;
        vCITYNAME_KANA:= NULL;
        vADDRESSNAME:= NULL;
        vADDRESSNAME_KANA:= NULL;
        vKOKYOCD:= NULL;
        vSTATECD:= NULL;

      --市町村名以降全てNull
      ELSIF vCOUNT2 <> vCOUNT3 THEN
        vCITYNAME:= NULL;
        vCITYNAME_KANA:= NULL;
        vADDRESSNAME:= NULL;
        vADDRESSNAME_KANA:= NULL;
        vKOKYOCD:= NULL;

      --町域名以降Null
      ELSIF vCOUNT3 <> vCOUNT4 then
        vADDRESSNAME:= NULL;
        vADDRESSNAME_KANA:= NULL;
      END IF;

      INSERT INTO CSG_P_POSTAL_CODE_WORK(
              POSTAL_CD,
              POSTAL_CD_WITH_HYPHEN,
              POSTAL_CD_3,
              POSTAL_CD_4,
              STATE_NAME,
              STATE_NAME_KANA,
              CITY_NAME,
              CITY_NAME_KANA,
              ADDRESS1_NAME,
              ADDRESS1_NAME_KANA,
              KIGYO_FLAG,
              KOKYO_CD,
              STATE_CD,
              PROGRAM_ID,
              PROCESS_ID,
              CREATION_USER_ID,
              UPDATE_USER_ID)
      VALUES(
              vPOSTALCDFULL,
              vPOSTALCD5,
              vPOSTALCD3,
              vPOSTALCD4,
              vSTATENAME,
              TO_MULTI_BYTE(vSTATENAME_KANA),
              vCITYNAME,
              TO_MULTI_BYTE(vCITYNAME_KANA),
              vADDRESSNAME,
              TO_MULTI_BYTE(vADDRESSNAME_KANA),
              vKIGYO_FLAG,
              vKOKYOCD,
              vSTATECD,
              PROGRAM_ID,
              INPUT_PROCESS_ID,
              INPUT_USERID,
              INPUT_USERID);

    END IF;
    END LOOP;

   --一つの郵便番号で二以上の町域を表す場合の表示="0"で、町域の名称が複数行にわたって登録されている場合
   vPOSTALCD2:= '0';

   FOR REC2 IN (
   SELECT * FROM CSG_P_POSTAL_CODE_IPPAN WHERE FLAG4 = '0' ORDER BY POSTAL_CD
   ) LOOP

   IF vPOSTALCD2 <> REC2.POSTAL_CD OR vPOSTALCD2 = '0' THEN
     vPOSTALCD2:= REC2.POSTAL_CD;
     SELECT COUNT(*) INTO vCOUNT4 FROM CSG_P_POSTAL_CODE_IPPAN WHERE FLAG4 = '0' AND POSTAL_CD = vPOSTALCD2;
     IF vCOUNT4 >= 2 then
       vPOSTALCDFULL:= TO_CHAR(vPOSTALCD2,'FM0000000');
       vPOSTALCD3:= SUBSTR(vPOSTALCDFULL,1,3);
       vPOSTALCD4:= SUBSTR(vPOSTALCDFULl,4,4);
       vPOSTALCD5:= vPOSTALCD3||'-'||vPOSTALCD4;
       vKOKYOCD:= TO_CHAR(REC2.KOKYO_CD,'FM00000');
       vSTATECD:= SUBSTR(vKOKYOCD,1,2);
       vADDRESSNAME:= '0';
       vADDRESSNAME_KANA:= '0';

       BEGIN
       FOR REC3 IN (SELECT * FROM CSG_P_POSTAL_CODE_IPPAN WHERE POSTAL_CD = vPOSTALCD2 AND FLAG4='0' ORDER BY POSTAL_CD)
       LOOP
         IF vADDRESSNAME = '0' THEN
           vADDRESSNAME := REC3.ADDRESS_NAME;
         ELSIF vADDRESSNAME <> REC3.ADDRESS_NAME THEN
           vADDRESSNAME := vADDRESSNAME||REC3.ADDRESS_NAME;
         END IF;

         IF vADDRESSNAME_KANA = '0' THEN
           vADDRESSNAME_KANA:= REC3.ADDRESS_NAME_KANA;
         ELSIF vADDRESSNAME_KANA <> REC3.ADDRESS_NAME_KANA THEN
           vADDRESSNAME_KANA:= vADDRESSNAME_KANA||REC3.ADDRESS_NAME_KANA;
         END IF;
       END LOOP;
       EXCEPTION
        WHEN VALUE_ERROR then
          IF vERROR IS NOT NULL THEN
            VERROR:= vERROR || 'chr(10)';
          END IF;
          vERROR:= vERROR ||
                   vPOSTALCDFULL || ',' ||
                   vPOSTALCD5 || ',' ||
                   vPOSTALCD3 || ',' ||
                   vPOSTALCD4 || ',' ||
                   REC2.STATE_NAME || ',' ||
                   TO_MULTI_BYTE(REC2.STATE_NAME_KANA) || ',' ||
                   REC2.CITY_NAME || ',' ||
                   TO_MULTI_BYTE(REC2.CITY_NAME_KANA) || ',' ||
                   vADDRESSNAME || ',' ||
                   TO_MULTI_BYTE(vADDRESSNAME_KANA) || ',' ||
                   null || ',' ||
                   NULL || ',' ||
                   vKIGYO_FLAG || ',' ||
                   vKOKYOCD || ',' ||
                   vSTATECD || ',' ||
                   PROGRAM_ID || ',' ||
                   INPUT_PROCESS_ID || ',' ||
                   sysdate || ',' ||
                   INPUT_USERID || ',' ||
                   sysdate || ',' ||
                   INPUT_USERID;
            vERRORFLAG:= '3'; --3:警告終了
            vERRORPOSTAL:= REC2.POSTAL_CD;
        CONTINUE;
       END;

         BEGIN
         INSERT INTO CSG_P_POSTAL_CODE_WORK(
               POSTAL_CD,
               POSTAL_CD_WITH_HYPHEN,
               POSTAL_CD_3,
               POSTAL_CD_4,
               STATE_NAME,
               STATE_NAME_KANA,
               CITY_NAME,
               CITY_NAME_KANA,
               ADDRESS1_NAME,
               ADDRESS1_NAME_KANA,
               KIGYO_FLAG,
               KOKYO_CD,
               STATE_CD,
               PROGRAM_ID,
               PROCESS_ID,
               CREATION_USER_ID,
               UPDATE_USER_ID)
         VALUES(
               vPOSTALCDFULL,
               vPOSTALCD5,
               vPOSTALCD3,
               vPOSTALCD4,
               REC2.STATE_NAME,
               TO_MULTI_BYTE(REC2.STATE_NAME_KANA),
               REC2.CITY_NAME,
               TO_MULTI_BYTE(REC2.CITY_NAME_KANA),
               vADDRESSNAME,
               vADDRESSNAME_KANA,
               vKIGYO_FLAG,
               vKOKYOCD,
               vSTATECD,
               PROGRAM_ID,
               INPUT_PROCESS_ID,
               INPUT_USERID,
               INPUT_USERID);
        EXCEPTION
        WHEN VALUE_ERROR THEN
          IF vERROR IS NOT NULL THEN
            vERROR:= vERROR || 'chr(10)';
          END IF;
          vERROR:= vERROR ||
                   vPOSTALCDFULL || ',' ||
                   vPOSTALCD5 || ',' ||
                   vPOSTALCD3 || ',' ||
                   vPOSTALCD4 || ',' ||
                   REC2.STATE_NAME || ',' ||
                   TO_MULTI_BYTE(REC2.STATE_NAME_KANA) || ',' ||
                   REC2.CITY_NAME || ',' ||
                   TO_MULTI_BYTE(REC2.CITY_NAME_KANA) || ',' ||
                   vADDRESSNAME || ',' ||
                   TO_MULTI_BYTE(vADDRESSNAME_KANA) || ',' ||
                   null || ',' ||
                   NULL || ',' ||
                   vKIGYO_FLAG || ',' ||
                   vKOKYOCD || ',' ||
                   vSTATECD || ',' ||
                   PROGRAM_ID || ',' ||
                   INPUT_PROCESS_ID || ',' ||
                   sysdate || ',' ||
                   INPUT_USERID || ',' ||
                   sysdate || ',' ||
                   INPUT_USERID;
            vERRORFLAG:= '3'; --3:警告終了

        WHEN DUP_VAL_ON_INDEX THEN
          IF vERROR IS NOT NULL THEN
            vERROR:= vERROR || 'chr(10)';
          END IF;
          vERROR:= vERROR ||
                   vPOSTALCDFULL || ',' ||
                   vPOSTALCD5 || ',' ||
                   vPOSTALCD3 || ',' ||
                   vPOSTALCD4 || ',' ||
                   REC2.STATE_NAME || ',' ||
                   TO_MULTI_BYTE(REC2.STATE_NAME_KANA) || ',' ||
                   REC2.CITY_NAME || ',' ||
                   TO_MULTI_BYTE(REC2.CITY_NAME_KANA) || ',' ||
                   vADDRESSNAME || ',' ||
                   TO_MULTI_BYTE(vADDRESSNAME_KANA) || ',' ||
                   null || ',' ||
                   NULL || ',' ||
                   vKIGYO_FLAG || ',' ||
                   vKOKYOCD || ',' ||
                   vSTATECD || ',' ||
                   PROGRAM_ID || ',' ||
                   INPUT_PROCESS_ID || ',' ||
                   sysdate || ',' ||
                   INPUT_USERID || ',' ||
                   sysdate || ',' ||
                   INPUT_USERID;
            vERRORFLAG:= '3'; --3:警告終了
        END;
     END IF;
   END IF;
   END LOOP;

  --重複レコードがない場合(郵便番号全国一般)
  FOR REC4 IN (
  SELECT * FROM CSG_P_POSTAL_CODE_IPPAN WHERE FLAG4 = '0' ORDER BY POSTAL_CD
  ) LOOP
   vPOSTALCDFULL:= TO_CHAR(REC4.POSTAL_CD,'FM0000000');
   SELECT COUNT(*) INTO VCOUNT FROM CSG_P_POSTAL_CODE_WORK WHERE POSTAL_CD = vPOSTALCDFULL;
    IF vCOUNT = 0 AND REC4.POSTAL_CD <> vERRORPOSTAL THEN
      vPOSTALCD3:= SUBSTR(vPOSTALCDFULL,1,3);
      vPostalcd4:= SUBSTR(vPOSTALCDFULL,4,4);
      vPOSTALCD5:= vPOSTALCD3||'-'||vPOSTALCD4;
      vKOKYOCD:= TO_CHAR(REC4.KOKYO_CD,'FM00000');
      vSTATECD:= SUBSTR(vKOKYOCD,1,2);
      --BEGIN
        INSERT INTO CSG_P_POSTAL_CODE_WORK(
              POSTAL_CD,
              POSTAL_CD_WITH_HYPHEN,
              POSTAL_CD_3,
              POSTAL_CD_4,
              STATE_NAME,
              STATE_NAME_KANA,
              CITY_NAME,
              CITY_NAME_KANA,
              ADDRESS1_NAME,
              ADDRESS1_NAME_KANA,
              ADDRESS2_NAME,
              JIGYOSHO_NAME,
              KIGYO_FLAG,
              KOKYO_CD,
              STATE_CD,
              PROGRAM_ID,
              PROCESS_ID,
              CREATION_USER_ID,
              UPDATE_USER_ID)
        VALUES (
              vPOSTALCDFULL,
              vPOSTALCD5,
              vPOSTALCD3,
              vPOSTALCD4,
              REC4.STATE_NAME,
              TO_MULTI_BYTE(REC4.STATE_NAME_KANA),
              REC4.CITY_NAME,
              TO_MULTI_BYTE(REC4.CITY_NAME_KANA),
              REC4.ADDRESS_NAME,
              TO_MULTI_BYTE(REC4.ADDRESS_NAME_KANA),
              null,
              null,
              vKIGYO_FLAG,
              vKOKYOCD,
              vSTATECD,
              PROGRAM_ID,
              INPUT_PROCESS_ID,
              INPUT_USERID,
              INPUT_USERID);
    ELSIF vCOUNT <> '0' THEN
    SELECT COUNT(*) INTO vCOUNT2 FROM CSG_P_POSTAL_CODE_IPPAN WHERE FLAG4='1' AND POSTAL_CD = REC4.POSTAL_CD;
      IF vCOUNT2 <> '0' THEN
        IF vERROR IS NOT NULL THEN
          vERROR:= vERROR || 'chr(10)';
        END IF;
        vERROR:= vERROR ||
                 vPOSTALCDFULL || ',' ||
                 vPOSTALCD5 || ',' ||
                 vPOSTALCD3 || ',' ||
                 vPOSTALCD4 || ',' ||
                 REC4.STATE_NAME || ',' ||
                 TO_MULTI_BYTE(REC4.STATE_NAME_KANA) || ',' ||
                 REC4.CITY_NAME || ',' ||
                 TO_MULTI_BYTE(REC4.CITY_NAME_KANA) || ',' ||
                 REC4.ADDRESS_NAME || ',' ||
                 TO_MULTI_BYTE(REC4.ADDRESS_NAME_KANA) || ',' ||
                 null || ',' ||
                 NULL || ',' ||
                 vKIGYO_FLAG || ',' ||
                 vKOKYOCD || ',' ||
                 vSTATECD || ',' ||
                 PROGRAM_ID || ',' ||
                 INPUT_PROCESS_ID || ',' ||
                 sysdate || ',' ||
                 INPUT_USERID || ',' ||
                 sysdate || ',' ||
                 INPUT_USERID;
            vERRORFLAG:= '3'; --3:警告終了
      END IF;
    END IF;
  END LOOP;


  --重複レコード処理(郵便番号企業)
  vPOSTALCDK:= '0';
  vKIGYO_FLAG:= 'Y';

  FOR REC5 IN (
  SELECT * FROM CSG_P_POSTAL_CODE_KIGYO ORDER BY POSTAL_CD
  ) LOOP

    IF vPOSTALCDK <> REC5.POSTAL_CD OR vPOSTALCDK = '0' THEN
      vPOSTALCDK:= REC5.POSTAL_CD;
      SELECT COUNT(*) INTO vCOUNTK FROM CSG_P_POSTAL_CODE_KIGYO WHERE POSTAL_CD = vPOSTALCDK;

      vPOSTALCDKFULL:= TO_CHAR(vPOSTALCDK,'FM0000000');
      vPOSTALCDK3:= SUBSTR(vPOSTALCDKFULL,1,3);
      vPOSTALCDK4:= SUBSTR(vPOSTALCDKFULL,4,4);
      vPOSTALCDK5:= vPOSTALCDK3||'-'||vPOSTALCDK4;
      vJISCDK:= TO_CHAR(REC5.JIS_CD,'FM00000');
      vSTATECDK:= SUBSTR(vJISCDK,1,2);

      --重複レコードがある場合(郵便番号企業)
      IF vCOUNTK >= 2 THEN

        vSTATENAMEK:= REC5.STATE_NAME;
        vCITYNAMEK:= REC5.CITY_NAME;
        vADDRESS1NAME:= REC5.ADDRESS1_NAME;
        vADDRESS2NAME:= REC5.ADDRESS2_NAME;
        vJIGYOSHONAME:= REC5.JIGYOSHO_NAME;

        SELECT COUNT(*) INTO vCOUNTK2 FROM CSG_P_POSTAL_CODE_KIGYO WHERE POSTAL_CD = vPOSTALCDK AND STATE_NAME = vSTATENAMEK;
        SELECT COUNT(*) INTO vCOUNTK3 FROM CSG_P_POSTAL_CODE_KIGYO WHERE POSTAL_CD = vPOSTALCDK AND STATE_NAME = vSTATENAMEK AND CITY_NAME = vCITYNAMEK;
        SELECT COUNT(*) INTO vCOUNTK4 FROM CSG_P_POSTAL_CODE_KIGYO WHERE POSTAL_CD = vPOSTALCDK AND STATE_NAME = vSTATENAMEK AND CITY_NAME = vCITYNAMEK AND ADDRESS1_NAME = vADDRESS1NAME;
        SELECT COUNT(*) INTO vCOUNTK5 FROM CSG_P_POSTAL_CODE_KIGYO WHERE POSTAL_CD = vPOSTALCDK AND STATE_NAME = vSTATENAMEK AND CITY_NAME = vCITYNAMEK AND ADDRESS1_NAME = vADDRESS1NAME AND ADDRESS2_NAME = vADDRESS2NAME;
        SELECT COUNT(*) INTO vCOUNTK6 FROM CSG_P_POSTAL_CODE_KIGYO WHERE POSTAL_CD = vPOSTALCDK AND STATE_NAME = vSTATENAMEK AND CITY_NAME = vCITYNAMEK AND ADDRESS1_NAME = vADDRESS1NAME AND ADDRESS2_NAME = vADDRESS2NAME AND JIGYOSHO_NAME = vJIGYOSHONAME;

        --都道府県名以降全てNull
        IF vCOUNTK <> vCOUNTK2 THEN
          vSTATENAMEK:= NULL;
          vCITYNAMEK:= NULL;
          vADDRESS1NAME:= NULL;
          vADDRESS2NAME:= NULL;
          vJIGYOSHONAME:= NULL;
          vJISCDK:= NULL;
          vSTATECDK:= NULL;

        --市町村名以降Null3
        ELSIF vCOUNTK2 <> vCOUNTK3 THEN
          vCITYNAMEK:= NULL;
          vADDRESS1NAME:= NULL;
          vADDRESS2NAME:= NULL;
          vJIGYOSHONAME:= NULL;
          vJISCDK:= NULL;

        --町域名以降Null
        ELSIF vCOUNTK3 <> vCOUNTK4 THEN
          vADDRESS1NAME:= NULL;
          vADDRESS2NAME:= NULL;
          vJIGYOSHONAME:= NULL;

        --番地以降Null
        ELSIF vCOUNTK4 <> vCOUNTK5 THEN
          vADDRESS2NAME:= NULL;
          vJIGYOSHONAME:= NULL;

        --事業所名以降Null
        ELSIF vCOUNTK5 <> vCOUNTK6 THEN
          vJIGYOSHONAME:= NULL;
        END IF;

      INSERT INTO CSG_P_POSTAL_CODE_WORK(
                POSTAL_CD,
                POSTAL_CD_WITH_HYPHEN,
                POSTAL_CD_3,
                POSTAL_CD_4,
                STATE_NAME,
                CITY_NAME,
                ADDRESS1_NAME,
                ADDRESS2_NAME,
                JIGYOSHO_NAME,
                KIGYO_FLAG,
                KOKYO_CD,
                STATE_CD,
                PROGRAM_ID,
                PROCESS_ID,
                CREATION_USER_ID,
                UPDATE_USER_ID)
      VALUES(
                vPOSTALCDKFULL,
                vPOSTALCDK5,
                vPOSTALCDK3,
                vPOSTALCDK4,
                vSTATENAMEK,
                vCITYNAMEK,
                vADDRESS1NAME,
                vADDRESS2NAME,
                vJIGYOSHONAME,
                vKIGYO_FLAG,
                vJISCDK,
                vSTATECDK,
                PROGRAM_ID,
                INPUT_PROCESS_ID,
                INPUT_USERID,
                INPUT_USERID);


      --重複レコードがない場合(郵便番号企業)
      ELSIF vCOUNTK = 1 THEN
       BEGIN
        INSERT INTO CSG_P_POSTAL_CODE_WORK(
              POSTAL_CD,
              POSTAL_CD_WITH_HYPHEN,
              POSTAL_CD_3,
              POSTAL_CD_4,
              STATE_NAME,
              CITY_NAME,
              ADDRESS1_NAME,
              ADDRESS2_NAME,
              JIGYOSHO_NAME,
              KIGYO_FLAG,
              KOKYO_CD,
              STATE_CD,
              PROGRAM_ID,
              PROCESS_ID,
              CREATION_USER_ID,
              UPDATE_USER_ID)
        VALUES (
              vPOSTALCDKFULL,
              vPOSTALCDK5,
              vPOSTALCDK3,
              vPOSTALCDK4,
              REC5.STATE_NAME,
              REC5.CITY_NAME,
              REC5.ADDRESS1_NAME,
              REC5.ADDRESS2_NAME,
              REC5.JIGYOSHO_NAME,
              vKIGYO_FLAG,
              vJISCDK,
              vSTATECDK,
              PROGRAM_ID,
              INPUT_PROCESS_ID,
              INPUT_USERID,
              INPUT_USERID);
       EXCEPTION
       WHEN DUP_VAL_ON_INDEX THEN
        --郵便番号がREC5と一致するレコードの数
        SELECT COUNT(*) INTO vCOUNT FROM CSG_P_POSTAL_CODE_IPPAN WHERE POSTAL_CD = vPOSTALCDK;
        --郵便番号と都道府県名がREC5と一致するレコードの数
        SELECT COUNT(*) INTO vCOUNT2 FROM CSG_P_POSTAL_CODE_IPPAN WHERE POSTAL_CD = vPOSTALCDK AND STATE_NAME = REC5.STATE_NAME;
        --郵便番号と都道府県名と市町村区名がREC5と一致するレコードの数
        SELECT COUNT(*) INTO vCOUNT3 FROM CSG_P_POSTAL_CODE_IPPAN where POSTAL_CD = vPOSTALCDK and STATE_NAME = REC5.STATE_NAME and CITY_NAME = REC5.CITY_NAME;
        --郵便番号と都道府県名と市町村区名と町域名がREC5と一致するレコードの数
        SELECT COUNT(*) INTO vCOUNT4 FROM CSG_P_POSTAL_CODE_IPPAN WHERE POSTAL_CD = vPOSTALCDK AND STATE_NAME = REC5.STATE_NAME AND CITY_NAME = REC5.CITY_NAME AND ADDRESS_NAME = REC5.ADDRESS1_NAME;

        IF vCOUNT = vCOUNT4 THEN
          SELECT STATE_NAME_KANA INTO vSTATENAMEK FROM CSG_P_POSTAL_CODE_IPPAN WHERE POSTAL_CD = vPOSTALCDK AND STATE_NAME = REC5.STATE_NAME;
          SELECT CITY_NAME_KANA INTO vCITYNAMEK FROM CSG_P_POSTAL_CODE_IPPAN WHERE POSTAL_CD = vPOSTALCDK AND STATE_NAME = REC5.STATE_NAME AND CITY_NAME = REC5.CITY_NAME;
          SELECT ADDRESS_NAME_KANA INTO vADDRESSNAME FROM CSG_P_POSTAL_CODE_IPPAN WHERE POSTAL_CD = vPOSTALCDK AND STATE_NAME = REC5.STATE_NAME AND CITY_NAME = REC5.CITY_NAME AND ADDRESS_NAME = REC5.ADDRESS1_NAME;
          UPDATE CSG_P_POSTAL_CODE_WORK
          SET STATE_NAME=REC5.STATE_NAME,
              STATE_NAME_KANA=vSTATENAMEK ,
              CITY_NAME=REC5.CITY_NAME ,
              CITY_NAME_KANA=vCITYNAMEK ,
              ADDRESS1_NAME=REC5.ADDRESS1_NAME ,
              ADDRESS1_NAME_KANA=vADDRESSNAME ,
              KIGYO_FLAG=vKIGYO_FLAG,
              KOKYO_CD=vJISCDK ,
              STATE_CD=vSTATECDK,
              PROGRAM_ID=INPUT_PROCESS_ID,
              UPDATE_USER_ID=INPUT_USERID
          WHERE POSTAL_CD = vPOSTALCDKFULL;
          vERRORFLAG:= '3'; --3:警告終了
        ELSIF vCOUNT <> vCOUNT2 THEN
          UPDATE CSG_P_POSTAL_CODE_WORK
          SET STATE_NAME=null ,
              STATE_NAME_KANA=null ,
              CITY_NAME=null ,
              CITY_NAME_KANA=null ,
              ADDRESS1_NAME=null ,
              ADDRESS1_NAME_KANA=null ,
              KIGYO_FLAG=vKIGYO_FLAG,
              KOKYO_CD=null ,
              STATE_CD=null ,
              PROGRAM_ID=INPUT_PROCESS_ID,
              UPDATE_USER_ID=INPUT_USERID
          WHERE POSTAL_CD = vPOSTALCDKFULL;
          vERRORFLAG:= '3'; --3:警告終了
        ELSIF vCOUNT2 <> vCOUNT3 THEN
          SELECT STATE_NAME_KANA INTO vSTATENAMEK FROM CSG_P_POSTAL_CODE_IPPAN WHERE POSTAL_CD = vPOSTALCDK AND STATE_NAME = REC5.STATE_NAME;
          UPDATE CSG_P_POSTAL_CODE_WORK
          SET STATE_NAME=REC5.STATE_NAME ,
              STATE_NAME_KANA=vSTATENAMEK ,
              CITY_NAME=null ,
              CITY_NAME_KANA=null ,
              ADDRESS1_NAME=null ,
              ADDRESS1_NAME_KANA=null ,
              KIGYO_FLAG=vKIGYO_FLAG,
              KOKYO_CD=null ,
              STATE_CD=vSTATECDK,
              PROGRAM_ID=INPUT_PROCESS_ID,
              UPDATE_USER_ID=INPUT_USERID
          WHERE POSTAL_CD = vPOSTALCDKFULL;
          vERRORFLAG:= '3'; --3:警告終了
        ELSIF vCOUNT3 <> vCOUNT4 THEN
          SELECT STATE_NAME_KANA INTO vSTATENAMEK FROM CSG_P_POSTAL_CODE_IPPAN WHERE POSTAL_CD = VPOSTALCDK AND STATE_NAME = REC5.STATE_NAME;
          SELECT CITY_NAME_KANA INTO vCITYNAMEK FROM CSG_P_POSTAL_CODE_IPPAN WHERE POSTAL_CD = VPOSTALCDK AND STATE_NAME = REC5.STATE_NAME AND CITY_NAME = REC5.CITY_NAME;
          UPDATE CSG_P_POSTAL_CODE_WORK
          SET STATE_NAME=REC5.STATE_NAME ,
              STATE_NAME_KANA=vSTATENAMEK ,
              CITY_NAME=REC5.CITY_NAME ,
              CITY_NAME_KANA=vCITYNAMEK ,
              ADDRESS1_NAME=null ,
              ADDRESS1_NAME_KANA=null ,
              KIGYO_FLAG=vKIGYO_FLAG,
              KOKYO_CD=vJISCDK ,
              STATE_CD=vSTATECDK,
              PROGRAM_ID=INPUT_PROCESS_ID,
              UPDATE_USER_ID=INPUT_USERID
          WHERE POSTAL_CD = vPOSTALCDKFULL;
          vERRORFLAG:= '3'; --3:警告終了
        END IF;
       END;
      END IF;
   END IF;
   END LOOP;

   COMMIT;
  --トランザクション開始
  LOCK TABLE CSG_M_POSTAL_CODE IN EXCLUSIVE MODE NOWAIT;

  --郵便番号マスタの更新処理
  DELETE FROM CSG_M_POSTAL_CODE WHERE KIGYO_FLAG = 'N' OR KIGYO_FLAG = 'Y';

  --レコード追加
  INSERT INTO CSG_M_POSTAL_CODE SELECT * FROM CSG_P_POSTAL_CODE_WORK WHERE KIGYO_FLAG = 'N' or KIGYO_FLAG = 'Y';

  COMMIT;
    IF VERRORFLAG IS NOT NULL THEN
      vIN_RESULT_CD:= vERRORFLAG;
      RESULT_CD:= '10';
    ELSE
      vIN_RESULT_CD:= '2';
      RESULT_CD:= '0';
    END IF;

  IF vIN_RESULT_CD = '3' THEN
  vERRORCONTEXT:= ERR_CONTEXT10;
  END IF;

  --更新時バックグラウンド処理
  CSG05_0101_PKG.CSG05_PROC_BG_PROCESS_UPD(INPUT_PROCESS_ID, vIN_RESULT_CD, SYSDATE, vERRORCONTEXT, VERROR, '-', VRESULT_CD);
  IF vRESULT_CD = '10' OR vRESULT_CD = '20' THEN
    dbms_output.put_line('処理結果の登録に失敗しました。ダウンロード、エラーログ参照ができない可能性がありますので、処理結果を確認してください。');
    RAISE PRAM_EXCEPTION;
  END IF;

  --終了時メッセージ
  dbms_output.put_line('郵便番号マスタ登録が正常終了しました。');

--更新処理中にエラーが発生した場合、ロールバックする
EXCEPTION
WHEN PRAM_EXCEPTION THEN
  RESULT_CD :='20';
WHEN OTHERS THEN
  DBMS_OUTPUT.PUT_LINE('予期せぬエラーが発生しました。');
  RESULT_CD :='20';
  vIN_RESULT_CD :='4';
  ROLLBACK;
  DBMS_OUTPUT.PUT_LINE('ErrCode: ' || SQLCODE) ;
  dbms_output.put_line('ErrMsg : ' || sqlerrm) ;

  vERRORCONTEXT:= ERR_CONTEXT20;
  IF vERROR IS NULL THEN
    vERROR:= sqlerrm;
  ELSE
    vERROR:= vERROR || 'chr(10)' || sqlerrm;
  END IF;

  --更新時バックグラウンド処理
  CSG05_0101_PKG.CSG05_PROC_BG_PROCESS_UPD(INPUT_PROCESS_ID, vIN_RESULT_CD, SYSDATE, vERRORCONTEXT, VERROR, '-', VRESULT_CD);
  IF vRESULT_CD = '10' AND VRESULT_CD = '20' THEN
    DBMS_OUTPUT.PUT_LINE('処理結果の登録に失敗しました。ダウンロード、エラーログ参照ができない可能性がありますので、処理結果を確認してください。');
  END IF;

  RAISE;
END "CSG04_PROC_ZIP_REGISTRATION";
END CSG04_0601_PKG;
