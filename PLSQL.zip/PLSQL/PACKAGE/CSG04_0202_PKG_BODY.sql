CREATE OR REPLACE PACKAGE BODY "CSG04_0202_PKG" AS

  PROCEDURE CSG04_PROC_GROUP (
    --終了コード
    RESULT_CD OUT VARCHAR2 )
    AS
      -----------------------------------------------------------------------------------
      --  定数宣言
      -----------------------------------------------------------------------------------
      vDATE                    DATE := sysdate;
      vSYSDATE                 DATE;
      vLOGDIR                  VARCHAR2(100);
      vLOGFILE                 VARCHAR2(100);
      vUSERID                  VARCHAR2(100);
      vPROCESS_ID              NUMBER(15);
      vRESULT_CD               VARCHAR2(1);
      vIN_RESULT_CD            VARCHAR2(1);
      vLASTPROC                DATE;
      vLASTPROC_TS             TIMESTAMP;
      vERRORCONTEXT            NVARCHAR2(64);
      vERROR                   CLOB;

      vGROUP_NAME              VARCHAR2(150);
      vGROUP_OUTLINE           VARCHAR2(150);
      vSTART_DATE              DATE;
      vEND_DATE                DATE;
      vSECTION_CODE_ACCOUNT    VARCHAR2(10);
      vSECTION_CODE_PERSON     VARCHAR2(10);

      vGROUP_ID                NUMBER(15);
      vGROUP_ID_MAX            NUMBER(15);
      vEMP_CD                  VARCHAR2(10);
      vCOMPETENT_FLG           VARCHAR2(1);
      vDELETE_FLAG             VARCHAR2(1);

      vCOUNT                   NUMBER(15) DEFAULT 0;
      vSETFLG                  NUMBER(1) := 0;
      --KEY_ITEM
      CSG_GENERAL_PROP         CONSTANT VARCHAR2(64) := 'CSG_GENERAL_PROP'; --汎用プロパティ
      CSG_SECTION_CODE_ACCOUNT CONSTANT VARCHAR2(64) := 'CSG_SECTION_CODE_ACCOUNT'; --CTC対象会計部課コード

      --CD_VAL
      PLSQL_LOG_DIR            CONSTANT VARCHAR2(64) := 'PLSQL_LOG_DIR'; --PLSQL用のログ出力DIR用
      PLSQL_LOG_FILE           CONSTANT VARCHAR2(64) := 'PLSQL_LOG_FILE'; --PLSQL用のログ出力ファイル名用
      BATCH_USER               CONSTANT VARCHAR2(64) := 'BATCH_USER'; --バッチユーザ

      CLSFCTN                  CONSTANT VARCHAR2(64) := 'M'; --固定値
      GRP_KEY                  CONSTANT VARCHAR2(64) := 'CSG'; --固定値
      LNG                      CONSTANT VARCHAR2(64) := 'JA'; --固定値
      PROGRAM_ID               CONSTANT VARCHAR2(64) := 'BAT-CSG04-0202-01'; --グループ作成
      ERR_CONTEXT              CONSTANT VARCHAR2(64) := '前回処理日時'; --エラー内容
      ERR_MSG                  CONSTANT VARCHAR2(64) := 'エラーメッセージあり';
      PRAM_EXCEPTION       EXCEPTION;

  BEGIN
    --開始メッセージ
    dbms_output.put_line('グループ作成処理を開始します。');

    --処理開始日時の取得
    SELECT SYSDATE INTO vSYSDATE FROM DUAL;

    --ユーザIDの取得
    SELECT DTL_TXT_SHRT_NM
    INTO vUSERID
    FROM SNV_M_GNRC_SNV
    WHERE KEY_ITEM = CSG_GENERAL_PROP
    AND CLSFCTN = CLSFCTN
    AND GRP_KEY = GRP_KEY
    AND LNG = LNG
    AND CD_VAL = BATCH_USER
    AND VALD_STRT_DT <= vDATE
    AND NVL(VALD_END_DT,vDATE) >= vDATE
    AND NVL(DEL_FLG,'N') <> 'X';

    --開始時バックグラウンド処理(処理IDの取得)
    CSG05_0101_PKG.CSG05_PROC_BG_PROCESS_START(PROGRAM_ID, '-', vSYSDATE, vUSERID, vPROCESS_ID,vRESULT_CD);
    IF vRESULT_CD = '20' THEN
      dbms_output.put_line('処理IDが取得できませんでした。システム管理者に問い合わせてください。');
      RAISE PRAM_EXCEPTION;
    END IF;

    --前回処理日時の取得
    vSETFLG := 2; --更新
    BEGIN
      SELECT PROCESS_DATE
      INTO vLASTPROC
      FROM CSG_T_BATCH_DATE
      WHERE EXC_PROGRAM_ID = PROGRAM_ID
      FOR UPDATE NOWAIT;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
    --取得できなかった場合は「1900/1/1」として保持
      vLASTPROC :='1900/1/1 00:00:00';
      vSETFLG := 1; --追加
    END;

    vLASTPROC_TS :=vLASTPROC;

    --トランザクション開始
    LOCK TABLE CSG_M_GROUP_MANAGEMENT IN EXCLUSIVE MODE NOWAIT;
    LOCK TABLE CSG_M_GROUP_MEMBER IN EXCLUSIVE MODE NOWAIT;

    --グループ管理の最大グループIDを取得
    SELECT NVL (MAX(GROUP_ID),0)
    INTO vGROUP_ID_MAX
    FROM CSG_M_GROUP_MANAGEMENT;

    --組織情報取得
    BEGIN
      FOR REC IN (
        SELECT SMD.DPT_NM,
          SMD.DPT_ABBR,
          SMD.EXP_DPT_CD ,
          SMHADM.HR_DPT_CD,
          SMD.VALD_STRT_DT,
          SMD.VALD_END_DT
        FROM SNV_M_DPT SMD INNER JOIN SNV_M_HR_ACCTG_DPT_MAPPG SMHADM
        ON SMD.EXP_DPT_CD = SMHADM.EXP_DPT_CD
        WHERE SMD.LAST_UPDATE_DATE > vLASTPROC_TS
        AND ((SMD.CMP_CD = 'B000' --CTCT
            AND SMD.DPT_HIER_TP IN ('40','50','60')) --40:部、50:課/グループ、60:SS
            OR SMD.EXP_DPT_CD IN (SELECT CD_VAL
                                  FROM SNV_M_GNRC_SNV
                                  WHERE KEY_ITEM = CSG_SECTION_CODE_ACCOUNT
                                  AND CLSFCTN = CLSFCTN
                                  AND GRP_KEY = GRP_KEY
                                  AND LNG = LNG
                                  AND VALD_STRT_DT <= vDATE
                                  AND NVL(VALD_END_DT,vDATE) >= vDATE
                                  AND NVL(DEL_FLG,'N') <> 'X'))
        AND SMHADM.VALD_FLG = 'Y'
        AND SMHADM.CUR_FLG = 'Y'
      ) LOOP

        --存在チェック
        BEGIN
          SELECT COUNT(REC.DPT_NM)
          INTO vCOUNT
          FROM CSG_M_GROUP_MANAGEMENT
          WHERE SECTION_CODE_ACCOUNT = REC.EXP_DPT_CD
          AND START_DATE = REC.VALD_STRT_DT;
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
          vCOUNT :=0;
        END;

        --取得件数が0件の場合
        IF vCOUNT = 0 THEN
          --グループ最大値の加算
          vGROUP_ID_MAX := vGROUP_ID_MAX + 1;
          --データ追加
          INSERT
          INTO CSG_M_GROUP_MANAGEMENT
            (
              GROUP_ID ,
              GROUP_NAME ,
              GROUP_OUTLINE ,
              START_DATE ,
              END_DATE ,
              SECTION_CODE_ACCOUNT ,
              SECTION_CODE_PERSON ,
              MODEL_CODE ,
              REPLY_TEMPLATE ,
              MAIL_ADDRESS ,
              TEL ,
              PROPRIETY_ADDRESS ,
              EXTENTION_NO ,
              MAIL_STORE ,
              ALERT_MAIL ,
              NON_WORK_NOTICE ,
              WORKDAY_UNDECIDED_FLAG ,
              MAIL_SEND_CHECK ,
              ACCEPT_MONITORING ,
              KANTO_FLAG ,
              STORAGE_SPACE ,
              INSTALL_BASE_USE_FLAG ,
              PROGRAM_ID ,
              PROCESS_ID ,
              CREATION_USER_ID ,
              CREATION_DATE ,
              UPDATE_USER_ID ,
              UPDATE_DATE
            )
            VALUES
            (
              vGROUP_ID_MAX ,
              REC.DPT_NM ,
              REC.DPT_ABBR ,
              REC.VALD_STRT_DT ,
              REC.VALD_END_DT ,
              REC.EXP_DPT_CD ,
              REC.HR_DPT_CD ,
              NULL ,
              NULL ,
              NULL ,
              NULL ,
              NULL ,
              NULL ,
              'N' ,
              'Y' ,
              'N' ,
              'Y' ,
              'N' ,
              'N' ,
              'N' ,
              NULL ,
              'N',
              PROGRAM_ID ,
              vPROCESS_ID ,
              vUSERID ,
              vSYSDATE ,
              vUSERID ,
              vSYSDATE
            );

        ELSE
          --データ更新
          UPDATE CSG_M_GROUP_MANAGEMENT
          SET GROUP_NAME         =REC.DPT_NM ,
            GROUP_OUTLINE        =REC.DPT_ABBR ,
            START_DATE           =REC.VALD_STRT_DT ,
            END_DATE             =REC.VALD_END_DT ,
            SECTION_CODE_PERSON  =REC.HR_DPT_CD ,
            PROGRAM_ID           =PROGRAM_ID ,
            PROCESS_ID           =vPROCESS_ID ,
            UPDATE_USER_ID       =vUSERID ,
            UPDATE_DATE          =vSYSDATE
          WHERE SECTION_CODE_ACCOUNT=REC.EXP_DPT_CD;

        END IF;
      END LOOP;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        vCOUNT :=0;
    END;

    --従業員情報取得
    BEGIN
      FOR REC IN (
        SELECT CMGM.GROUP_ID,
          SME.EMP_CD,
          SMEA.COMPETENT_FLG ,
          SMEA.VALD_STRT_DT ,
          SMEA.VALD_END_DT
        FROM (CSG_M_GROUP_MANAGEMENT CMGM INNER JOIN SNV_M_EMP_AFFLN SMEA
             ON CMGM.SECTION_CODE_ACCOUNT = SMEA.EXP_DPT_CD)
             INNER JOIN SNV_M_EMP SME
             ON SME.EMP_ID = SMEA.EMP_ID
        WHERE SMEA.LAST_UPDATE_DATE > vLASTPROC_TS
        AND CMGM.SECTION_CODE_ACCOUNT IS NOT NULL

      ) LOOP

        --存在チェック
        BEGIN
          SELECT COUNT(REC.GROUP_ID)
          INTO vCOUNT
          FROM CSG_M_GROUP_MEMBER
          WHERE EMPLOYEE_ID = REC.EMP_CD
          AND GROUP_ID = REC.GROUP_ID ;
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
          vCOUNT := 0;
        END;

        --取得件数が0件の場合
        IF vCOUNT = 0 THEN
          --データ追加判定
          IF REC.VALD_STRT_DT <= vSYSDATE AND REC.VALD_END_DT >= vSYSDATE THEN
            --データ追加
            INSERT
            INTO CSG_M_GROUP_MEMBER
              (
                EMPLOYEE_ID ,
                GROUP_ID ,
                PRIMARY_FLAG ,
                DELETE_FLAG ,
                PROGRAM_ID ,
                PROCESS_ID ,
                CREATION_USER_ID ,
                CREATION_DATE ,
                UPDATE_USER_ID ,
                UPDATE_DATE
              )
              VALUES
              (
                REC.EMP_CD ,
                REC.GROUP_ID ,
                REC.COMPETENT_FLG ,
                'N' ,
                PROGRAM_ID ,
                vPROCESS_ID ,
                vUSERID ,
                vSYSDATE ,
                vUSERID ,
                vSYSDATE
              ) ;
          END IF;
        ELSE
          --削除フラグの判定
          IF REC.VALD_STRT_DT <= vSYSDATE AND REC.VALD_END_DT >= vSYSDATE THEN
            vDELETE_FLAG :='N';
          ELSE
            vDELETE_FLAG :='Y';
          END IF;

          --データ更新
          UPDATE CSG_M_GROUP_MEMBER
          SET PRIMARY_FLAG       =REC.COMPETENT_FLG ,
            DELETE_FLAG          =vDELETE_FLAG ,
            PROGRAM_ID           =PROGRAM_ID ,
            PROCESS_ID           =vPROCESS_ID ,
            UPDATE_USER_ID       =vUSERID ,
            UPDATE_DATE          =vSYSDATE
          WHERE EMPLOYEE_ID = REC.EMP_CD
          AND GROUP_ID = REC.GROUP_ID
          AND NVL(BATCH_EXEMPT_FLAG,'N') <> 'Y' ;

        END IF;
      END LOOP;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
      vCOUNT :=0;
    END;

    --前回処理日時更新
    IF vSETFLG = 1 THEN
      --データ追加
      INSERT
      INTO CSG_T_BATCH_DATE
        (
          EXC_PROGRAM_ID ,
          PROCESS_DATE ,
          PROGRAM_ID ,
          PROCESS_ID ,
          CREATION_USER_ID ,
          CREATION_DATE ,
          UPDATE_USER_ID ,
          UPDATE_DATE
        )
        VALUES
        (
          PROGRAM_ID ,
          vSYSDATE ,
          PROGRAM_ID ,
          vPROCESS_ID ,
          vUSERID ,
          vSYSDATE ,
          vUSERID ,
          vSYSDATE
        );

    ELSE
      --データ更新
      UPDATE CSG_T_BATCH_DATE
      SET PROCESS_DATE       =vSYSDATE ,
        PROGRAM_ID           =PROGRAM_ID ,
        PROCESS_ID           =vPROCESS_ID ,
        UPDATE_USER_ID       =vUSERID ,
        UPDATE_DATE          =vSYSDATE
      WHERE EXC_PROGRAM_ID = PROGRAM_ID ;

    END IF;

    COMMIT;
    RESULT_CD :='0';
    vERRORCONTEXT := to_char(vLASTPROC);
    vERROR := to_char(vLASTPROC);
    IF RESULT_CD = '0' THEN
      vIN_RESULT_CD :='2';
      vERRORCONTEXT :=ERR_CONTEXT;
    END IF;

    --更新時バックグラウンド処理
    CSG05_0101_PKG.CSG05_PROC_BG_PROCESS_UPD(vPROCESS_ID, vIN_RESULT_CD, SYSDATE, vERRORCONTEXT, vERROR, '', vRESULT_CD);
    IF vRESULT_CD = '20' THEN
      dbms_output.put_line('処理結果の登録に失敗しました。ダウンロード、エラーログ参照ができない可能性がありますので、処理結果を確認してください。');
      RAISE PRAM_EXCEPTION;
    END IF;

     --終了時メッセージ
    dbms_output.put_line('グループ作成処理が正常終了しました。');

  EXCEPTION
  WHEN PRAM_EXCEPTION THEN
    RESULT_CD :='20';
  WHEN OTHERS THEN
    RESULT_CD :='20';
    vIN_RESULT_CD :='4';
    ROLLBACK;
    dbms_output.put_line('ErrCode: ' || SQLCODE) ;
    dbms_output.put_line('ErrMsg : ' || sqlerrm) ;

    vERRORCONTEXT :=ERR_CONTEXT || ' ' || ERR_MSG;
    vERROR :=to_char(vLASTPROC) || ' ' || sqlerrm;

    --更新時バックグラウンド処理
    CSG05_0101_PKG.CSG05_PROC_BG_PROCESS_UPD(vPROCESS_ID, vIN_RESULT_CD, SYSDATE, vERRORCONTEXT, vERROR, '', vRESULT_CD);
    IF vRESULT_CD = '20' THEN
      dbms_output.put_line('処理結果の登録に失敗しました。ダウンロード、エラーログ参照ができない可能性がありますので、処理結果を確認してください。');
    END IF;
    RAISE;
  END CSG04_PROC_GROUP;
END CSG04_0202_PKG;