CREATE OR REPLACE PACKAGE BODY "CSG02_0302_PKG" AS 
/*******************************************************************************
* 設置機器更新(契約起動)_要サポートフラグ更新移行
*-------------------------------------------------------------------------------
* <更新履歴>
* <Version>   <日付>      <更新概要>                             <更新者>
*   1.0     2016/04/06      新規                                FOCUS_LTMINH
*   1.01    2016/05/17      修正                                FOCUS_AOKI
*******************************************************************************/
  /*****************************************************************************
  * 設置機器更新(契約起動)_要サポートフラグ更新（PL/SQL）
  * CSG02-0302 (MAIN)
  *****************************************************************************/
  g_shori_point                 VARCHAR2(250);    -- 処理ポイント

  PROCEDURE MAIN_CSG02_0302
  (
    RETURN_PROCESS_ID  OUT VARCHAR2 ,--処理ID
    RETURN_STATUS      OUT VARCHAR2 ,--ステータス
    RETURN_ERR_CONTENT OUT VARCHAR2 ,--エラー内容
    RETURN_ERR_DETAIL  OUT VARCHAR2 ,--エラー詳細
    RETURN_RESULT_CD   OUT VARCHAR2  -- 終了コード (0  ：正常終了コード  ／  '20' ：異常終了コード)
  )
  AS
    BATCH_USER_ID             NVARCHAR2(250);
    P_EXCEPTION               EXCEPTION;
    P_BATCH_PROCESS_DATE      DATE;
  BEGIN
    g_shori_point := 'MAIN_CSG02_0302';
    -- *************************************************************************
    -- 0.1.システム日時の取得
    -- システム日時を取得する。
    -- *************************************************************************
    P_BATCH_PROCESS_DATE := sysdate;

    -- *************************************************************************
    -- 0.2.バッチ実行ユーザID 取得
    -- 汎用マスタより、バッチ実行ユーザIDを取得する。
    -- *************************************************************************
    SELECT SNV_M_GNRC_SNV.DTL_TXT_FRML_NM
      INTO BATCH_USER_ID
      FROM SNV_M_GNRC_SNV
     WHERE SNV_M_GNRC_SNV.KEY_ITEM = 'CSG_GENERAL_PROP' --(汎用プロパティ)
       AND SNV_M_GNRC_SNV.CD_VAL = 'BATCH_USER';        --(バッチ実行ユーザID)
    
    -- *************************************************************************
    -- 0.3.処理IDの取得
    -- 開始時バックグラウンド処理を呼び出す。
    -- *************************************************************************
    CSG05_0101_PKG.CSG05_PROC_BG_PROCESS_START(
                                'BAT-CSG02-0302-01'
                                , '-' 
                                , P_BATCH_PROCESS_DATE
                                , BATCH_USER_ID
                                , RETURN_PROCESS_ID
                                , RETURN_RESULT_CD
                              );
    
    -- *************************************************************************
    -- 処理結果 = "20"（異常終了）の場合
    -- エラーメッセージ[MSG-CSG-F-0003]をログ出力し、後続の処理を中断する。
    -- *************************************************************************
    IF RETURN_RESULT_CD = '20' THEN
        DBMS_OUTPUT.PUT_LINE('処理IDが取得できませんでした。システム管理者に問い合わせてください。');
        RAISE P_EXCEPTION;
    END IF;

    /***************************************************************************
    * 設置機器更新(契約起動)_要サポートフラグ更新（PL/SQL）
    * CSG02-0302
    ***************************************************************************/
    CSG02_PROC_SUPPORT_FLAG_UPDATE(
                                    BATCH_USER_ID,
                                    P_BATCH_PROCESS_DATE,
                                    RETURN_PROCESS_ID,
                                    RETURN_STATUS,
                                    RETURN_ERR_CONTENT,
                                    RETURN_ERR_DETAIL,
                                    RETURN_RESULT_CD
                                  );

    /***************************************************************************
    * 14_バッチ設計_1408050_終了時バックグラウンド処理（PL/SQL）
    * BAT-CSG05-0101-02
    ***************************************************************************/
    CSG05_0101_PKG.CSG05_PROC_BG_PROCESS_UPD(
                                              RETURN_PROCESS_ID,
                                              RETURN_STATUS,
                                              P_BATCH_PROCESS_DATE,
                                              RETURN_ERR_CONTENT,
                                              RETURN_ERR_DETAIL,
                                              '-',
                                              RETURN_RESULT_CD
                                            );
    -- *************************************************************************
    -- 処理結果 ≠ 0（正常終了でない）の場合
    -- エラーメッセージ[MSG-CSG-W-0033]をログ出力し、呼び出し元に警告終了コードを返却する
    -- *************************************************************************
    IF RETURN_RESULT_CD <> '0' THEN
        DBMS_OUTPUT.PUT_LINE('処理結果の登録に失敗しました。ダウンロード、エラーログ参照ができない可能性がありますので、処理結果を確認してください。');
        RETURN_RESULT_CD   := '10';
        RETURN_STATUS      := '2';
    END IF;

    EXCEPTION
      WHEN P_EXCEPTION THEN
        RETURN_RESULT_CD   := '20';
        RETURN_STATUS      := '3';
        RETURN_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
        RETURN_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
        ROLLBACK;
        RETURN;
      -- その他未定義の例外の処理
      WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('ORACLE ERR_CODE    := ' || SQLCODE);          -- ＤＢエラーコード
        DBMS_OUTPUT.PUT_LINE('ORACLE ERR_MESSAGE := ' || SQLERRM(SQLCODE)); -- ＤＢエラーメッセージ
        DBMS_OUTPUT.PUT_LINE('PROC POINT         := ' || g_shori_point);    -- 処理ポイント
        RETURN_RESULT_CD   := '20';
        RETURN_STATUS      := '3';-- 3:エラー
        RETURN_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
        RETURN_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
        ROLLBACK;
        RETURN;
  END MAIN_CSG02_0302;

  /*****************************************************************************
  * 設置機器更新(契約起動)_要サポートフラグ更新（PL/SQL）
  * CSG02-0502
  *****************************************************************************/
  PROCEDURE CSG02_PROC_SUPPORT_FLAG_UPDATE
  (
    INPUT_USER_ID             IN NVARCHAR2,   --ユーザID
    INPUT_BATCH_PROCESS_DATE  DATE,           -- 処理開始日時
    INPUT_PROCESS_ID          IN VARCHAR2,    -- プロセスID
    RETURN_STATUS             OUT VARCHAR2 ,  --ステータス
    RETURN_ERR_CONTENT        OUT VARCHAR2 ,  --エラー内容
    RETURN_ERR_DETAIL         OUT VARCHAR2 ,  --エラー詳細
    RETURN_RESULT_CD          OUT VARCHAR2    -- 終了コード
  )
  AS
  -- ***************************************************************************
  -- 処理パラメータ
  -- ***************************************************************************
    P_PLACE_HOLDER            VARCHAR2(100);                              -- プレースホルダパラメータ
    P_EXCEPTION               EXCEPTION;
    P_BATCH_PROCESS_DATE      DATE;
    P_INSTANCE_ID             CSG_M_IB_INFO.INSTANCE_ID%type;
    P_TOP_INSTANCE_ID         CSG_M_IB_INFO.TOP_INSTANCE_ID%type;
    OUT_INSTANCE_ID           CSG_M_IB_INFO.INSTANCE_ID%type DEFAULT NULL; -- インスタンス番号
    OUT_UPDATE_DATE           CSG_M_IB_INFO.UPDATE_DATE%type ;             -- 更新日時  
    tIB_BASE                  ARRAY_IB_BASE;
    i_CUR_ROWCOUNT            NUMBER(1);

  --****************************************************************************
  -- 1.1.契約データ取得
  -- 契約情報ビューより契約データを取得する
  --****************************************************************************
    CURSOR cur_V_IB_CNTRCT (PROCESS_DATE DATE) IS
      SELECT INSTANCE_ID             -- インスタンス番号
           , CNTRCT_END_DT       -- 契約終了日
        FROM CSG_T_V_IB_CNTRCT V1    -- 契約情報ビュー
       WHERE CNTRCT_END_DT < PROCESS_DATE
         AND CNTRCT_END_DT > ADD_MONTHS ( PROCESS_DATE , -1 )
         AND CNTRCT_STS_CD IN('ENTRY', 'CONCLUDED', 'EXPRIRED')--('作成中', '締結済', '満了済')
         AND NOT EXISTS(
                        SELECT 1 FROM CSG_T_V_IB_CNTRCT V2
                         WHERE CNTRCT_END_DT >= PROCESS_DATE
                           AND CNTRCT_STS_CD IN('CONCLUDED','EXPRIRED')--('締結済','満了済')
                           AND V1.CNTRCT_NO = V2.CNTRCT_NO --*** 契約番号(仮)
                      );
      row_V_IB_CNTRCT cur_V_IB_CNTRCT%ROWTYPE;

  --****************************************************************************
  -- 3.1.サポート期間切れ情報取得
  -- 設置機器情報よりサポート期間切れのデータを取得する。
  --**************************************************************************** 
  CURSOR cur_CSG_M_IB_INFO (EXECUTE_DATE DATE) IS
    SELECT INSTANCE_ID            -- インスタンス番号
         , PARENT_INSTANCE_ID        -- 親インスタンス番号
         , TOP_INSTANCE_ID           -- 最上位インスタンス番号
         , SUPPORT_INSTRUCT_CODE     -- 要サポートフラグ
         , SUPPORT_START_DATE        -- 要サポート開始日
         , SUPPORT_END_DATE          -- 要サポート終了日
         , UPDATE_DATE               -- 更新日時
      FROM CSG_M_IB_INFO            -- 設置機器情報
     WHERE SUPPORT_END_DATE < TO_DATE(EXECUTE_DATE);
    row_CSG_M_IB_INFO cur_CSG_M_IB_INFO%ROWTYPE;

  BEGIN
    --initialize
    g_shori_point       := 'CSG02_PROC_SUPPORT_FLAG_UPDATE';
    RETURN_STATUS       := 0;
    RETURN_ERR_CONTENT  :='';
    RETURN_ERR_DETAIL   :='';
    RETURN_RESULT_CD    :='0';
    i_CUR_ROWCOUNT      := 0;

    --バッチ処理日設定
    IF INPUT_BATCH_PROCESS_DATE IS NULL THEN
        P_BATCH_PROCESS_DATE := sysdate;
    ELSE
        P_BATCH_PROCESS_DATE := INPUT_BATCH_PROCESS_DATE;
    END IF;

  --↓↓2.要サポート情報更新↓↓************************************************************************
    OPEN cur_V_IB_CNTRCT(P_BATCH_PROCESS_DATE);
    LOOP
        FETCH cur_V_IB_CNTRCT INTO row_V_IB_CNTRCT;
        EXIT WHEN cur_V_IB_CNTRCT%NOTFOUND;
        i_CUR_ROWCOUNT      := 1;

        --************************************************************************
        -- 1.3.設置機器情報取得
        --************************************************************************
        P_PLACE_HOLDER :='設置機器情報取得';
        BEGIN
          SELECT INSTANCE_ID           -- インスタンス番号
            , TOP_INSTANCE_ID          -- 最上位インスタンス番号
          INTO P_INSTANCE_ID
            , P_TOP_INSTANCE_ID
          FROM CSG_M_IB_INFO           -- 設置機器情報
          WHERE INSTANCE_ID = row_V_IB_CNTRCT.INSTANCE_ID --[1.1.]で取得したインスタンス番号
            AND IB_SYNC_STATUS = '10009'           -- IBステータスが「Normal」
            AND SUPPORT_INSTRUCT_CODE  IS NULL     -- 要サポートフラグがNULL
            AND OUT_SOURCING_FLAG <> 'Y2';         -- 外注フラグが「取次コールなし」
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            RETURN_RESULT_CD   := '20';
            RETURN_STATUS      := '3';-- 呼び出し元機能のステータス 3:エラー
            RETURN_ERR_CONTENT := P_PLACE_HOLDER || 'に失敗しました。';
            RETURN_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
            ROLLBACK;
            RETURN;
        END;

        --************************************************************************
        -- 2.2.設置機器情報の設定
        -- 対象データを設置機器情報に設定する。
        --************************************************************************
        P_PLACE_HOLDER := '設置機器情報の設定';
        tIB_BASE := NEW ARRAY_IB_BASE(
                                      NEW CONTACT_IB_BASE_OBJ('SUPPORT_START_DATE', row_V_IB_CNTRCT.CNTRCT_END_DT + 1),          -- 要サポート開始日
                                      NEW CONTACT_IB_BASE_OBJ('SUPPORT_END_DATE', ADD_MONTHS(row_V_IB_CNTRCT.CNTRCT_END_DT, 1)), -- 要サポート終了日
                                      NEW CONTACT_IB_BASE_OBJ('SUPPORT_INSTRUCT_CODE', 'E')                                          -- 要サポートフラグ
                                    );

        --************************************************************************
        -- 2.3.設置機器・共通テーブル追加更新APIのコール
        -- 設置機器・共通テーブル追加更新APIを呼び出す
        --************************************************************************
        P_PLACE_HOLDER   := '設置機器・設置機器共通情報更新';
        CSG02_IB_COMMON_PKG.CSG02_PROC_IB_TABLE_UPDATE(
                                                        10
                                                        , row_V_IB_CNTRCT.INSTANCE_ID
                                                        , P_TOP_INSTANCE_ID
                                                        , tIB_BASE
                                                        , NULL
                                                        , 'BAT-CSG02-0302-01'
                                                        , INPUT_PROCESS_ID
                                                        , INPUT_USER_ID
                                                        , 'N'
                                                        , NULL
                                                        , RETURN_RESULT_CD
                                                        , RETURN_ERR_CONTENT
                                                        , OUT_INSTANCE_ID
                                                        , OUT_UPDATE_DATE
                                                      );
        CASE 
          WHEN RETURN_RESULT_CD = 0  THEN --正常
            NULL;--nop
          ELSE    --その他エラー
            RAISE P_EXCEPTION;
        END CASE;

    END LOOP;    
    CLOSE cur_V_IB_CNTRCT;
    COMMIT;
  --↑↑2.要サポート情報更新↑↑************************************************************************

  --↓↓3.要サポートフラグクリア処理↓↓************************************************************************
    IF i_CUR_ROWCOUNT = 1 THEN--要サポート情報更新 処理件数＝０件のとき、処理しない
        OPEN cur_CSG_M_IB_INFO(P_BATCH_PROCESS_DATE);
        LOOP
            FETCH cur_CSG_M_IB_INFO INTO row_CSG_M_IB_INFO;
            --************************************************************************
            -- 3.2.取得件数チェック
            --************************************************************************
            EXIT WHEN cur_CSG_M_IB_INFO%NOTFOUND;

            --************************************************************************
            -- 3.3.設置機器情報の設定
            -- 対象データを設置機器情報に設定する。
            --************************************************************************
            P_PLACE_HOLDER := '設置機器情報の設定';
            tIB_BASE := NEW ARRAY_IB_BASE(
                                          NEW CONTACT_IB_BASE_OBJ('SUPPORT_START_DATE', NULL),    -- 要サポート開始日
                                          NEW CONTACT_IB_BASE_OBJ('SUPPORT_END_DATE', NULL),      -- 要サポート終了日
                                          NEW CONTACT_IB_BASE_OBJ('SUPPORT_INSTRUCT_CODE', NULL)  -- 要サポートフラグ
                                        );

            --************************************************************************
            -- 3.4.設置機器・共通テーブル追加更新APIのコール
            -- 設置機器・共通テーブル追加更新APIを呼び出す。
            --************************************************************************
            P_PLACE_HOLDER   := '設置機器・設置機器共通情報更新';
            CSG02_IB_COMMON_PKG.CSG02_PROC_IB_TABLE_UPDATE(
                                                            10
                                                            , row_CSG_M_IB_INFO.INSTANCE_ID
                                                            , row_CSG_M_IB_INFO.TOP_INSTANCE_ID
                                                            , tIB_BASE
                                                            , NULL
                                                            , 'BAT-CSG02-0302-01'
                                                            , INPUT_PROCESS_ID
                                                            , INPUT_USER_ID
                                                            , 'N'
                                                            , NULL
                                                            , RETURN_RESULT_CD
                                                            , RETURN_ERR_CONTENT
                                                            , OUT_INSTANCE_ID
                                                            , OUT_UPDATE_DATE
                                                          );

            CASE 
              WHEN RETURN_RESULT_CD = 0  THEN --正常
                NULL;--nop
              ELSE    --その他エラー
                RAISE P_EXCEPTION;
            END CASE;

        END LOOP;
        CLOSE cur_CSG_M_IB_INFO;
        COMMIT;
    END IF;
  --↑↑3.要サポートフラグクリア処理↑↑************************************************************************

    RETURN_STATUS := '1'; -- 1：正常終了
  EXCEPTION
      WHEN P_EXCEPTION THEN
        -- データの取得に失敗した場合、エラーメッセージ[]をログ出力し、後続の処理を中断する。
        --DBMS_OUTPUT.PUT_LINE(P_PLACE_HOLDER || 'に失敗しました。');
        RETURN_RESULT_CD   := '20';--'20' ：異常終了コード
        RETURN_STATUS      := '3' ;-- 3:エラー
        RETURN_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
        ROLLBACK;
        RETURN;  

      -- その他未定義の例外の処理
      WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('ORACLE ERR_CODE    := ' || SQLCODE);            -- ＤＢエラーコード
        DBMS_OUTPUT.PUT_LINE('ORACLE ERR_MESSAGE := ' || SQLERRM(SQLCODE));   -- ＤＢエラーメッセージ
        DBMS_OUTPUT.PUT_LINE('PROC POINT         := ' || g_shori_point);      -- 処理ポイント      
        RETURN_RESULT_CD := '20';
        RETURN_STATUS      := '3';-- 3:エラー
        RETURN_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
        RETURN_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
        ROLLBACK;
        RETURN;
    END CSG02_PROC_SUPPORT_FLAG_UPDATE;

END CSG02_0302_PKG;

/
