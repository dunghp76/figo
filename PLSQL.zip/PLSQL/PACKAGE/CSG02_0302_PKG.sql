CREATE OR REPLACE PACKAGE "CSG02_0302_PKG"
AS
/*******************************************************************************
* 設置機器更新(契約起動)_要サポートフラグ更新移行
*-------------------------------------------------------------------------------
* <更新履歴>
* <Version>   <日付>      <更新概要>                             <更新者>
*   1.0     2016/04/06      新規                                FOCUS_LTMINH
*   1.01    2016/05/16      修正                                FOCUS_AOKI
*******************************************************************************/
  /*****************************************************************************
  * 設置機器更新(契約起動)_要サポートフラグ更新（PL/SQL）
  * CSG02-0302 (MAIN)
  *****************************************************************************/
  PROCEDURE MAIN_CSG02_0302
  (
    RETURN_PROCESS_ID  OUT VARCHAR2 ,--処理ID
    RETURN_STATUS      OUT VARCHAR2 ,--ステータス
    RETURN_ERR_CONTENT OUT VARCHAR2 ,--エラー内容
    RETURN_ERR_DETAIL  OUT VARCHAR2 ,--エラー詳細
    RETURN_RESULT_CD   OUT VARCHAR2  -- 終了コード (0  ：正常終了コード  ／  '20' ：異常終了コード)
  );

  /*****************************************************************************
  * 設置機器更新(契約起動)_要サポートフラグ更新（PL/SQL）
  * CSG02-0302
  *****************************************************************************/
  PROCEDURE CSG02_PROC_SUPPORT_FLAG_UPDATE
  (
    INPUT_USER_ID             IN NVARCHAR2,   -- ユーザID
    INPUT_BATCH_PROCESS_DATE  DATE,           -- 処理開始日時
    INPUT_PROCESS_ID          IN VARCHAR2,    -- プロセスID
    RETURN_STATUS             OUT VARCHAR2 ,  --ステータス
    RETURN_ERR_CONTENT        OUT VARCHAR2 ,  --エラー内容
    RETURN_ERR_DETAIL         OUT VARCHAR2 ,  --エラー詳細
    RETURN_RESULT_CD          OUT VARCHAR2    -- 終了コード
  );

END CSG02_0302_PKG;
/
