CREATE OR REPLACE PACKAGE BODY "CSG02_0303_PKG" AS
/*******************************************************************************
* 設置機器更新(契約起動)_ワランティ切れ自動更新移行
*-------------------------------------------------------------------------------
* <更新履歴>
* <Version>   <日付>      <更新概要>                             <更新者>
*   1.0     2016/04/07      新規                                FOCUS_LTMINH
*   1.01    2016/05/16      修正                                FOCUS_AOKI
*******************************************************************************/
  /*****************************************************************************
  * 設置機器更新(契約起動)_ワランティ切れ自動更新（PL/SQL）
  * CSG02-0303 (MAIN)
  *****************************************************************************/
  g_shori_point                 VARCHAR2(250);    -- 処理ポイント

  PROCEDURE MAIN_CSG02_0303
  (
    RETURN_PROCESS_ID  OUT VARCHAR2 ,--処理ID
    RETURN_STATUS      OUT VARCHAR2 ,--ステータス
    RETURN_ERR_CONTENT OUT VARCHAR2 ,--エラー内容
    RETURN_ERR_DETAIL  OUT VARCHAR2 ,--エラー詳細
    RETURN_RESULT_CD   OUT VARCHAR2  -- 終了コード (0  ：正常終了コード  ／  '20' ：異常終了コード)
  )
  AS
    PRAGMA AUTONOMOUS_TRANSACTION;
    P_BATCH_USER_ID             NVARCHAR2(250);
    P_EXCEPTION                 EXCEPTION;
    P_BATCH_PROCESS_DATE        DATE;

  BEGIN
    g_shori_point := 'MAIN_CSG02_0303';
    -- *************************************************************************
    -- 0.1.システム日時の取得
    -- システム日時を取得する。
    -- *************************************************************************
    P_BATCH_PROCESS_DATE := SYSDATE;
    -- *************************************************************************
    -- 0.2.バッチ実行ユーザID 取得
    -- 汎用マスタより、バッチ実行ユーザIDを取得する。
    -- *************************************************************************
    SELECT SNV_M_GNRC_SNV.DTL_TXT_FRML_NM
    INTO P_BATCH_USER_ID
    FROM SNV_M_GNRC_SNV
    WHERE SNV_M_GNRC_SNV.KEY_ITEM = 'CSG_GENERAL_PROP'--(汎用プロパティ)
      AND SNV_M_GNRC_SNV.CD_VAL = 'BATCH_USER';       --(バッチ実行ユーザID)

    -- *************************************************************************
    -- 0.3.処理IDの取得
    -- 開始時バックグラウンド処理を呼び出す。
    -- *************************************************************************
    CSG05_0101_PKG.CSG05_PROC_BG_PROCESS_START
    (
      'BAT-CSG02-0303-01'
      , '-' 
      , P_BATCH_PROCESS_DATE
      , P_BATCH_USER_ID
      , RETURN_PROCESS_ID
      , RETURN_RESULT_CD
    );
    -- *************************************************************************
    -- 処理結果 = "20"（異常終了）の場合
    -- エラーメッセージ[MSG-CSG-F-0003]をログ出力し、後続の処理を中断する。
    -- *************************************************************************
    IF RETURN_RESULT_CD = '20' THEN
        DBMS_OUTPUT.PUT_LINE('処理IDが取得できませんでした。システム管理者に問い合わせてください。');
        RAISE P_EXCEPTION;
    END IF;

    /***************************************************************************
    * 設置機器更新(契約起動)_ワランティ切れ自動更新（PL/SQL）
    * CSG02-0303
    ***************************************************************************/
    CSG02_PROC_WAR_BROKEN_AUTO_UPD
    (
      P_BATCH_PROCESS_DATE,     -- バッチ処理日
      P_BATCH_USER_ID,          -- ユーザID
      RETURN_PROCESS_ID,        -- 処理ID
      RETURN_STATUS,            -- ステータス
      RETURN_ERR_CONTENT,       -- エラー内容
      RETURN_ERR_DETAIL,        -- エラー詳細
      RETURN_RESULT_CD          -- 終了コード
    );

    /***************************************************************************
    * 14_バッチ設計_1408050_終了時バックグラウンド処理（PL/SQL）
    * BAT-CSG05-0101-02
    ***************************************************************************/
    CSG05_0101_PKG.CSG05_PROC_BG_PROCESS_UPD
    (
      RETURN_PROCESS_ID,
      RETURN_STATUS,
      P_BATCH_PROCESS_DATE,
      RETURN_ERR_CONTENT,
      RETURN_ERR_DETAIL,
      '-',
      RETURN_RESULT_CD
    );
    -- *************************************************************************
    -- 処理結果 ≠ 0（正常終了でない）の場合
    -- エラーメッセージ[MSG-CSG-W-0033]をログ出力し、呼び出し元に警告終了コードを返却する
    -- *************************************************************************
    IF RETURN_RESULT_CD <> '0' THEN
        DBMS_OUTPUT.PUT_LINE('処理結果の登録に失敗しました。ダウンロード、エラーログ参照ができない可能性がありますので、処理結果を確認してください。');
        RETURN_RESULT_CD   := '10';
        RETURN_STATUS      := '2';
    END IF;

    EXCEPTION
      WHEN P_EXCEPTION THEN
        RETURN_RESULT_CD   := '20';
        RETURN_STATUS      := '3';
        RETURN_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
        RETURN_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
        ROLLBACK;
        RETURN;
      -- その他未定義の例外の処理
      WHEN OTHERS THEN
        RETURN_RESULT_CD := '20';
        DBMS_OUTPUT.PUT_LINE('ORACLE ERR_CODE    := ' || SQLCODE);          -- ＤＢエラーコード
        DBMS_OUTPUT.PUT_LINE('ORACLE ERR_MESSAGE := ' || SQLERRM(SQLCODE)); -- ＤＢエラーメッセージ
        DBMS_OUTPUT.PUT_LINE('PROC POINT         := ' || g_shori_point);    -- 処理ポイント
        RETURN_STATUS      := '3';
        RETURN_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
        RETURN_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
        ROLLBACK;
        RETURN;
  END MAIN_CSG02_0303;

  /*****************************************************************************
  * 設置機器更新(契約起動)_ワランティ切れ自動更新（PL/SQL）
  * CSG02-0303
  *****************************************************************************/
  PROCEDURE CSG02_PROC_WAR_BROKEN_AUTO_UPD
  (
    INPUT_BATCH_PROCESS_DATE  IN DATE DEFAULT NULL,-- バッチ処理日
    INPUT_USER_ID             IN NVARCHAR2,        -- ユーザID
    INPUT_PROCESS_ID          IN VARCHAR2,         -- 処理ID
    RETURN_STATUS             OUT VARCHAR2 ,       --ステータス
    RETURN_ERR_CONTENT        OUT VARCHAR2 ,       --エラー内容
    RETURN_ERR_DETAIL         OUT VARCHAR2 ,       --エラー詳細
    RETURN_RESULT_CD          OUT VARCHAR2         -- 終了コード (0  ：正常終了コード  ／  '20' ：異常終了コード)
  )
  AS
  -- ***************************************************************************
  -- 処理パラメータ
  -- ***************************************************************************
    P_PLACE_HOLDER           VARCHAR2(100);  -- プレースホルダパラメータ
    P_MASTER_EXCEPTION       EXCEPTION;
    P_EXCEPTION              EXCEPTION;
    P_BATCH_PROCESS_DATE     DATE;
    OUT_INSTANCE_ID          CSG_M_IB_INFO.INSTANCE_ID%type DEFAULT NULL; -- インスタンス番号
    OUT_UPDATE_DATE          CSG_M_IB_INFO.UPDATE_DATE%type ;             -- 更新日時
    tIB_BASE                 ARRAY_IB_BASE;

    --**************************************************************************
    -- 1.1.期限切れデータの取得
    -- 以下の条件に合致するデータを取得する。
    --**************************************************************************
    CURSOR cur_CSG_M_IB_INFO (PROCESS_DATE DATE) IS
       SELECT INSTANCE_ID,                  -- インスタンス番号
              PARENT_INSTANCE_ID,           -- 親インスタンス番号
              TOP_INSTANCE_ID,              -- 最上位インスタンス番号
              SERVICE_CONDITION,            -- サービス形態
              FIRST_COVERAGE,               -- 初回ワランティ条件
              FIRST_END_DATE,               -- 初回期間(至)
              NEXT_COVERAGE,                -- 次回ワランティ条件
              NEXT_END_DATE                 -- 次回期間(至)
        FROM CSG_M_IB_INFO
        WHERE CSG_M_IB_INFO.SERVICE_CONDITION IN ('W','S','T','B','U')
          AND ((CSG_M_IB_INFO.FIRST_END_DATE < PROCESS_DATE
              AND CSG_M_IB_INFO.NEXT_END_DATE IS NULL)
           OR CSG_M_IB_INFO.NEXT_END_DATE < PROCESS_DATE);

          row_CSG_M_IB_INFO cur_CSG_M_IB_INFO%ROWTYPE;
    --**************************************************************************
    -- 3.1次回ワランティ更新データ取得
    -- 以下の条件に合致するデータを取得する。
    --**************************************************************************
    CURSOR CUR_INSTALL_BASE_INFO (PROCESS_DATE DATE) IS
      SELECT IBI.INSTANCE_ID                               -- インスタンス番号
        , IBI.PARENT_INSTANCE_ID                           -- 親インスタンス番号
        , IBI.TOP_INSTANCE_ID                              -- 最上位インスタンス番号
        , SNVE.PARM2                                       -- 汎用マスタ．パラメータ２
      FROM CSG_M_IB_INFO IBI                               -- 設置機器情報
      INNER JOIN SNV_M_GNRC_ERP  SNVE                      -- 汎用マスタ（ERP）
        ON SNVE．CLSFCTN = 'V'                             -- 分類
          AND SNVE.GRP_KEY = 'MATERIAL'                    -- グループキー
          AND SNVE.KEY_ITEM = 'ZMMDENEXT_WT_COND'          -- キー項目 = 次回ワランティ条件
          AND SNVE.VALD_STRT_DT <= PROCESS_DATE            -- 有効開始日
          AND NVL(SNVE.VALD_END_DT,PROCESS_DATE) >= PROCESS_DATE -- 有効終了日
          AND NVL(SNVE.DEL_FLG,'N') <> 'X'                 -- 削除フラグ
          AND SNVE.CD_VAL = IBI.NEXT_COVERAGE              -- コード値＝設置.次回ワランティ条件
          AND SNVE.PARM2 <> IBI.SERVICE_CONDITION          -- 汎用マスタ．パラメータ２
      WHERE IBI.SERVICE_CONDITION IN ('W','S','T','B','U')
        AND IBI.FIRST_END_DATE < PROCESS_DATE              -- 初回ワランティ終了日 ＜ バッチ処理日
        AND PROCESS_DATE <= IBI.NEXT_END_DATE;             -- バッチ処理日 ≦ 次回ワランティ終了日  

        row_INSTALL_BASE_INFO cur_INSTALL_BASE_INFO%ROWTYPE;

  BEGIN
    --initialize
    g_shori_point       := 'CSG02_PROC_WAR_BROKEN_AUTO_UPD';
    RETURN_STATUS       := 0;
    RETURN_ERR_CONTENT  := '';
    RETURN_ERR_DETAIL   := '';
    RETURN_RESULT_CD    := '0';

    --バッチ処理日設定
    IF INPUT_BATCH_PROCESS_DATE IS NULL THEN
      P_BATCH_PROCESS_DATE := SYSDATE;
    ELSE
      P_BATCH_PROCESS_DATE := INPUT_BATCH_PROCESS_DATE;
    END IF;

  -- ↓↓初回ワランティ切れ更新処理↓↓************************************************************************
    OPEN cur_CSG_M_IB_INFO(P_BATCH_PROCESS_DATE);
    LOOP
        P_PLACE_HOLDER :='期限切れデータの取得';
        FETCH cur_CSG_M_IB_INFO INTO row_CSG_M_IB_INFO;
        --************************************************************************
        -- 1.2.取得件数チェック
        --取得件数が0件の場合、処理３に遷移する。
        --************************************************************************
        EXIT WHEN cur_CSG_M_IB_INFO%NOTFOUND;

        --************************************************************************
        -- 2.2.設置機器情報の設定
        -- 対象データを設置機器情報に設定する。
        --************************************************************************
        P_PLACE_HOLDER :='設置機器情報の設定';
        tIB_BASE := NEW ARRAY_IB_BASE(NEW CONTACT_IB_BASE_OBJ('SERVICE_CONDITION', 'O')); --'"O"(ワランティ切れ) サービス形態

        --************************************************************************
        -- 2.3.設置機器・共通テーブル追加更新APIのコール
        -- 設置機器・共通テーブル追加更新APIを呼び出す
        --************************************************************************

        P_PLACE_HOLDER   := '設置機器・設置機器共通情報更新';
        CSG02_IB_COMMON_PKG.CSG02_PROC_IB_TABLE_UPDATE(
                                                        10
                                                        , row_CSG_M_IB_INFO.INSTANCE_ID
                                                        , row_CSG_M_IB_INFO.TOP_INSTANCE_ID
                                                        , tIB_BASE
                                                        , NULL
                                                        , 'BAT-CSG02-0303-01'
                                                        , INPUT_PROCESS_ID
                                                        , INPUT_USER_ID
                                                        , 'N'
                                                        , NULL
                                                        , RETURN_RESULT_CD
                                                        , RETURN_ERR_CONTENT
                                                        , OUT_INSTANCE_ID
                                                        , OUT_UPDATE_DATE
                                                      );
        CASE 
          WHEN RETURN_RESULT_CD = 0  THEN --正常
            NULL;--nop
          WHEN RETURN_RESULT_CD = 21 THEN --マスタ存在チェックエラーの場合
            RAISE P_MASTER_EXCEPTION;
          ELSE    --その他エラー
            RAISE P_EXCEPTION;
        END CASE;
    END LOOP;
    CLOSE cur_CSG_M_IB_INFO;
    COMMIT;
  -- ↑↑初回ワランティ切れ更新処理↑↑************************************************************************

  -- ↓↓次回ワランティ切れ更新処理↓↓************************************************************************
    --**********************************************************************
    -- 3.次回ワランティ更新データ取得
    --**********************************************************************
    OPEN cur_INSTALL_BASE_INFO(P_BATCH_PROCESS_DATE);
    LOOP
        P_PLACE_HOLDER :='期限切れデータの取得';
        FETCH cur_INSTALL_BASE_INFO INTO row_INSTALL_BASE_INFO; 
        --********************************************************************
        -- 3.2.取得件数チェック
        -- 取得件数が0件の場合、処理５に遷移する
        --********************************************************************
        EXIT WHEN cur_INSTALL_BASE_INFO%NOTFOUND;

        --********************************************************************
        -- 4.2.設置機器情報の設定
        -- 対象データを設置機器情報に設定する。
        --********************************************************************
        P_PLACE_HOLDER := '設置機器情報の設定';
        tIB_BASE := NEW ARRAY_IB_BASE(NEW CONTACT_IB_BASE_OBJ('SERVICE_CONDITION', row_INSTALL_BASE_INFO.PARM2)); --[3.1.]で取得した汎用マスタ．パラメータ２ サービス形態

        --********************************************************************
        -- 4.3.設置機器・共通テーブル追加更新APIのコール
        -- 設置機器・共通テーブル追加更新APIを呼び出す
        --********************************************************************
        P_PLACE_HOLDER   := '設置機器・設置機器共通情報更新';
        CSG02_IB_COMMON_PKG.CSG02_PROC_IB_TABLE_UPDATE(
                                                        10
                                                        , row_INSTALL_BASE_INFO.INSTANCE_ID
                                                        , row_INSTALL_BASE_INFO.TOP_INSTANCE_ID
                                                        , tIB_BASE
                                                        , NULL
                                                        , 'BAT-CSG02-0303-01'
                                                        , INPUT_PROCESS_ID
                                                        , INPUT_USER_ID
                                                        , 'N'
                                                        , NULL
                                                        , RETURN_RESULT_CD
                                                        , RETURN_ERR_CONTENT
                                                        , OUT_INSTANCE_ID
                                                        , OUT_UPDATE_DATE
                                                      );
        CASE 
          WHEN RETURN_RESULT_CD = 0  THEN --正常
            NULL;--nop
          WHEN RETURN_RESULT_CD = 21 THEN --マスタ存在チェックエラーの場合
            RAISE P_MASTER_EXCEPTION;
          ELSE    --その他エラー
            RAISE P_EXCEPTION;
        END CASE;
    END LOOP;
    CLOSE cur_INSTALL_BASE_INFO;
    COMMIT;
  -- ↑↑次回ワランティ切れ更新処理↑↑************************************************************************

    -- 1：正常終了
    RETURN_STATUS := '1';

    EXCEPTION
      WHEN P_MASTER_EXCEPTION THEN --マスタ存在チェックエラーの場合
        DBMS_OUTPUT.PUT_LINE('更新できなかったレコードが存在します。 インスタンス番号：' || OUT_INSTANCE_ID || '  エラー内容:' || RETURN_ERR_CONTENT);
        RETURN_RESULT_CD   := '20';--'20' ：異常終了コード
        RETURN_STATUS      := '3' ;-- 3:エラー
        RETURN_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
        ROLLBACK;
        RETURN;  
      WHEN P_EXCEPTION THEN
        -- データの取得に失敗した場合、エラーメッセージ[]をログ出力し、後続の処理を中断する。
        --DBMS_OUTPUT.PUT_LINE(P_PLACE_HOLDER || 'に失敗しました。');
        RETURN_RESULT_CD   := '20';--'20' ：異常終了コード
        RETURN_STATUS      := '3' ;-- 3:エラー
        RETURN_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
        ROLLBACK;
        RETURN;  
      -- その他未定義の例外の処理
      WHEN OTHERS THEN
        -- データの取得に失敗した場合、エラーメッセージ[]をログ出力し、後続の処理を中断する。
        DBMS_OUTPUT.PUT_LINE(P_PLACE_HOLDER || 'に失敗しました。');
        DBMS_OUTPUT.PUT_LINE('ORACLE ERR_CODE    := ' || SQLCODE);            -- ＤＢエラーコード
        DBMS_OUTPUT.PUT_LINE('ORACLE ERR_MESSAGE := ' || SQLERRM(SQLCODE));   -- ＤＢエラーメッセージ
        DBMS_OUTPUT.PUT_LINE('PROC POINT         := ' || G_SHORI_POINT);      -- 処理ポイント
        RETURN_RESULT_CD   := '20';--'20' ：異常終了コード
        RETURN_STATUS      := '3' ;-- 3:エラー
        RETURN_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
        RETURN_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
        ROLLBACK;
        RETURN;
  END CSG02_PROC_WAR_BROKEN_AUTO_UPD;

END CSG02_0303_PKG;

/
