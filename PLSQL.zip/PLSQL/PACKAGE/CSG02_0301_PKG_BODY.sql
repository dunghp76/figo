CREATE OR REPLACE PACKAGE BODY "CSG02_0301_PKG" AS
/*******************************************************************************
* 設置機器情報中間ワーク移行                                                       *
*-------------------------------------------------------------------------------*
* <更新履歴>                                                                     *
* <Version>   <日付>      <更新概要>                             <更新者>         *
*   1.0     2016/04/01      新規                                FOCUS_LTBINH    *
********************************************************************************/
  g_update_prg_id               VARCHAR2(20);     -- 更新プログラムＩＤ
  g_update_tanto                VARCHAR2(10);     -- 更新者
  g_shori_point                 VARCHAR2(250);    -- 処理ポイント
  set_sysdate                   DATE;             -- システム日時
  g_err_command                 VARCHAR2(250);    -- ＤＢエラーキー
  g_err_key                     VARCHAR2(250);    -- ＤＢエラーキー
  g_target_sel_cnt              NUMBER;           -- 入力定義（設置機器構成情報ワークの単独機器）の読込件数
  g_normal_sel_cnt              NUMBER;           -- 入力定義（設置機器構成情報ワークの単独機器）の読込件数
  g_warnings_sel_cnt            NUMBER;           -- 入力定義（設置機器構成情報ワークの単独機器）の読込件数
  
/*******************************************************************************
* 設置機器登録（出荷実績）（PL/SQL）                                               *
* CSG02_0301 (MAIN)                                                            *
********************************************************************************/
  PROCEDURE MAIN_CSG02_0301(
      INPUT_USER_ID    IN VARCHAR2 ,         --ユーザID
      INPUT_PROCESS_ID IN VARCHAR2 ,         --プロセスID
      RETURN_PROCESS_ID OUT VARCHAR2 ,       --処理ID
      RETURN_STATUS OUT VARCHAR2 ,           --ステータス
      RETURN_ERR_CONTENT OUT NVARCHAR2 ,     --エラー内容
      RETURN_ERR_DETAIL OUT NVARCHAR2 ,       --エラー詳細
      RETURN_RESULT_CD OUT VARCHAR2          --終了コード
    ) AS
  v_DTL_TXT_FRML_NM             SNV_M_GNRC_SNV.DTL_TXT_FRML_NM%TYPE; -- 汎用マスタ.明細テキスト(正式名)（バッチ実行ユーザID）
  PRAM_EXCEPTION                EXCEPTION;                           -- ＤＢエラーパラメータ
  v_PROCESS_ID                  VARCHAR2(15);                        -- 処理ID
  BEGIN
  g_shori_point             := 'MAIN_CSG02_0301';
--******************************************************************************
-- 0.開始処理
-- 0.1.システム日時の取得
-- システム日時を取得する。
--******************************************************************************
  set_sysdate               := SYSDATE;
--******************************************************************************
-- 0.2.バッチ実行ユーザID 取得
-- 汎用マスタより、バッチ実行ユーザIDを取得する。
--******************************************************************************
    SELECT SMGS.DTL_TXT_FRML_NM                  -- 汎用マスタ.明細テキスト(正式名)（バッチ実行ユーザID）
      INTO v_DTL_TXT_FRML_NM
      FROM SNV_M_GNRC_SNV SMGS                   -- 汎用マスタ
     WHERE SMGS.KEY_ITEM   = 'CSG_GENERAL_PROP'  -- 汎用マスタ.コード区分
       AND SMGS.CD_VAL     = 'BATCH_USER';       -- 汎用マスタ.コード値
--******************************************************************************
-- 0.3.処理IDの取得
-- 開始時バックグラウンド処理を呼び出す。
--******************************************************************************
    CSG05_0101_PKG.CSG05_PROC_BG_PROCESS_START(
                                                'BAT-CSG02-0301-01',
                                                INPUT_PROCESS_ID,
                                                set_sysdate,
                                                v_DTL_TXT_FRML_NM,
                                                RETURN_PROCESS_ID,
                                                RETURN_RESULT_CD
                                             );
    v_PROCESS_ID := RETURN_PROCESS_ID;
--******************************************************************************
-- [例外処理]
-- 処理結果 = 1（処理IDを取得できなかった）の場合
-- エラーメッセージ[MSG-CSG-F-0003]をログ出力し、後続の処理を中断する。
--******************************************************************************
    IF RETURN_PROCESS_ID = 1 THEN
      RAISE PRAM_EXCEPTION;
    END IF;
--******************************************************************************
-- 設置機器情報中間ワーク移行
-- CSG02_PROC_INS_EQUIPMENT_REG
--******************************************************************************
    CSG02_PROC_INS_EQUIPMENT_REG(
                                  v_DTL_TXT_FRML_NM,
                                  v_PROCESS_ID,
                                  RETURN_PROCESS_ID,
                                  RETURN_STATUS,
                                  RETURN_ERR_CONTENT,
                                  RETURN_ERR_DETAIL,
                                  RETURN_RESULT_CD
                                );
  
--******************************************************************************
-- 7.終了処理
-- 7.1.実行結果の登録
-- 終了時バックグラウンド処理を呼び出す。
--******************************************************************************
    CSG05_0101_PKG.CSG05_PROC_BG_PROCESS_UPD(
                                v_PROCESS_ID,
                                RETURN_STATUS,
                                set_sysdate,
                                RETURN_ERR_CONTENT,
                                RETURN_ERR_DETAIL,
                                '-',
                                RETURN_RESULT_CD
                               );
  EXCEPTION
    WHEN PRAM_EXCEPTION THEN
      DBMS_OUTPUT.PUT_LINE('処理IDが取得できませんでした。システム管理者に問い合わせてください。');
      RETURN_RESULT_CD := '20';
      --************************************************************************
      -- 呼び出し元機能のステータス
      -- 0:処理中
      -- 1:正常終了
      -- 2:警告終了
      -- 3:エラー
      --************************************************************************
        RETURN_STATUS      := '3';
        RETURN_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
        RETURN_ERR_DETAIL := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
      ROLLBACK;
      RETURN;
    -- その他未定義の例外の処理
    WHEN OTHERS THEN
        RETURN_RESULT_CD := '20';
        DBMS_OUTPUT.PUT_LINE('ORACLE ERR_CODE    := ' || SQLCODE);            -- ＤＢエラーコード
        DBMS_OUTPUT.PUT_LINE('ORACLE ERR_MESSAGE := ' || SQLERRM(SQLCODE));   -- ＤＢエラーメッセージ
        DBMS_OUTPUT.PUT_LINE('PROC POINT         := ' || g_shori_point);      -- 処理ポイント
        IF g_err_command IS NOT NULL THEN
            DBMS_OUTPUT.PUT_LINE(g_err_command);
            DBMS_OUTPUT.PUT_LINE(g_err_key);
        END IF;
      --************************************************************************
      -- 呼び出し元機能のステータス
      -- 0:処理中
      -- 1:正常終了
      -- 2:警告終了
      -- 3:エラー
      --************************************************************************
        RETURN_STATUS      := '3';
        RETURN_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
        RETURN_ERR_DETAIL := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
        ROLLBACK;
        RETURN;
  END MAIN_CSG02_0301;

/*******************************************************************************
* 設置機器登録（出荷実績）（PL/SQL）                                               *
* CSG02-0301                                                                   *
********************************************************************************/
  PROCEDURE CSG02_PROC_INS_EQUIPMENT_REG(
      INPUT_USER_ID    IN VARCHAR2 ,         --ユーザID
      INPUT_PROCESS_ID IN VARCHAR2 ,         --プロセスID
      RETURN_PROCESS_ID OUT VARCHAR2 ,       --処理ID
      RETURN_STATUS OUT VARCHAR2 ,           --ステータス
      RETURN_ERR_CONTENT OUT NVARCHAR2 ,     --エラー内容
      RETURN_ERR_DETAIL OUT NVARCHAR2 ,      --エラー詳細
      RETURN_RESULT_CD OUT VARCHAR2          --終了コード
    ) AS
/*******************************************************************************
* 設置機器情報中間ワーク移行                                                       *
*-------------------------------------------------------------------------------*
* <更新履歴>                                                                     *
* <Version>   <日付>      <更新概要>                             <更新者>         *
*   1.0     2016/03/03      新規                                FOCUS_LTBINH    *
********************************************************************************/
  PRAM_PLACE_HOLDER             VARCHAR2(100);    -- プレースホルダパラメータ
  PRAM_EXCEPTION                EXCEPTION;        -- ＤＢエラーパラメータ
  
  tIB_BASE                      ARRAY_IB_BASE;
  tIB_COMMON                    ARRAY_IB_COMMON;
  tIB_MEMO                      ARRAY_IB_MEMO;
  -- 終了コード
  -- OUT_RESULT_CD                 VARCHAR2(4);      -- 0  ：正常終了コード　／　20 ：異常終了コード
  -- 取得結果
  OUT_RESULT_GET                VARCHAR2(10);     -- OK / NGを返却する
  -- 取得条件
  OUT_CONDITION_GET             VARCHAR2(10);     -- 補足-No.4  を参照　※試験確認用
--******************************************************************************
-- 設置機器情報中間ワークのパラメータ
--******************************************************************************
  p_ID                                CSG_P_IB_INFO_WORK.ID%type ;                                       -- ID
  p_SLIP_NO                           CSG_P_IB_INFO_WORK.SLIP_NO%type ;                                  -- 伝票番号
  p_SLIP_DETAILED_NO                  CSG_P_IB_INFO_WORK.SLIP_DETAILED_NO%type ;                         -- 伝票明細番号
  p_CONSTRUCT_CNT                     CSG_P_IB_INFO_WORK.CONSTRUCT_CNT%type ;                            -- 構成数(SEQ NO)
  p_INSTANCE_ID                       CSG_P_IB_INFO_WORK.INSTANCE_ID%type DEFAULT NULL;                  -- インスタンス番号
  p_PARENT_INVENTORY_ITEM_CODE        CSG_P_IB_INFO_WORK.PARENT_INVENTORY_ITEM_CODE%type ;               -- 親品目コード
  p_PARENT_SERIAL_NO                  CSG_P_IB_INFO_WORK.PARENT_SERIAL_NO%type DEFAULT NULL;             -- 親シリアル番号
  p_INVENTORY_ITEM_CODE               CSG_P_IB_INFO_WORK.INVENTORY_ITEM_CODE%type ;                      -- 品目コード
  p_INVENTORY_ITEM_NAME               CSG_P_IB_INFO_WORK.INVENTORY_ITEM_NAME%type DEFAULT NULL;          -- 品目名
  p_SERIAL_NO                         CSG_P_IB_INFO_WORK.SERIAL_NO%type DEFAULT NULL;                    -- シリアル番号
  p_MAIN_OPTION_TYPE                  CSG_P_IB_INFO_WORK.MAIN_OPTION_TYPE%type DEFAULT NULL;             -- 本体オプション区分
  p_QUANTITY                          CSG_P_IB_INFO_WORK.QUANTITY%type DEFAULT NULL;                     -- 数量
  p_INSTALL_DATE                      CSG_P_IB_INFO_WORK.INSTALL_DATE%type DEFAULT NULL;                 -- 納入日
  p_USER_ACCEPT_DATE                  CSG_P_IB_INFO_WORK.USER_ACCEPT_DATE%type DEFAULT NULL;             -- 客先検収日
  p_CUSTOMER_ORDER_NO                 CSG_P_IB_INFO_WORK.CUSTOMER_ORDER_NO%type DEFAULT NULL;            -- 客先注文番号
  p_MAKER_ORDER_NO                    CSG_P_IB_INFO_WORK.MAKER_ORDER_NO%type DEFAULT NULL;               -- メーカー発注番号
  p_ORDER_NO                          CSG_P_IB_INFO_WORK.ORDER_NO%type DEFAULT NULL;                     -- 受注番号
  p_TRANSFER_FLAG                     CSG_P_IB_INFO_WORK.TRANSFER_FLAG%type DEFAULT NULL;                -- 移管品フラグ
  p_SALES_OWNER_CODE                  CSG_P_IB_INFO_WORK.SALES_OWNER_CODE%type DEFAULT NULL;             -- 販売元
  p_MAINTENANCE_TYPE                  CSG_P_IB_INFO_WORK.MAINTENANCE_TYPE%type DEFAULT NULL;             -- 保守種別
  p_SERVICE_CONDITION                 CSG_P_IB_INFO_WORK.SERVICE_CONDITION%type DEFAULT NULL;            -- サービス形態
  p_OUT_SOURCING_FLAG                 CSG_P_IB_INFO_WORK.OUT_SOURCING_FLAG%type DEFAULT NULL;            -- 外注フラグ
  p_SHIPPING_INSPECTION_FLAG          CSG_P_IB_INFO_WORK.SHIPPING_INSPECTION_FLAG%type DEFAULT NULL;     -- 出荷検査実施フラグ
  p_FIRST_SALE_PARTY_CODE             CSG_P_IB_INFO_WORK.FIRST_SALE_PARTY_CODE%type DEFAULT NULL;        -- 初期販売会社コード
  p_FIRST_SALE_PARTY_LOCATION         CSG_P_IB_INFO_WORK.FIRST_SALE_PARTY_LOCATION%type DEFAULT NULL;    -- 初期販売会社住所
  p_FIRST_SALE_DEPT_CODE              CSG_P_IB_INFO_WORK.FIRST_SALE_DEPT_CODE%type DEFAULT NULL;         -- 初期販売部署コード
  p_FIRST_SALE_TEL                    CSG_P_IB_INFO_WORK.FIRST_SALE_TEL%type DEFAULT NULL;               -- 初期販売会社TEL
  p_FIRST_SALE_FAX                    CSG_P_IB_INFO_WORK.FIRST_SALE_FAX%type DEFAULT NULL;               -- 初期販売会社FAX
  p_FIRST_SALE_PERSON_CODE            CSG_P_IB_INFO_WORK.FIRST_SALE_PERSON_CODE%type DEFAULT NULL;       -- 初期販売担当者コード
  p_FIRST_SALE_MAIL_ADDRESS           CSG_P_IB_INFO_WORK.FIRST_SALE_MAIL_ADDRESS%type DEFAULT NULL;      -- 初期販売メールアドレス
  p_FIRST_COVERAGE                    CSG_P_IB_INFO_WORK.FIRST_COVERAGE%type DEFAULT NULL;               -- 初回ワランティ条件
  p_FIRST_MONTHS                      CSG_P_IB_INFO_WORK.FIRST_MONTHS%type DEFAULT NULL;                 -- 初回ワランティ月数
  p_FIRST_START_DATE                  CSG_P_IB_INFO_WORK.FIRST_START_DATE%type DEFAULT NULL;             -- 初回期間(自)
  p_FIRST_END_DATE                    CSG_P_IB_INFO_WORK.FIRST_END_DATE%type DEFAULT NULL;               -- 初回期間(至)
  p_NEXT_COVERAGE                     CSG_P_IB_INFO_WORK.NEXT_COVERAGE%type DEFAULT NULL;                -- 次回ワランティ条件
  p_NEXT_MONTHS                       CSG_P_IB_INFO_WORK.NEXT_MONTHS%type DEFAULT NULL;                  -- 次回ワランティ月数
  p_NEXT_START_DATE                   CSG_P_IB_INFO_WORK.NEXT_START_DATE%type DEFAULT NULL;              -- 次回期間(自)
  p_NEXT_END_DATE                     CSG_P_IB_INFO_WORK.NEXT_END_DATE%type DEFAULT NULL;                -- 次回期間(至)
  p_AGENT_FLAG                        CSG_P_IB_INFO_WORK.AGENT_FLAG%type DEFAULT NULL;                   -- 販社フラグ
  p_BUNDLE_ITEM_CODE                  CSG_P_IB_INFO_WORK.BUNDLE_ITEM_CODE%type DEFAULT NULL;             -- バンドル品目コード
  p_BUNDLE_SERIAL_NO                  CSG_P_IB_INFO_WORK.BUNDLE_SERIAL_NO%type DEFAULT NULL;             -- バンドルシリアル
  p_INSTALL_CUSTOMER_CODE             CSG_P_IB_INFO_WORK.INSTALL_CUSTOMER_CODE%type DEFAULT NULL;        -- 設置先顧客コード
  p_INSTALL_LOCATION_DEPT_NAME        CSG_P_IB_INFO_WORK.INSTALL_LOCATION_DEPT_NAME%type DEFAULT NULL;   -- 設置先顧客部署名
  p_INSTALL_LOCATION_PERSON_NAME      CSG_P_IB_INFO_WORK.INSTALL_LOCATION_PERSON_NAME%type DEFAULT NULL; -- 設置先顧客担当者名
  p_INSTALL_LOCATION_TEL              CSG_P_IB_INFO_WORK.INSTALL_LOCATION_TEL%type DEFAULT NULL;         -- 設置先TEL
  p_INCIDENT_SERVIRITY_NAME           CSG_P_IB_INFO_WORK.INCIDENT_SERVIRITY_NAME%type DEFAULT NULL;      -- 重要度
  p_KEEP_WATCH_SYSTEM_ID              CSG_P_IB_INFO_WORK.KEEP_WATCH_SYSTEM_ID%type DEFAULT NULL;         -- 監視システムID
  p_USE_CONDITION                     CSG_P_IB_INFO_WORK.USE_CONDITION%type DEFAULT NULL;                -- 利用形態
  p_USE_PERPOSE                       CSG_P_IB_INFO_WORK.USE_PERPOSE%type DEFAULT NULL;                  -- 利用目的
  p_ENDUSER_PARTY_ID                  CSG_P_IB_INFO_WORK.ENDUSER_PARTY_ID%TYPE DEFAULT NULL;             -- エンドユーザ会社コード
  p_ENDUSER_PARTY_NAME_WK             CSG_P_IB_INFO_WORK.ENDUSER_PARTY_NAME%type DEFAULT NULL;           -- エンドユーザ会社名
  p_ENDUSER_LOCATION                  CSG_P_IB_INFO_WORK.ENDUSER_LOCATION%type DEFAULT NULL;             -- エンドユーザ住所
  p_ENDUSER_CHRG_DEPT_NAME            CSG_P_IB_INFO_WORK.ENDUSER_CHRG_DEPT_NAME%type DEFAULT NULL;       -- エンドユーザ部署名
  p_ENDUSER_CHRG_PERSON_NAME          CSG_P_IB_INFO_WORK.ENDUSER_CHRG_PERSON_NAME%type DEFAULT NULL;     -- エンドユーザ担当者名
  p_ENDUSER_TEL                       CSG_P_IB_INFO_WORK.ENDUSER_TEL%type DEFAULT NULL;                  -- エンドユーザTEL
  p_ENDUSER_FAX                       CSG_P_IB_INFO_WORK.ENDUSER_FAX%type DEFAULT NULL;                  -- エンドユーザFAX
  p_ENDUSER_MAIL_ADDRESS              CSG_P_IB_INFO_WORK.ENDUSER_MAIL_ADDRESS%type DEFAULT NULL;         -- エンドユーザメールアドレス
  p_SALES_DEPT_ORG_ID                 CSG_P_IB_INFO_WORK.SALES_DEPT_ORG_ID%type DEFAULT NULL;            -- F営業販売部署コード
  p_SALES_DEPT_PERSON_ID              CSG_P_IB_INFO_WORK.SALES_DEPT_PERSON_ID%type DEFAULT NULL;         -- F営業販売担当者コード
  p_PRESENT_DEPT_ORG_ID               CSG_P_IB_INFO_WORK.PRESENT_DEPT_ORG_ID%type DEFAULT NULL;          -- F営業現在担当部署コード
  p_CTC_SALESREP_PERSON_ID            CSG_P_IB_INFO_WORK.CTC_SALESREP_PERSON_ID%type DEFAULT NULL;       -- F営業現在担当者コード
  p_MAINTE_BUS_DEPT_ORG_ID            CSG_P_IB_INFO_WORK.MAINTE_BUS_DEPT_ORG_ID%type DEFAULT NULL;       -- 保守営業担当部署コード
  p_MAINTE_BUS_PERSON_ID              CSG_P_IB_INFO_WORK.MAINTE_BUS_PERSON_ID%type DEFAULT NULL;         -- 保守営業担当者コード
  p_X_DEPLOY_FLAG                     CSG_P_IB_INFO_WORK.X_DEPLOY_FLAG%type DEFAULT NULL;                -- X配備対象フラグ
  p_ACCEPTANCE_DATE                   CSG_P_IB_INFO_WORK.ACCEPTANCE_DATE%type DEFAULT NULL;              -- 受入日
  p_MEMO                              CSG_P_IB_INFO_WORK.MEMO%type DEFAULT NULL;                         -- メモ
  p_GROUP_PARTY                       CSG_P_IB_INFO_WORK.GROUP_PARTY%type DEFAULT NULL;                  -- グループ会社
  p_KINDS_CODE                        CSG_P_IB_INFO_WORK.KINDS_CODE%type DEFAULT NULL;                   -- 機種コード
  p_SHIPMENT_LOCATION_CODE            CSG_P_IB_INFO_WORK.SHIPMENT_LOCATION_CODE%type DEFAULT NULL;       -- 出荷先コード
  p_PROCESS_FLAG                      CSG_P_IB_INFO_WORK.PROCESS_FLAG%type DEFAULT NULL;                 -- 処理済フラグ
  P_SEND_FLAG                         CSG_P_IB_INFO_WORK.SEND_FLAG%TYPE DEFAULT NULL;                    -- 送信予定フラグ
  p_PROC_MEMO                         CSG_P_IB_INFO_WORK.PROC_MEMO%type DEFAULT NULL;                    -- 処理結果メモ
  p_PROGRAM_ID                        CSG_P_IB_INFO_WORK.PROGRAM_ID%type DEFAULT NULL;                   -- 更新プログラムID
  p_PROCESS_ID                        CSG_P_IB_INFO_WORK.PROCESS_ID%type DEFAULT NULL;                   -- 処理ID
  p_CREATION_USER_ID                  CSG_P_IB_INFO_WORK.CREATION_USER_ID%type ;                         -- 作成者
  p_CREATION_DATE                     CSG_P_IB_INFO_WORK.CREATION_DATE%type ;                            -- 作成日時
  p_UPDATE_USER_ID                    CSG_P_IB_INFO_WORK.UPDATE_USER_ID%type ;                           -- 更新者
  p_update_date                       csg_p_ib_info_work.update_date%type ;                              -- 更新日時
  
  v_ENDUSER_PARTY_ID                  CSG_P_IB_INFO_WORK.ENDUSER_PARTY_ID%TYPE DEFAULT NULL;             -- エンドユーザ会社コード
--******************************************************************************
-- 設置機器情報のパラメータ
--******************************************************************************
  p_INSTANCE_ID_IBI              CSG_M_IB_INFO.INSTANCE_ID%type ;                  -- インスタンス番号
  p_PARENT_INSTANCE_ID_IBI       CSG_M_IB_INFO.PARENT_INSTANCE_ID%type ;           -- 親インスタンス番号
  p_TOP_INSTANCE_ID_IBI          CSG_M_IB_INFO.TOP_INSTANCE_ID%type ;              -- 最上位インスタンス番号
  p_INVENTORY_ITEM_CODE_IBI      CSG_M_IB_INFO.INVENTORY_ITEM_CODE%type ;          -- 品目コード
  p_ORG_ID_IBI                   CSG_M_IB_INFO.ORG_ID%type ;                       -- プラント
  p_INVENTORY_ITEM_NAME_IBI      CSG_M_IB_INFO.INVENTORY_ITEM_NAME%type ;          -- 品目名
  p_SERIAL_NO_IBI                CSG_M_IB_INFO.SERIAL_NO%type DEFAULT NULL;        -- シリアル番号
  p_MAIN_OPTION_TYPE_IBI         CSG_M_IB_INFO.MAIN_OPTION_TYPE%type ;             -- 本体オプション区分
  p_IB_SYNC_STATUS_IBI           CSG_M_IB_INFO.IB_SYNC_STATUS%type ;               -- IBステータス
  p_QUANTITY_IBI                 CSG_M_IB_INFO.QUANTITY%type ;                     -- 数量
  p_INSTALL_DATE_IBI             CSG_M_IB_INFO.INSTALL_DATE%type ;                 -- 納入日
  p_SALES_OWNER_CODE_IBI         CSG_M_IB_INFO.SALES_OWNER_CODE%type ;             -- 販売元
  p_MAINTENANCE_TYPE_IBI         CSG_M_IB_INFO.MAINTENANCE_TYPE%type ;             -- 保守種別
  p_AGENT_FLAG_IBI               CSG_M_IB_INFO.AGENT_FLAG%type ;                   -- 販社フラグ
  p_CREATION_USER_ID_IBI         CSG_M_IB_INFO.CREATION_USER_ID%type ;             -- 作成者
  p_CREATION_DATE_IBI            CSG_M_IB_INFO.CREATION_DATE%type ;                -- 作成日時
  p_UPDATE_USER_ID_IBI           CSG_M_IB_INFO.UPDATE_USER_ID%type ;               -- 更新者
  p_UPDATE_DATE_IBI              CSG_M_IB_INFO.UPDATE_DATE%type ;                  -- 更新日時
  p_BUNDLE_ITEM_NAME_IBI         CSG_M_IB_INFO.BUNDLE_ITEM_NAME%type DEFAULT NULL; -- バンドル品目名
  
--******************************************************************************
-- 設置機器共通情報のパラメータ
--******************************************************************************
  p_TOP_INSTANCE_ID                   CSG_M_IB_COMMON_INFO.TOP_INSTANCE_ID%type ;                          -- 最上位インスタンス番号
  p_CS_IN_CHARGE_CODE                 CSG_M_IB_COMMON_INFO.CS_IN_CHARGE_CODE%type ;                        -- 担当CSコード
  p_CE_CODE                           CSG_M_IB_COMMON_INFO.CE_CODE%type DEFAULT NULL;                      -- 担当CEコード
  p_INSTALL_CUSTOMER_CODE             CSG_M_IB_COMMON_INFO.INSTALL_CUSTOMER_CODE%type ;                    -- 設置先顧客コード
  p_INSTALL_LOCATION_CODE             CSG_M_IB_COMMON_INFO.INSTALL_LOCATION_CODE%type ;                    -- 設置先顧客住所コード
  p_INSTALL_LOCATION_DEPT_NAME        CSG_M_IB_COMMON_INFO.INSTALL_LOCATION_DEPT_NAME%type DEFAULT NULL;   -- 設置先顧客部署名
  p_INSTALL_LOCATION_PERSON_NAME      CSG_M_IB_COMMON_INFO.INSTALL_LOCATION_PERSON_NAME%type DEFAULT NULL; -- 設置先顧客担当者名
  p_INSTALL_LOCATION_TEL              CSG_M_IB_COMMON_INFO.INSTALL_LOCATION_TEL%type DEFAULT NULL;         -- 設置先TEL
  p_INSTALL_LOCATION_FAX              CSG_M_IB_COMMON_INFO.INSTALL_LOCATION_FAX%type DEFAULT NULL;         -- 設置先FAX
  p_INCIDENT_SERVIRITY_NAME           CSG_M_IB_COMMON_INFO.INCIDENT_SERVIRITY_NAME%type ;                  -- 重要度
  p_USE_CONDITION                     CSG_M_IB_COMMON_INFO.USE_CONDITION%type DEFAULT NULL;                -- 利用形態
  p_USE_PERPOSE                       CSG_M_IB_COMMON_INFO.USE_PERPOSE%type DEFAULT NULL;                  -- 利用目的
  p_ENDUSER_PARTY_CODE                CSG_M_IB_COMMON_INFO.ENDUSER_PARTY_CODE%type DEFAULT NULL;           -- エンドユーザ会社コード
  p_ENDUSER_PARTY_NAME                CSG_M_IB_COMMON_INFO.ENDUSER_PARTY_NAME%type DEFAULT NULL;           -- エンドユーザ会社名
  p_ENDUSER_LOCATION                  CSG_M_IB_COMMON_INFO.ENDUSER_LOCATION%type DEFAULT NULL;             -- エンドユーザ住所
  p_ENDUSER_CHRG_DEPT_NAME            CSG_M_IB_COMMON_INFO.ENDUSER_CHRG_DEPT_NAME%type DEFAULT NULL;       -- エンドユーザ部署名
  p_ENDUSER_CHRG_PERSON_NAME          CSG_M_IB_COMMON_INFO.ENDUSER_CHRG_PERSON_NAME%type DEFAULT NULL;     -- エンドユーザ担当者名
  p_ENDUSER_TEL                       CSG_M_IB_COMMON_INFO.ENDUSER_TEL%type DEFAULT NULL;                  -- エンドユーザTEL
  p_ENDUSER_FAX                       CSG_M_IB_COMMON_INFO.ENDUSER_FAX%type DEFAULT NULL;                  -- エンドユーザFAX
  p_ENDUSER_MAIL_ADDRESS              CSG_M_IB_COMMON_INFO.ENDUSER_MAIL_ADDRESS%type DEFAULT NULL;         -- エンドユーザメールアドレス
  p_PROGRAM_ID                        CSG_M_IB_COMMON_INFO.PROGRAM_ID%type DEFAULT NULL;                   -- 更新プログラムID
  p_PROCESS_ID                        CSG_M_IB_COMMON_INFO.PROCESS_ID%type DEFAULT NULL;                   -- 処理ID
  p_CREATION_USER_ID                  CSG_M_IB_COMMON_INFO.CREATION_USER_ID%type ;                         -- 作成者
  p_CREATION_DATE                     CSG_M_IB_COMMON_INFO.CREATION_DATE%type ;                            -- 作成日時
  p_UPDATE_USER_ID                    CSG_M_IB_COMMON_INFO.UPDATE_USER_ID%type ;                           -- 更新者
  p_UPDATE_DATE                       CSG_M_IB_COMMON_INFO.UPDATE_DATE%TYPE ;                              -- 更新日時
--******************************************************************************
-- 設置機器メモ情報のパラメータ
--******************************************************************************
  p_INSTANCE_MEMO_ID_CMIMI           CSG_M_IB_MEMO_INFO.INSTANCE_MEMO_ID%type ;       -- メモID
  p_INSTANCE_ID_CMIMI                CSG_M_IB_MEMO_INFO.INSTANCE_ID%type ;            -- インスタンス番号
  p_MEMO_TYPE_CMIMI                  CSG_M_IB_MEMO_INFO.MEMO_TYPE%type ;              -- メモタイプ
  p_TITLE_CMIMI                      CSG_M_IB_MEMO_INFO.TITLE%type DEFAULT NULL;      -- タイトル
  p_MEMO_CMIMI                       CSG_M_IB_MEMO_INFO.MEMO%type DEFAULT NULL;       -- メモ
  p_SORT_NO_CMIMI                    CSG_M_IB_MEMO_INFO.SORT_NO%type DEFAULT NULL;    -- ソート順
  p_PROGRAM_ID_CMIMI                 CSG_M_IB_MEMO_INFO.PROGRAM_ID%type DEFAULT NULL; -- 更新プログラムID
  p_PROCESS_ID_CMIMI                 CSG_M_IB_MEMO_INFO.PROCESS_ID%type DEFAULT NULL; -- 処理ID
  p_CREATION_USER_ID_CMIMI           CSG_M_IB_MEMO_INFO.CREATION_USER_ID%type ;       -- 作成者
  p_CREATION_DATE_CMIMI              CSG_M_IB_MEMO_INFO.CREATION_DATE%type ;          -- 作成日時
  p_UPDATE_USER_ID_CMIMI             CSG_M_IB_MEMO_INFO.UPDATE_USER_ID%TYPE ;         -- 更新者
  p_UPDATE_DATE_CMIMI                CSG_M_IB_MEMO_INFO.UPDATE_DATE%TYPE ;            -- 更新日時
  
  --****************************************************************************
  -- 汎用マスタ情報のパラメータ
  --****************************************************************************
  p_DTL_TXT_FRML_NM                SNV_M_GNRC_SNV.DTL_TXT_FRML_NM%TYPE ;              -- 明細テキスト(正式名)
  --****************************************************************************
  -- 1.処理対象データの取得(最上位)
  -- 1.1.最上位インスタンスの取得
  -- 以下の条件に合致するデータを設置機器情報中間ワークより取得する。
  --****************************************************************************
CURSOR c_CSG_P_IB_INFO_WORK
IS
  SELECT IBI.INSTANCE_ID AS INSTANCE_ID_IBI,                        -- 設置機器情報テーブルのインスタンス番号（登録済み判定用）
        IBIW.ID,                                                    -- ID
        IBIW.INSTANCE_ID,                                           -- インスタンス番号
        IBIW.PARENT_INVENTORY_ITEM_CODE,                            -- 親品目コード
        IBIW.PARENT_SERIAL_NO,                                      -- 親シリアル番号
        IBIW.INVENTORY_ITEM_CODE,                                   -- 品目コード
        IBIW.INVENTORY_ITEM_NAME,                                   -- 品目名
        IBIW.SERIAL_NO,                                             -- シリアル番号
        IBIW.MAIN_OPTION_TYPE,                                      -- 本体オプション区分
        IBIW.QUANTITY,                                              -- 数量
        IBIW.INSTALL_DATE,                                          -- 納入日
        IBIW.CUSTOMER_ORDER_NO,                                     -- 客先注文番号
        IBIW.MAKER_ORDER_NO,                                        -- メーカー発注番号
        IBIW.ORDER_NO,                                              -- 受注番号
        IBIW.TRANSFER_FLAG,                                         -- 移管品フラグ
        IBIW.SALES_OWNER_CODE,                                      -- 販売元
        IBIW.MAINTENANCE_TYPE,                                      -- 保守種別
        IBIW.SERVICE_CONDITION,                                     -- サービス形態
        IBIW.OUT_SOURCING_FLAG,                                     -- 外注フラグ
        IBIW.SHIPPING_INSPECTION_FLAG,                              -- 出荷検査実施フラグ
        IBIW.FIRST_SALE_PARTY_CODE,                                 -- 初期販売会社コード
        IBIW.FIRST_SALE_PARTY_LOCATION,                             -- 初期販売会社住所
        IBI.FIRST_SALE_DEPT_NAME,                                   -- 初期販売部署名
        IBIW.FIRST_SALE_DEPT_CODE,                                  -- 初期販売部署コード
        IBIW.FIRST_SALE_TEL,                                        -- 初期販売会社TEL
        IBIW.FIRST_SALE_FAX,                                        -- 初期販売会社FAX
        IBI.FIRST_SALE_PERSON_NAME,                                 -- 初期販売担当者名
        IBIW.FIRST_SALE_PERSON_CODE,                                -- 初期販売担当者コード
        IBIW.FIRST_SALE_MAIL_ADDRESS,                               -- 初期販売メールアドレス
        IBIW.FIRST_COVERAGE,                                        -- 初回ワランティ条件
        IBIW.FIRST_MONTHS,                                          -- 初回ワランティ月数
        IBIW.FIRST_START_DATE,                                      -- 初回期間(自)
        IBIW.FIRST_END_DATE,                                        -- 初回期間(至)
        IBIW.NEXT_COVERAGE,                                         -- 次回ワランティ条件
        IBIW.NEXT_MONTHS,                                           -- 次回ワランティ月数
        IBIW.NEXT_START_DATE,                                       -- 次回期間(自)
        IBIW.NEXT_END_DATE,                                         -- 次回期間(至)
        IBIW.AGENT_FLAG,                                            -- 販社フラグ
        IBIW.BUNDLE_ITEM_CODE,                                      -- バンドル品目コード
        IBIW.BUNDLE_SERIAL_NO,                                      -- バンドルシリアル
        IBIW.INSTALL_CUSTOMER_CODE,                                 -- 設置先顧客コード
--        IBIW.INSTALL_LOCATION_CODE,                                 -- 設置先顧客住所コード
        IBIW.INSTALL_LOCATION_DEPT_NAME,                            -- 設置先顧客部署名
        IBIW.INSTALL_LOCATION_PERSON_NAME,                          -- 設置先顧客担当者名
        IBIW.INSTALL_LOCATION_TEL,                                  -- 設置先TEL
        IBIW.INCIDENT_SERVIRITY_NAME,                               -- 重要度
        IBIW.KEEP_WATCH_SYSTEM_ID,                                  -- 監視システムID
        IBIW.USE_CONDITION,                                         -- 利用形態
        IBIW.USE_PERPOSE,                                           -- 利用目的
        IBIW.ENDUSER_PARTY_ID,                                      -- エンドユーザ会社コード
        IBIW.ENDUSER_PARTY_NAME,                                    -- エンドユーザ会社名 (Add New 2016/03/28)
        IBIW.ENDUSER_LOCATION,                                      -- エンドユーザ住所
        IBIW.ENDUSER_CHRG_DEPT_NAME,                                -- エンドユーザ部署名
        IBIW.ENDUSER_CHRG_PERSON_NAME,                              -- エンドユーザ担当者名
        IBIW.ENDUSER_TEL,                                           -- エンドユーザTEL
        IBIW.ENDUSER_FAX,                                           -- エンドユーザFAX
        IBIW.ENDUSER_MAIL_ADDRESS,                                  -- エンドユーザメールアドレス
        IBIW.SALES_DEPT_ORG_ID,                                     -- F営業販売部署コード
        IBIW.SALES_DEPT_PERSON_ID,                                  -- F営業販売担当者コード
        IBIW.PRESENT_DEPT_ORG_ID,                                   -- F営業現在担当部署コード
        IBIW.CTC_SALESREP_PERSON_ID,                                -- F営業現在担当者コード
        IBIW.MAINTE_BUS_DEPT_ORG_ID,                                -- 保守営業担当部署コード
        IBIW.MAINTE_BUS_PERSON_ID,                                  -- 保守営業担当者コード
        IBIW.X_DEPLOY_FLAG,                                         -- X配備対象フラグ
--        IBI.ACCEPTANCE_DATE,                                        -- 受入日
        IBIW.ACCEPTANCE_DATE,                                       -- 受入日
        IBIW.MEMO,                                                  -- メモ
        IBIW.GROUP_PARTY,                                           -- グループ会社
        IBIW.KINDS_CODE,                                            -- 機種コード
        IBIW.SHIPMENT_LOCATION_CODE,                                -- 出荷先コード
        IBIW.PROCESS_FLAG,                                          -- 処理済フラグ
        IBIW.SEND_FLAG,                                             -- 送信予定フラグ
        IBIW.PROGRAM_ID,                                            -- 更新プログラムID
        IBIW.PROCESS_ID,                                            -- 処理ID
        IBIW.CREATION_USER_ID,                                      -- 作成者
        IBIW.CREATION_DATE,                                         -- 作成日時
        IBIW.UPDATE_USER_ID,                                        -- 更新者
        IBIW.UPDATE_DATE                                            -- 更新日時
      FROM CSG_P_IB_INFO_WORK IBIW                        -- 設置機器情報中間ワーク
      LEFT OUTER JOIN CSG_M_IB_INFO IBI                   -- 設置機器情報
        ON IBIW.INVENTORY_ITEM_CODE = IBI.INVENTORY_ITEM_CODE          -- ワーク.品目コード＝設置.品目コード
       AND IBIW.SERIAL_NO           = IBI.SERIAL_NO                    -- ワーク.シリアル番号＝設置.シリアル番号
     WHERE IBIW.INVENTORY_ITEM_CODE = IBIW.PARENT_INVENTORY_ITEM_CODE  -- ワーク.品目コード＝ワーク.親品目コード
       AND IBIW.SERIAL_NO           = IBIW.PARENT_SERIAL_NO            -- ワーク.シリアル番号＝ワーク.親シリアル番号
       AND IBIW.PROCESS_FLAG        = '0';                             -- ワーク.処理済みフラグ
      
  --****************************************************************************     
  -- 3.処理対象データの取得(第2階層、第3階層)
  -- 3.1.子インスタンスの取得
  -- 以下の条件に合致するデータを設置機器情報中間ワークより取得する。
  --****************************************************************************
CURSOR c_CSG_P_IB_INFO_WORK02 
IS 
  SELECT IBI.INSTANCE_ID AS INSTANCE_ID_IBI,                        -- 設置機器情報テーブルのインスタンス番号（登録済み判定用）
      IBIW.ID,                                                      -- ID
      IBIW.INSTANCE_ID,                                             -- インスタンス番号
      IBIW.PARENT_INVENTORY_ITEM_CODE,                              -- 親品目コード
      IBIW.PARENT_SERIAL_NO,                                        -- 親シリアル番号
      IBIW.INVENTORY_ITEM_CODE,                                     -- 品目コード
      IBIW.INVENTORY_ITEM_NAME,                                     -- 品目名
      IBIW.SERIAL_NO,                                               -- シリアル番号
      IBIW.MAIN_OPTION_TYPE,                                        -- 本体オプション区分
      IBIW.QUANTITY,                                                -- 数量
      IBIW.INSTALL_DATE,                                            -- 納入日
      IBIW.CUSTOMER_ORDER_NO,                                       -- 客先注文番号
      IBIW.MAKER_ORDER_NO,                                          -- メーカー発注番号
      IBIW.ORDER_NO,                                                -- 受注番号
      IBIW.TRANSFER_FLAG,                                           -- 移管品フラグ
      IBIW.SALES_OWNER_CODE,                                        -- 販売元
      IBIW.MAINTENANCE_TYPE,                                        -- 保守種別
      IBIW.SERVICE_CONDITION,                                       -- サービス形態
      IBIW.OUT_SOURCING_FLAG,                                       -- 外注フラグ
      IBIW.SHIPPING_INSPECTION_FLAG,                                -- 出荷検査実施フラグ
      IBIW.FIRST_SALE_PARTY_CODE,                                   -- 初期販売会社コード
      IBIW.FIRST_SALE_PARTY_LOCATION,                               -- 初期販売会社住所
      IBI.FIRST_SALE_DEPT_NAME,                                     -- 初期販売部署名
      IBIW.FIRST_SALE_DEPT_CODE,                                    -- 初期販売部署コード
      IBIW.FIRST_SALE_TEL,                                          -- 初期販売会社TEL
      IBIW.FIRST_SALE_FAX,                                          -- 初期販売会社FAX
      IBI.FIRST_SALE_PERSON_NAME,                                   -- 初期販売担当者名
      IBIW.FIRST_SALE_PERSON_CODE,                                  -- 初期販売担当者コード
      IBIW.FIRST_SALE_MAIL_ADDRESS,                                 -- 初期販売メールアドレス
      IBIW.FIRST_COVERAGE,                                          -- 初回ワランティ条件
      IBIW.FIRST_MONTHS,                                            -- 初回ワランティ月数
      IBIW.FIRST_START_DATE,                                        -- 初回期間(自)
      IBIW.FIRST_END_DATE,                                          -- 初回期間(至)
      IBIW.NEXT_COVERAGE,                                           -- 次回ワランティ条件
      IBIW.NEXT_MONTHS,                                             -- 次回ワランティ月数
      IBIW.NEXT_START_DATE,                                         -- 次回期間(自)
      IBIW.NEXT_END_DATE,                                           -- 次回期間(至)
      IBIW.AGENT_FLAG,                                              -- 販社フラグ
      IBIW.BUNDLE_ITEM_CODE,                                        -- バンドル品目コード
      IBIW.BUNDLE_SERIAL_NO,                                        -- バンドルシリアル
      IBIW.INSTALL_CUSTOMER_CODE,                                   -- 設置先顧客コード
    --  IBIW.INSTALL_LOCATION_CODE,                                   -- 設置先顧客住所コード
      IBIW.INSTALL_LOCATION_DEPT_NAME,                              -- 設置先顧客部署名
      IBIW.INSTALL_LOCATION_PERSON_NAME,                            -- 設置先顧客担当者名
      IBIW.INSTALL_LOCATION_TEL,                                    -- 設置先TEL
      IBIW.INCIDENT_SERVIRITY_NAME,                                 -- 重要度
      IBIW.KEEP_WATCH_SYSTEM_ID,                                    -- 監視システムID
      IBIW.USE_CONDITION,                                           -- 利用形態
      IBIW.USE_PERPOSE,                                             -- 利用目的
      IBIW.ENDUSER_PARTY_ID,                                        -- エンドユーザ会社コード
      IBIW.ENDUSER_PARTY_NAME,                                      -- エンドユーザ会社名 (Add New 2016/03/28)
      IBIW.ENDUSER_LOCATION,                                        -- エンドユーザ住所
      IBIW.ENDUSER_CHRG_DEPT_NAME,                                  -- エンドユーザ部署名
      IBIW.ENDUSER_CHRG_PERSON_NAME,                                -- エンドユーザ担当者名
      IBIW.ENDUSER_TEL,                                             -- エンドユーザTEL
      IBIW.ENDUSER_FAX,                                             -- エンドユーザFAX
      IBIW.ENDUSER_MAIL_ADDRESS,                                    -- エンドユーザメールアドレス
      IBIW.SALES_DEPT_ORG_ID,                                       -- F営業販売部署コード
      IBIW.SALES_DEPT_PERSON_ID,                                    -- F営業販売担当者コード
      IBIW.PRESENT_DEPT_ORG_ID,                                     -- F営業現在担当部署コード
      IBIW.CTC_SALESREP_PERSON_ID,                                  -- F営業現在担当者コード
      IBIW.MAINTE_BUS_DEPT_ORG_ID,                                  -- 保守営業担当部署コード
      IBIW.MAINTE_BUS_PERSON_ID,                                    -- 保守営業担当者コード
      IBIW.X_DEPLOY_FLAG,                                           -- X配備対象フラグ
--      IBI.ACCEPTANCE_DATE,                                          -- 受入日
      IBIW.ACCEPTANCE_DATE,                                         -- 受入日
      IBIW.MEMO,                                                    -- メモ
      IBIW.GROUP_PARTY,                                             -- グループ会社
      IBIW.KINDS_CODE,                                              -- 機種コード
      IBIW.SHIPMENT_LOCATION_CODE,                                  -- 出荷先コード
      IBIW.PROCESS_FLAG,                                            -- 処理済フラグ
      IBIW.SEND_FLAG,                                               -- 送信予定フラグ
      IBIW.PROGRAM_ID,                                              -- 更新プログラムID
      IBIW.PROCESS_ID,                                              -- 処理ID
      IBIW.CREATION_USER_ID,                                        -- 作成者
      IBIW.CREATION_DATE,                                           -- 作成日時
      IBIW.UPDATE_USER_ID,                                          -- 更新者
      IBIW.UPDATE_DATE                                              -- 更新日時
    FROM CSG_P_IB_INFO_WORK IBIW                                    -- 設置機器情報中間ワーク
    LEFT OUTER JOIN CSG_M_IB_INFO IBI                               -- 設置機器情報
      ON IBIW.INVENTORY_ITEM_CODE   = IBI.INVENTORY_ITEM_CODE         -- ワーク.品目コード＝設置.品目コード
     AND IBIW.SERIAL_NO             = IBI.SERIAL_NO                   -- ワーク.シリアル番号＝設置.シリアル番号
   WHERE (IBIW.INVENTORY_ITEM_CODE <> IBIW.PARENT_INVENTORY_ITEM_CODE -- ワーク.品目コード<>ワーク.親品目コード
      OR IBIW.SERIAL_NO            <> IBIW.PARENT_SERIAL_NO)          -- ワーク.シリアル番号<>ワーク.親シリアル番号
     AND IBIW.PROCESS_FLAG          = '0';                            -- ワーク.処理済みフラグ
    
    
    row_CSG_P_IB_INFO_WORK02         c_CSG_P_IB_INFO_WORK02%ROWTYPE;
  --****************************************************************************     
  -- 5.紐付きなしデータの取得
  -- 5.1.単独インスタンスの取得
  -- 第2階層、第3階層インスタンスで残ってしまったデータ（紐付かないレコード）を単独インスタンスとして登録する。
  -- 以下の条件に合致するデータを設置機器情報中間ワークより取得する。
  --****************************************************************************
CURSOR c_CSG_P_IB_INFO_WORK03 
IS 
  SELECT IBI.INSTANCE_ID AS INSTANCE_ID_IBI,                        -- 設置機器情報テーブルのインスタンス番号（登録済み判定用）
      IBIW.ID,                                                      -- ID
      IBIW.INSTANCE_ID,                                             -- インスタンス番号
      IBIW.PARENT_INVENTORY_ITEM_CODE,                              -- 親品目コード
      IBIW.PARENT_SERIAL_NO,                                        -- 親シリアル番号
      IBIW.INVENTORY_ITEM_CODE,                                     -- 品目コード
      IBIW.INVENTORY_ITEM_NAME,                                     -- 品目名
      IBIW.SERIAL_NO,                                               -- シリアル番号
      IBIW.MAIN_OPTION_TYPE,                                        -- 本体オプション区分
      IBIW.QUANTITY,                                                -- 数量
      IBIW.INSTALL_DATE,                                            -- 納入日
      IBIW.CUSTOMER_ORDER_NO,                                       -- 客先注文番号
      IBIW.MAKER_ORDER_NO,                                          -- メーカー発注番号
      IBIW.ORDER_NO,                                                -- 受注番号
      IBIW.TRANSFER_FLAG,                                           -- 移管品フラグ
      IBIW.SALES_OWNER_CODE,                                        -- 販売元
      IBIW.MAINTENANCE_TYPE,                                        -- 保守種別
      IBIW.SERVICE_CONDITION,                                       -- サービス形態
      IBIW.OUT_SOURCING_FLAG,                                       -- 外注フラグ
      IBIW.SHIPPING_INSPECTION_FLAG,                                -- 出荷検査実施フラグ
      IBIW.FIRST_SALE_PARTY_CODE,                                   -- 初期販売会社コード
      IBIW.FIRST_SALE_PARTY_LOCATION,                               -- 初期販売会社住所
      IBI.FIRST_SALE_DEPT_NAME,                                     -- 初期販売部署名
      IBIW.FIRST_SALE_DEPT_CODE,                                    -- 初期販売部署コード
      IBIW.FIRST_SALE_TEL,                                          -- 初期販売会社TEL
      IBIW.FIRST_SALE_FAX,                                          -- 初期販売会社FAX
      IBI.FIRST_SALE_PERSON_NAME,                                  -- 初期販売担当者名
      IBIW.FIRST_SALE_PERSON_CODE,                                  -- 初期販売担当者コード
      IBIW.FIRST_SALE_MAIL_ADDRESS,                                 -- 初期販売メールアドレス
      IBIW.FIRST_COVERAGE,                                          -- 初回ワランティ条件
      IBIW.FIRST_MONTHS,                                            -- 初回ワランティ月数
      IBIW.FIRST_START_DATE,                                        -- 初回期間(自)
      IBIW.FIRST_END_DATE,                                          -- 初回期間(至)
      IBIW.NEXT_COVERAGE,                                           -- 次回ワランティ条件
      IBIW.NEXT_MONTHS,                                             -- 次回ワランティ月数
      IBIW.NEXT_START_DATE,                                         -- 次回期間(自)
      IBIW.NEXT_END_DATE,                                           -- 次回期間(至)
      IBIW.AGENT_FLAG,                                              -- 販社フラグ
      IBIW.BUNDLE_ITEM_CODE,                                        -- バンドル品目コード
      IBIW.BUNDLE_SERIAL_NO,                                        -- バンドルシリアル
      IBIW.INSTALL_CUSTOMER_CODE,                                   -- 設置先顧客コード
    --  IBIW.INSTALL_LOCATION_CODE,                                   -- 設置先顧客住所コード
      IBIW.INSTALL_LOCATION_DEPT_NAME,                              -- 設置先顧客部署名
      IBIW.INSTALL_LOCATION_PERSON_NAME,                            -- 設置先顧客担当者名
      IBIW.INSTALL_LOCATION_TEL,                                    -- 設置先TEL
      IBIW.INCIDENT_SERVIRITY_NAME,                                 -- 重要度
      IBIW.KEEP_WATCH_SYSTEM_ID,                                    -- 監視システムID
      IBIW.USE_CONDITION,                                           -- 利用形態
      IBIW.USE_PERPOSE,                                             -- 利用目的
      IBIW.ENDUSER_PARTY_ID,                                        -- エンドユーザ会社コード
      IBIW.ENDUSER_PARTY_NAME,                                      -- エンドユーザ会社名 (Add New 2016/03/28)
      IBIW.ENDUSER_LOCATION,                                        -- エンドユーザ住所
      IBIW.ENDUSER_CHRG_DEPT_NAME,                                  -- エンドユーザ部署名
      IBIW.ENDUSER_CHRG_PERSON_NAME,                                -- エンドユーザ担当者名
      IBIW.ENDUSER_TEL,                                             -- エンドユーザTEL
      IBIW.ENDUSER_FAX,                                             -- エンドユーザFAX
      IBIW.ENDUSER_MAIL_ADDRESS,                                    -- エンドユーザメールアドレス
      IBIW.SALES_DEPT_ORG_ID,                                       -- F営業販売部署コード
      IBIW.SALES_DEPT_PERSON_ID,                                    -- F営業販売担当者コード
      IBIW.PRESENT_DEPT_ORG_ID,                                     -- F営業現在担当部署コード
      IBIW.CTC_SALESREP_PERSON_ID,                                  -- F営業現在担当者コード
      IBIW.MAINTE_BUS_DEPT_ORG_ID,                                  -- 保守営業担当部署コード
      IBIW.MAINTE_BUS_PERSON_ID,                                    -- 保守営業担当者コード
      IBIW.X_DEPLOY_FLAG,                                           -- X配備対象フラグ
--      IBI.ACCEPTANCE_DATE,                                          -- 受入日
      IBIW.ACCEPTANCE_DATE,                                            -- 受入日
      IBIW.MEMO,                                                    -- メモ
      IBIW.GROUP_PARTY,                                             -- グループ会社
      IBIW.KINDS_CODE,                                              -- 機種コード
      IBIW.SHIPMENT_LOCATION_CODE,                                  -- 出荷先コード
      IBIW.PROCESS_FLAG,                                            -- 処理済フラグ
      IBIW.SEND_FLAG,                                               -- 送信予定フラグ
      IBIW.PROGRAM_ID,                                              -- 更新プログラムID
      IBIW.PROCESS_ID,                                              -- 処理ID
      IBIW.CREATION_USER_ID,                                        -- 作成者
      IBIW.CREATION_DATE,                                           -- 作成日時
      IBIW.UPDATE_USER_ID,                                          -- 更新者
      IBIW.UPDATE_DATE                                              -- 更新日時
    FROM CSG_P_IB_INFO_WORK IBIW                                    -- 設置機器情報中間ワーク
    LEFT OUTER JOIN CSG_M_IB_INFO IBI                                 -- 設置機器情報
      ON IBIW.INVENTORY_ITEM_CODE  = IBI.INVENTORY_ITEM_CODE          -- ワーク.品目コード＝設置.品目コード
     AND IBIW.SERIAL_NO            = IBI.SERIAL_NO                    -- ワーク.シリアル番号＝設置.シリアル番号
   WHERE (IBIW.INVENTORY_ITEM_CODE = IBIW.PARENT_INVENTORY_ITEM_CODE  -- ワーク.品目コード=ワーク.親品目コード
      OR IBIW.SERIAL_NO            = IBIW.PARENT_SERIAL_NO)           -- ワーク.シリアル番号=ワーク.親シリアル番号
     AND IBIW.PROCESS_FLAG         = '0';                             -- ワーク.処理済みフラグ
    
    
    row_CSG_P_IB_INFO_WORK03         c_CSG_P_IB_INFO_WORK03%ROWTYPE;
    
  BEGIN
  g_shori_point             := 'CSG02_PROC_INS_EQUIPMENT_REG';
  PRAM_PLACE_HOLDER         := 'データの取得';
  g_target_sel_cnt          := 0; -- 対象データは単独機器(第1階層)がない。
  g_normal_sel_cnt          := 0; -- 対象データは単独機器(第1階層)がない。
  g_warnings_sel_cnt        := 0; -- 対象データは単独機器(第1階層)がない。
  --****************************************************************************
  -- 0 ：正常コード
  -- 10：警告コード(排他エラー)
  -- 20：異常コード
  -- 21：異常コード(マスタ存在チェックエラー)
  -- 22：異常コード(排他エラー)
  --****************************************************************************
  RETURN_RESULT_CD := '0'; -- 0 ：正常コード
  --****************************************************************************
  -- 呼び出し元機能のステータス
  -- 0:処理中
  -- 1:正常終了
  -- 2:警告終了
  -- 3:エラー
  --****************************************************************************
  RETURN_STATUS      := '1';  
  --****************************************************************************
  -- 2.親情報(第1階層)の登録
  -- 2.1. レコード件数ループ
  -- 処理1.1.取得したレコード件数分、以降の処理を行う。
  --****************************************************************************
  <<C_CSG_W_INS_BS_IF_WORK_LOOP>>
  FOR row_CSG_W_IBI_W IN c_CSG_P_IB_INFO_WORK
    LOOP
    --**************************************************************************
    -- レコードの読込み件数カウンター
    --**************************************************************************
    g_target_sel_cnt          := g_target_sel_cnt + 1;

    BEGIN
    --**************************************************************************
    -- ※１　プラントの取得　（販売元が”CTCT”の場合、”CTC”と同じプラントを参照する。）
    -- [1.1.]で取得した「販売元」が設定されいる場合のみ、実施する。
    --**************************************************************************
    IF row_CSG_W_IBI_W.SALES_OWNER_CODE IS NOT NULL THEN
      BEGIN
        SELECT SMGS.PARM4                                                 -- パラメータ4 (プラント)
          INTO p_ORG_ID_IBI                                               -- プラント
          FROM SNV_M_GNRC_SNV SMGS                                        -- 汎用マスタ(SNV)
         WHERE SMGS.KEY_ITEM          ='CSG_ROLE_CLASS'                   -- (設置機器使用会社) 汎用マスタ(SNV).キー項目
           and SMGS.VALD_STRT_DT     <= SYSDATE                           -- 汎用マスタ(SNV).有効開始日
           AND NVL(SMGS.VALD_END_DT,SYSDATE) >= SYSDATE                           -- 汎用マスタ(SNV).有効終了日
           AND NVL(SMGS.DEL_FLG,'N') <> 'X'                               -- 汎用マスタ(SNV).削除フラグ
           AND SMGS.CD_VAL            = row_CSG_W_IBI_W.SALES_OWNER_CODE; -- [1.1.]で取得した「SALES_OWNER_CODE」 汎用マスタ(SNV).コード値
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          GOTO END_LOOP;
      END;
    END IF;
    --**************************************************************************
    -- ※2　バンドル品目名の取得　
    -- [1.1.]で取得した「バンドル品目コード」が設定れている場合のみ、実施する。
    --**************************************************************************
    IF row_CSG_W_IBI_W.BUNDLE_ITEM_CODE IS NOT NULL THEN
      BEGIN
        SELECT SMI.REMARKS                                              -- 摘要
          INTO p_BUNDLE_ITEM_NAME_IBI                                   -- バンドル品目コード
          FROM SNV_M_ITEM SMI                                           -- 品目マスタ
         WHERE SMI.ITEM_CD           = row_CSG_W_IBI_W.BUNDLE_ITEM_CODE -- 品目マスタ.品目コード [1.1.]で取得した「バンドル品目コード」
           AND SMI.PLT               = p_ORG_ID_IBI                     -- 品目マスタ.プラント ※1で取得したプラント
           AND NVL(SMI.DEL_FLG,'N') <> 'X';                             -- 品目マスタ.削除フラグ
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          GOTO END_LOOP;
      END;
    END IF;
    --**************************************************************************
    -- Oracleシーケンスで採番したインスタンスID
    --**************************************************************************
    -- SELECT INSTANCE_ID_IBI_SEQ.NEXTVAL INTO v_INSTANCE_ID_SEQ FROM DUAL;
    --**************************************************************************
    -- 2.3.設置機器情報の設定
    -- 対象データを設置機器情報に設定する。
    -- ※以下の内容は、設置機器・共通テーブル追加更新APIのパラメータ「設置機器情報」として、設定する。
    -- （NULL項目は追加・更新APIに渡す項目として、不要な項目とする。）
    --**************************************************************************
      PRAM_PLACE_HOLDER   := '設置機器情報の設定';
    --**************************************************************************
    tIB_BASE               := NEW ARRAY_IB_BASE(
--                              NEW CONTACT_IB_BASE_OBJ('INSTANCE_ID', v_INSTANCE_ID_SEQ),                                       -- インスタンス番号
--                              NEW CONTACT_IB_BASE_OBJ('PARENT_INSTANCE_ID', v_INSTANCE_ID_SEQ),                                -- 親インスタンス番号
--                              NEW CONTACT_IB_BASE_OBJ('TOP_INSTANCE_ID', v_INSTANCE_ID_SEQ),                                   -- 最上位インスタンス番号
                              NEW CONTACT_IB_BASE_OBJ('INVENTORY_ITEM_CODE', row_CSG_W_IBI_W.INVENTORY_ITEM_CODE),             -- 品目コード
                              NEW CONTACT_IB_BASE_OBJ('ORG_ID', p_ORG_ID_IBI),                                                 -- プラント
                              NEW CONTACT_IB_BASE_OBJ('INVENTORY_ITEM_NAME', row_CSG_W_IBI_W.INVENTORY_ITEM_NAME),             -- 品目名
                              NEW CONTACT_IB_BASE_OBJ('SERIAL_NO', row_CSG_W_IBI_W.SERIAL_NO),                                 -- シリアル番号
                              NEW CONTACT_IB_BASE_OBJ('MAIN_OPTION_TYPE', row_CSG_W_IBI_W.MAIN_OPTION_TYPE),                   -- 本体オプション区分
                              NEW CONTACT_IB_BASE_OBJ('IB_SYNC_STATUS', '10009'),                                              -- IBステータス
                              NEW CONTACT_IB_BASE_OBJ('QUANTITY', row_CSG_W_IBI_W.QUANTITY),                                   -- 数量
                              NEW CONTACT_IB_BASE_OBJ('INSTALL_DATE', row_CSG_W_IBI_W.INSTALL_DATE),                           -- 納入日
--                              NEW CONTACT_IB_BASE_OBJ('SALES_DATE', NULL),                                                     -- 売上日
                              NEW CONTACT_IB_BASE_OBJ('CUSTOMER_ORDER_NO', row_CSG_W_IBI_W.CUSTOMER_ORDER_NO),                 -- 客先注文番号
                              NEW CONTACT_IB_BASE_OBJ('MAKER_ORDER_NO', row_CSG_W_IBI_W.MAKER_ORDER_NO),                       -- メーカー発注番号
                              NEW CONTACT_IB_BASE_OBJ('ORDER_NO', row_CSG_W_IBI_W.ORDER_NO),                                   -- 受注番号
                              NEW CONTACT_IB_BASE_OBJ('TRANSFER_FLAG', row_CSG_W_IBI_W.TRANSFER_FLAG),                        -- 移管品フラグ
--                              NEW CONTACT_IB_BASE_OBJ('TRANSFER_MAINTENANCE_FROM', NULL),                                      -- 保守移管元
--                              NEW CONTACT_IB_BASE_OBJ('TRANSFER_MAINTENANCE_TO', NULL),                                        -- 保守移管先
--                              NEW CONTACT_IB_BASE_OBJ('TRANSFER_MAINTENANCE_DATE', NULL),                                      -- 保守移管日
--                              NEW CONTACT_IB_BASE_OBJ('TRANSFER_MAINTNANCE_REASON', NULL),                                     -- 保守移管理由
                              NEW CONTACT_IB_BASE_OBJ('SALES_OWNER_CODE', row_CSG_W_IBI_W.SALES_OWNER_CODE),                   -- 販売元
                              NEW CONTACT_IB_BASE_OBJ('MAINTENANCE_TYPE', row_CSG_W_IBI_W.MAINTENANCE_TYPE),                   -- 保守種別
--                              NEW CONTACT_IB_BASE_OBJ('IMPORTANT_ITEM_FLAG', NULL),                                            -- 重要案件
--                              NEW CONTACT_IB_BASE_OBJ('SERVICE_CONDITION', NULL),                                              -- サービス形態
                              NEW CONTACT_IB_BASE_OBJ('OUT_SOURCING_FLAG', row_CSG_W_IBI_W.OUT_SOURCING_FLAG),                 -- 外注フラグ
                              NEW CONTACT_IB_BASE_OBJ('SHIPPING_INSPECTION_FLAG', row_CSG_W_IBI_W.SHIPPING_INSPECTION_FLAG),   -- 出荷検査実施フラグ
--                              NEW CONTACT_IB_BASE_OBJ('HOST_NAME', NULL),                                                      -- ホスト名
--                              NEW CONTACT_IB_BASE_OBJ('SYSTEM_NAME', NULL),                                                    -- システム名
--                              NEW CONTACT_IB_BASE_OBJ('SUPPORT_START_DATE', NULL),                                             -- 要サポート開始日
--                              NEW CONTACT_IB_BASE_OBJ('SUPPORT_END_DATE', NULL),                                               -- 要サポート終了日
--                              NEW CONTACT_IB_BASE_OBJ('SUPPORT_INSTRUCT_CODE', NULL),                                          -- 要サポートフラグ
                              NEW CONTACT_IB_BASE_OBJ('FIRST_SALE_PARTY_CODE', row_CSG_W_IBI_W.FIRST_SALE_PARTY_CODE),         -- 初期販売会社コード
                              NEW CONTACT_IB_BASE_OBJ('FIRST_SALE_PARTY_LOCATION', row_CSG_W_IBI_W.FIRST_SALE_PARTY_LOCATION), -- 初期販売会社住所
                              NEW CONTACT_IB_BASE_OBJ('FIRST_SALE_DEPT_NAME', row_CSG_W_IBI_W.FIRST_SALE_DEPT_NAME),           -- 初期販売部署名
                              NEW CONTACT_IB_BASE_OBJ('FIRST_SALE_TEL', row_CSG_W_IBI_W.FIRST_SALE_TEL),                       -- 初期販売会社TEL
                              NEW CONTACT_IB_BASE_OBJ('FIRST_SALE_FAX', row_CSG_W_IBI_W.FIRST_SALE_FAX),                       -- 初期販売会社FAX
                              NEW CONTACT_IB_BASE_OBJ('FIRST_SALE_PERSON_NAME', row_CSG_W_IBI_W.FIRST_SALE_PERSON_NAME),       -- 初期販売担当者名
                              NEW CONTACT_IB_BASE_OBJ('FIRST_SALE_MAIL_ADDRESS', row_CSG_W_IBI_W.FIRST_SALE_MAIL_ADDRESS),     -- 初期販売メールアドレス
                              NEW CONTACT_IB_BASE_OBJ('FIRST_COVERAGE', row_CSG_W_IBI_W.FIRST_COVERAGE),                       -- 初回ワランティ条件
                              NEW CONTACT_IB_BASE_OBJ('FIRST_MONTHS', row_CSG_W_IBI_W.FIRST_MONTHS),                          -- 初回ワランティ月数
                              NEW CONTACT_IB_BASE_OBJ('FIRST_START_DATE', row_CSG_W_IBI_W.FIRST_START_DATE),                   -- 初回期間(自)
                              NEW CONTACT_IB_BASE_OBJ('FIRST_END_DATE', row_CSG_W_IBI_W.FIRST_END_DATE),                       -- 初回期間(至)
                              NEW CONTACT_IB_BASE_OBJ('NEXT_COVERAGE', row_CSG_W_IBI_W.NEXT_COVERAGE),                         -- 次回ワランティ条件
                              NEW CONTACT_IB_BASE_OBJ('NEXT_MONTHS', row_CSG_W_IBI_W.NEXT_MONTHS),                             -- 次回ワランティ月数
                              NEW CONTACT_IB_BASE_OBJ('NEXT_START_DATE', row_CSG_W_IBI_W.NEXT_START_DATE),                     -- 次回期間(自)
                              NEW CONTACT_IB_BASE_OBJ('NEXT_END_DATE', row_CSG_W_IBI_W.NEXT_END_DATE),                        -- 次回期間(至)
                              NEW CONTACT_IB_BASE_OBJ('AGENT_FLAG', row_CSG_W_IBI_W.AGENT_FLAG),                               -- 販社フラグ
--                              NEW CONTACT_IB_BASE_OBJ('SECONDARY_INVENTORY_CODE', NULL),                                       -- 委託先コード
                              NEW CONTACT_IB_BASE_OBJ('BUNDLE_ITEM_CODE', row_CSG_W_IBI_W.BUNDLE_ITEM_CODE),                   -- バンドル品目コード
                              NEW CONTACT_IB_BASE_OBJ('BUNDLE_ITEM_NAME', p_BUNDLE_ITEM_NAME_IBI),                             -- バンドル品目名
                              NEW CONTACT_IB_BASE_OBJ('BUNDLE_SERIAL_NO', row_CSG_W_IBI_W.BUNDLE_SERIAL_NO),                   -- バンドルシリアル
--                              NEW CONTACT_IB_BASE_OBJ('HOST_ID', NULL),                                                        -- ホストID
--                              NEW CONTACT_IB_BASE_OBJ('KEEP_WATCH_SYSTEM_ID', NULL),                                           -- 監視システムID
--                              NEW CONTACT_IB_BASE_OBJ('HP_CONFIG_CODE', NULL),                                                 -- HPコンフィグコード
--                              NEW CONTACT_IB_BASE_OBJ('OS_TYPE', NULL),                                                        -- OS種別
--                              NEW CONTACT_IB_BASE_OBJ('OS_VERSION', NULL),                                                     -- OSバージョン
--                              NEW CONTACT_IB_BASE_OBJ('FIRMWARE_VERSION', NULL),                                               -- Firmware Version
--                              NEW CONTACT_IB_BASE_OBJ('REVISION', NULL),                                                       -- リビジョン
--                              NEW CONTACT_IB_BASE_OBJ('CPU_ROM_REVISION', NULL),                                               -- CPU　ROMリビジョン
--                              NEW CONTACT_IB_BASE_OBJ('DISK_CAPACITY', NULL),                                                  -- ディスク容量
--                              NEW CONTACT_IB_BASE_OBJ('POWER_SUPPLY_TYPE', NULL),                                              -- 電源設備種類
--                              NEW CONTACT_IB_BASE_OBJ('POWER_SUPPLY_CAPACITY', NULL),                                          -- 電源容量
--                              NEW CONTACT_IB_BASE_OBJ('USE_POWER_FREQUENCY', NULL),                                            -- 使用電源周波数
--                              NEW CONTACT_IB_BASE_OBJ('USE_POWER_VOLTAGE', NULL),                                              -- 使用電源電圧
--                              NEW CONTACT_IB_BASE_OBJ('HAVING_EARTH_FLAG', NULL),                                              -- アース有無フラグ
--                              NEW CONTACT_IB_BASE_OBJ('MAC_ADDRESS', NULL),                                                    -- MACアドレス
--                              NEW CONTACT_IB_BASE_OBJ('IP_ADDRESS', NULL),                                                     -- IPアドレス
--                              NEW CONTACT_IB_BASE_OBJ('LICENSE_MANAGEMENT_NO', NULL),                                          -- ライセンス管理番号
--                              NEW CONTACT_IB_BASE_OBJ('SUPERINTENDE_MANAGE_NO', NULL),                                         -- 主管部管理番号
--                              NEW CONTACT_IB_BASE_OBJ('LISENCE_START_DATE', NULL),                                             -- ライセンス開始日
--                              NEW CONTACT_IB_BASE_OBJ('LISENCE_END_DATE', NULL),                                               -- ライセンス終了日
--                              NEW CONTACT_IB_BASE_OBJ('REMOVE_ORDER_NO', NULL),                                                -- 移設受注番号
--                              NEW CONTACT_IB_BASE_OBJ('REMOVE_PO_NO', NULL),                                                   -- 移設先発注番号
--                              NEW CONTACT_IB_BASE_OBJ('REMOVE_DATE', NULL),                                                    -- 移設日
--                              NEW CONTACT_IB_BASE_OBJ('REMOVE_REASON', NULL),                                                  -- 移設理由
                              NEW CONTACT_IB_BASE_OBJ('SALES_DEPT_ORG_ID', row_CSG_W_IBI_W.SALES_DEPT_ORG_ID),                 -- F営業販売部署コード
                              NEW CONTACT_IB_BASE_OBJ('SALES_DEPT_PERSON_ID', row_CSG_W_IBI_W.SALES_DEPT_PERSON_ID),           -- F営業販売担当者コード
                              NEW CONTACT_IB_BASE_OBJ('PRESENT_DEPT_ORG_ID', row_CSG_W_IBI_W.PRESENT_DEPT_ORG_ID),             -- F営業現在担当部署コード
                              NEW CONTACT_IB_BASE_OBJ('CTC_SALESREP_PERSON_ID', row_CSG_W_IBI_W.CTC_SALESREP_PERSON_ID),       -- F営業現在担当者コード
                              NEW CONTACT_IB_BASE_OBJ('MAINTE_BUS_DEPT_ORG_ID', row_CSG_W_IBI_W.MAINTE_BUS_DEPT_ORG_ID),       -- 保守営業担当部署コード
                              NEW CONTACT_IB_BASE_OBJ('MAINTE_BUS_PERSON_ID', row_CSG_W_IBI_W.MAINTE_BUS_PERSON_ID),           -- 保守営業担当者コード
--                              NEW CONTACT_IB_BASE_OBJ('PP_CONT_AK_NO', NULL),                                                  -- PP契約AK番号
--                              NEW CONTACT_IB_BASE_OBJ('PP_CONT_START_DATE', NULL),                                             -- 契約期間(自)
--                              NEW CONTACT_IB_BASE_OBJ('PP_CONT_END_DATE', NULL),                                               -- 契約期間(至)
--                              NEW CONTACT_IB_BASE_OBJ('SN_CHANGE_REASON', NULL),                                               -- シリアル番号変更理由
                              NEW CONTACT_IB_BASE_OBJ('X_DEPLOY_FLAG', row_CSG_W_IBI_W.X_DEPLOY_FLAG),                         -- X配備対象フラグ
                              NEW CONTACT_IB_BASE_OBJ('ACCEPTANCE_DATE', row_CSG_W_IBI_W.ACCEPTANCE_DATE),                     -- 受入日
                              NEW CONTACT_IB_BASE_OBJ('OUT_WARRANTY_REGISTERED_FLAG', '1')                                     -- 外注契約ワランティ登録済フラグ
                              );
    --**************************************************************************
    -- ※２　設置先住所コードの取得　
    -- [1.1.]で取得した「SHIPMENT_LOCATION_CODE」が設定されている場合のみ、実施する。
    --**************************************************************************
    IF row_CSG_W_IBI_W.SHIPMENT_LOCATION_CODE IS NOT NULL THEN
      BEGIN
        SELECT CMIA.INSTALL_LOCATION_CODE                                              -- 設置先住所コード
          INTO p_INSTALL_LOCATION_CODE
          FROM CSG_M_IB_ADDRESS CMIA                                                   -- 設置先住所マスタ
         WHERE CMIA.SHIPMENT_LOCATION_CODE   = row_CSG_W_IBI_W.SHIPMENT_LOCATION_CODE  -- 設置先住所マスタ.出荷先コード [1.1.]で取得した「出荷先コード」
           AND CMIA.ACTIVE_FLAG              = 'Y';                                    -- 設置先住所マスタ.有効フラグ "Y"：有効
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          GOTO END_LOOP;
      END;
    END IF;
    
    --**************************************************************************
    -- ※１　担当CSコードの取得
    -- 中間ワークテーブルの以下の項目により、顧客マスタ、設置先住所マスタ、郵便番号マスタ、担当CSテリトリー情報より「グループID」を取得する。
    -- ※取得方法に関しては、別ファイル「バッチ設計_CSG02-0019-担当CS設定.xlsx」参照
    -- NO	 I/O			項目名										備考
    --  1	  I			機種コード									[1.1.]で取得した機種コード            IBIW.KINDS_CODE
    --  2	  I			顧客番号										[1.1.]で取得した設置先顧客コード       IBIW.INSTALL_CUSTOMER_CODE
    --  3	  I			Ｆ営業部課コード							[1.1.]で取得したF営業現在部署コード    IBIW.PRESENT_DEPT_ORG_ID
    --  4	  I			設置先住所ＩＤ							[1.1.]で取得した設置先顧客住所コード    IBIW.INSTALL_LOCATION_CODE
    --  5	  O			グループID									担当CSコードとして取得
    --  6	  O			終了コード									0：正常終了　20：異常終了	
    --**************************************************************************
      PRAM_PLACE_HOLDER   := '担当CSコードの取得';
      
      CSG02_0110_PKG.CSG02_PROC_CHARGE_OF_CS_SET(
                                  row_CSG_W_IBI_W.KINDS_CODE,
                                  row_CSG_W_IBI_W.INSTALL_CUSTOMER_CODE,
                                  row_CSG_W_IBI_W.PRESENT_DEPT_ORG_ID,
                                  p_INSTALL_LOCATION_CODE,
                                  RETURN_RESULT_CD,
                                  OUT_RESULT_GET,
                                  OUT_CONDITION_GET,
                                  p_CS_IN_CHARGE_CODE
                                  );
    
    --**************************************************************************
    -- ※３　エンドユーザ会社名の取得
    -- [1.1.]で取得した「ENDUSER_PARTY_CODE」が設定されている場合のみ、実施する。
    --**************************************************************************
    IF row_CSG_W_IBI_W.ENDUSER_PARTY_ID IS NOT NULL THEN
      BEGIN
        SELECT SMC.CUST_FRML_NM                                      -- 顧客正式名称
          INTO p_ENDUSER_PARTY_NAME
          FROM SNV_M_CUST SMC                                        -- 顧客マスタ
         WHERE SMC.CUST_CD        = row_CSG_W_IBI_W.ENDUSER_PARTY_ID -- 顧客マスタ.顧客コード [1.1.]で取得した「エンドユーザ会社コード」
           AND SMC.HDQRTRS_ID_FLG = 'Y'                              -- 顧客マスタ.本社識別フラグ "Y"：本社
           AND NVL(SMC.DEL_FLG, 'N')       <> 'X';                   -- 顧客マスタ.削除フラグ "X"：削除　以外
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          GOTO END_LOOP;
      END;
    END IF;
    --**************************************************************************
    -- ※4　エンドユーザ特定顧客コードの取得　
    -- エンドユーザ特定顧客コードは汎用マスタ（汎用プロパティ）より取得する。
    -- ※上記で取得したエンドユーザ特定顧客コードは、カンマ区切りで設定されている。（例：0000000001,0000000002）
    --**************************************************************************
    BEGIN
      SELECT LISTAGG(SMGS.DTL_TXT_SHRT_NM, ',') 
      WITHIN GROUP (ORDER BY SMGS.DTL_TXT_SHRT_NM) AS DTL_TXT_SHRT_NM -- 汎用マスタ.明細テキスト(短縮名)
        INTO p_ENDUSER_PARTY_ID
        FROM SNV_M_GNRC_SNV SMGS                                      -- 汎用マスタ(SNV)
       WHERE SMGS.KEY_ITEM          = 'CSG_GENERAL_PROP'              -- 汎用マスタ(SNV).キー項目 'CSG_GENERAL_PROP'(汎用プロパティ)
         AND SMGS.VALD_STRT_DT     <= SYSDATE                         -- 汎用マスタ(SNV).有効開始日
         AND NVL(SMGS.VALD_END_DT,SYSDATE) >= SYSDATE                         -- 汎用マスタ(SNV).有効終了日
         AND NVL(SMGS.DEL_FLG,'N') <> 'X'                             -- 汎用マスタ(SNV).削除フラグ
         AND SMGS.CD_VAL            = 'EU_SP_CUSTOMER_CODE';          -- 汎用マスタ(SNV).コード値  エンドユーザ特定顧客コード 'EU_SP_CUSTOMER_CODE'
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        GOTO END_LOOP;
    END;
      --************************************************************************
      -- INSTALL_BASE_INFO_WORK.ENDUSER_PARTY_IDにエンドユーザ特定顧客コード（※4）が設定されている場合
      -- ⇒INSTALL_BASE_INFO_WORK.ENDUSER_PARTY_NAMEの値を設定
      -- INSTALL_BASE_INFO_WORK.ENDUSER_PARTY_IDにエンドユーザ特定顧客コード以外が設定されている場合
      -- ⇒顧客マスタから取得　※３参照
      --************************************************************************
      IF p_ENDUSER_PARTY_ID IS NOT NULL THEN
          BEGIN
            SELECT Count(*)
              INTO v_ENDUSER_PARTY_ID
              FROM(
                SELECT REGEXP_SUBSTR(p_ENDUSER_PARTY_ID, '[^,]+', 1, LEVEL) AS ENDUSER_PARTY_CODE
                  FROM DUAL
                CONNECT BY REGEXP_SUBSTR(p_ENDUSER_PARTY_ID, '[^,]+', 1, LEVEL) IS NOT NULL
              )
              WHERE ENDUSER_PARTY_CODE = row_CSG_W_IBI_W.ENDUSER_PARTY_ID;
          END;
          
          IF v_ENDUSER_PARTY_ID >= 1 THEN
            p_ENDUSER_PARTY_NAME_WK   :=   row_CSG_W_IBI_W.ENDUSER_PARTY_NAME;
          ELSE
            p_ENDUSER_PARTY_NAME_WK   :=   p_ENDUSER_PARTY_NAME;
          END IF;
      END IF;
    --**************************************************************************
    -- 2.4.設置機器共通情報の設定
    -- 対象データを設置機器共通情報に設定する。
    -- ※以下の内容は、設置機器・共通テーブル追加更新APIのパラメータ「設置機器共通情報」として、設定する。
    -- （NULL項目は追加・更新APIに渡す項目として、不要な項目とする。）
    --**************************************************************************
      PRAM_PLACE_HOLDER   := '設置機器共通情報の設定';
    --**************************************************************************
    tIB_COMMON               := NEW ARRAY_IB_COMMON(
                                NEW CONTACT_IB_COMMON_OBJ('CS_IN_CHARGE_CODE', p_CS_IN_CHARGE_CODE),                                    -- 担当CSコード
--                                NEW CONTACT_IB_COMMON_OBJ('CE_CODE', NULL),                                                             -- 担当CEコード
                                NEW CONTACT_IB_COMMON_OBJ('INSTALL_CUSTOMER_CODE', row_CSG_W_IBI_W.INSTALL_CUSTOMER_CODE),              -- 設置先顧客コード
                                NEW CONTACT_IB_COMMON_OBJ('INSTALL_LOCATION_CODE', p_INSTALL_LOCATION_CODE),                            -- 設置先顧客住所コード
                                NEW CONTACT_IB_COMMON_OBJ('INSTALL_LOCATION_DEPT_NAME', row_CSG_W_IBI_W.INSTALL_LOCATION_DEPT_NAME),    -- 設置先顧客部署名
                                NEW CONTACT_IB_COMMON_OBJ('INSTALL_LOCATION_PERSON_NAME', row_CSG_W_IBI_W.INSTALL_LOCATION_PERSON_NAME),-- 設置先顧客担当者名
                                NEW CONTACT_IB_COMMON_OBJ('INSTALL_LOCATION_TEL', row_CSG_W_IBI_W.INSTALL_LOCATION_TEL),                -- 設置先TEL
--                                NEW CONTACT_IB_COMMON_OBJ('INSTALL_LOCATION_FAX', NULL),                                                -- 設置先FAX
                                NEW CONTACT_IB_COMMON_OBJ('INCIDENT_SERVIRITY_NAME', 'P5'),                                             -- 重要度
--                                NEW CONTACT_IB_COMMON_OBJ('USE_CONDITION', NULL),                                                       -- 利用形態
--                                NEW CONTACT_IB_COMMON_OBJ('USE_PERPOSE', NULL),                                                         -- 利用目的
                                NEW CONTACT_IB_COMMON_OBJ('ENDUSER_PARTY_CODE', row_CSG_W_IBI_W.ENDUSER_PARTY_ID),                      -- エンドユーザ会社コード
                                NEW CONTACT_IB_COMMON_OBJ('ENDUSER_PARTY_NAME', p_ENDUSER_PARTY_NAME_WK),                                  -- エンドユーザ会社名
                                NEW CONTACT_IB_COMMON_OBJ('ENDUSER_LOCATION', row_CSG_W_IBI_W.ENDUSER_LOCATION),                        -- エンドユーザ住所
                                NEW CONTACT_IB_COMMON_OBJ('ENDUSER_CHRG_DEPT_NAME', row_CSG_W_IBI_W.ENDUSER_CHRG_DEPT_NAME),            -- エンドユーザ部署名
                                NEW CONTACT_IB_COMMON_OBJ('ENDUSER_CHRG_PERSON_NAME', row_CSG_W_IBI_W.ENDUSER_CHRG_PERSON_NAME),        -- エンドユーザ担当者名
                                NEW CONTACT_IB_COMMON_OBJ('ENDUSER_TEL', row_CSG_W_IBI_W.ENDUSER_TEL),                                  -- エンドユーザTEL
                                NEW CONTACT_IB_COMMON_OBJ('ENDUSER_FAX', row_CSG_W_IBI_W.ENDUSER_FAX),                                  -- エンドユーザFAX
                                NEW CONTACT_IB_COMMON_OBJ('ENDUSER_MAIL_ADDRESS', row_CSG_W_IBI_W.ENDUSER_MAIL_ADDRESS),                -- エンドユーザメールアドレス
                                NEW CONTACT_IB_COMMON_OBJ('PROGRAM_ID', 'BAT-CSG02-0301'),                                              -- 更新プログラムID
                                NEW CONTACT_IB_COMMON_OBJ('PROCESS_ID', INPUT_PROCESS_ID),                                              -- 処理ID
                                NEW CONTACT_IB_COMMON_OBJ('CREATION_USER_ID', INPUT_USER_ID),                                           -- 作成者
                                NEW CONTACT_IB_COMMON_OBJ('CREATION_DATE', SYSDATE),                                                    -- 作成日時
                                NEW CONTACT_IB_COMMON_OBJ('UPDATE_USER_ID', INPUT_USER_ID),                                             -- 更新者
                                NEW CONTACT_IB_COMMON_OBJ('UPDATE_DATE', SYSDATE)                                                       --更新日時
                                );
    --**************************************************************************
    -- 2.5.設置機器・共通テーブル追加更新APIのコール
    -- 設置機器・共通テーブル追加更新APIを呼び出す。
    --      引数											            値
    -- 追加・更新区分（I）											  0 ：追加
    -- インスタンス番号（I）										  NULL
    -- 最上位インスタンス番号（I）								NULL
    -- 設置機器情報（I）											　  [2.3.]で設定した情報
    -- 設置機器共通情報（I）										  [2.4.]で設定した情報
    -- 更新プログラムID（I）										  "BAT-CSG02-0301"
    -- 処理ID（I）											        [0.1.]で取得した処理ID
    -- ユーザID（I）											      バッチ実行ユーザID
    -- 楽観ロック比較有無フラグ（I）							N ：楽観ロック比較なし
    -- 比較日時（I）											      NULL
    -- インスタンス番号（O）										  新規に払い出したインスタンス番号
    -- 更新日時（O）											      テーブルに更新した日時
    -- 戻り値											            終了コード
    --**************************************************************************
      PRAM_PLACE_HOLDER   := '設置機器・設置機器共通情報更新';

      CSG02_IB_COMMON_PKG.CSG02_PROC_IB_TABLE_UPDATE(
                                                      0,
                                                      NULL,
                                                      NULL,
                                                      tIB_BASE,
                                                      tIB_COMMON,
                                                      'BAT-CSG02-0301',
                                                      INPUT_PROCESS_ID,
                                                      INPUT_USER_ID,
                                                      'N',
                                                      NULL,
                                                      RETURN_RESULT_CD,
                                                      RETURN_ERR_CONTENT,
                                                      p_INSTANCE_ID,
                                                      p_UPDATE_DATE_IBI
                                                    );
    --**************************************************************************
    -- [マスタ存在チェックエラーの場合]
    -- ・中間ワークの処理結果メモにエラー内容を更新し、次のレコードに遷移する。
    --**************************************************************************
        PRAM_PLACE_HOLDER   := '設置機器情報中間ワーク更新';
        IF RETURN_ERR_CONTENT IS NOT NULL AND RETURN_RESULT_CD = '21' THEN
          UPDATE CSG_P_IB_INFO_WORK
             SET PROC_MEMO      = 'マスタ存在チェックエラー',
                 UPDATE_USER_ID = INPUT_USER_ID,
                 UPDATE_DATE    = SYSDATE
           WHERE ID             = row_CSG_W_IBI_W.ID;
         --********************************************************************
         -- レコードの読込み件数カウンター
         --********************************************************************
         g_warnings_sel_cnt          := g_warnings_sel_cnt + 1;
         END IF;
    --**************************************************************************
    -- Oracleシーケンスで採番したインスタンスID
    --**************************************************************************
    -- SELECT INSTANCE_MEMO_ID_SEQ.NEXTVAL INTO v_INSTANCE_MEMO_ID_CMIMI FROM DUAL;
    --**************************************************************************
    -- 2.6.設置機器メモ情報の設定
    -- 処理1.1で取得したデータの「メモ」に値が設定されている場合のみ、以下を実行する。
    -- 対象データを設置機器メモ情報に設定する。
    --**************************************************************************
      PRAM_PLACE_HOLDER   := '設置機器メモ情報の設定';
      
      tIB_MEMO            := NEW ARRAY_IB_MEMO(
--                             NEW CONTACT_IB_MEMO_OBJ('INSTANCE_MEMO_ID', v_INSTANCE_MEMO_ID_CMIMI),
                             NEW CONTACT_IB_MEMO_OBJ('INSTANCE_ID', p_INSTANCE_ID),
                             NEW CONTACT_IB_MEMO_OBJ('MEMO_TYPE', '04'),            
                             NEW CONTACT_IB_MEMO_OBJ('TITLE', '出荷時指示'),
                             NEW CONTACT_IB_MEMO_OBJ('MEMO', row_csg_w_ibi_w.MEMO),
                             NEW CONTACT_IB_MEMO_OBJ('SORT_NO', '10'),
                             NEW CONTACT_IB_MEMO_OBJ('PROGRAM_ID', 'BAT-CSG02-0301'),
                             NEW CONTACT_IB_MEMO_OBJ('PROCESS_ID', INPUT_PROCESS_ID),
                             NEW CONTACT_IB_MEMO_OBJ('CREATION_USER_ID', INPUT_USER_ID),
                             NEW CONTACT_IB_MEMO_OBJ('CREATION_DATE', SYSDATE),
                             new contact_ib_memo_obj('UPDATE_USER_ID', INPUT_USER_ID),
                             NEW CONTACT_IB_MEMO_OBJ('UPDATE_DATE', SYSDATE)
                            );
    --**************************************************************************
    -- 2.7.設置機器メモ情報追加更新APIのコール
    -- 設置機器メモ情報追加更新APIを呼び出す。
    --    引数											            値
    -- 追加・更新区分（I）											0 ：追加
    -- インスタンス番号（I）										[2.5.]で払い出したインスタンス番号
    -- メモID（I）											      NULL
    -- メモ情報（I）											    [2.6.]で設定した情報
    -- 更新プログラムID（I）										"BAT-CSG02-0301"
    -- 処理ID（I）											      [0.1.]で取得した処理ID
    -- ユーザID（I）											    バッチ実行ユーザID
    -- 楽観ロック比較有無フラグ（I）					  N ：楽観ロック比較なし
    -- 比較日時（I）											    NULL
    -- インスタンス番号（O）										更新したインスタンス番号
    -- メモID（O）											      新規に払い出したメモID
    -- 更新日時（O）											    テーブルに更新した日時
    -- 戻り値											          終了コード
    --**************************************************************************
      PRAM_PLACE_HOLDER   := '設置機器メモ情報更新';
      
      CSG02_IB_COMMON_PKG.CSG02_PROC_IB_MEMO_INFO_UPDATE(
                                                          0,
                                                          p_INSTANCE_ID,
                                                          NULL,
                                                          tIB_MEMO,
                                                          'BAT-CSG02-0301',
                                                          INPUT_PROCESS_ID,
                                                          INPUT_USER_ID,
                                                          'N',
                                                          NULL,
                                                          RETURN_RESULT_CD,
                                                          RETURN_ERR_CONTENT,
                                                          p_INSTANCE_ID_CMIMI,
                                                          p_MEMO_CMIMI,
                                                          p_UPDATE_DATE_CMIMI
                                                        );
    --**************************************************************************
    -- [マスタ存在チェックエラーの場合]
    -- ・中間ワークの処理結果メモにエラー内容を更新し、次のレコードに遷移する。
    --**************************************************************************
        PRAM_PLACE_HOLDER   := '設置機器情報中間ワーク更新';
        IF RETURN_ERR_CONTENT IS NOT NULL AND RETURN_RESULT_CD = '21' THEN
          UPDATE CSG_P_IB_INFO_WORK
             SET PROC_MEMO      = 'マスタ存在チェックエラー',
                 UPDATE_USER_ID = INPUT_USER_ID,
                 UPDATE_DATE    = SYSDATE
           WHERE ID             = row_CSG_W_IBI_W.ID;
         --********************************************************************
         -- レコードの読込み件数カウンター
         --********************************************************************
         g_warnings_sel_cnt          := g_warnings_sel_cnt + 1;
         END IF;
    --**************************************************************************
    -- 2.2.重複チェック
    -- 処理1.1で取得した「設置機器情報テーブルのインスタンス番号」がNULLでない場合
    -- 設置機器情報テーブルのインスタンス番号で中間ワークテーブルを更新し、次のレコードの処理を行う。（[2.8.]に遷移）
    --**************************************************************************
    --**************************************************************************
    -- 2.8.中間ワークの更新
    -- インスタンスIDを設置機器情報中間ワークに更新する。
    --**************************************************************************
      IF p_INSTANCE_ID_CMIMI IS NOT NULL THEN
        PRAM_PLACE_HOLDER   := '設置機器情報中間ワーク更新';
        
        UPDATE CSG_P_IB_INFO_WORK
           SET INSTANCE_ID    = p_INSTANCE_ID_CMIMI, --row_CSG_W_IBI_W.INSTANCE_ID_IBI,
               PROCESS_FLAG   = '1',
               SEND_FLAG      = NULL,
               PROC_MEMO      = NULL,
               UPDATE_USER_ID = INPUT_USER_ID,
               UPDATE_DATE    = SYSDATE
         WHERE ID             = row_CSG_W_IBI_W.ID;
      --************************************************************************
      -- レコードの読込み件数カウンター
      --************************************************************************
      g_normal_sel_cnt          := g_normal_sel_cnt + 1;
      END IF; 
    END;
    <<END_LOOP>>
    NULL;
    END LOOP C_CSG_W_INS_BS_IF_WORK_LOOP;
  --****************************************************************************
  -- 2.7.コミットの実行
  --****************************************************************************
  COMMIT;
  --******************************
  -- [データ取得件数が0件の場合]
  -- 処理「3.処理対象データの取得(第2階層、第3階層)」に遷移
  --******************************    
    BEGIN
      PRAM_PLACE_HOLDER   := '子情報（第2階層、第3階層）の登録';
      
      OPEN c_CSG_P_IB_INFO_WORK02;
      --************************************************************************
      -- 4.子情報（第2階層、第3階層）の登録
      -- ※当処理を実行する時点では、第一階層の登録は既に完了している。
      -- 4.1. レコード件数ループ
      -- 処理3.1.取得したレコード件数分、以降の処理を行う。
      --************************************************************************
      LOOP
        FETCH c_CSG_P_IB_INFO_WORK02 INTO row_CSG_P_IB_INFO_WORK02;
        --**********************************************************************
        -- [データ取得件数が0件の場合]
        -- 処理「7.終了処理」に遷移
        --**********************************************************************
        EXIT WHEN c_CSG_P_IB_INFO_WORK02%NOTFOUND;
        
        --**********************************************************************
        -- レコードの読込み件数カウンター
        --**********************************************************************
        g_target_sel_cnt          := g_target_sel_cnt + 1;
        -- 4.3.親インスタンスの検索
        -- 対象データの親情報を設置機器情報から取得する。
        --**********************************************************************
          PRAM_PLACE_HOLDER   := '親情報を設置機器情報から取得する';
        BEGIN
          SELECT CMIBI.INSTANCE_ID,                                                                   -- インスタンス番号
                 CMIBI.PARENT_INSTANCE_ID,                                                            -- 親インスタンス番号
                 CMIBI.TOP_INSTANCE_ID,                                                               -- 最上位インスタンス番号
                 CMIBI.INVENTORY_ITEM_CODE,                                                           -- 品目コード
                 CMIBI.SERIAL_NO                                                                      -- シリアル番号
            INTO p_INSTANCE_ID_IBI,
                 p_PARENT_INSTANCE_ID_IBI,
                 p_TOP_INSTANCE_ID_IBI,
                 p_INVENTORY_ITEM_CODE_IBI,
                 p_SERIAL_NO_IBI
            FROM CSG_M_IB_INFO CMIBI                                                                  -- 設置機器情報
           WHERE CMIBI.INVENTORY_ITEM_CODE   = row_CSG_P_IB_INFO_WORK02.PARENT_INVENTORY_ITEM_CODE    --  対象データ（処理3.1）の親品目コード
             AND CMIBI.SERIAL_NO             = row_CSG_P_IB_INFO_WORK02.PARENT_SERIAL_NO;             -- 対象データ（処理3.1）の親シリアル番号
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            NULL;
        END;
        --**********************************************************************
        -- [データ取得件数が0件の場合]
        -- 次のレコードに遷移する。
        -- ※中間テーブルに第2階層、第3階層のレコードが存在する場合、ループ１回目で第2階層、ループ2回目で第3階層の処理となる。
        --**********************************************************************
          IF p_INSTANCE_ID_IBI IS NULL AND 
             p_PARENT_INSTANCE_ID_IBI IS NULL AND
             p_TOP_INSTANCE_ID_IBI IS NULL AND
             p_INVENTORY_ITEM_CODE_IBI IS NULL AND
             p_SERIAL_NO_IBI IS NULL THEN
             GOTO END_LOOP;
          ELSE
          --********************************************************************
          -- Oracleシーケンスで採番したインスタンス番号
          --********************************************************************
          -- SELECT INSTANCE_ID_IBI_SEQ.NEXTVAL INTO v_INSTANCE_ID_SEQ FROM DUAL;
          --********************************************************************
          -- 4.4.設置機器情報の設定
          -- 対象データを設置機器情報に設定する。
          -- ※以下の内容は、設置機器・共通テーブル追加更新APIのパラメータ「設置機器情報」として、設定する。
          -- ※上記以外の項目の更新内容とエラー処理に関しては、処理[2.3]と同様の内容となる為、割愛する。
          -- ＜注＞最上位インスタンスではない為、設置機器共通情報の登録は行わない。
          --********************************************************************
          PRAM_PLACE_HOLDER   := '設置機器情報の設定';
          --********************************************************************
          tIB_BASE               := NEW ARRAY_IB_BASE(
      --                              NEW CONTACT_IB_BASE_OBJ('INSTANCE_ID', v_INSTANCE_ID_SEQ),                                              -- インスタンス番号
                                    NEW CONTACT_IB_BASE_OBJ('PARENT_INSTANCE_ID', p_PARENT_INSTANCE_ID_IBI),                                  -- 親インスタンス番号
                                    NEW CONTACT_IB_BASE_OBJ('TOP_INSTANCE_ID', p_TOP_INSTANCE_ID_IBI),                                        -- 最上位インスタンス番号
                                    NEW CONTACT_IB_BASE_OBJ('INVENTORY_ITEM_CODE', row_CSG_P_IB_INFO_WORK02.INVENTORY_ITEM_CODE),             -- 品目コード
                                    NEW CONTACT_IB_BASE_OBJ('ORG_ID', p_ORG_ID_IBI),                                                          -- プラント
                                    NEW CONTACT_IB_BASE_OBJ('INVENTORY_ITEM_NAME', row_CSG_P_IB_INFO_WORK02.INVENTORY_ITEM_NAME),             -- 品目名
                                    NEW CONTACT_IB_BASE_OBJ('SERIAL_NO', row_CSG_P_IB_INFO_WORK02.SERIAL_NO),                                 -- シリアル番号
                                    NEW CONTACT_IB_BASE_OBJ('MAIN_OPTION_TYPE', row_CSG_P_IB_INFO_WORK02.MAIN_OPTION_TYPE),                   -- 本体オプション区分
                                    NEW CONTACT_IB_BASE_OBJ('IB_SYNC_STATUS', '10009'),                                                       -- IBステータス
                                    NEW CONTACT_IB_BASE_OBJ('QUANTITY', row_CSG_P_IB_INFO_WORK02.QUANTITY),                                   -- 数量
                                    NEW CONTACT_IB_BASE_OBJ('INSTALL_DATE', row_CSG_P_IB_INFO_WORK02.INSTALL_DATE),                           -- 納入日
                                    NEW CONTACT_IB_BASE_OBJ('SALES_DATE', NULL),                                                              -- 売上日
                                    NEW CONTACT_IB_BASE_OBJ('CUSTOMER_ORDER_NO', row_CSG_P_IB_INFO_WORK02.CUSTOMER_ORDER_NO),                 -- 客先注文番号
                                    NEW CONTACT_IB_BASE_OBJ('MAKER_ORDER_NO', row_CSG_P_IB_INFO_WORK02.MAKER_ORDER_NO),                       -- メーカー発注番号
                                    NEW CONTACT_IB_BASE_OBJ('ORDER_NO', row_CSG_P_IB_INFO_WORK02.ORDER_NO),                                   -- 受注番号
                                    NEW CONTACT_IB_BASE_OBJ('TRANSFER_FLAG', row_CSG_P_IB_INFO_WORK02.TRANSFER_FLAG),                        -- 移管品フラグ
--                                    NEW CONTACT_IB_BASE_OBJ('TRANSFER_MAINTENANCE_FROM', NULL),                                               -- 保守移管元
--                                    NEW CONTACT_IB_BASE_OBJ('TRANSFER_MAINTENANCE_TO', NULL),                                                 -- 保守移管先
--                                    NEW CONTACT_IB_BASE_OBJ('TRANSFER_MAINTENANCE_DATE', NULL),                                               -- 保守移管日
--                                    NEW CONTACT_IB_BASE_OBJ('TRANSFER_MAINTNANCE_REASON', NULL),                                              -- 保守移管理由
                                    NEW CONTACT_IB_BASE_OBJ('SALES_OWNER_CODE', row_CSG_P_IB_INFO_WORK02.SALES_OWNER_CODE),                   -- 販売元
                                    NEW CONTACT_IB_BASE_OBJ('MAINTENANCE_TYPE', row_CSG_P_IB_INFO_WORK02.MAINTENANCE_TYPE),                   -- 保守種別
--                                    NEW CONTACT_IB_BASE_OBJ('IMPORTANT_ITEM_FLAG', NULL),                                                     -- 重要案件
--                                    NEW CONTACT_IB_BASE_OBJ('SERVICE_CONDITION', NULL),                                                       -- サービス形態
                                    NEW CONTACT_IB_BASE_OBJ('OUT_SOURCING_FLAG', row_CSG_P_IB_INFO_WORK02.OUT_SOURCING_FLAG),                 -- 外注フラグ
                                    NEW CONTACT_IB_BASE_OBJ('SHIPPING_INSPECTION_FLAG', row_CSG_P_IB_INFO_WORK02.SHIPPING_INSPECTION_FLAG),   -- 出荷検査実施フラグ
--                                    NEW CONTACT_IB_BASE_OBJ('HOST_NAME', NULL),                                                               -- ホスト名
--                                    NEW CONTACT_IB_BASE_OBJ('SYSTEM_NAME', NULL),                                                             -- システム名
--                                    NEW CONTACT_IB_BASE_OBJ('SUPPORT_START_DATE', NULL),                                                      -- 要サポート開始日
--                                    NEW CONTACT_IB_BASE_OBJ('SUPPORT_END_DATE', NULL),                                                        -- 要サポート終了日
--                                    NEW CONTACT_IB_BASE_OBJ('SUPPORT_INSTRUCT_CODE', NULL),                                                   -- 要サポートフラグ
                                    NEW CONTACT_IB_BASE_OBJ('FIRST_SALE_PARTY_CODE', row_CSG_P_IB_INFO_WORK02.FIRST_SALE_PARTY_CODE),         -- 初期販売会社コード
                                    NEW CONTACT_IB_BASE_OBJ('FIRST_SALE_PARTY_LOCATION', row_CSG_P_IB_INFO_WORK02.FIRST_SALE_PARTY_LOCATION), -- 初期販売会社住所
                                    NEW CONTACT_IB_BASE_OBJ('FIRST_SALE_DEPT_NAME', row_CSG_P_IB_INFO_WORK02.FIRST_SALE_DEPT_NAME),           -- 初期販売部署名
                                    NEW CONTACT_IB_BASE_OBJ('FIRST_SALE_TEL', row_CSG_P_IB_INFO_WORK02.FIRST_SALE_TEL),                       -- 初期販売会社TEL
                                    NEW CONTACT_IB_BASE_OBJ('FIRST_SALE_FAX', row_CSG_P_IB_INFO_WORK02.FIRST_SALE_FAX),                       -- 初期販売会社FAX
                                    NEW CONTACT_IB_BASE_OBJ('FIRST_SALE_PERSON_NAME', row_CSG_P_IB_INFO_WORK02.FIRST_SALE_PERSON_NAME),       -- 初期販売担当者名
                                    NEW CONTACT_IB_BASE_OBJ('FIRST_SALE_MAIL_ADDRESS', row_CSG_P_IB_INFO_WORK02.FIRST_SALE_MAIL_ADDRESS),     -- 初期販売メールアドレス
                                    NEW CONTACT_IB_BASE_OBJ('FIRST_COVERAGE', row_CSG_P_IB_INFO_WORK02.FIRST_COVERAGE),                       -- 初回ワランティ条件
                                    NEW CONTACT_IB_BASE_OBJ('FIRST_MONTHS', row_CSG_P_IB_INFO_WORK02.FIRST_MONTHS),                          -- 初回ワランティ月数
                                    NEW CONTACT_IB_BASE_OBJ('FIRST_START_DATE', row_CSG_P_IB_INFO_WORK02.FIRST_START_DATE),                   -- 初回期間(自)
                                    NEW CONTACT_IB_BASE_OBJ('FIRST_END_DATE', row_CSG_P_IB_INFO_WORK02.FIRST_END_DATE),                       -- 初回期間(至)
                                    NEW CONTACT_IB_BASE_OBJ('NEXT_COVERAGE', row_CSG_P_IB_INFO_WORK02.NEXT_COVERAGE),                         -- 次回ワランティ条件
                                    NEW CONTACT_IB_BASE_OBJ('NEXT_MONTHS', row_CSG_P_IB_INFO_WORK02.NEXT_MONTHS),                             -- 次回ワランティ月数
                                    NEW CONTACT_IB_BASE_OBJ('NEXT_START_DATE', row_CSG_P_IB_INFO_WORK02.NEXT_START_DATE),                     -- 次回期間(自)
                                    NEW CONTACT_IB_BASE_OBJ('NEXT_END_DATE', row_CSG_P_IB_INFO_WORK02.NEXT_END_DATE),                        -- 次回期間(至)
                                    NEW CONTACT_IB_BASE_OBJ('AGENT_FLAG', row_CSG_P_IB_INFO_WORK02.AGENT_FLAG),                               -- 販社フラグ
--                                    NEW CONTACT_IB_BASE_OBJ('SECONDARY_INVENTORY_CODE', NULL),                                                -- 委託先コード
                                    NEW CONTACT_IB_BASE_OBJ('BUNDLE_ITEM_CODE', row_CSG_P_IB_INFO_WORK02.BUNDLE_ITEM_CODE),                   -- バンドル品目コード
                                    NEW CONTACT_IB_BASE_OBJ('BUNDLE_ITEM_NAME', p_BUNDLE_ITEM_NAME_IBI),                                      -- バンドル品目名
                                    NEW CONTACT_IB_BASE_OBJ('BUNDLE_SERIAL_NO', row_CSG_P_IB_INFO_WORK02.BUNDLE_SERIAL_NO),                   -- バンドルシリアル
--                                    NEW CONTACT_IB_BASE_OBJ('HOST_ID', NULL),                                                                 -- ホストID
--                                    NEW CONTACT_IB_BASE_OBJ('KEEP_WATCH_SYSTEM_ID', NULL),                                                    -- 監視システムID
--                                    NEW CONTACT_IB_BASE_OBJ('HP_CONFIG_CODE', NULL),                                                          -- HPコンフィグコード
--                                    NEW CONTACT_IB_BASE_OBJ('OS_TYPE', NULL),                                                                 -- OS種別
--                                    NEW CONTACT_IB_BASE_OBJ('OS_VERSION', NULL),                                                              -- OSバージョン
--                                    NEW CONTACT_IB_BASE_OBJ('FIRMWARE_VERSION', NULL),                                                        -- Firmware Version
--                                    NEW CONTACT_IB_BASE_OBJ('REVISION', NULL),                                                                -- リビジョン
--                                    NEW CONTACT_IB_BASE_OBJ('CPU_ROM_REVISION', NULL),                                                        -- CPU　ROMリビジョン
--                                    NEW CONTACT_IB_BASE_OBJ('DISK_CAPACITY', NULL),                                                           -- ディスク容量
--                                    NEW CONTACT_IB_BASE_OBJ('POWER_SUPPLY_TYPE', NULL),                                                       -- 電源設備種類
--                                    NEW CONTACT_IB_BASE_OBJ('POWER_SUPPLY_CAPACITY', NULL),                                                   -- 電源容量
--                                    NEW CONTACT_IB_BASE_OBJ('USE_POWER_FREQUENCY', NULL),                                                     -- 使用電源周波数
--                                    NEW CONTACT_IB_BASE_OBJ('USE_POWER_VOLTAGE', NULL),                                                       -- 使用電源電圧
--                                    NEW CONTACT_IB_BASE_OBJ('HAVING_EARTH_FLAG', NULL),                                                       -- アース有無フラグ
--                                    NEW CONTACT_IB_BASE_OBJ('MAC_ADDRESS', NULL),                                                             -- MACアドレス
--                                    NEW CONTACT_IB_BASE_OBJ('IP_ADDRESS', NULL),                                                              -- IPアドレス
--                                    NEW CONTACT_IB_BASE_OBJ('LICENSE_MANAGEMENT_NO', NULL),                                                   -- ライセンス管理番号
--                                    NEW CONTACT_IB_BASE_OBJ('SUPERINTENDE_MANAGE_NO', NULL),                                                  -- 主管部管理番号
--                                    NEW CONTACT_IB_BASE_OBJ('LISENCE_START_DATE', NULL),                                                      -- ライセンス開始日
--                                    NEW CONTACT_IB_BASE_OBJ('LISENCE_END_DATE', NULL),                                                        -- ライセンス終了日
--                                    NEW CONTACT_IB_BASE_OBJ('REMOVE_ORDER_NO', NULL),                                                         -- 移設受注番号
--                                    NEW CONTACT_IB_BASE_OBJ('REMOVE_PO_NO', NULL),                                                            -- 移設先発注番号
--                                    NEW CONTACT_IB_BASE_OBJ('REMOVE_DATE', NULL),                                                             -- 移設日
--                                    NEW CONTACT_IB_BASE_OBJ('REMOVE_REASON', NULL),                                                           -- 移設理由
                                    NEW CONTACT_IB_BASE_OBJ('SALES_DEPT_ORG_ID', row_CSG_P_IB_INFO_WORK02.SALES_DEPT_ORG_ID),                 -- F営業販売部署コード
                                    NEW CONTACT_IB_BASE_OBJ('SALES_DEPT_PERSON_ID', row_CSG_P_IB_INFO_WORK02.SALES_DEPT_PERSON_ID),           -- F営業販売担当者コード
                                    NEW CONTACT_IB_BASE_OBJ('PRESENT_DEPT_ORG_ID', row_CSG_P_IB_INFO_WORK02.PRESENT_DEPT_ORG_ID),             -- F営業現在担当部署コード
                                    NEW CONTACT_IB_BASE_OBJ('CTC_SALESREP_PERSON_ID', row_CSG_P_IB_INFO_WORK02.CTC_SALESREP_PERSON_ID),       -- F営業現在担当者コード
                                    NEW CONTACT_IB_BASE_OBJ('MAINTE_BUS_DEPT_ORG_ID', row_CSG_P_IB_INFO_WORK02.MAINTE_BUS_DEPT_ORG_ID),       -- 保守営業担当部署コード
                                    NEW CONTACT_IB_BASE_OBJ('MAINTE_BUS_PERSON_ID', row_CSG_P_IB_INFO_WORK02.MAINTE_BUS_PERSON_ID),           -- 保守営業担当者コード
--                                    NEW CONTACT_IB_BASE_OBJ('PP_CONT_AK_NO', NULL),                                                           -- PP契約AK番号
--                                    NEW CONTACT_IB_BASE_OBJ('PP_CONT_START_DATE', NULL),                                                      -- 契約期間(自)
--                                    NEW CONTACT_IB_BASE_OBJ('PP_CONT_END_DATE', NULL),                                                        -- 契約期間(至)
--                                    NEW CONTACT_IB_BASE_OBJ('SN_CHANGE_REASON', NULL),                                                        -- シリアル番号変更理由
                                    NEW CONTACT_IB_BASE_OBJ('X_DEPLOY_FLAG', row_CSG_P_IB_INFO_WORK02.X_DEPLOY_FLAG),                         -- X配備対象フラグ
                                    NEW CONTACT_IB_BASE_OBJ('ACCEPTANCE_DATE', row_CSG_P_IB_INFO_WORK02.ACCEPTANCE_DATE),                     -- 受入日
                                    NEW CONTACT_IB_BASE_OBJ('OUT_WARRANTY_REGISTERED_FLAG', '1')                                              -- 外注契約ワランティ登録済フラグ
                                    );
          --********************************************************************
          -- 4.5.設置機器・共通テーブル追加更新APIのコール
          -- 設置機器・共通テーブル追加更新APIを呼び出す。
          --      引数											            値
          -- 追加・更新区分（I）											  0 ：追加
          -- インスタンス番号（I）										  NULL
          -- 最上位インスタンス番号（I）								処理4.3で取得したインスタンス番号
          -- 設置機器情報（I）											    [4.4.]で設定した情報
          -- 設置機器共通情報（I）										  未設定
          -- 更新プログラムID（I）										  "BAT-CSG02-0301"
          -- 処理ID（I）											        [0.1.]で取得した処理ID
          -- ユーザID（I）											      バッチ実行ユーザID
          -- 楽観ロック比較有無フラグ（I）							N ：楽観ロック比較なし
          -- 比較日時（I）											      NULL
          -- インスタンス番号（O）										  新規に払い出したインスタンス番号
          -- 更新日時（O）											      テーブルに更新した日時
          -- 戻り値											            終了コード
          --********************************************************************
            PRAM_PLACE_HOLDER   := '設置機器・設置機器共通情報更新';
            
            CSG02_IB_COMMON_PKG.CSG02_PROC_IB_TABLE_UPDATE(
                                                            0,
                                                            NULL,
                                                            p_TOP_INSTANCE_ID_IBI,
                                                            tIB_BASE,
                                                            NULL,
                                                            'BAT-CSG02-0301',
                                                            INPUT_PROCESS_ID,
                                                            INPUT_USER_ID,
                                                            'N',
                                                            NULL,
                                                            RETURN_RESULT_CD,
                                                            RETURN_ERR_CONTENT,
                                                            p_INSTANCE_ID,
                                                            P_UPDATE_DATE_IBI
                                                          );
          --********************************************************************
          -- [マスタ存在チェックエラーの場合]
          -- ・中間ワークの処理結果メモにエラー内容を更新し、次のレコードに遷移する。
          --********************************************************************
              PRAM_PLACE_HOLDER   := '設置機器情報中間ワーク更新';
              IF RETURN_ERR_CONTENT IS NOT NULL AND RETURN_RESULT_CD = '21' THEN
                UPDATE CSG_P_IB_INFO_WORK
                   SET PROC_MEMO      = 'マスタ存在チェックエラー',
                       UPDATE_USER_ID = INPUT_USER_ID,
                       UPDATE_DATE    = SYSDATE
                 WHERE ID             = row_CSG_P_IB_INFO_WORK02.ID;
              --****************************************************************
              -- レコードの読込み件数カウンター
              --****************************************************************
              g_warnings_sel_cnt          := g_warnings_sel_cnt + 1;
              END IF;
          --********************************************************************
          -- Oracleシーケンスで採番したインスタンスID
          --********************************************************************
          -- SELECT INSTANCE_MEMO_ID_SEQ.NEXTVAL INTO v_INSTANCE_MEMO_ID_CMIMI FROM DUAL;
          --********************************************************************
          -- 4.6.設置機器メモ情報の設定
          -- [3.1.]で取得したデータの「メモ」に値が設定されている場合のみ、以下を実行する。
          -- 対象データを設置機器メモ情報に設定する。
          -- ※上記以外の項目の更新内容とエラー処理に関しては、処理[2.5.]と同様の内容となる為、割愛する。
          --********************************************************************
          PRAM_PLACE_HOLDER   := '設置機器メモ情報の設定';
          
          tIB_MEMO            := NEW ARRAY_IB_MEMO(
--                                     NEW CONTACT_IB_MEMO_OBJ('INSTANCE_MEMO_ID', v_INSTANCE_MEMO_ID_CMIMI),
                                     NEW CONTACT_IB_MEMO_OBJ('INSTANCE_ID', p_INSTANCE_ID),
                                     NEW CONTACT_IB_MEMO_OBJ('MEMO_TYPE', '04'),            
                                     NEW CONTACT_IB_MEMO_OBJ('TITLE', '出荷時指示'),
                                     NEW CONTACT_IB_MEMO_OBJ('MEMO', row_CSG_P_IB_INFO_WORK02.MEMO),
                                     NEW CONTACT_IB_MEMO_OBJ('SORT_NO', '10'),
                                     NEW CONTACT_IB_MEMO_OBJ('PROGRAM_ID', 'BAT-CSG02-0301'),
                                     NEW CONTACT_IB_MEMO_OBJ('PROCESS_ID', INPUT_PROCESS_ID),
                                     NEW CONTACT_IB_MEMO_OBJ('CREATION_USER_ID', INPUT_USER_ID),
                                     NEW CONTACT_IB_MEMO_OBJ('CREATION_DATE', SYSDATE),
                                     NEW CONTACT_IB_MEMO_OBJ('UPDATE_USER_ID', INPUT_USER_ID),
                                     NEW CONTACT_IB_MEMO_OBJ('UPDATE_DATE', SYSDATE)
                                );
          --********************************************************************
          -- 4.7.設置機器メモ情報追加更新APIのコール
          -- 設置機器メモ情報追加更新APIを呼び出す。
          --      引数											          値
          -- 追加・更新区分（I）											0 ：追加
          -- インスタンス番号（I）										[2.5.]で払い出したインスタンス番号
          -- メモID（I）											      NULL
          -- メモ情報（I）											    [2.6.]で設定した情報
          -- 更新プログラムID（I）										"BAT-CSG02-0301"
          -- 処理ID（I）											      [0.1.]で取得した処理ID
          -- ユーザID（I）											    バッチ実行ユーザID
          -- 楽観ロック比較有無フラグ（I）						N ：楽観ロック比較なし
          -- 比較日時（I）											    NULL
          -- インスタンス番号（O）										更新したインスタンス番号
          -- メモID（O）											      新規に払い出したメモID
          -- 更新日時（O）											    テーブルに更新した日時
          -- 戻り値											          終了コード
          --********************************************************************
            PRAM_PLACE_HOLDER   := '設置機器メモ情報更新';
            CSG02_IB_COMMON_PKG.CSG02_PROC_IB_MEMO_INFO_UPDATE(
                                                                0,
                                                                p_INSTANCE_ID, --row_CSG_P_IB_INFO_WORK02.INSTANCE_ID_IBI,
                                                                NULL,
                                                                tIB_MEMO,
                                                                'BAT-CSG02-0301',
                                                                INPUT_PROCESS_ID,
                                                                INPUT_USER_ID,
                                                                'N',
                                                                NULL,
                                                                RETURN_RESULT_CD,
                                                                RETURN_ERR_CONTENT,
                                                                p_INSTANCE_ID_CMIMI,
                                                                p_MEMO_CMIMI,
                                                                P_UPDATE_DATE_CMIMI
                                                              );
          --********************************************************************
          -- [マスタ存在チェックエラーの場合]
          -- ・中間ワークの処理結果メモにエラー内容を更新し、次のレコードに遷移する。
          -- ・コミットの実行
          -- ・次のレコードの処理に遷移する。（「4.1. レコード件数ループ」に遷移）
          --********************************************************************
            PRAM_PLACE_HOLDER   := '設置機器情報中間ワーク更新';
            IF RETURN_ERR_CONTENT IS NOT NULL AND RETURN_RESULT_CD = '21' THEN
              UPDATE CSG_P_IB_INFO_WORK
                 SET PROC_MEMO      = 'マスタ存在チェックエラー',
                     UPDATE_USER_ID = INPUT_USER_ID,
                     UPDATE_DATE    = SYSDATE
               WHERE ID             = row_CSG_P_IB_INFO_WORK02.ID;
            --******************************************************************
            -- レコードの読込み件数カウンター
            --******************************************************************
            g_warnings_sel_cnt          := g_warnings_sel_cnt + 1;
            END IF;
          END IF;
        --**********************************************************************
        -- 4.2.重複チェック
        -- 処理3.1で取得した「設置機器情報テーブルのインスタンス番号」がNULLでない場合
        -- 設置機器情報テーブルのインスタンス番号で中間ワークテーブルを更新し、次のレコードの処理を行う。（[4.6.]に遷移 → [4.8.]に遷移）
        --**********************************************************************
        --**********************************************************************
        -- 4.8.中間ワーク更新
        -- [3.1.]で設置機器情報登録時に採番されたインスタンスIDを設置機器情報中間ワークに更新する。
        --**********************************************************************
        IF p_INSTANCE_ID IS NOT NULL THEN
          PRAM_PLACE_HOLDER   := '設置機器情報中間ワーク更新';
          
          UPDATE CSG_P_IB_INFO_WORK
             SET INSTANCE_ID    = p_INSTANCE_ID, --row_CSG_P_IB_INFO_WORK02.INSTANCE_ID_IBI,
                 PROCESS_FLAG   = '1',
                 SEND_FLAG      = NULL,
                 UPDATE_USER_ID = INPUT_USER_ID,
                 UPDATE_DATE    = SYSDATE
           WHERE ID             = row_CSG_P_IB_INFO_WORK02.ID;
        --**********************************************************************
        -- レコードの読込み件数カウンター
        --**********************************************************************
        g_normal_sel_cnt          := g_normal_sel_cnt + 1;
        END IF;
      <<END_LOOP>>
      NULL;
      END LOOP;
      CLOSE C_CSG_P_IB_INFO_WORK02;
  --****************************************************************************
  -- 4.9.コミットの実行
  --****************************************************************************
    COMMIT;
    END;
  
    BEGIN
      PRAM_PLACE_HOLDER   := '単独インスタンスの取得';
      
      OPEN c_CSG_P_IB_INFO_WORK03;
      --************************************************************************
      -- 6.単独インスタンスの登録
      -- 6.1. レコード件数ループ
      -- 処理5.1.取得したレコード件数分、以降の処理を行う。
      --************************************************************************
      LOOP
        FETCH c_CSG_P_IB_INFO_WORK03 INTO row_CSG_P_IB_INFO_WORK03;
        --**********************************************************************
        -- [データ取得件数が0件の場合]
        -- 処理「7.終了処理」に遷移
        --**********************************************************************
        EXIT WHEN c_CSG_P_IB_INFO_WORK03%NOTFOUND;
        --**********************************************************************
        -- ※１　プラントの取得　（販売元が”CTCT”の場合、”CTC”と同じプラントを参照する。）
        -- [5.1.]で取得した「販売元」が設定されいる場合のみ、実施する。
        --**********************************************************************
        IF row_CSG_P_IB_INFO_WORK03.SALES_OWNER_CODE IS NOT NULL THEN
          BEGIN
            SELECT SMGS.PARM4                                                 -- パラメータ4 (プラント)
              INTO p_ORG_ID_IBI                                               -- プラント
              FROM SNV_M_GNRC_SNV SMGS                                        -- 汎用マスタ(SNV)
             WHERE SMGS.KEY_ITEM          ='CSG_ROLE_CLASS'                   -- (設置機器使用会社) 汎用マスタ(SNV).キー項目
               AND SMGS.VALD_STRT_DT     <= SYSDATE                           -- 汎用マスタ(SNV).有効開始日
               AND NVL(SMGS.VALD_END_DT,SYSDATE) >= SYSDATE                           -- 汎用マスタ(SNV).有効終了日
               AND NVL(SMGS.DEL_FLG,'N') <> 'X'                               -- 汎用マスタ(SNV).削除フラグ
               AND SMGS.CD_VAL            = row_CSG_P_IB_INFO_WORK03.SALES_OWNER_CODE; -- [1.1.]で取得した「SALES_OWNER_CODE」 汎用マスタ(SNV).コード値
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              GOTO END_LOOP;
          END;
        END IF;
        --**********************************************************************
        -- ※2　バンドル品目名の取得　
        -- [5.1.]で取得した「バンドル品目コード」が設定れている場合のみ、実施する。
        --**********************************************************************
        IF row_CSG_P_IB_INFO_WORK03.BUNDLE_ITEM_CODE IS NOT NULL THEN
          BEGIN
            SELECT SMI.REMARKS                                              -- 摘要
              INTO p_BUNDLE_ITEM_NAME_IBI                                   -- バンドル品目コード
              FROM SNV_M_ITEM SMI                                           -- 品目マスタ
             WHERE SMI.ITEM_CD           = row_CSG_P_IB_INFO_WORK03.BUNDLE_ITEM_CODE -- 品目マスタ.品目コード [1.1.]で取得した「バンドル品目コード」
               AND SMI.PLT               = p_ORG_ID_IBI                     -- 品目マスタ.プラント ※1で取得したプラント
               AND NVL(SMI.DEL_FLG,'N') <> 'X';                             -- 品目マスタ.削除フラグ
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
                GOTO END_LOOP;
          END;
        END IF;
        --********************************************************************
        -- Oracleシーケンスで採番したインスタンス番号
        --********************************************************************
        --  SELECT INSTANCE_ID_IBI_SEQ.NEXTVAL INTO v_INSTANCE_ID_SEQ FROM DUAL;
        --********************************************************************
        -- 6.3.設置機器情報の設定
        -- 対象データを設置機器情報に設定する。
        -- ※以下の内容は、設置機器・共通テーブル追加更新APIのパラメータ「設置機器情報」として、設定する。
        -- （NULL項目は追加・更新APIに渡す項目として、不要な項目とする。）
        --**********************************************************************
        PRAM_PLACE_HOLDER   := '設置機器情報の設定';
        --**********************************************************************
        tIB_BASE               := NEW ARRAY_IB_BASE(
      --                            NEW CONTACT_IB_BASE_OBJ('INSTANCE_ID', v_INSTANCE_ID_SEQ),                                       -- インスタンス番号
--                                  NEW CONTACT_IB_BASE_OBJ('PARENT_INSTANCE_ID', v_INSTANCE_ID_SEQ),                                -- 親インスタンス番号
--                                  NEW CONTACT_IB_BASE_OBJ('TOP_INSTANCE_ID', v_INSTANCE_ID_SEQ),                                   -- 最上位インスタンス番号
                                  NEW CONTACT_IB_BASE_OBJ('INVENTORY_ITEM_CODE', row_CSG_P_IB_INFO_WORK03.INVENTORY_ITEM_CODE),             -- 品目コード
                                  NEW CONTACT_IB_BASE_OBJ('ORG_ID', p_ORG_ID_IBI),                                                 -- プラント
                                  NEW CONTACT_IB_BASE_OBJ('INVENTORY_ITEM_NAME', row_CSG_P_IB_INFO_WORK03.INVENTORY_ITEM_NAME),             -- 品目名
                                  NEW CONTACT_IB_BASE_OBJ('SERIAL_NO', row_CSG_P_IB_INFO_WORK03.SERIAL_NO),                                 -- シリアル番号
                                  NEW CONTACT_IB_BASE_OBJ('MAIN_OPTION_TYPE', row_CSG_P_IB_INFO_WORK03.MAIN_OPTION_TYPE),                   -- 本体オプション区分
                                  NEW CONTACT_IB_BASE_OBJ('IB_SYNC_STATUS', '10009'),                                              -- IBステータス
                                  NEW CONTACT_IB_BASE_OBJ('QUANTITY', row_CSG_P_IB_INFO_WORK03.QUANTITY),                                   -- 数量
                                  NEW CONTACT_IB_BASE_OBJ('INSTALL_DATE', row_CSG_P_IB_INFO_WORK03.INSTALL_DATE),                           -- 納入日
--                                  NEW CONTACT_IB_BASE_OBJ('SALES_DATE', NULL),                                                     -- 売上日
                                  NEW CONTACT_IB_BASE_OBJ('CUSTOMER_ORDER_NO', row_CSG_P_IB_INFO_WORK03.CUSTOMER_ORDER_NO),                 -- 客先注文番号
                                  NEW CONTACT_IB_BASE_OBJ('MAKER_ORDER_NO', row_CSG_P_IB_INFO_WORK03.MAKER_ORDER_NO),                       -- メーカー発注番号
                                  NEW CONTACT_IB_BASE_OBJ('ORDER_NO', row_CSG_P_IB_INFO_WORK03.ORDER_NO),                                   -- 受注番号
                                  NEW CONTACT_IB_BASE_OBJ('TRANSFER_FLAG', row_CSG_P_IB_INFO_WORK03.TRANSFER_FLAG),                        -- 移管品フラグ
--                                  NEW CONTACT_IB_BASE_OBJ('TRANSFER_MAINTENANCE_FROM', NULL),                                      -- 保守移管元
--                                  NEW CONTACT_IB_BASE_OBJ('TRANSFER_MAINTENANCE_TO', NULL),                                        -- 保守移管先
--                                  NEW CONTACT_IB_BASE_OBJ('TRANSFER_MAINTENANCE_DATE', NULL),                                      -- 保守移管日
--                                  NEW CONTACT_IB_BASE_OBJ('TRANSFER_MAINTNANCE_REASON', NULL),                                     -- 保守移管理由
                                  NEW CONTACT_IB_BASE_OBJ('SALES_OWNER_CODE', row_CSG_P_IB_INFO_WORK03.SALES_OWNER_CODE),                   -- 販売元
                                  NEW CONTACT_IB_BASE_OBJ('MAINTENANCE_TYPE', row_CSG_P_IB_INFO_WORK03.MAINTENANCE_TYPE),                   -- 保守種別
--                                  NEW CONTACT_IB_BASE_OBJ('IMPORTANT_ITEM_FLAG', NULL),                                            -- 重要案件
--                                  NEW CONTACT_IB_BASE_OBJ('SERVICE_CONDITION', NULL),                                              -- サービス形態
                                  NEW CONTACT_IB_BASE_OBJ('OUT_SOURCING_FLAG', row_CSG_P_IB_INFO_WORK03.OUT_SOURCING_FLAG),                 -- 外注フラグ
                                  NEW CONTACT_IB_BASE_OBJ('SHIPPING_INSPECTION_FLAG', row_CSG_P_IB_INFO_WORK03.SHIPPING_INSPECTION_FLAG),   -- 出荷検査実施フラグ
--                                  NEW CONTACT_IB_BASE_OBJ('HOST_NAME', NULL),                                                      -- ホスト名
--                                  NEW CONTACT_IB_BASE_OBJ('SYSTEM_NAME', NULL),                                                    -- システム名
--                                  NEW CONTACT_IB_BASE_OBJ('SUPPORT_START_DATE', NULL),                                             -- 要サポート開始日
--                                  NEW CONTACT_IB_BASE_OBJ('SUPPORT_END_DATE', NULL),                                               -- 要サポート終了日
--                                  NEW CONTACT_IB_BASE_OBJ('SUPPORT_INSTRUCT_CODE', NULL),                                          -- 要サポートフラグ
                                  NEW CONTACT_IB_BASE_OBJ('FIRST_SALE_PARTY_CODE', row_CSG_P_IB_INFO_WORK03.FIRST_SALE_PARTY_CODE),         -- 初期販売会社コード
                                  NEW CONTACT_IB_BASE_OBJ('FIRST_SALE_PARTY_LOCATION', row_CSG_P_IB_INFO_WORK03.FIRST_SALE_PARTY_LOCATION), -- 初期販売会社住所
                                  NEW CONTACT_IB_BASE_OBJ('FIRST_SALE_DEPT_NAME', row_CSG_P_IB_INFO_WORK03.FIRST_SALE_DEPT_NAME),                                             -- 初期販売部署名
                                  NEW CONTACT_IB_BASE_OBJ('FIRST_SALE_TEL', row_CSG_P_IB_INFO_WORK03.FIRST_SALE_TEL),                       -- 初期販売会社TEL
                                  NEW CONTACT_IB_BASE_OBJ('FIRST_SALE_FAX', row_CSG_P_IB_INFO_WORK03.FIRST_SALE_FAX),                       -- 初期販売会社FAX
                                  NEW CONTACT_IB_BASE_OBJ('FIRST_SALE_PERSON_NAME', row_CSG_P_IB_INFO_WORK03.FIRST_SALE_PERSON_NAME),                                           -- 初期販売担当者名
                                  NEW CONTACT_IB_BASE_OBJ('FIRST_SALE_MAIL_ADDRESS', row_CSG_P_IB_INFO_WORK03.FIRST_SALE_MAIL_ADDRESS),     -- 初期販売メールアドレス
                                  NEW CONTACT_IB_BASE_OBJ('FIRST_COVERAGE', row_CSG_P_IB_INFO_WORK03.FIRST_COVERAGE),                       -- 初回ワランティ条件
                                  NEW CONTACT_IB_BASE_OBJ('FIRST_MONTHS', row_CSG_P_IB_INFO_WORK03.FIRST_MONTHS),                          -- 初回ワランティ月数
                                  NEW CONTACT_IB_BASE_OBJ('FIRST_START_DATE', row_CSG_P_IB_INFO_WORK03.FIRST_START_DATE),                   -- 初回期間(自)
                                  NEW CONTACT_IB_BASE_OBJ('FIRST_END_DATE', row_CSG_P_IB_INFO_WORK03.FIRST_END_DATE),                       -- 初回期間(至)
                                  NEW CONTACT_IB_BASE_OBJ('NEXT_COVERAGE', row_CSG_P_IB_INFO_WORK03.NEXT_COVERAGE),                         -- 次回ワランティ条件
                                  NEW CONTACT_IB_BASE_OBJ('NEXT_MONTHS', row_CSG_P_IB_INFO_WORK03.NEXT_MONTHS),                             -- 次回ワランティ月数
                                  NEW CONTACT_IB_BASE_OBJ('NEXT_START_DATE', row_CSG_P_IB_INFO_WORK03.NEXT_START_DATE),                     -- 次回期間(自)
                                  NEW CONTACT_IB_BASE_OBJ('NEXT_END_DATE', row_CSG_P_IB_INFO_WORK03.NEXT_END_DATE),                        -- 次回期間(至)
                                  NEW CONTACT_IB_BASE_OBJ('AGENT_FLAG', row_CSG_P_IB_INFO_WORK03.AGENT_FLAG),                               -- 販社フラグ
--                                  NEW CONTACT_IB_BASE_OBJ('SECONDARY_INVENTORY_CODE', NULL),                                       -- 委託先コード
                                  NEW CONTACT_IB_BASE_OBJ('BUNDLE_ITEM_CODE', row_CSG_P_IB_INFO_WORK03.BUNDLE_ITEM_CODE),                   -- バンドル品目コード
                                  NEW CONTACT_IB_BASE_OBJ('BUNDLE_ITEM_NAME', p_BUNDLE_ITEM_NAME_IBI),                             -- バンドル品目名
                                  NEW CONTACT_IB_BASE_OBJ('BUNDLE_SERIAL_NO', row_CSG_P_IB_INFO_WORK03.BUNDLE_SERIAL_NO),                   -- バンドルシリアル
--                                  NEW CONTACT_IB_BASE_OBJ('HOST_ID', NULL),                                                        -- ホストID
--                                  NEW CONTACT_IB_BASE_OBJ('KEEP_WATCH_SYSTEM_ID', NULL),                                           -- 監視システムID
--                                  NEW CONTACT_IB_BASE_OBJ('HP_CONFIG_CODE', NULL),                                                 -- HPコンフィグコード
--                                  NEW CONTACT_IB_BASE_OBJ('OS_TYPE', NULL),                                                        -- OS種別
--                                  NEW CONTACT_IB_BASE_OBJ('OS_VERSION', NULL),                                                     -- OSバージョン
--                                  NEW CONTACT_IB_BASE_OBJ('FIRMWARE_VERSION', NULL),                                               -- Firmware Version
--                                  NEW CONTACT_IB_BASE_OBJ('REVISION', NULL),                                                       -- リビジョン
--                                  NEW CONTACT_IB_BASE_OBJ('CPU_ROM_REVISION', NULL),                                               -- CPU　ROMリビジョン
--                                  NEW CONTACT_IB_BASE_OBJ('DISK_CAPACITY', NULL),                                                  -- ディスク容量
--                                  NEW CONTACT_IB_BASE_OBJ('POWER_SUPPLY_TYPE', NULL),                                              -- 電源設備種類
--                                  NEW CONTACT_IB_BASE_OBJ('POWER_SUPPLY_CAPACITY', NULL),                                          -- 電源容量
--                                  NEW CONTACT_IB_BASE_OBJ('USE_POWER_FREQUENCY', NULL),                                            -- 使用電源周波数
--                                  NEW CONTACT_IB_BASE_OBJ('USE_POWER_VOLTAGE', NULL),                                              -- 使用電源電圧
--                                  NEW CONTACT_IB_BASE_OBJ('HAVING_EARTH_FLAG', NULL),                                              -- アース有無フラグ
--                                  NEW CONTACT_IB_BASE_OBJ('MAC_ADDRESS', NULL),                                                    -- MACアドレス
--                                  NEW CONTACT_IB_BASE_OBJ('IP_ADDRESS', NULL),                                                     -- IPアドレス
--                                  NEW CONTACT_IB_BASE_OBJ('LICENSE_MANAGEMENT_NO', NULL),                                          -- ライセンス管理番号
--                                  NEW CONTACT_IB_BASE_OBJ('SUPERINTENDE_MANAGE_NO', NULL),                                         -- 主管部管理番号
--                                  NEW CONTACT_IB_BASE_OBJ('LISENCE_START_DATE', NULL),                                             -- ライセンス開始日
--                                  NEW CONTACT_IB_BASE_OBJ('LISENCE_END_DATE', NULL),                                               -- ライセンス終了日
--                                  NEW CONTACT_IB_BASE_OBJ('REMOVE_ORDER_NO', NULL),                                                -- 移設受注番号
--                                  NEW CONTACT_IB_BASE_OBJ('REMOVE_PO_NO', NULL),                                                   -- 移設先発注番号
--                                  NEW CONTACT_IB_BASE_OBJ('REMOVE_DATE', NULL),                                                    -- 移設日
--                                  NEW CONTACT_IB_BASE_OBJ('REMOVE_REASON', NULL),                                                  -- 移設理由
                                  NEW CONTACT_IB_BASE_OBJ('SALES_DEPT_ORG_ID', row_CSG_P_IB_INFO_WORK03.SALES_DEPT_ORG_ID),                 -- F営業販売部署コード
                                  NEW CONTACT_IB_BASE_OBJ('SALES_DEPT_PERSON_ID', row_CSG_P_IB_INFO_WORK03.SALES_DEPT_PERSON_ID),           -- F営業販売担当者コード
                                  NEW CONTACT_IB_BASE_OBJ('PRESENT_DEPT_ORG_ID', row_CSG_P_IB_INFO_WORK03.PRESENT_DEPT_ORG_ID),             -- F営業現在担当部署コード
                                  NEW CONTACT_IB_BASE_OBJ('CTC_SALESREP_PERSON_ID', row_CSG_P_IB_INFO_WORK03.CTC_SALESREP_PERSON_ID),       -- F営業現在担当者コード
                                  NEW CONTACT_IB_BASE_OBJ('MAINTE_BUS_DEPT_ORG_ID', row_CSG_P_IB_INFO_WORK03.MAINTE_BUS_DEPT_ORG_ID),       -- 保守営業担当部署コード
                                  NEW CONTACT_IB_BASE_OBJ('MAINTE_BUS_PERSON_ID', row_CSG_P_IB_INFO_WORK03.MAINTE_BUS_PERSON_ID),           -- 保守営業担当者コード
--                                  NEW CONTACT_IB_BASE_OBJ('PP_CONT_AK_NO', NULL),                                                  -- PP契約AK番号
--                                  NEW CONTACT_IB_BASE_OBJ('PP_CONT_START_DATE', NULL),                                             -- 契約期間(自)
--                                  NEW CONTACT_IB_BASE_OBJ('PP_CONT_END_DATE', NULL),                                               -- 契約期間(至)
--                                  NEW CONTACT_IB_BASE_OBJ('SN_CHANGE_REASON', NULL),                                               -- シリアル番号変更理由
                                  NEW CONTACT_IB_BASE_OBJ('X_DEPLOY_FLAG', row_CSG_P_IB_INFO_WORK03.X_DEPLOY_FLAG),                         -- X配備対象フラグ
                                  NEW CONTACT_IB_BASE_OBJ('ACCEPTANCE_DATE', row_CSG_P_IB_INFO_WORK03.ACCEPTANCE_DATE),                                                  -- 受入日
                                  NEW CONTACT_IB_BASE_OBJ('OUT_WARRANTY_REGISTERED_FLAG', '1')                                     -- 外注契約ワランティ登録済フラグ
                                  );
        --**********************************************************************
        -- ※２　設置先住所コードの取得　
        -- [5.1.]で取得した「SHIPMENT_LOCATION_CODE」が設定されている場合のみ、実施する。
        --**********************************************************************
        IF row_CSG_P_IB_INFO_WORK03.SHIPMENT_LOCATION_CODE IS NOT NULL THEN
          BEGIN
            SELECT CMIA.INSTALL_LOCATION_CODE                                              -- 設置先住所コード
              INTO p_INSTALL_LOCATION_CODE
              FROM CSG_M_IB_ADDRESS CMIA                                                   -- 設置先住所マスタ
             WHERE CMIA.SHIPMENT_LOCATION_CODE   = row_CSG_P_IB_INFO_WORK03.SHIPMENT_LOCATION_CODE  -- 設置先住所マスタ.出荷先コード [1.1.]で取得した「出荷先コード」
               AND CMIA.ACTIVE_FLAG              = 'Y';                                    -- 設置先住所マスタ.有効フラグ "Y"：有効
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              GOTO END_LOOP;
          END;
        END IF;
        --**************************************************************************
        -- ※１　担当CSコードの取得
        -- 中間ワークテーブルの以下の項目により、顧客マスタ、設置先住所マスタ、郵便番号マスタ、担当CSテリトリー情報より「グループID」を取得する。
        -- ※取得方法に関しては、別ファイル「バッチ設計_CSG02-0019-担当CS設定.xlsx」参照
        -- NO	 I/O			項目名										備考
        --  1	  I			機種コード									[1.1.]で取得した機種コード            IBIW.KINDS_CODE
        --  2	  I			顧客番号										[1.1.]で取得した設置先顧客コード       IBIW.INSTALL_CUSTOMER_CODE
        --  3	  I			Ｆ営業部課コード							[1.1.]で取得したF営業現在部署コード    IBIW.PRESENT_DEPT_ORG_ID
        --  4	  I			設置先住所ＩＤ							[1.1.]で取得した設置先顧客住所コード    IBIW.INSTALL_LOCATION_CODE
        --  5	  O			グループID									担当CSコードとして取得
        --  6	  O			終了コード									0：正常終了　20：異常終了	
        --**************************************************************************
          PRAM_PLACE_HOLDER   := '担当CSコードの取得';
          
          CSG02_0110_PKG.CSG02_PROC_CHARGE_OF_CS_SET(
                                      row_CSG_P_IB_INFO_WORK03.KINDS_CODE,
                                      row_CSG_P_IB_INFO_WORK03.INSTALL_CUSTOMER_CODE,
                                      row_CSG_P_IB_INFO_WORK03.PRESENT_DEPT_ORG_ID,
                                      p_INSTALL_LOCATION_CODE,
                                      RETURN_RESULT_CD,
                                      OUT_RESULT_GET,
                                      OUT_CONDITION_GET,
                                      p_CS_IN_CHARGE_CODE
                                      );
        
        --**********************************************************************
        -- ※３　エンドユーザ会社名の取得　※購買からもらえる可能性あり（保留）
        -- [5.1.]で取得した「ENDUSER_PARTY_CODE」が設定されている場合のみ、実施する。
        --**********************************************************************
        IF row_CSG_P_IB_INFO_WORK03.ENDUSER_PARTY_ID IS NOT NULL THEN
          BEGIN
            SELECT SMC.CUST_FRML_NM                                      -- 顧客正式名称
              INTO p_ENDUSER_PARTY_NAME
              FROM SNV_M_CUST SMC                                        -- 顧客マスタ
             WHERE SMC.CUST_CD        = row_CSG_P_IB_INFO_WORK03.ENDUSER_PARTY_ID -- 顧客マスタ.顧客コード [1.1.]で取得した「エンドユーザ会社コード」
               AND SMC.HDQRTRS_ID_FLG = 'Y'                              -- 顧客マスタ.本社識別フラグ "Y"：本社
               AND SMC.DEL_FLG       <> 'X';                             -- 顧客マスタ.削除フラグ "X"：削除　以外
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              GOTO END_LOOP;
          END;
        END IF;
        --**************************************************************************
        -- ※4　エンドユーザ特定顧客コードの取得　
        -- エンドユーザ特定顧客コードは汎用マスタ（汎用プロパティ）より取得する。
        --**************************************************************************
        BEGIN
          SELECT LISTAGG(SMGS.DTL_TXT_SHRT_NM, ',') 
          WITHIN GROUP (ORDER BY SMGS.DTL_TXT_SHRT_NM) AS DTL_TXT_SHRT_NM -- 汎用マスタ.明細テキスト(短縮名)
            INTO p_ENDUSER_PARTY_ID
            FROM SNV_M_GNRC_SNV SMGS                                      -- 汎用マスタ(SNV)
           WHERE SMGS.KEY_ITEM          = 'CSG_GENERAL_PROP'              -- 汎用マスタ(SNV).キー項目 'CSG_GENERAL_PROP'(汎用プロパティ)
             AND SMGS.VALD_STRT_DT     <= SYSDATE                         -- 汎用マスタ(SNV).有効開始日
             AND NVL(SMGS.VALD_END_DT,SYSDATE) >= SYSDATE                 -- 汎用マスタ(SNV).有効終了日
             AND NVL(SMGS.DEL_FLG,'N') <> 'X'                             -- 汎用マスタ(SNV).削除フラグ
             AND SMGS.CD_VAL            = 'EU_SP_CUSTOMER_CODE';          -- 汎用マスタ(SNV).コード値  エンドユーザ特定顧客コード 'EU_SP_CUSTOMER_CODE'
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            GOTO END_LOOP;
        END;
          --********************************************************************
          -- INSTALL_BASE_INFO_WORK.ENDUSER_PARTY_IDにエンドユーザ特定顧客コード（※4）が設定されている場合
          -- ⇒INSTALL_BASE_INFO_WORK.ENDUSER_PARTY_NAMEの値を設定
          -- INSTALL_BASE_INFO_WORK.ENDUSER_PARTY_IDにエンドユーザ特定顧客コード以外が設定されている場合
          -- ⇒顧客マスタから取得　※３参照
          --********************************************************************
          IF p_ENDUSER_PARTY_ID IS NOT NULL THEN
              BEGIN
                SELECT Count(*)
                  INTO v_ENDUSER_PARTY_ID
                  FROM(
                    SELECT REGEXP_SUBSTR(to_char(p_ENDUSER_PARTY_ID), '[^,]+', 1, LEVEL) AS ENDUSER_PARTY_CODE
                      FROM DUAL
                   CONNECT BY REGEXP_SUBSTR(to_char(p_ENDUSER_PARTY_ID), '[^,]+', 1, LEVEL) IS NOT NULL
                  )
                 WHERE ENDUSER_PARTY_CODE = row_CSG_P_IB_INFO_WORK03.ENDUSER_PARTY_ID;
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  GOTO END_LOOP;
              END;
              
              IF v_ENDUSER_PARTY_ID >= 1 THEN
                p_ENDUSER_PARTY_NAME_WK   :=   row_CSG_P_IB_INFO_WORK03.ENDUSER_PARTY_NAME;
              ELSE
                p_ENDUSER_PARTY_NAME_WK   :=   p_ENDUSER_PARTY_NAME;
              END IF;
          END IF;
        --**************************************************************************
        -- 6.4.設置機器共通情報の設定
        -- 対象データを設置機器共通情報に設定する。
        -- ※以下の内容は、設置機器・共通テーブル追加更新APIのパラメータ「設置機器共通情報」として、設定する。
        -- （NULL項目は追加・更新APIに渡す項目として、不要な項目とする。）
        --**************************************************************************
          PRAM_PLACE_HOLDER   := '設置機器共通情報の設定';
        --**************************************************************************
        tIB_COMMON               := NEW ARRAY_IB_COMMON(
                                    NEW CONTACT_IB_COMMON_OBJ('CS_IN_CHARGE_CODE', p_CS_IN_CHARGE_CODE),                                    -- 担当CSコード
--                                    NEW CONTACT_IB_COMMON_OBJ('CE_CODE', NULL),                                                             -- 担当CEコード
                                    NEW CONTACT_IB_COMMON_OBJ('INSTALL_CUSTOMER_CODE', row_CSG_P_IB_INFO_WORK03.INSTALL_CUSTOMER_CODE),              -- 設置先顧客コード
                                    NEW CONTACT_IB_COMMON_OBJ('INSTALL_LOCATION_CODE', p_INSTALL_LOCATION_CODE),                            -- 設置先顧客住所コード
                                    NEW CONTACT_IB_COMMON_OBJ('INSTALL_LOCATION_DEPT_NAME', row_CSG_P_IB_INFO_WORK03.INSTALL_LOCATION_DEPT_NAME),    -- 設置先顧客部署名
                                    NEW CONTACT_IB_COMMON_OBJ('INSTALL_LOCATION_PERSON_NAME', row_CSG_P_IB_INFO_WORK03.INSTALL_LOCATION_PERSON_NAME),-- 設置先顧客担当者名
                                    NEW CONTACT_IB_COMMON_OBJ('INSTALL_LOCATION_TEL', row_CSG_P_IB_INFO_WORK03.INSTALL_LOCATION_TEL),                -- 設置先TEL
--                                    NEW CONTACT_IB_COMMON_OBJ('INSTALL_LOCATION_FAX', NULL),                                                -- 設置先FAX
                                    NEW CONTACT_IB_COMMON_OBJ('INCIDENT_SERVIRITY_NAME', 'P5'),                                             -- 重要度
--                                    NEW CONTACT_IB_COMMON_OBJ('USE_CONDITION', NULL),                                                       -- 利用形態
--                                    NEW CONTACT_IB_COMMON_OBJ('USE_PERPOSE', NULL),                                                         -- 利用目的
                                    NEW CONTACT_IB_COMMON_OBJ('ENDUSER_PARTY_CODE', row_CSG_P_IB_INFO_WORK03.ENDUSER_PARTY_ID),                      -- エンドユーザ会社コード
                                    NEW CONTACT_IB_COMMON_OBJ('ENDUSER_PARTY_NAME', p_ENDUSER_PARTY_NAME_WK),                                  -- エンドユーザ会社名
                                    NEW CONTACT_IB_COMMON_OBJ('ENDUSER_LOCATION', row_CSG_P_IB_INFO_WORK03.ENDUSER_LOCATION),                        -- エンドユーザ住所
                                    NEW CONTACT_IB_COMMON_OBJ('ENDUSER_CHRG_DEPT_NAME', row_CSG_P_IB_INFO_WORK03.ENDUSER_CHRG_DEPT_NAME),            -- エンドユーザ部署名
                                    NEW CONTACT_IB_COMMON_OBJ('ENDUSER_CHRG_PERSON_NAME', row_CSG_P_IB_INFO_WORK03.ENDUSER_CHRG_PERSON_NAME),        -- エンドユーザ担当者名
                                    NEW CONTACT_IB_COMMON_OBJ('ENDUSER_TEL', row_CSG_P_IB_INFO_WORK03.ENDUSER_TEL),                                  -- エンドユーザTEL
                                    NEW CONTACT_IB_COMMON_OBJ('ENDUSER_FAX', row_CSG_P_IB_INFO_WORK03.ENDUSER_FAX),                                  -- エンドユーザFAX
                                    NEW CONTACT_IB_COMMON_OBJ('ENDUSER_MAIL_ADDRESS', row_CSG_P_IB_INFO_WORK03.ENDUSER_MAIL_ADDRESS),                -- エンドユーザメールアドレス
                                    NEW CONTACT_IB_COMMON_OBJ('PROGRAM_ID', 'BAT-CSG02-0301'),                                              -- 更新プログラムID
                                    NEW CONTACT_IB_COMMON_OBJ('PROCESS_ID', INPUT_PROCESS_ID),                                              -- 処理ID
                                    NEW CONTACT_IB_COMMON_OBJ('CREATION_USER_ID', INPUT_USER_ID),                                           -- 作成者
                                    NEW CONTACT_IB_COMMON_OBJ('CREATION_DATE', SYSDATE),                                                    -- 作成日時
                                    NEW CONTACT_IB_COMMON_OBJ('UPDATE_USER_ID', INPUT_USER_ID),                                             -- 更新者
                                    NEW CONTACT_IB_COMMON_OBJ('UPDATE_DATE', SYSDATE)                                                       --更新日時
                                    );
        --********************************************************************
        -- 6.5.設置機器・共通テーブル追加更新APIのコール
        -- 設置機器・共通テーブル追加更新APIを呼び出す。
        --      引数											            値
        -- 追加・更新区分（I）											  0 ：追加
        -- インスタンス番号（I）										  NULL
        -- 最上位インスタンス番号（I）								処理4.3で取得したインスタンス番号
        -- 設置機器情報（I）											    [4.4.]で設定した情報
        -- 設置機器共通情報（I）										  未設定
        -- 更新プログラムID（I）										  "BAT-CSG02-0301"
        -- 処理ID（I）											        [0.1.]で取得した処理ID
        -- ユーザID（I）											      バッチ実行ユーザID
        -- 楽観ロック比較有無フラグ（I）							N ：楽観ロック比較なし
        -- 比較日時（I）											      NULL
        -- インスタンス番号（O）										  新規に払い出したインスタンス番号
        -- 更新日時（O）											      テーブルに更新した日時
        -- 戻り値											            終了コード
        --********************************************************************
          PRAM_PLACE_HOLDER   := '設置機器・設置機器共通情報更新';
          
          CSG02_IB_COMMON_PKG.CSG02_PROC_IB_TABLE_UPDATE(
                                                          0,
                                                          NULL,
                                                          NULL,
                                                          tIB_BASE,
                                                          tIB_COMMON,
                                                          'BAT-CSG02-0301',
                                                          INPUT_PROCESS_ID,
                                                          INPUT_USER_ID,
                                                          'N',
                                                          NULL,
                                                          RETURN_RESULT_CD,
                                                          RETURN_ERR_CONTENT,
                                                          p_INSTANCE_ID,
                                                          P_UPDATE_DATE_IBI
                                                        );
        --********************************************************************
        -- [マスタ存在チェックエラーの場合]
        -- ・中間ワークの処理結果メモにエラー内容を更新し、次のレコードに遷移する。
        --********************************************************************
            PRAM_PLACE_HOLDER   := '設置機器情報中間ワーク更新';
            IF RETURN_ERR_CONTENT IS NOT NULL AND RETURN_RESULT_CD = '21' THEN
              UPDATE CSG_P_IB_INFO_WORK
                 SET PROC_MEMO      = 'マスタ存在チェックエラー',
                     UPDATE_USER_ID = INPUT_USER_ID,
                     UPDATE_DATE    = SYSDATE
               WHERE ID             = row_CSG_P_IB_INFO_WORK03.ID;
           --*******************************************************************
           -- レコードの読込み件数カウンター
           --*******************************************************************
           g_warnings_sel_cnt          := g_warnings_sel_cnt + 1;
            END IF;
        --********************************************************************
        -- Oracleシーケンスで採番したインスタンスID
        --********************************************************************
        -- SELECT INSTANCE_MEMO_ID_SEQ.NEXTVAL INTO v_INSTANCE_MEMO_ID_CMIMI FROM DUAL;
        --********************************************************************
        -- 6.6.設置機器メモ情報の設定
        -- 以下の処理は必須で実行する。（処理5.1で取得したデータの「メモ」に値に関係なく、以下を実行する。）
        -- 対象データを設置機器メモ情報に設定する。
        --********************************************************************
            p_MEMO  :=  '親インスタンスなし 親品目コード = ' || row_CSG_P_IB_INFO_WORK03.PARENT_INVENTORY_ITEM_CODE || 
                        ' 親シリアル番号 = ' || row_CSG_P_IB_INFO_WORK03.PARENT_SERIAL_NO;
            PRAM_PLACE_HOLDER   := '設置機器メモ情報の設定';
            
            tIB_MEMO            := NEW ARRAY_IB_MEMO(
--                                     NEW CONTACT_IB_MEMO_OBJ('INSTANCE_MEMO_ID', v_INSTANCE_MEMO_ID_CMIMI),
                                     NEW CONTACT_IB_MEMO_OBJ('INSTANCE_ID', p_INSTANCE_ID),
                                     NEW CONTACT_IB_MEMO_OBJ('MEMO_TYPE', '04'),            
                                     NEW CONTACT_IB_MEMO_OBJ('TITLE', '出荷時指示'),
                                     NEW CONTACT_IB_MEMO_OBJ('MEMO', p_MEMO),
                                     NEW CONTACT_IB_MEMO_OBJ('SORT_NO', '10'),
                                     NEW CONTACT_IB_MEMO_OBJ('PROGRAM_ID', 'BAT-CSG02-0301'),
                                     NEW CONTACT_IB_MEMO_OBJ('PROCESS_ID', INPUT_PROCESS_ID),
                                     NEW CONTACT_IB_MEMO_OBJ('CREATION_USER_ID', INPUT_USER_ID),
                                     NEW CONTACT_IB_MEMO_OBJ('CREATION_DATE', SYSDATE),
                                     NEW CONTACT_IB_MEMO_OBJ('UPDATE_USER_ID', INPUT_USER_ID),
                                     NEW CONTACT_IB_MEMO_OBJ('UPDATE_DATE', SYSDATE)
                                  );
        --********************************************************************
        -- 6.7.設置機器メモ情報追加更新APIのコール
        -- 設置機器メモ情報追加更新APIを呼び出す。
        --      引数											          値
        -- 追加・更新区分（I）											0 ：追加
        -- インスタンス番号（I）										[2.5.]で払い出したインスタンス番号
        -- メモID（I）											      NULL
        -- メモ情報（I）											    [2.6.]で設定した情報
        -- 更新プログラムID（I）										"BAT-CSG02-0301"
        -- 処理ID（I）											      [0.1.]で取得した処理ID
        -- ユーザID（I）											    バッチ実行ユーザID
        -- 楽観ロック比較有無フラグ（I）						N ：楽観ロック比較なし
        -- 比較日時（I）											    NULL
        -- インスタンス番号（O）										更新したインスタンス番号
        -- メモID（O）											      新規に払い出したメモID
        -- 更新日時（O）											    テーブルに更新した日時
        -- 戻り値											          終了コード
        --********************************************************************
          PRAM_PLACE_HOLDER   := '設置機器メモ情報更新';
          
          CSG02_IB_COMMON_PKG.CSG02_PROC_IB_MEMO_INFO_UPDATE(
                                                              0,
                                                              p_INSTANCE_ID, --row_CSG_P_IB_INFO_WORK03.INSTANCE_ID_IBI,
                                                              NULL,
                                                              tIB_MEMO,
                                                              'BAT-CSG02-0301',
                                                              INPUT_PROCESS_ID,
                                                              INPUT_USER_ID,
                                                              'N',
                                                              NULL,
                                                              RETURN_RESULT_CD,
                                                              RETURN_ERR_CONTENT,
                                                              p_INSTANCE_ID_CMIMI,
                                                              p_MEMO_CMIMI,
                                                              P_UPDATE_DATE_CMIMI
                                                            );
        --********************************************************************
        -- [マスタ存在チェックエラーの場合]
        -- ・中間ワークの処理結果メモにエラー内容を更新し、次のレコードに遷移する。
        --********************************************************************
            PRAM_PLACE_HOLDER   := '設置機器情報中間ワーク更新';
            IF RETURN_ERR_CONTENT IS NOT NULL AND RETURN_RESULT_CD = '21' THEN
              UPDATE CSG_P_IB_INFO_WORK
                 SET PROC_MEMO      = 'マスタ存在チェックエラー',
                     UPDATE_USER_ID = INPUT_USER_ID,
                     UPDATE_DATE    = SYSDATE
               WHERE ID             = row_CSG_P_IB_INFO_WORK03.ID;
            --******************************************************************
            -- レコードの読込み件数カウンター
            --******************************************************************
            g_warnings_sel_cnt          := g_warnings_sel_cnt + 1;
            END IF;
        --**********************************************************************
        -- 6.2.重複チェック
        -- 処理5.1で取得した「設置機器情報テーブルのインスタンス番号」がNULLでない場合
        -- 設置機器情報テーブルのインスタンス番号で中間ワークテーブルを更新し、次のレコードの処理を行う。（[6.8.]に遷移）
        --**********************************************************************
        --**********************************************************************
        -- 6.8.中間ワークの更新
        -- インスタンスIDを設置機器情報中間ワークに更新する。
        --**********************************************************************
        IF p_INSTANCE_ID IS NOT NULL THEN
          PRAM_PLACE_HOLDER   := '設置機器情報中間ワーク更新';
          
          UPDATE CSG_P_IB_INFO_WORK
             SET INSTANCE_ID    = p_INSTANCE_ID, --row_CSG_P_IB_INFO_WORK03.INSTANCE_ID_IBI,
                 PROCESS_FLAG   = '1',
                 SEND_FLAG      = NULL,
                 UPDATE_USER_ID = INPUT_USER_ID,
                 UPDATE_DATE    = SYSDATE
           WHERE ID             = row_CSG_P_IB_INFO_WORK03.ID;
        --******************************************************************
        -- レコードの読込み件数カウンター
        --******************************************************************
        g_normal_sel_cnt          := g_normal_sel_cnt + 1;
        END IF;
      <<END_LOOP>>
      NULL;
      END LOOP;
      CLOSE c_CSG_P_IB_INFO_WORK03;
  --****************************************************************************
  -- 6.7.コミットの実行
  --****************************************************************************
    COMMIT;
    END;
    
    RETURN_ERR_CONTENT := '処理結果　対象件数：' || g_target_sel_cnt || '　正常件数：' || g_normal_sel_cnt || '　警告件数：' || g_warnings_sel_cnt;
EXCEPTION
    WHEN PRAM_EXCEPTION THEN
        RETURN_RESULT_CD := '20';
      --************************************************************************
      -- 呼び出し元機能のステータス
      -- 0:処理中
      -- 1:正常終了
      -- 2:警告終了
      -- 3:エラー
      --************************************************************************
        RETURN_STATUS      := '3';
        RETURN_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
        RETURN_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
        ROLLBACK;
        RETURN;
    -- その他未定義の例外の処理
    WHEN OTHERS THEN
        RETURN_RESULT_CD := '20';
        DBMS_OUTPUT.PUT_LINE('ORACLE ERR_CODE    := ' || SQLCODE);            -- ＤＢエラーコード
        DBMS_OUTPUT.PUT_LINE('ORACLE ERR_MESSAGE := ' || SQLERRM(SQLCODE));   -- ＤＢエラーメッセージ
        DBMS_OUTPUT.PUT_LINE('PROC POINT         := ' || g_shori_point);      -- 処理ポイント
        IF g_err_command IS NOT NULL THEN
            DBMS_OUTPUT.PUT_LINE(g_err_command);
            DBMS_OUTPUT.PUT_LINE(g_err_key);
        END IF;
      --************************************************************************
      -- 呼び出し元機能のステータス
      -- 0:処理中
      -- 1:正常終了
      -- 2:警告終了
      -- 3:エラー
      --************************************************************************
        RETURN_STATUS      := '3';
        RETURN_ERR_CONTENT := g_shori_point || ' ' || TO_CHAR(SQLCODE);
        RETURN_ERR_DETAIL  := g_shori_point || ' ' || TO_CHAR(SQLCODE) || ' ' || SQLERRM(SQLCODE);
        ROLLBACK;
        RETURN;
  END CSG02_PROC_INS_EQUIPMENT_REG;
  
END CSG02_0301_PKG;

/
