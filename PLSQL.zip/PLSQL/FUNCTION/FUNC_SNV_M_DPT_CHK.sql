--------------------------------------------------------
--  DDL for Function FUNC_SNV_M_DPT_CHK
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "FUNC_SNV_M_DPT_CHK" 
(
  PARAM1 IN VARCHAR2,           -- 組織マスタ.組織コード(経費負担部課)
  PARAM2 IN NUMBER DEFAULT 0
) RETURN NUMBER AS 
--******************************************************************************
-- ■マスタ存在チェック
-- 設置機器共通情報の以下の項目が存在する値か否かをチェックする。
-- ※件数が0件の場合は、マスタに存在しない値として、エラーとする。
--******************************************************************************
  GET_COUNT       NUMBER;
BEGIN
  IF PARAM1 IS NOT NULL THEN
--******************************************************************************
-- 19.F営業販売部署コード
--******************************************************************************
    IF PARAM2 = 1 THEN
      SELECT COUNT(*)                     -- 件数
        INTO GET_COUNT
        FROM SNV_M_DPT                    -- 組織マスタ
       WHERE EXP_DPT_CD       = PARAM1;   -- 組織マスタ.組織コード(経費負担部課)
--******************************************************************************
-- 20.F営業現在部署コード
-- 21.保守営業担当部署
--******************************************************************************
     ELSIF PARAM2 = 2 THEN
      SELECT COUNT(*)                               -- 件数
        INTO GET_COUNT
        FROM SNV_M_DPT                              -- 組織マスタ
       WHERE EXP_DPT_CD          = PARAM1           -- 組織マスタ.組織コード(経費負担部課)
         AND VALD_STRT_DT       <= SYSDATE          -- 組織マスタ.有効開始日
         AND NVL(VALD_END_DT,SYSDATE)   >= SYSDATE  -- 組織マスタ.有効終了日
         AND NVL(DEL_FLG, 'N')  <> 'X';             -- 組織マスタ.削除フラグ
     END IF;
  END IF;
  
  IF GET_COUNT > 0 THEN
    GET_COUNT := 0;
  ELSE
    GET_COUNT := 1;
  END IF;
  
  RETURN GET_COUNT;
END FUNC_SNV_M_DPT_CHK;

/
