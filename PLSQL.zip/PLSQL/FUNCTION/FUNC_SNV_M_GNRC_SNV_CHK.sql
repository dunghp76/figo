--------------------------------------------------------
--  DDL for Function FUNC_SNV_M_GNRC_SNV_CHK
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "FUNC_SNV_M_GNRC_SNV_CHK" 
(
  PARAM1 IN VARCHAR2,                  -- 汎用マスタ.キー項目
  PARAM2 IN VARCHAR2,                  -- 汎用マスタ.コード値
  PARAM3 IN NUMBER DEFAULT 0           -- パラメータ１（保守種別選択可能フラグ）
) RETURN NUMBER AS 
--******************************************************************************
-- ■マスタ存在チェック
-- 設置機器共通情報の以下の項目が存在する値か否かをチェックする。
-- ※件数が0件の場合は、マスタに存在しない値として、エラーとする。
--******************************************************************************
  GET_COUNT       NUMBER;
BEGIN
  IF PARAM1 IS NOT NULL AND PARAM2 IS NOT NULL THEN
--******************************************************************************
-- 2.本体オプション区分（汎用マスタ（オプション区分））
--******************************************************************************
    IF PARAM1 = 'CSG_CONFIG_TYPE' THEN
        SELECT COUNT(*)                    -- 件数
          INTO GET_COUNT
          FROM SNV_M_GNRC_SNV              -- 汎用マスタ
         WHERE CLSFCTN           = 'M'     -- 汎用マスタ.分類
           AND KEY_ITEM          = PARAM1  -- 汎用マスタ.キー項目
           AND VALD_STRT_DT     <= SYSDATE -- 汎用マスタ.有効開始日
           AND NVL(VALD_END_DT,SYSDATE) >= SYSDATE -- 汎用マスタ.有効終了日
           AND NVL(DEL_FLG,'N') <> 'X'     -- 汎用マスタ.削除フラグ
           AND CD_VAL            = PARAM2; -- 汎用マスタ.コード値
--******************************************************************************
-- 3.IBステータス（汎用マスタ（設置機器ステータス））
--******************************************************************************
    ELSIF PARAM1 = 'CSG_INSTANCE_STATUSES' THEN
        SELECT COUNT(*)                    -- 件数
          INTO GET_COUNT
          FROM SNV_M_GNRC_SNV              -- 汎用マスタ
         WHERE CLSFCTN           = 'M'     -- 汎用マスタ.分類
           AND KEY_ITEM          = PARAM1  -- 汎用マスタ.キー項目
           AND VALD_STRT_DT     <= SYSDATE -- 汎用マスタ.有効開始日
           AND NVL(VALD_END_DT,SYSDATE) >= SYSDATE -- 汎用マスタ.有効終了日
           AND NVL(DEL_FLG,'N') <> 'X'     -- 汎用マスタ.削除フラグ
           AND CD_VAL            = PARAM2; -- 汎用マスタ.コード値
--******************************************************************************
-- 4.販売元（汎用マスタ（設置機器使用会社））
--******************************************************************************
    ELSIF PARAM1 = 'CSG_INSTANCE_USE_COMPANY' AND PARAM3 = 2 THEN
        SELECT COUNT(*)                    -- 件数
          INTO GET_COUNT
          FROM SNV_M_GNRC_SNV              -- 汎用マスタ
         WHERE CLSFCTN           = 'M'     -- 汎用マスタ.分類
           AND KEY_ITEM          = PARAM1  -- 汎用マスタ.キー項目
           AND PARM2             = 'Y'     -- 汎用マスタ.キー項目
           AND VALD_STRT_DT     <= SYSDATE -- 汎用マスタ.有効開始日
           AND NVL(VALD_END_DT,SYSDATE) >= SYSDATE -- 汎用マスタ.有効終了日
           AND NVL(DEL_FLG,'N') <> 'X'     -- 汎用マスタ.削除フラグ
           AND CD_VAL            = PARAM2; -- 汎用マスタ.コード値
--******************************************************************************
-- 5.保守種別（汎用マスタ（設置機器使用会社））
--******************************************************************************
    ELSIF PARAM1 = 'CSG_INSTANCE_USE_COMPANY' AND PARAM3 = 1 THEN
        SELECT COUNT(*)                    -- 件数
          INTO GET_COUNT
          FROM SNV_M_GNRC_SNV              -- 汎用マスタ
         WHERE CLSFCTN           = 'M'     -- 汎用マスタ.分類
           AND KEY_ITEM          = PARAM1  -- 汎用マスタ.キー項目
           AND PARM1             = 'Y'     -- 汎用マスタ.キー項目
           AND VALD_STRT_DT     <= SYSDATE -- 汎用マスタ.有効開始日
           AND NVL(VALD_END_DT,SYSDATE) >= SYSDATE -- 汎用マスタ.有効終了日
           AND NVL(DEL_FLG,'N') <> 'X'     -- 汎用マスタ.削除フラグ
           AND CD_VAL            = PARAM2; -- 汎用マスタ.コード値
--******************************************************************************
-- 6.サービス形態（汎用マスタ-ERP（サービス形態））
--******************************************************************************
    ELSIF PARAM1 = 'ZMMDESERVICE' THEN
        SELECT COUNT(*)                    -- 件数
          INTO GET_COUNT
          FROM SNV_M_GNRC_ERP              -- 汎用マスタ（ERP）
         WHERE CLSFCTN           = 'V'     -- 汎用マスタ.分類
           AND GRP_KEY           = 'IBDATA'-- 汎用マスタ.グループキー
           AND KEY_ITEM          = PARAM1  -- 汎用マスタ.キー項目
           AND VALD_STRT_DT     <= SYSDATE -- 汎用マスタ.有効開始日
           AND NVL(VALD_END_DT,SYSDATE) >= SYSDATE -- 汎用マスタ.有効終了日
           AND NVL(DEL_FLG,'N') <> 'X'     -- 汎用マスタ.削除フラグ
           AND CD_VAL            = PARAM2; -- 汎用マスタ.コード値
--******************************************************************************
-- 7.外注フラグ（汎用マスタ（外注フラグ））
--******************************************************************************
    ELSIF PARAM1 = 'SBCN_FLAG' THEN
        SELECT COUNT(*)                    -- 件数
          INTO GET_COUNT
          FROM SNV_M_GNRC_SNV              -- 汎用マスタ
         WHERE CLSFCTN           = 'M'     -- 汎用マスタ.分類
           AND GRP_KEY           = 'SNV'   -- 汎用マスタ.グループキー
           AND KEY_ITEM          = PARAM1  -- 汎用マスタ.キー項目
           AND VALD_STRT_DT     <= SYSDATE -- 汎用マスタ.有効開始日
           AND NVL(VALD_END_DT,SYSDATE) >= SYSDATE -- 汎用マスタ.有効終了日
           AND NVL(DEL_FLG,'N') <> 'X'     -- 汎用マスタ.削除フラグ
           AND CD_VAL            = PARAM2; -- 汎用マスタ.コード値
--******************************************************************************
-- 8.要サポートフラグ（汎用マスタ（要サポートフラグ））
--******************************************************************************
    ELSIF PARAM1 = 'CSG_SUPPORT_INSTRUCT_CODE' THEN
        SELECT COUNT(*)                    -- 件数
          INTO GET_COUNT
          FROM SNV_M_GNRC_SNV              -- 汎用マスタ
         WHERE CLSFCTN           = 'M'     -- 汎用マスタ.分類
           AND KEY_ITEM          = PARAM1  -- 汎用マスタ.キー項目
           AND VALD_STRT_DT     <= SYSDATE -- 汎用マスタ.有効開始日
           AND NVL(VALD_END_DT,SYSDATE) >= SYSDATE -- 汎用マスタ.有効終了日
           AND NVL(DEL_FLG,'N') <> 'X'     -- 汎用マスタ.削除フラグ
           AND CD_VAL            = PARAM2; -- 汎用マスタ.コード値
--******************************************************************************
-- 10.初回ワランティ条件
--******************************************************************************
    ELSIF PARAM1 = 'ZMMDEFIRST_WT_COND' THEN
        SELECT COUNT(*)                       -- 件数
          INTO GET_COUNT
          FROM SNV_M_GNRC_ERP                 -- 汎用マスタ（ERP）
         WHERE CLSFCTN           = 'V'        -- 汎用マスタ.分類
           AND GRP_KEY           = 'MATERIAL' -- 汎用マスタ.グループキー
           AND KEY_ITEM          = PARAM1     -- 汎用マスタ.キー項目
           AND VALD_STRT_DT     <= SYSDATE    -- 汎用マスタ.有効開始日
           AND NVL(VALD_END_DT,SYSDATE) >= SYSDATE    -- 汎用マスタ.有効終了日
           AND NVL(DEL_FLG,'N') <> 'X'        -- 汎用マスタ.削除フラグ
           AND CD_VAL            = PARAM2;    -- 汎用マスタ.コード値
--******************************************************************************
-- 11.次回ワランティ条件
--******************************************************************************
    --ELSIF PARAM1 = 'ZMMDENEXT_VW_COND' THEN
    ELSIF PARAM1 = 'ZMMDENEXT_WT_COND' THEN
        SELECT COUNT(*)                       -- 件数
          INTO GET_COUNT
          FROM SNV_M_GNRC_ERP                 -- 汎用マスタ（ERP）
         WHERE CLSFCTN           = 'V'        -- 汎用マスタ.分類
           AND GRP_KEY           = 'MATERIAL' -- 汎用マスタ.グループキー
           AND KEY_ITEM          = PARAM1     -- 汎用マスタ.キー項目
           AND VALD_STRT_DT     <= SYSDATE    -- 汎用マスタ.有効開始日
           AND NVL(VALD_END_DT,SYSDATE) >= SYSDATE    -- 汎用マスタ.有効終了日
           AND NVL(DEL_FLG,'N') <> 'X'        -- 汎用マスタ.削除フラグ
           AND CD_VAL            = PARAM2;    -- 汎用マスタ.コード値
--******************************************************************************
-- 12.ワランティ開始日基準
--******************************************************************************
    ELSIF PARAM1 = 'ZMMDEWT_STDATE_CRIT' THEN
        SELECT COUNT(*)                       -- 件数
          INTO GET_COUNT
          FROM SNV_M_GNRC_ERP                 -- 汎用マスタ（ERP）
         WHERE CLSFCTN           = 'V'        -- 汎用マスタ.分類
           AND GRP_KEY           = 'MATERIAL' -- 汎用マスタ.グループキー
           AND KEY_ITEM          = PARAM1     -- 汎用マスタ.キー項目
           AND VALD_STRT_DT     <= SYSDATE    -- 汎用マスタ.有効開始日
           AND NVL(VALD_END_DT,SYSDATE) >= SYSDATE    -- 汎用マスタ.有効終了日
           AND NVL(DEL_FLG,'N') <> 'X'        -- 汎用マスタ.削除フラグ
           AND CD_VAL            = PARAM2;    -- 汎用マスタ.コード値
--******************************************************************************
-- 14.販社フラグ（汎用マスタ（設置機器使用会社））
--******************************************************************************
    ELSIF PARAM1 = 'CSG_INSTANCE_USE_COMPANY' AND PARAM3 = 3 THEN
        SELECT COUNT(*)                    -- 件数
          INTO GET_COUNT
          FROM SNV_M_GNRC_SNV              -- 汎用マスタ
         WHERE CLSFCTN           = 'M'     -- 汎用マスタ.分類
           AND KEY_ITEM          = PARAM1  -- 汎用マスタ.キー項目
           AND PARM3             = 'Y'     -- 汎用マスタ.パラメータ３（販社フラグ選択可能フラグ）
           AND VALD_STRT_DT     <= SYSDATE -- 汎用マスタ.有効開始日
           AND NVL(VALD_END_DT,SYSDATE) >= SYSDATE -- 汎用マスタ.有効終了日
           AND NVL(DEL_FLG,'N') <> 'X'     -- 汎用マスタ.削除フラグ
           AND CD_VAL            = PARAM2; -- 汎用マスタ.コード値
--******************************************************************************
-- 16.OS種別
--******************************************************************************
    ELSIF PARAM1 = 'CSG_OS_TYPE' THEN
        SELECT COUNT(*)                    -- 件数
          INTO GET_COUNT
          FROM SNV_M_GNRC_SNV              -- 汎用マスタ
         WHERE CLSFCTN           = 'M'     -- 汎用マスタ.分類
           AND KEY_ITEM          = PARAM1  -- 汎用マスタ.キー項目
           AND VALD_STRT_DT     <= SYSDATE -- 汎用マスタ.有効開始日
           AND NVL(VALD_END_DT,SYSDATE) >= SYSDATE -- 汎用マスタ.有効終了日
           AND NVL(DEL_FLG,'N') <> 'X'     -- 汎用マスタ.削除フラグ
           AND CD_VAL            = PARAM2; -- 汎用マスタ.コード値
--******************************************************************************
-- 17.電源設備種類
--******************************************************************************
    ELSIF PARAM1 = 'CSG_POWER_SUPPLY_TYPE' THEN
        SELECT COUNT(*)                    -- 件数
          INTO GET_COUNT
          FROM SNV_M_GNRC_SNV              -- 汎用マスタ
         WHERE CLSFCTN           = 'M'     -- 汎用マスタ.分類
           AND KEY_ITEM          = PARAM1  -- 汎用マスタ.キー項目
           AND VALD_STRT_DT     <= SYSDATE -- 汎用マスタ.有効開始日
           AND NVL(VALD_END_DT,SYSDATE) >= SYSDATE -- 汎用マスタ.有効終了日
           AND NVL(DEL_FLG,'N') <> 'X'     -- 汎用マスタ.削除フラグ
           AND CD_VAL            = PARAM2; -- 汎用マスタ.コード値
--******************************************************************************
-- 18.使用電源周波数
--******************************************************************************
    ELSIF PARAM1 = 'CSG_USE_POWER_FREQUENCY' THEN
        SELECT COUNT(*)                    -- 件数
          INTO GET_COUNT
          FROM SNV_M_GNRC_SNV              -- 汎用マスタ
         WHERE CLSFCTN           = 'M'     -- 汎用マスタ.分類
           AND KEY_ITEM          = PARAM1  -- 汎用マスタ.キー項目
           AND VALD_STRT_DT     <= SYSDATE -- 汎用マスタ.有効開始日
           AND NVL(VALD_END_DT,SYSDATE) >= SYSDATE -- 汎用マスタ.有効終了日
           AND NVL(DEL_FLG,'N') <> 'X'     -- 汎用マスタ.削除フラグ
           AND CD_VAL            = PARAM2; -- 汎用マスタ.コード値
--******************************************************************************
-- 5.重要度（汎用マスタ（重要度））
--******************************************************************************
    ELSIF PARAM1 = 'CSG_IMPORTANCE_LEVEL' THEN
        SELECT COUNT(*)                    -- 件数
          INTO GET_COUNT
          FROM SNV_M_GNRC_SNV              -- 汎用マスタ
         WHERE CLSFCTN           = 'M'     -- 汎用マスタ.分類
           AND KEY_ITEM          = PARAM1  -- 汎用マスタ.キー項目
           AND VALD_STRT_DT     <= SYSDATE -- 汎用マスタ.有効開始日
           AND NVL(VALD_END_DT,SYSDATE) >= SYSDATE -- 汎用マスタ.有効終了日
           AND NVL(DEL_FLG,'N') <> 'X'     -- 汎用マスタ.削除フラグ
           AND CD_VAL            = PARAM2; -- 汎用マスタ.コード値
--******************************************************************************
-- 1.メモタイプ（汎用マスタ（メモタイプ））
--******************************************************************************
    ELSIF PARAM1 = 'CSG_MEMO_TYPE' THEN
        SELECT COUNT(*)                    -- 件数
          INTO GET_COUNT
          FROM SNV_M_GNRC_SNV              -- 汎用マスタ
         WHERE CLSFCTN           = 'M'     -- 汎用マスタ.分類
           AND KEY_ITEM          = PARAM1  -- 汎用マスタ.キー項目
           AND VALD_STRT_DT     <= SYSDATE -- 汎用マスタ.有効開始日
           AND NVL(VALD_END_DT,SYSDATE) >= SYSDATE -- 汎用マスタ.有効終了日
           AND NVL(DEL_FLG,'N') <> 'X'     -- 汎用マスタ.削除フラグ
           AND CD_VAL            = PARAM2; -- 汎用マスタ.コード値
    END IF;
  END IF;
  
  IF GET_COUNT > 0 THEN
    GET_COUNT := 0;
  ELSE
    GET_COUNT := 1;
  END IF;
  
  RETURN GET_COUNT;
END FUNC_SNV_M_GNRC_SNV_CHK;

/
