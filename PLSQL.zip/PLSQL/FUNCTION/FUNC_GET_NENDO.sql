--------------------------------------------------------
--  DDL for Function FUNC_GET_NENDO
--------------------------------------------------------

CREATE OR REPLACE EDITIONABLE FUNCTION "FUNC_GET_NENDO"(
      PARAM1 IN DATE )
return NUMBER is 
	countValue NUMBER;
	thisYear   NUMBER;
	tempStr	   varchar2(16);
	currDate   NUMBER;
	fromDate   NUMBER;
BEGIN
	/* 現在の年度を得る */
	select to_char(PARAM1,'YYYYMMDD') into tempStr from dual;

	fromDate := to_number(substr(tempStr,1,4) || '0401');
        currDate := to_number( tempStr );

        thisYear := to_number( substr(tempStr,1,4) );

	if fromDate <= currDate Then
		return thisYear;
	Else
		return thisYear - 1;
	End If;
END;