--------------------------------------------------------
--  DDL for Function FUNC_SNV_M_EMP_CHK
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "FUNC_SNV_M_EMP_CHK"
(
  PARAM1 IN VARCHAR2,                     -- 従業員マスタ.従業員コード
  PARAM2 IN NUMBER DEFAULT 0
) RETURN NUMBER AS
--******************************************************************************
-- ■マスタ存在チェック
-- 設置機器共通情報の以下の項目が存在する値か否かをチェックする。
-- ※件数が0件の場合は、マスタに存在しない値として、エラーとする。
--******************************************************************************
  GET_COUNT       NUMBER;
BEGIN
  IF PARAM1 IS NOT NULL THEN
--******************************************************************************
-- 22.F営業販売担当者コード
--******************************************************************************
    IF PARAM2 = 1 THEN
      SELECT COUNT(*)                     -- 件数
        INTO GET_COUNT
        FROM SNV_M_EMP                    -- 従業員マスタ
       WHERE EMP_CD       = PARAM1;       -- 従業員マスタ.従業員CD
--******************************************************************************
-- 23.F営業現在担当者コード
-- 24.保守営業担当者コード
--******************************************************************************
     ELSIF PARAM2 = 2 THEN
      SELECT COUNT(*)                  -- 件数
        INTO GET_COUNT
        FROM SNV_M_EMP                 -- 従業員マスタ
       WHERE EMP_CD         = PARAM1   -- 従業員マスタ.従業員CD
         AND VALD_STRT_DT  <= SYSDATE  -- 従業員マスタ.有効開始日
         AND NVL(VALD_END_DT,SYSDATE) >= SYSDATE; -- 従業員マスタ.有効終了日
--******************************************************************************
-- 2.担当CEコード
--******************************************************************************
     ELSIF PARAM2 = 3 THEN
      SELECT COUNT(*)                  -- 件数
        INTO GET_COUNT
        FROM SNV_M_EMP                 -- 従業員マスタ
       WHERE EMP_CD         = PARAM1   -- 従業員マスタ.従業員CD
         AND VALD_STRT_DT  <= SYSDATE  -- 従業員マスタ.有効開始日
         AND NVL(VALD_END_DT,SYSDATE) >= SYSDATE; -- 従業員マスタ.有効終了日
     END IF;
  END IF;

  IF GET_COUNT > 0 THEN
    GET_COUNT := 0;
  ELSE
    GET_COUNT := 1;
  END IF;

  RETURN GET_COUNT;
END FUNC_SNV_M_EMP_CHK;

/
