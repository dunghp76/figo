--------------------------------------------------------
--  DDL for Function FUNC_NVAR_LENGTH_CHK
--------------------------------------------------------
create or replace FUNCTION          "FUNC_NVAR_LENGTH_CHK" (
      PARAM1 IN VARCHAR2,
      LEN    IN NUMBER )
    RETURN NUMBER
  AS
   maxLSen                 NUMBER(15) := LEN*2/3;
   maxByte                 NUMBER(4) := 4000;
  BEGIN
	IF LEN < LENGTH(PARAM1) THEN
		RETURN 1;
    ELSE
      IF LEN > maxLSen AND maxByte < LENGTHB(PARAM1) THEN
         RETURN 1;
      ELSE
         RETURN 0;
      END IF;
  	END IF;
    RETURN 1;
  END FUNC_NVAR_LENGTH_CHK;