--------------------------------------------------------
--  DDL for Function FUNC_CSL_M_DEPO_CHK
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "FUNC_CSL_M_DEPO_CHK" 
(
  PARAM1 IN VARCHAR2  
) RETURN NUMBER AS 
--******************************************************************************
-- ■マスタ存在チェック
-- 設置機器共通情報の以下の項目が存在する値か否かをチェックする。
-- ※件数が0件の場合は、マスタに存在しない値として、エラーとする。
--******************************************************************************
  GET_COUNT       NUMBER;
BEGIN
--******************************************************************************
-- 13.委託先コード
--******************************************************************************
  IF PARAM1 IS NOT NULL THEN
    SELECT COUNT(*)                  -- 件数
      INTO GET_COUNT
      FROM CSL_M_DEPO                -- 保管場所マスタ
     WHERE DEPO_SUM_TYPE   = '30'    -- 保管場所マスタ.保管場所集計区分 "30"(委託先)
       AND INVALID_FLAG    = '0'     -- 保管場所マスタ.無効フラグ "0"(有効)
       AND DEPO_CD         = PARAM1; -- 保管場所マスタ.保管場所コード
  END IF;
  
  IF GET_COUNT > 0 THEN
    GET_COUNT := 0;
  ELSE
    GET_COUNT := 1;
  END IF;
 
  RETURN GET_COUNT;
END FUNC_CSL_M_DEPO_CHK;

/
