--------------------------------------------------------
--  DDL for Function FUNC_EXTERNALCHAR_CHK
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "FUNC_EXTERNALCHAR_CHK" (
    P_TargerStr  IN VARCHAR2
  )
    RETURN NUMBER
  AS
    --変数
    targetLen    PLS_INTEGER := 0;    --チェック対象文字列の文字数
    i            PLS_INTEGER := 0;    --loop用変数
    cmpRet       PLS_INTEGER;        --1文字チェック結果
    cmpSJIS      PLS_INTEGER;        --1文字SJISコード（10進数）
    
    --定数
    isValid      PLS_INTEGER := 0;    --有効文字列
    isInvalid    PLS_INTEGER := 1;    --無効文字列
  BEGIN
    
    if P_TargerStr is NULL then
    --チェック対象文字列がセットされていない場合
        --処理中断：戻り値=isValid
        return isValid;
    end if;
    
    --チェック対象文字列の文字数：LENGTH関数でセット
    targetLen := LENGTH(P_TargerStr);

    for i in 1..targetLen loop
        --1文字ずつSJISコード（10進数）取得
        cmpSJIS := ASCII(SUBSTR(P_TargerStr,i,1));

        --SJISコード（10進数）のチェック※判断文字コードを10進数に変換してチェック
        case
            when cmpSJIS between TO_NUMBER('21','XXXX') and TO_NUMBER('DF','XXXX') then
            --半角文字（JIS X 0201）/Shift_JIS：21～DF
                case
                    when cmpSJIS between TO_NUMBER('21','XXXX') and TO_NUMBER('7E','XXXX') then
                    --記号・数字・英字：21～7E
                        cmpRet := isValid;
                    when cmpSJIS between TO_NUMBER('A1','XXXX') and TO_NUMBER('DF','XXXX') then
                    --カナ：A1～DF
                        cmpRet := isValid;
                    else
                        cmpRet := isInvalid;
                end case;
            when cmpSJIS between TO_NUMBER('8140','XXXX') and TO_NUMBER('9872','XXXX') then
            --第一水準文字（JIS X 0208:1997）01区～47区/Shift_JIS：8140～9872
                case
                    when cmpSJIS between TO_NUMBER('8140','XXXX') and TO_NUMBER('81FC','XXXX') then
                    --記号/Shift_JIS：0x8140～81FC
                        cmpRet := isValid;
                    when cmpSJIS between TO_NUMBER('824F','XXXX') and TO_NUMBER('829A','XXXX') then
                    --英数字/Shift_JIS：0x824F～829A
                        cmpRet := isValid;
                    when cmpSJIS between TO_NUMBER('829F','XXXX') and TO_NUMBER('8396','XXXX') then
                    --かな/Shift_JIS：0x829F～8396
                        cmpRet := isValid;
                    when cmpSJIS between TO_NUMBER('839F','XXXX') and TO_NUMBER('83D6','XXXX') then
                    --ギリシャ文字/Shift_JIS：0x839F～83D6
                        cmpRet := isInvalid;
                    when cmpSJIS between TO_NUMBER('8440','XXXX') and TO_NUMBER('8491','XXXX') then
                    --ロシア文字/Shift_JIS：0x8440～8491
                        cmpRet := isInvalid;
                    when cmpSJIS between TO_NUMBER('849F','XXXX') and TO_NUMBER('84BE','XXXX') then
                    --罫線素片/Shift_JIS：0x849F～84BE
                        cmpRet := isInvalid;
                    when cmpSJIS between TO_NUMBER('8740','XXXX') and TO_NUMBER('879F','XXXX') then
                    --機種依存文字/Shift_JIS：0x8740～879D
                        cmpRet := isInvalid;
                    when cmpSJIS between TO_NUMBER('889F','XXXX') and TO_NUMBER('9872','XXXX') then
                    --漢字/Shift_JIS：0x889F～9872
                        cmpRet := isValid;
                    else
                        cmpRet := isInvalid;
                end case;
            when cmpSJIS between TO_NUMBER('989F','XXXX') and TO_NUMBER('EAA4','XXXX') then
            --第二水準文字（JIS X 0208:1997）48区～84区/Shift_JIS：989F～EAA4
                cmpRet := isInvalid;
            when cmpSJIS between TO_NUMBER('ED40','XXXX') and TO_NUMBER('EEFC','XXXX') then
            --NEC拡張　89区～92区/Shift_JIS：ED40～EEFC
                cmpRet := isInvalid;
            when cmpSJIS between TO_NUMBER('F040','XXXX') and TO_NUMBER('F9FC','XXXX') then
            --外字    95区～114区/Shift_JIS：F040～F9FC
                cmpRet := isInvalid;
            when cmpSJIS between TO_NUMBER('FA40','XXXX') and TO_NUMBER('FC4B','XXXX') then
            --IBM拡張　115区～119区/Shift_JIS：FA40～FC4B
                cmpRet := isInvalid;
            else
                cmpRet := isInvalid;
        end case;
        
        if cmpRet = isInvalid then
        --規定の文字以外が使用されている場合
            --処理中断：戻り値=isInvalid
            RETURN isInvalid;
        end if;
    end loop;
    
    --全て有効文字のみ：戻り値=isValid
    RETURN isValid;

--エラー処理
  EXCEPTION
    WHEN OTHERS THEN
        RETURN NULL;
  END;