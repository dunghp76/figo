--------------------------------------------------------
--  DDL for Function FUNC_CSG_M_GROUP_MANA_CHK
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "FUNC_CSG_M_GROUP_MANA_CHK" 
(
  PARAM1 IN VARCHAR2                -- グループ管理.グループID
) RETURN NUMBER AS 
--******************************************************************************
-- ■マスタ存在チェック
-- 設置機器共通情報の以下の項目が存在する値か否かをチェックする。
-- ※件数が0件の場合は、マスタに存在しない値として、エラーとする。
--******************************************************************************
  GET_COUNT       NUMBER;
BEGIN
--******************************************************************************
-- 1.担当CSコードの存在チェック（グループマスタ）
--******************************************************************************
  IF PARAM1 IS NOT NULL THEN
    SELECT COUNT(*)                            -- 件数
      INTO GET_COUNT
      FROM CSG_M_GROUP_MANAGEMENT              -- グループ管理
     WHERE GROUP_ID    = PARAM1                -- グループ管理.グループID
       AND START_DATE <= SYSDATE               -- グループ管理.開始日
       AND NVL(END_DATE,SYSDATE)   >= SYSDATE; -- グループ管理.終了日
  END IF;
  
  IF GET_COUNT > 0 THEN
    GET_COUNT := 0;
  ELSE
    GET_COUNT := 1;
  END IF;
 
  RETURN GET_COUNT;
END FUNC_CSG_M_GROUP_MANA_CHK;

/
