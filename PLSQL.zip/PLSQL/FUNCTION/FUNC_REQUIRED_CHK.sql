--------------------------------------------------------
--  DDL for Function FUNC_REQUIRED_CHK
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "FUNC_REQUIRED_CHK" (
      PARAM1 IN VARCHAR2 )
    RETURN NUMBER
  AS
  BEGIN
    IF PARAM1 IS NULL THEN
      RETURN 1;
    END IF;
    RETURN 0;
  END FUNC_REQUIRED_CHK;
