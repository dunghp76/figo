--------------------------------------------------------
--  DDL for Function GET_FILE_NAME
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "GET_FILE_NAME" (
      P_FULL_PATH IN VARCHAR2,
      P_DIR_PATH  IN VARCHAR2)
    RETURN VARCHAR2
  IS
    v_file_name VARCHAR2(1500);
  BEGIN
    -- Parse string for full path
    IF INSTR(P_FULL_PATH, P_DIR_PATH) > 0 THEN
      V_FILE_NAME                    := SUBSTR(P_FULL_PATH, LENGTH(P_DIR_PATH) + 2, 100);
      -- If no slashes were found, return the empty string
    ELSE
      v_file_name := '';
    END IF;
    RETURN v_file_name;
  END;

/
