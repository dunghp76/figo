--------------------------------------------------------
--  DDL for Function FUNC_EXTERNALCHAR_REP
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "FUNC_EXTERNALCHAR_REP" (
  PARAM1 IN CLOB)
 RETURN CLOB
AS 
  v_setText CLOB;
  v_returnText CLOB;
BEGIN
  v_setText := REPLACE(PARAM1, '№', 'No.');
  v_setText := REPLACE(v_setText, '㏍', 'K.K.');
  v_setText := REPLACE(v_setText, '℡', 'TEL');
  v_setText := REPLACE(v_setText, '㈱', '(株)');
  v_setText := REPLACE(v_setText, '㈲', '(有)');
  v_setText := REPLACE(v_setText, '㈹', '(代)');
  v_setText := REPLACE(v_setText, '㍾', '明治');
  v_setText := REPLACE(v_setText, '㍽', '大正');
  v_setText := REPLACE(v_setText, '㍼', '昭和');
  v_setText := REPLACE(v_setText, '㍻', '平成');
  v_setText := REPLACE(v_setText, '①', '(1)');
  v_setText := REPLACE(v_setText, '②', '(2)');
  v_setText := REPLACE(v_setText, '③', '(3)');
  v_setText := REPLACE(v_setText, '④', '(4)');
  v_setText := REPLACE(v_setText, '⑤', '(5)');
  v_setText := REPLACE(v_setText, '⑥', '(6)');
  v_setText := REPLACE(v_setText, '⑦', '(7)');
  v_setText := REPLACE(v_setText, '⑧', '(8)');
  v_setText := REPLACE(v_setText, '⑨', '(9)');
  v_setText := REPLACE(v_setText, '⑩', '(10)');
  v_setText := REPLACE(v_setText, '⑪', '(11)');
  v_setText := REPLACE(v_setText, '⑫', '(12)');
  v_setText := REPLACE(v_setText, '⑬', '(13)');
  v_setText := REPLACE(v_setText, '⑭', '(14)');
  v_setText := REPLACE(v_setText, '⑮', '(15)');
  v_setText := REPLACE(v_setText, '⑯', '(16)');
  v_setText := REPLACE(v_setText, '⑰', '(17)');
  v_setText := REPLACE(v_setText, '⑱', '(18)');
  v_setText := REPLACE(v_setText, '⑲', '(19)');
  v_setText := REPLACE(v_setText, '⑳', '(20)');
  v_setText := REPLACE(v_setText, 'Ⅰ', 'I');
  v_setText := REPLACE(v_setText, 'Ⅱ', 'II');
  v_setText := REPLACE(v_setText, 'Ⅲ', 'III');
  v_setText := REPLACE(v_setText, 'Ⅳ', 'IV');
  v_setText := REPLACE(v_setText, 'Ⅴ', 'V');
  v_setText := REPLACE(v_setText, 'Ⅵ', 'VI');
  v_setText := REPLACE(v_setText, 'Ⅶ', 'VII');
  v_setText := REPLACE(v_setText, 'Ⅷ', 'VIII');
  v_setText := REPLACE(v_setText, 'Ⅸ', 'IX');
  v_setText := REPLACE(v_setText, 'Ⅹ', 'X');
  v_setText := REPLACE(v_setText, '髙', '高');
  v_setText := REPLACE(v_setText, '﨑', '崎');
  v_setText := REPLACE(v_setText, '濵', '浜');
  v_returnText := v_setText;
	RETURN v_returnText;
END FUNC_EXTERNALCHAR_REP;

/
