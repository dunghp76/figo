--------------------------------------------------------
--  DDL for Function FUNC_CSG_M_IB_ADDRESS_CHK
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "FUNC_CSG_M_IB_ADDRESS_CHK" 
(
  PARAM1 IN VARCHAR2  
) RETURN NUMBER AS 
--******************************************************************************
-- ■マスタ存在チェック
-- 設置機器共通情報の以下の項目が存在する値か否かをチェックする。
-- ※件数が0件の場合は、マスタに存在しない値として、エラーとする。
--******************************************************************************
  GET_COUNT       NUMBER;
BEGIN
--******************************************************************************
-- 4.設置先顧客住所コード
--******************************************************************************
  IF PARAM1 IS NOT NULL THEN
    SELECT COUNT(*)                         -- 件数
      INTO GET_COUNT
      FROM CSG_M_IB_ADDRESS                 -- 設置先住所マスタ
     WHERE INSTALL_LOCATION_CODE   = PARAM1 -- 設置先住所マスタ.設置先住所コード
       AND NVL(ACTIVE_FLAG,'Y')   <> 'N';   -- 設置先住所マスタ.有効フラグ
  END IF;
  
  IF GET_COUNT > 0 THEN
    GET_COUNT := 0;
  ELSE
    GET_COUNT := 1;
  END IF;
 
  RETURN GET_COUNT;
END FUNC_CSG_M_IB_ADDRESS_CHK;

/
