--------------------------------------------------------
--  DDL for Function FUNC_SNV_M_ITEM_CHK
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "FUNC_SNV_M_ITEM_CHK" 
(
  PARAM1 IN VARCHAR2  -- 設置機器情報の品目コード
, PARAM2 IN VARCHAR2  -- 設置機器情報のプラント
) RETURN NUMBER AS 
--******************************************************************************
-- ■マスタ存在チェック
-- 設置機器共通情報の以下の項目が存在する値か否かをチェックする。
-- ※件数が0件の場合は、マスタに存在しない値として、エラーとする。
--******************************************************************************
  GET_COUNT       NUMBER;
BEGIN
--******************************************************************************
-- 1.品目コードの存在チェック（品目マスタ）
-- 15.バンドル品目コード
-- 1.品目コードの存在チェック（品目マスタ）
--******************************************************************************
  IF PARAM1 IS NOT NULL AND PARAM2 IS NOT NULL THEN
    SELECT COUNT(*)                     -- 件数
      INTO GET_COUNT
      FROM SNV_M_ITEM                   -- 品目マスタ
     WHERE ITEM_CD           = PARAM1   -- 品目マスタ.品目コード
       AND PLT               = PARAM2   -- 品目マスタ.プラント
       AND NVL(DEL_FLG,'N') <> 'X';     -- 品目マスタ.削除フラグ
  END IF;
  
  IF GET_COUNT > 0 THEN
    GET_COUNT := 0;
  ELSE
    GET_COUNT := 1;
  END IF;
  
  RETURN GET_COUNT;
END FUNC_SNV_M_ITEM_CHK;

/
