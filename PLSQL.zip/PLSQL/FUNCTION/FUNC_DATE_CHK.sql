--------------------------------------------------------
--  DDL for Function FUNC_DATE_CHK
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "FUNC_DATE_CHK" (
      PARAM1 IN VARCHAR2 )
    RETURN NUMBER
  AS
    vDATE_FORMAT VARCHAR (40) NOT NULL := 'YYYY/MM/DD HH24:MI:SS';
    vDATE        DATE;
  BEGIN
    vDATE := TO_DATE(PARAM1, vDATE_FORMAT, q'{NLS_CALENDAR = 'GREGORIAN'}' );
    RETURN 0;
  EXCEPTION
  WHEN OTHERS THEN
    RETURN 1;
  END FUNC_DATE_CHK;
