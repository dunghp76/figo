--------------------------------------------------------
--  DDL for Sequence ERROR_LOG_ID
--------------------------------------------------------

   CREATE SEQUENCE  "ADMIN"."ERROR_LOG_ID"  MINVALUE 1 MAXVALUE 99999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE  NOPARTITION ;
