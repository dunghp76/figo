--------------------------------------------------------
--  DDL for Type ARRAY_IB_PARTS
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TYPE "ADMIN"."ARRAY_IB_PARTS" 
AS
  TABLE OF CONTACT_IB_PARTS_OBJ;

/
