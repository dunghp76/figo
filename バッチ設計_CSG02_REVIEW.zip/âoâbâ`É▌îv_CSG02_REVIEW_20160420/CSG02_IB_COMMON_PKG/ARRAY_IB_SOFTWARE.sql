--------------------------------------------------------
--  DDL for Type ARRAY_IB_SOFTWARE
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TYPE "ADMIN"."ARRAY_IB_SOFTWARE" 
AS
  TABLE OF CONTACT_IB_SOFTWARE_OBJ;

/
