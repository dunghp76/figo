--------------------------------------------------------
--  DDL for Type ARRAY_IB_BASE
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TYPE "ADMIN"."ARRAY_IB_BASE" 
AS
  TABLE OF CONTACT_IB_BASE_OBJ;

/
