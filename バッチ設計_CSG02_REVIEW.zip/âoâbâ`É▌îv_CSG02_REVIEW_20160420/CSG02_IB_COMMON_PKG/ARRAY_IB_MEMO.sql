--------------------------------------------------------
--  DDL for Type ARRAY_IB_MEMO
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TYPE "ADMIN"."ARRAY_IB_MEMO" 
AS
  TABLE OF CONTACT_IB_MEMO_OBJ;

/
