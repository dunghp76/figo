--------------------------------------------------------
--  DDL for Type CONTACT_IB_PARTS_OBJ
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TYPE "ADMIN"."CONTACT_IB_PARTS_OBJ" 
AS
  OBJECT
  (
    COLUM_NAME VARCHAR2(30) ,
    SET_VALUE  VARCHAR2(2000) )

/
