--------------------------------------------------------
--  DDL for Type ARRAY_IB_COMMON
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TYPE "ADMIN"."ARRAY_IB_COMMON" 
AS
  TABLE OF CONTACT_IB_COMMON_OBJ;

/
