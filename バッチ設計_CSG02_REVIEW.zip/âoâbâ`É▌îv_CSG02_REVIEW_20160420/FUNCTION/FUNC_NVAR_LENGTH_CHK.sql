--------------------------------------------------------
--  DDL for Function FUNC_NVAR_LENGTH_CHK
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "ADMIN"."FUNC_NVAR_LENGTH_CHK" (
      PARAM1 IN VARCHAR2,
      LEN    IN NUMBER )
    RETURN NUMBER
  AS
   maxLSen                 NUMBER(15) := LEN*2/3;
  BEGIN
  	IF LEN > maxLSen THEN
		RETURN 1;
  	ELSE
		IF LEN < LENGTH(PARAM1) THEN
			RETURN 1;
	    ELSE
	      RETURN 0;
	    END IF;
  	END IF;	    
  RETURN 1;
  END FUNC_NVAR_LENGTH_CHK;

/
