--------------------------------------------------------
--  DDL for Function GET_DIR_PATH
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "ADMIN"."GET_DIR_PATH" (
      p_path IN VARCHAR2)
    RETURN VARCHAR2
  IS
    v_dir VARCHAR2(1500);
  BEGIN
    -- Parse string for UNIX system
    IF INSTR(p_path,'/') > 0 THEN
      v_dir             := SUBSTR(p_path,1,(INSTR(p_path,'/',-1,1)-1));
      -- Parse string for Windows system
    ELSIF INSTR(p_path,'\') > 0 THEN
      v_dir                := SUBSTR(p_path,1,(INSTR(p_path,'\',-1,1)-1));
      -- If no slashes were found, return the original string
    ELSE
      v_dir := p_path;
    END IF;
    RETURN v_dir;
  END;

/
