--------------------------------------------------------
--  DDL for Sequence CS_TERITORY_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "ADMIN"."CS_TERITORY_ID_SEQ"  MINVALUE 1 MAXVALUE 99999999999999 INCREMENT BY 1 START WITH 21 CACHE 20 NOORDER  NOCYCLE  NOPARTITION ;
