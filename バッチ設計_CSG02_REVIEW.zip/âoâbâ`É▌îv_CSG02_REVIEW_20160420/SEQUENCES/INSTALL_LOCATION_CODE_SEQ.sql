--------------------------------------------------------
--  DDL for Sequence INSTALL_LOCATION_CODE_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "ADMIN"."INSTALL_LOCATION_CODE_SEQ"  MINVALUE 1 MAXVALUE 99999999999999 INCREMENT BY 1 START WITH 41 CACHE 20 NOORDER  NOCYCLE  NOPARTITION ;
